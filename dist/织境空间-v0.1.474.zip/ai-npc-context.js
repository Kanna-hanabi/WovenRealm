/* ============================================================
 * AIStoryGen NPC context provider
 * Builds read-only NPC presence, relationship, and soft schedule
 * hints for story prompts. Native page/state always wins.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 2;

  function text(value, maxLen) {
    var out = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    if (maxLen && out.length > maxLen) out = out.slice(0, maxLen).trim();
    return out;
  }

  function cloneValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function numberOrNull(value) {
    var n = Number(value);
    return isFinite(n) ? n : null;
  }

  function compactHay(fields) {
    return (fields || []).map(function (v) { return text(v, 240).toLowerCase(); }).join(' ');
  }

  function hasAny(hay, words) {
    hay = text(hay).toLowerCase();
    words = words || [];
    for (var i = 0; i < words.length; i++) {
      var word = text(words[i]).toLowerCase();
      if (word && hay.indexOf(word) >= 0) return true;
    }
    return false;
  }

  var NPC_AFFINITY = {
    Robin: {
      home: ['home', 'orphanage', 'bedroom', 'loft', 'ward', '孤儿院', '卧室'],
      schedule: 'Robin is usually tied to the orphanage/home context and care routines.',
      caution: 'Do not make Robin present outside home/orphanage/supported pages unless native page text says Robin is present.'
    },
    Bailey: {
      home: ['orphanage', 'home', 'bailey', 'rent', '孤儿院', '贝利', '租金'],
      schedule: 'Bailey is tied to orphanage management, rent, discipline, and debt pressure.',
      caution: 'Rent/debt reminders do not prove Bailey is physically present.'
    },
    Sydney: {
      home: ['temple', 'school', 'library', '神殿', '学校', '图书馆'],
      schedule: 'Sydney is most often grounded by temple, school, faith, purity, and corruption contexts.',
      caution: 'Use the canonical name 悉尼. Do not summon Sydney from temple/school background alone.'
    },
    Kylar: {
      home: ['school', 'manor', 'kylar_manor', 'library', '凯拉尔', '宅邸'],
      schedule: 'Kylar is most often grounded by school, library, manor, obsession, and watching contexts.',
      caution: 'Use the canonical name 凯拉尔. Do not confuse Kylar with Jordan/乔丹/约旦.'
    },
    Eden: {
      home: ['forest_cabin', 'eden', 'cabin', 'forest', '伊甸', '森林小屋'],
      schedule: 'Eden is grounded by the forest cabin, hunting, care, caution, and quiet companionship.',
      caution: 'Do not make Eden present away from the forest cabin unless native state or current page supports it.'
    },
    Whitney: {
      home: ['school', 'hallway', 'schoolyard', '学校', '走廊'],
      schedule: 'Whitney is grounded by school, peer pressure, bullying, and dominance contexts.',
      caution: 'School background alone does not prove Whitney is present.'
    },
    Avery: {
      home: ['hotel', 'town', 'avery', 'car', '酒馆', '酒店', '城镇'],
      schedule: 'Avery is grounded by wealth, cars, dates, hotels, and upper-class social pressure.',
      caution: 'Do not make Avery present from hotel/town background alone.'
    },
    Alex: {
      home: ['farm', 'alex', 'kennel', 'field', '农场'],
      schedule: 'Alex is grounded by farm work, animals, crops, and trust-building routines.',
      caution: 'Farm context is relevant to Alex, but page text still decides presence.'
    },
    Jordan: {
      home: ['temple', 'jordan', '神殿'],
      schedule: 'Jordan is grounded by temple authority and religious routines.',
      caution: 'Do not confuse Jordan with Kylar. Chinese display should follow the game localization.'
    },
    Leighton: {
      home: ['school', 'head', 'office', 'principal', '学校', '校长室'],
      schedule: 'Leighton is grounded by school authority, discipline, and office contexts.',
      caution: 'School management text does not prove Leighton is in the room.'
    },
    Briar: {
      home: ['brothel', 'briar', '妓院'],
      schedule: 'Briar is grounded by brothel management and work/service contexts.',
      caution: 'Brothel menus and prices do not prove Briar is personally present.'
    },
    Mason: {
      home: ['school', 'class', 'gym', '体育', '课堂'],
      schedule: 'Mason is grounded by school lessons, physical education, and teacher contexts.',
      caution: 'Use current page and class state before narrating Mason directly.'
    },
    Harper: {
      home: ['hospital', 'doctor', 'clinic', '医院', '医生'],
      schedule: 'Harper is grounded by hospital, appointments, treatment, and observation contexts.',
      caution: 'Medical UI or an appointment reminder does not prove Harper is currently present.'
    },
    Doren: {
      home: ['museum', 'history', 'study', '博物馆', '历史'],
      schedule: 'Doren is grounded by history, research, museums, and academic clues.',
      caution: 'Museum context alone does not prove Doren is present.'
    },
    Morgan: {
      home: ['sewers', 'underground', 'morgan', '下水道', '地下'],
      schedule: 'Morgan is grounded by sewers, hidden routes, and underground spaces.',
      caution: 'Do not add Morgan unless the page text, NPC state, or visible event supports it.'
    },
    'Great Hawk': {
      home: ['bird tower', 'tower', 'hawk', 'eagle', '鸟塔', '鹰'],
      schedule: 'Great Hawk is grounded by high places, Bird Tower, wind, carrying objects, and nest-like spaces.',
      caution: 'Do not add extra animals or pets beyond the current page/story facts.'
    }
  };

  function relationLevel(value, field) {
    var n = numberOrNull(value);
    if (n == null) return '';
    if (field === 'rage') {
      if (n >= 70) return 'high anger';
      if (n >= 35) return 'irritated';
      if (n > 0) return 'mild irritation';
      return 'calm';
    }
    if (field === 'dom') {
      if (n >= 70) return 'strongly dominant';
      if (n >= 35) return 'assertive';
      if (n > 0) return 'slightly assertive';
      return 'not dominant';
    }
    if (n >= 70) return 'high';
    if (n >= 35) return 'medium';
    if (n > 0) return 'low';
    return 'none';
  }

  function readRelationValue(row, key) {
    if (!row) return null;
    var rel = row.relationship && row.relationship[key];
    if (rel && rel.value != null) return numberOrNull(rel.value);
    if (row[key] != null) return numberOrNull(row[key]);
    return null;
  }

  function summarizeRelationships(row) {
    var fields = ['love', 'lust', 'trust', 'dom', 'rage'];
    var out = [];
    fields.forEach(function (field) {
      var value = readRelationValue(row, field);
      if (value == null) return;
      out.push({
        field: field,
        value: value,
        level: relationLevel(value, field)
      });
    });
    return out;
  }

  function hintLevel(value) {
    var n = numberOrNull(value);
    if (n == null) return '';
    if (n >= 70) return 'high';
    if (n >= 35) return 'medium';
    if (n > 0) return 'low';
    return 'none';
  }

  function pushHint(out, type, level, summary, caution) {
    if (!summary) return;
    out.push({
      type: text(type, 40),
      level: text(level || '', 30),
      summary: text(summary, 220),
      caution: text(caution || '', 220)
    });
  }

  function relationshipValue(relationships, field) {
    relationships = relationships || [];
    for (var i = 0; i < relationships.length; i++) {
      if (relationships[i] && relationships[i].field === field) return relationships[i].value;
    }
    return null;
  }

  function summarizeReactionHints(row, relationships) {
    row = row || {};
    relationships = relationships || [];
    var out = [];
    var love = relationshipValue(relationships, 'love');
    var lust = relationshipValue(relationships, 'lust');
    var trust = relationshipValue(relationships, 'trust');
    var dom = relationshipValue(relationships, 'dom');
    var rage = relationshipValue(relationships, 'rage');
    var extra = row.extra || {};

    if (love != null) {
      if (love >= 70) pushHint(out, 'affection', 'high', 'This NPC is strongly attached to the player; reactions can be warmer, more protective, or more personally invested.');
      else if (love >= 35) pushHint(out, 'affection', 'medium', 'This NPC has meaningful positive feelings toward the player; allow familiarity and concern.');
      else if (love > 0) pushHint(out, 'affection', 'low', 'This NPC has mild positive regard; keep reactions cautious rather than intimate.');
    }
    if (trust != null) {
      if (trust >= 70) pushHint(out, 'trust', 'high', 'This NPC substantially trusts the player; cooperation and honest responses are plausible.');
      else if (trust >= 35) pushHint(out, 'trust', 'medium', 'This NPC has partial trust; cooperation is possible but still conditional.');
      else pushHint(out, 'trust', 'low', 'This NPC does not strongly trust the player; avoid sudden full cooperation without clear story cause.');
    }
    if (lust != null) {
      if (lust >= 70) pushHint(out, 'desire', 'high', 'This NPC has high desire/arousal toward the situation; attraction, distraction, or charged tension may color reactions.', 'Do not force explicit action unless current scene and player action support it.');
      else if (lust >= 35) pushHint(out, 'desire', 'medium', 'This NPC has noticeable desire/arousal; keep the tension visible but controlled by current scene context.');
    }
    if (dom != null) {
      if (dom >= 70) pushHint(out, 'dominance', 'high', 'This NPC is strongly dominant/assertive; reactions may push control, pressure, or confident direction.');
      else if (dom >= 35) pushHint(out, 'dominance', 'medium', 'This NPC can be assertive; reactions may test boundaries without overriding current mechanics.');
    }
    if (rage != null) {
      if (rage >= 70) pushHint(out, 'anger', 'high', 'This NPC is very angry; reactions should be tense, hostile, or punitive unless the story clearly de-escalates.', 'Do not make the NPC suddenly gentle without a visible reason.');
      else if (rage >= 35) pushHint(out, 'anger', 'medium', 'This NPC is irritated; preserve guarded or sharp reactions.');
    }
    ['fear', 'stress', 'trauma', 'insecurity', 'purity', 'corruption', 'obedience'].forEach(function (key) {
      var value = extra && extra[key];
      var n = numberOrNull(value);
      if (n == null) return;
      var level = hintLevel(n);
      if (key === 'fear' && n >= 35) pushHint(out, 'fear', level, 'This NPC has notable fear; reactions may be guarded, flinching, avoidant, or defensive.');
      else if (key === 'stress' && n >= 35) pushHint(out, 'stress', level, 'This NPC is under stress; reactions may be impatient, distracted, or emotionally strained.');
      else if (key === 'trauma' && n >= 35) pushHint(out, 'trauma', level, 'This NPC carries trauma pressure; avoid casual emotional resets and keep reactions careful.');
      else if (key === 'insecurity' && n >= 35) pushHint(out, 'insecurity', level, 'This NPC is insecure; reactions may seek reassurance, control, or retreat.');
      else if (key === 'purity' && n >= 35) pushHint(out, 'purity', level, 'This NPC has a strong purity/faith restraint; reactions may show moral hesitation or internal conflict.');
      else if (key === 'corruption' && n >= 35) pushHint(out, 'corruption', level, 'This NPC has corruption pressure; reactions may be more tempted, conflicted, or transgressive.');
      else if (key === 'obedience' && n >= 35) pushHint(out, 'obedience', level, 'This NPC is inclined toward obedience; reactions may be more compliant if current scene supports it.');
    });
    return out.slice(0, 8);
  }

  function mergeNpc(out, row, source) {
    if (!row) return null;
    var key = text(row.key || row.name || row.title, 80);
    if (!key) return null;
    var existing = out[key] || {
      key: key,
      name: text(row.name || row.title || key, 80),
      title: text(row.title || row.name || key, 100),
      gender: text(row.gender || '', 30),
      state: text(row.state || '', 80),
      extra: {},
      sources: []
    };
    existing.name = existing.name || text(row.name || row.title || key, 80);
    existing.title = existing.title || text(row.title || row.name || key, 100);
    existing.gender = existing.gender || text(row.gender || '', 30);
    existing.state = existing.state || text(row.state || '', 80);
    if (row.extra) existing.extra = Object.assign(existing.extra || {}, cloneValue(row.extra));
    ['love', 'lust', 'trust', 'dom', 'rage'].forEach(function (field) {
      var value = readRelationValue(row, field);
      if (value != null) existing[field] = value;
    });
    if (source && existing.sources.indexOf(source) < 0) existing.sources.push(source);
    out[key] = existing;
    return existing;
  }

  function buildBaseNpcMap(state, deps) {
    var map = {};
    state = state || {};
    (state.npcDetails || []).forEach(function (row) { mergeNpc(map, row, 'npcDetails'); });
    (state.npcs || []).forEach(function (row) { mergeNpc(map, row, 'npcs'); });
    (state.presentNpcDetails || []).forEach(function (row) { mergeNpc(map, row, 'presentNpcDetails'); });
    try {
      if (deps && typeof deps.getKnownNpcNames === 'function') {
        (deps.getKnownNpcNames() || []).forEach(function (row) {
          if (typeof row === 'string') mergeNpc(map, { key: row, name: row, title: row }, 'knownNpcNames');
          else mergeNpc(map, row, 'knownNpcNames');
        });
      }
    } catch (_) {}
    return map;
  }

  function markPresence(map, state, worldContext) {
    var present = {};
    function mark(key, source, evidence) {
      key = text(key, 80);
      if (!key) return;
      var row = map[key] || mergeNpc(map, { key: key }, 'presence');
      row.present = true;
      row.presenceSource = row.presenceSource || source || 'unknown';
      if (evidence && !row.evidence) row.evidence = text(evidence, 220);
      present[key] = true;
    }
    (state.presentNpcDetails || []).forEach(function (row) {
      mark(row && row.key, row && row.presentSource || 'presentNpcDetails', row && row.presentEvidence);
    });
    try {
      var visible = worldContext && worldContext.visibleFacts && worldContext.visibleFacts.presentCharacters || [];
      visible.forEach(function (row) {
        mark(row && row.key, row && row.authority || 'visibleFacts', row && row.evidence);
      });
    } catch (_) {}
    return present;
  }

  function buildNearbyGeneric(state) {
    var out = [];
    (state.nearbyNpcDetails || []).forEach(function (row) {
      if (!row) return;
      out.push({
        name: text(row.name || '', 100),
        type: text(row.type || '', 40),
        role: text(row.role || '', 60),
        gender: text(row.gender || '', 30),
        stance: text(row.stance || '', 50),
        relationshipHints: summarizeRelationships(row).slice(0, 4)
      });
    });
    return out.slice(0, 6);
  }

  function scheduleHintFor(row, worldContext, input) {
    row = row || {};
    var key = row.key;
    var affinity = NPC_AFFINITY[key] || null;
    var facts = worldContext && worldContext.facts || {};
    var current = worldContext && worldContext.currentMap && worldContext.currentMap.current || {};
    var hay = compactHay([
      facts.passage,
      facts.location,
      facts.area,
      facts.nearby,
      current.label,
      current.passage,
      current.locId,
      current.parent,
      input && input.pageText
    ]);
    if (!affinity) {
      return {
        relevance: 'unknown',
        summary: 'No static schedule hint; rely on current native page and NPC state.',
        caution: 'Do not infer this NPC is present unless native state or page text says so.'
      };
    }
    var relevant = hasAny(hay, affinity.home);
    return {
      relevance: relevant ? 'context_related' : 'not_currently_grounded',
      summary: affinity.schedule,
      caution: affinity.caution
    };
  }

  function buildRules(presentRows, backgroundRows, nearbyGeneric) {
    var rules = [];
    rules.push('NPC context is read-only. It explains native NPC state but must not create NPC presence by itself.');
    rules.push('Current page text and presentNpcDetails decide who is physically present. Static schedule hints are background only.');
    if (presentRows.length) {
      rules.push('NPCs listed in npc_context.present are currently present and may react according to relationship/state hints.');
      rules.push('Use npc_context.present[].reactionHints to shape tone, caution, desire, anger, trust, dominance, and restraint; do not print numeric stats in prose.');
    }
    if (backgroundRows.length) {
      rules.push('NPCs listed in npc_context.background are known characters only; do not insert them into the scene unless the player goes to them or native text supports it.');
    }
    if (nearbyGeneric.length) {
      rules.push('Generic nearby NPC slots describe current encounter actors; use their role/stance without inventing named identity.');
    }
    return rules;
  }

  function create(deps) {
    deps = deps || {};

    function build(input) {
      input = input || {};
      var state = input.state || {};
      var worldContext = input.worldContext || {};
      var map = buildBaseNpcMap(state, deps);
      markPresence(map, state, worldContext);
      var presentRows = [];
      var backgroundRows = [];
      Object.keys(map).forEach(function (key) {
        var row = map[key] || {};
        var relationships = summarizeRelationships(row);
        var reactionHints = summarizeReactionHints(row, relationships);
        var schedule = scheduleHintFor(row, worldContext, input);
        var entry = {
          key: text(row.key || key, 80),
          name: text(row.name || row.title || key, 80),
          title: text(row.title || row.name || key, 100),
          present: !!row.present,
          presenceSource: text(row.presenceSource || '', 50),
          evidence: text(row.evidence || '', 220),
          gender: text(row.gender || '', 30),
          state: text(row.state || '', 80),
          relationshipHints: relationships,
          reactionHints: reactionHints,
          extra: cloneValue(row.extra || {}),
          scheduleHint: schedule
        };
        if (!entry.evidence) delete entry.evidence;
        if (!entry.presenceSource) delete entry.presenceSource;
        if (!entry.gender) delete entry.gender;
        if (!entry.state) delete entry.state;
        if (!entry.relationshipHints.length) delete entry.relationshipHints;
        if (!entry.reactionHints.length) delete entry.reactionHints;
        if (!entry.extra || !Object.keys(entry.extra).length) delete entry.extra;
        if (entry.present) presentRows.push(entry);
        else if (schedule.relevance === 'context_related' || relationships.length) backgroundRows.push(entry);
      });
      presentRows.sort(function (a, b) { return a.name.localeCompare(b.name); });
      backgroundRows.sort(function (a, b) {
        if (a.scheduleHint.relevance !== b.scheduleHint.relevance) return a.scheduleHint.relevance === 'context_related' ? -1 : 1;
        return a.name.localeCompare(b.name);
      });
      var nearbyGeneric = buildNearbyGeneric(state);
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        authority: 'native_state_and_current_page',
        present: presentRows.slice(0, 8),
        background: backgroundRows.slice(0, 10),
        nearbyGeneric: nearbyGeneric,
        rules: buildRules(presentRows, backgroundRows, nearbyGeneric)
      };
    }

    function formatPromptBlock(input) {
      return [
        '<npc_context schema="' + MODULE_SCHEMA_VERSION + '">',
        JSON.stringify(build(input), null, 2),
        '</npc_context>'
      ].join('\n');
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      build: build,
      formatPromptBlock: formatPromptBlock
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: create
  };

  root.AIStoryGen.NpcContextModule = api;
  root.AIStoryGenNpcContextModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
