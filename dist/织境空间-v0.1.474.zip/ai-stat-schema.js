/* ============================================================
 * AIStoryGen stat limit schema
 * Owns configurable per-stat change limits for player state effects.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  var STAT_LIMIT_FIELDS = [
    { field: 'pain', key: 'statChangeLimitPain', label: '\u75bc\u75db', max: 200, step: 1, fallback: 50 },
    { field: 'arousal', key: 'statChangeLimitArousal', label: '\u6027\u594b', max: 5000, step: 50, fallback: 3000 },
    { field: 'tiredness', key: 'statChangeLimitTiredness', label: '\u75b2\u52b3', max: 2000, step: 25, fallback: 1000 },
    { field: 'stress', key: 'statChangeLimitStress', label: '\u538b\u529b', max: 5000, step: 50, fallback: 3000 },
    { field: 'trauma', key: 'statChangeLimitTrauma', label: '\u521b\u4f24', max: 2000, step: 25, fallback: 1000 },
    { field: 'control', key: 'statChangeLimitControl', label: '\u81ea\u63a7', max: 200, step: 1, fallback: 50 },
    { field: 'seduction', key: 'statChangeLimitSeduction', label: '\u8bf1\u60d1', max: 200, step: 1, fallback: 50 }
  ];

  function cloneList(list) {
    return (Array.isArray(list) ? list : []).map(function (item) {
      return Object.assign({}, item);
    });
  }

  function clampFieldLimit(value, fallback, max) {
    var num = Number(value == null || value === '' ? fallback : value);
    if (!isFinite(num)) num = Number(fallback) || 0;
    return Math.max(0, Math.min(Number(max) || 5000, Math.round(num)));
  }

  function defaultLimitFromConfig(cfg) {
    cfg = cfg || {};
    return Math.max(0, parseInt(cfg.statChangeLimit, 10) || 0);
  }

  function findFieldDef(field) {
    field = String(field || '');
    for (var i = 0; i < STAT_LIMIT_FIELDS.length; i++) {
      if (STAT_LIMIT_FIELDS[i].field === field || STAT_LIMIT_FIELDS[i].key === field) return STAT_LIMIT_FIELDS[i];
    }
    return null;
  }

  function getFieldLimit(cfg, defaults, field, runtimeLimitFn) {
    cfg = cfg || {};
    defaults = defaults || {};
    var def = findFieldDef(field);
    if (def) {
      return clampFieldLimit(cfg[def.key], defaults[def.key] == null ? def.fallback : defaults[def.key], def.max);
    }
    var defaultLimit = defaultLimitFromConfig(cfg);
    if (typeof runtimeLimitFn === 'function') return runtimeLimitFn(field, defaultLimit);
    return defaultLimit;
  }

  function getFieldLimits(cfg, defaults, runtimeLimitFn) {
    var out = {};
    STAT_LIMIT_FIELDS.forEach(function (def) {
      out[def.field] = getFieldLimit(cfg, defaults, def.field, runtimeLimitFn);
    });
    return out;
  }

  function formatFieldLimitText(cfg, defaults, runtimeLimitFn) {
    var limits = getFieldLimits(cfg, defaults, runtimeLimitFn);
    return STAT_LIMIT_FIELDS.map(function (def) {
      var limit = Number(limits[def.field] || 0);
      return def.field + (limit > 0 ? ' +/-' + limit : ' disabled');
    }).join(', ');
  }

  function create(deps) {
    deps = deps || {};
    function defaults() {
      try {
        return typeof deps.getDefaults === 'function' ? (deps.getDefaults() || {}) : (deps.defaults || {});
      } catch (_) {
        return {};
      }
    }
    function runtimeLimit(key, limit) {
      try {
        return typeof deps.getRuntimeStatLimit === 'function' ? deps.getRuntimeStatLimit(key, limit) : limit;
      } catch (_) {
        return limit;
      }
    }
    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      getFieldDefs: function () { return cloneList(STAT_LIMIT_FIELDS); },
      clampFieldLimit: clampFieldLimit,
      getFieldLimit: function (cfg, field) { return getFieldLimit(cfg, defaults(), field, runtimeLimit); },
      getFieldLimits: function (cfg) { return getFieldLimits(cfg, defaults(), runtimeLimit); },
      formatFieldLimitText: function (cfg) { return formatFieldLimitText(cfg, defaults(), runtimeLimit); }
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    getFieldDefs: function () { return cloneList(STAT_LIMIT_FIELDS); },
    clampFieldLimit: clampFieldLimit,
    getFieldLimit: getFieldLimit,
    getFieldLimits: getFieldLimits,
    formatFieldLimitText: formatFieldLimitText,
    create: create
  };

  root.AIStoryGen.StatSchemaModule = api;
  root.AIStoryGenStatSchemaModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
