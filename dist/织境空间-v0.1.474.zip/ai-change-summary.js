/* ============================================================
 * AIStoryGen change summary
 * Formats transaction audit results into short player-facing
 * status change summaries. It never changes game state.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  var STAT_LABELS = {
    money: '\u91d1\u94b1',
    arousal: '\u6027\u594b',
    stress: '\u538b\u529b',
    pain: '\u75bc\u75db',
    trauma: '\u521b\u4f24',
    tiredness: '\u75b2\u52b3',
    fatigue: '\u75b2\u52b3',
    control: '\u81ea\u63a7',
    seductionskill: '\u8bf1\u60d1',
    seduction: '\u8bf1\u60d1',
    drunk: '\u9189\u9152',
    drugged: '\u836f\u7269\u5f71\u54cd'
  };

  var RELATION_LABELS = {
    love: '\u597d\u611f',
    lust: '\u6b32\u671b',
    trust: '\u4fe1\u4efb',
    dom: '\u652f\u914d',
    rage: '\u6012\u6c14',
    respect: '\u5c0a\u91cd',
    fear: '\u6050\u60e7'
  };

  function num(value) {
    var n = Number(value);
    return isFinite(n) ? n : null;
  }

  function fmtDelta(value) {
    var n = num(value);
    if (n == null) return '';
    return (n > 0 ? '+' : '') + String(n);
  }

  function labelStat(key) {
    key = String(key || '');
    return STAT_LABELS[key] || key || '\u672a\u77e5\u6570\u503c';
  }

  function labelRelation(key) {
    key = String(key || '');
    return RELATION_LABELS[key] || key || '\u672a\u77e5\u5173\u7cfb';
  }

  function pushLine(lines, line, maxLines) {
    line = String(line || '').trim();
    if (!line || lines.length >= maxLines) return;
    lines.push(line);
  }

  function summarizeAudit(audit, opts) {
    opts = opts || {};
    var maxLines = Math.max(1, Math.min(12, Number(opts.maxLines) || 6));
    audit = audit || {};
    var actual = audit.actual || {};
    var lines = [];

    var time = actual.time || {};
    if (num(time.actual) || num(time.expected)) {
      var minutes = num(time.actual);
      if (minutes == null) minutes = num(time.expected);
      if (minutes) pushLine(lines, '\u65f6\u95f4 +' + minutes + ' \u5206\u949f', maxLines);
    }

    (Array.isArray(actual.stats) ? actual.stats : []).forEach(function (entry) {
      var delta = num(entry && entry.actual);
      if (delta == null || delta === 0) delta = num(entry && entry.expected);
      if (delta == null || delta === 0) return;
      pushLine(lines, labelStat(entry.key) + ' ' + fmtDelta(delta), maxLines);
    });

    var items = actual.items || {};
    (Array.isArray(items.consumed) ? items.consumed : []).forEach(function (entry) {
      var actualConsumed = num(entry && entry.actualConsumed);
      var expected = num(entry && entry.expectedConsumed);
      var qty = actualConsumed && actualConsumed > 0 ? actualConsumed : expected;
      if (!qty) return;
      pushLine(lines, '\u6d88\u8017\u9053\u5177\uff1a' + String(entry.name || '\u672a\u77e5\u9053\u5177') + ' x' + qty, maxLines);
    });
    (Array.isArray(items.pickupItems) ? items.pickupItems : []).forEach(function (item) {
      var name = String(item && (item.name || item.label || item.id) || '').trim();
      if (!name) return;
      var qty = num(item.qty == null ? item.count : item.qty) || 1;
      pushLine(lines, '\u83b7\u5f97\u5f85\u62fe\u53d6\u9053\u5177\uff1a' + name + ' x' + qty, maxLines);
    });

    (Array.isArray(actual.relationships) ? actual.relationships : []).forEach(function (entry) {
      var delta = num(entry && entry.actual);
      if (delta == null || delta === 0) delta = num(entry && entry.expected);
      if (delta == null || delta === 0) return;
      pushLine(lines, String(entry.npc || 'NPC') + ' ' + labelRelation(entry.field) + ' ' + fmtDelta(delta), maxLines);
    });

    var loc = actual.location || {};
    if (loc.changed && loc.after) {
      var label = loc.after.currentLabel || loc.after.targetLabel || loc.target || '';
      if (label) pushLine(lines, '\u5730\u70b9\u66f4\u65b0\uff1a' + label, maxLines);
    }

    var mem = actual.memory || {};
    if (mem.changed) pushLine(lines, 'AI \u8bb0\u5fc6\u5df2\u66f4\u65b0', maxLines);

    var warningCount = Array.isArray(audit.warnings) ? audit.warnings.length : 0;
    if (warningCount) pushLine(lines, '\u4e8b\u52a1\u5ba1\u8ba1\u63d0\u793a\uff1a' + warningCount + ' \u9879\u9700\u68c0\u67e5', maxLines);

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      ok: warningCount === 0,
      count: lines.length,
      lines: lines,
      text: lines.length ? ('\u672c\u6b21 AI \u5267\u60c5\u53d8\u5316\uff1a' + lines.join('\uff1b')) : ''
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    summarizeAudit: summarizeAudit,
    labelStat: labelStat,
    labelRelation: labelRelation
  };

  root.ChangeSummaryModule = api;
  root.AIStoryGenChangeSummaryModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
