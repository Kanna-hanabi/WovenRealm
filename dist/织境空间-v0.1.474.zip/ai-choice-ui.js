/* ============================================================
 * AIStoryGen choice UI helpers
 * UI-only helpers for AI choice time editing and refinement.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  function clampChoiceTimeInput(value, min, max) {
    var n = parseInt(value, 10);
    if (!isFinite(n) || isNaN(n)) n = 0;
    n = Math.max(min, Math.min(max, n));
    return n;
  }

  function ensureChoiceLayoutStyles() {
    if (!root.document) return;
    if (root.document.getElementById('ai-choice-ui-layout-guard')) return;
    var style = root.document.createElement('style');
    style.id = 'ai-choice-ui-layout-guard';
    style.textContent = [
      '#passages .ai-choices-list .ai-choice-row{display:flex!important;align-items:flex-start!important;gap:.2em!important;flex-wrap:nowrap!important;width:100%!important;min-width:0!important;}',
      '#passages .ai-choices-list .ai-choice-row.is-editing-choice{flex-wrap:wrap!important;}',
      '#passages .ai-choices-list .ai-choice-row>.ai-choice-edit-btn{flex:0 0 auto!important;}',
      '#passages .ai-choices-list .ai-choice-row>.ai-choice-btn{display:block!important;flex:0 1 auto!important;min-width:0!important;width:auto!important;max-width:calc(100% - 2.6em)!important;overflow-wrap:anywhere!important;word-break:break-word!important;white-space:normal!important;}',
      '#passages .ai-choices-list .ai-choice-edit-panel{box-sizing:border-box!important;flex:0 0 calc(100% - 2.7em)!important;min-width:0!important;margin:.25em 0 0 2.7em!important;}',
      '#passages .ai-choices-list .ai-choice-edit-main{display:block!important;}',
      '#passages .ai-choices-list .ai-choice-edit-footer{display:flex!important;align-items:flex-end!important;justify-content:space-between!important;gap:.75em!important;margin-top:.5em!important;}',
      '#passages .ai-choices-list .ai-choice-edit-actions{display:flex!important;justify-content:flex-end!important;gap:.45em!important;margin-left:auto!important;white-space:nowrap!important;}',
      '#passages .ai-choices-list .ai-choice-edit-time-panel{display:flex!important;flex-direction:column!important;gap:.28em!important;min-width:0!important;}',
      '#passages .ai-choices-custom>.ai-choices-input{flex:1 1 18em!important;min-width:0!important;}',
      '#passages .ai-choices-custom>.ai-choice-custom-btn{flex:0 0 auto!important;min-width:4.2em!important;max-width:5.8em!important;width:auto!important;}'
    ].join('\n');
    (root.document.head || root.document.documentElement).appendChild(style);
  }

  function create(deps) {
    deps = deps || {};
    var $ = deps.$ || root.jQuery || root.$;
    if (!$) throw new Error('[AIStoryGen] ai-choice-ui requires jQuery');
    ensureChoiceLayoutStyles();
    var cfg = deps.cfg || {};
    var formatChoiceTime = deps.formatChoiceTime || function (total) {
      total = Math.max(0, Math.round(Number(total || 0)));
      return Math.floor(total / 60) + ':' + String(total % 60).padStart(2, '0');
    };
    var parseTimeFromChoice = deps.parseTimeFromChoice || function () { return 0; };
    var stripTimeFromChoice = deps.stripTimeFromChoice || function (text) { return String(text || '').trim(); };
    var buildChoiceTextWithTime = deps.buildChoiceTextWithTime || function (text, total) {
      return stripTimeFromChoice(text) + ' (' + formatChoiceTime(total) + ')';
    };
    var inferDefaultTimeCost = deps.inferDefaultTimeCost || function () { return 5; };
    var bindInteractionShield = deps.bindInteractionShield || function () {};

    function readChoiceTimeFromRow($row, fallbackText) {
      var $display = $row.find('.ai-choice-time-editor');
      if ($display.length) {
        var stored = parseInt($display.attr('data-minutes'), 10);
        if (isFinite(stored) && !isNaN(stored) && stored >= 0) return stored;
      }
      var $hour = $row.find('.ai-choice-hour');
      var $minute = $row.find('.ai-choice-minute');
      if ($hour.length && $minute.length) {
        var hours = clampChoiceTimeInput($hour.val(), 0, 99);
        var minutes = clampChoiceTimeInput($minute.val(), 0, 59);
        $hour.val(String(hours));
        $minute.val(String(minutes).padStart(2, '0'));
        return (hours * 60) + minutes;
      }
      var parsed = parseTimeFromChoice(fallbackText);
      return parsed > 0 ? parsed : inferDefaultTimeCost(fallbackText);
    }

    function openChoiceTimeInlineEdit($target, label) {
      if ($target.attr('data-editing') === '1') return;
      $('.ai-choice-time-pop').remove();
      $('.ai-choice-time-editor.is-editing').removeClass('is-editing').removeAttr('data-editing');
      var current = Math.max(0, parseInt($target.attr('data-minutes'), 10) || 0);
      var hours = Math.floor(current / 60);
      var minutes = current % 60;
      var originalText = $target.text();
      var originalMinutes = current;
      var $hour = $('<input type="text" class="ai-choice-time-inline-input ai-choice-time-inline-hour" inputmode="numeric" pattern="[0-9]*" maxlength="2">').val(String(hours));
      var $minute = $('<input type="text" class="ai-choice-time-inline-input ai-choice-time-inline-minute" inputmode="numeric" pattern="[0-9]*" maxlength="2">').val(String(minutes).padStart(2, '0'));
      var closing = false;
      function cleanDigits($input) {
        var value = String($input.val() || '').replace(/[^\d]/g, '').slice(0, 2);
        $input.val(value);
      }
      function readEditingTotal() {
        cleanDigits($hour);
        cleanDigits($minute);
        return (clampChoiceTimeInput($hour.val(), 0, 99) * 60) + clampChoiceTimeInput($minute.val(), 0, 59);
      }
      function setEditingTotal(total) {
        total = Math.max(0, Math.min((99 * 60) + 59, Math.round(Number(total || 0))));
        $hour.val(String(Math.floor(total / 60)));
        $minute.val(String(total % 60).padStart(2, '0'));
        $target
          .attr('data-minutes', String(total))
          .text('(' + formatChoiceTime(total) + ')');
      }
      function adjustEditingTotal(delta) {
        setEditingTotal(readEditingTotal() + delta);
        $target.trigger('ai-choice-timechange', [readEditingTotal()]);
      }
      function makeAdjustButtons(unitStep) {
        var $buttons = $('<span class="ai-choice-time-pop-buttons"></span>');
        var deltas = [-10, -5, -1, 1, 5, 10];
        function bindAdjust($btn, delta) {
          function run(e) {
            e.preventDefault();
            e.stopPropagation();
            adjustEditingTotal(delta * unitStep);
          }
          $btn.on('mousedown pointerdown', function (e) {
            e.stopPropagation();
          });
          $btn.on('click', run);
          $btn.on('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') run(e);
            if (e.key === 'Escape') cancel();
          });
        }
        deltas.forEach(function (delta) {
          var label = delta > 0 ? '+' + delta : String(delta);
          var $btn = $('<button type="button" class="ai-choice-time-pop-step"></button>').text(label);
          bindAdjust($btn, delta);
          $buttons.append($btn);
        });
        return $buttons;
      }
      function finish(total, notify) {
        closing = true;
        $target
          .removeClass('is-editing')
          .removeAttr('data-editing')
          .empty()
          .attr('data-minutes', String(total))
          .text('(' + formatChoiceTime(total) + ')');
        $panel.remove();
        if (notify) $target.trigger('ai-choice-timechange', [total]);
      }
      function apply() {
        finish(readEditingTotal(), true);
      }
      function cancel() {
        closing = true;
        $target
          .removeClass('is-editing')
          .removeAttr('data-editing')
          .empty()
          .attr('data-minutes', String(originalMinutes))
          .text(originalText);
        $panel.remove();
      }
      var hourLabel = cfg.language === 'zh' ? '\u5c0f\u65f6' : 'Hours';
      var minuteLabel = cfg.language === 'zh' ? '\u5206\u949f' : 'Minutes';
      var okLabel = cfg.language === 'zh' ? '\u786e\u5b9a' : 'OK';
      var cancelLabel = cfg.language === 'zh' ? '\u53d6\u6d88' : 'Cancel';
      var $panel = $('<div class="ai-choice-time-pop"></div>');
      var $hourRow = $('<div class="ai-choice-time-pop-row"></div>')
        .append($('<span class="ai-choice-time-pop-label"></span>').text(hourLabel))
        .append($hour)
        .append(makeAdjustButtons(60));
      var $minuteRow = $('<div class="ai-choice-time-pop-row"></div>')
        .append($('<span class="ai-choice-time-pop-label"></span>').text(minuteLabel))
        .append($minute)
        .append(makeAdjustButtons(1));
      var $actions = $('<div class="ai-choice-time-pop-actions"></div>');
      var $ok = $('<button type="button" class="ai-choice-time-pop-action"></button>').text(okLabel);
      var $cancel = $('<button type="button" class="ai-choice-time-pop-action"></button>').text(cancelLabel);
      $actions.append($ok).append($cancel);
      $panel.append($hourRow).append($minuteRow).append($actions);
      $target
        .attr('data-editing', '1')
        .addClass('is-editing');
      var $anchor = $target.closest('.ai-choice-row, .ai-choices-custom');
      if ($anchor.length) $anchor.after($panel);
      else $target.after($panel);
      bindInteractionShield($panel, 'choice-time-pop');
      $ok.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        apply();
      });
      $cancel.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        cancel();
      });
      $hour.add($minute).on('click mousedown keyup input', function (e) {
        e.stopPropagation();
        if (e.type === 'input' || e.type === 'keyup') {
          cleanDigits($(this));
          setEditingTotal(readEditingTotal());
          $target.trigger('ai-choice-timechange', [readEditingTotal()]);
        }
      });
      $hour.add($minute).on('keydown', function (e) {
        e.stopPropagation();
        if (e.key === 'Enter') apply();
        if (e.key === 'Escape') cancel();
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          adjustEditingTotal($(this).hasClass('ai-choice-time-inline-hour') ? 60 : 1);
        }
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          adjustEditingTotal($(this).hasClass('ai-choice-time-inline-hour') ? -60 : -1);
        }
      });
      $hour.add($minute).on('blur', function () {
        setTimeout(function () {
          if (closing) return;
          if ($panel.find(document.activeElement).length) return;
        }, 30);
      });
      setTimeout(function () { try { $hour.focus().select(); } catch (_) {} }, 0);
    }

    function createChoiceTimeEditor(totalMinutes, label, opts) {
      opts = opts || {};
      var total = Math.max(0, Math.round(Number(totalMinutes || 0)));
      var title = cfg.language === 'zh' ? '\u8017\u65f6\uff08\u5c0f\u65f6:\u5206\u949f\uff09' : 'Time cost (hours:minutes)';
      var editable = opts.editable !== false;
      var $wrap = $('<span class="ai-choice-time-editor"></span>')
        .attr('title', title)
        .attr('aria-label', (label || '') + ' ' + title)
        .attr('data-minutes', String(total))
        .text('(' + formatChoiceTime(total) + ')');
      if (!editable) {
        $wrap.addClass('is-display-only');
        return $wrap;
      }
      $wrap.attr('role', 'button').attr('tabindex', '0');
      $wrap.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        openChoiceTimeInlineEdit($(this), label || '');
      });
      $wrap.on('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          e.stopPropagation();
          openChoiceTimeInlineEdit($(this), label || '');
        }
      });
      return $wrap;
    }

    function createChoiceEditTimeControls(initialMinutes) {
      var total = Math.max(0, Math.min((99 * 60) + 59, Math.round(Number(initialMinutes || 0))));
      var $wrap = $('<div class="ai-choice-edit-time-panel"></div>');
      var $hour = $('<input type="text" class="ai-choice-time-inline-input ai-choice-time-inline-hour" inputmode="numeric" pattern="[0-9]*" maxlength="2">');
      var $minute = $('<input type="text" class="ai-choice-time-inline-input ai-choice-time-inline-minute" inputmode="numeric" pattern="[0-9]*" maxlength="2">');
      function cleanDigits($input) {
        var value = String($input.val() || '').replace(/[^\d]/g, '').slice(0, 2);
        $input.val(value);
      }
      function setTotal(nextTotal) {
        total = Math.max(0, Math.min((99 * 60) + 59, Math.round(Number(nextTotal || 0))));
        $hour.val(String(Math.floor(total / 60)));
        $minute.val(String(total % 60).padStart(2, '0'));
        $wrap.attr('data-minutes', String(total));
      }
      function readTotal() {
        cleanDigits($hour);
        cleanDigits($minute);
        total = (clampChoiceTimeInput($hour.val(), 0, 99) * 60) + clampChoiceTimeInput($minute.val(), 0, 59);
        setTotal(total);
        return total;
      }
      function adjustTotal(delta) {
        setTotal(readTotal() + delta);
      }
      function makeAdjustButtons(unitStep) {
        var $buttons = $('<span class="ai-choice-time-pop-buttons"></span>');
        [-10, -5, -1, 1, 5, 10].forEach(function (delta) {
          var $step = $('<button type="button" class="ai-choice-time-pop-step"></button>').text(delta > 0 ? '+' + delta : String(delta));
          $step.on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            adjustTotal(delta * unitStep);
          });
          $buttons.append($step);
        });
        return $buttons;
      }
      var hourLabel = cfg.language === 'zh' ? '\u5c0f\u65f6' : 'Hours';
      var minuteLabel = cfg.language === 'zh' ? '\u5206\u949f' : 'Minutes';
      var $hourRow = $('<div class="ai-choice-time-pop-row"></div>')
        .append($('<span class="ai-choice-time-pop-label"></span>').text(hourLabel))
        .append($hour)
        .append(makeAdjustButtons(60));
      var $minuteRow = $('<div class="ai-choice-time-pop-row"></div>')
        .append($('<span class="ai-choice-time-pop-label"></span>').text(minuteLabel))
        .append($minute)
        .append(makeAdjustButtons(1));
      $hour.add($minute).on('click mousedown keyup input keydown', function (e) {
        e.stopPropagation();
        if (e.type === 'input' || e.type === 'keyup') readTotal();
        if (e.type === 'keydown') {
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            adjustTotal($(this).hasClass('ai-choice-time-inline-hour') ? 60 : 1);
          } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            adjustTotal($(this).hasClass('ai-choice-time-inline-hour') ? -60 : -1);
          }
        }
      });
      $wrap.data('readMinutes', readTotal);
      $wrap.data('setMinutes', setTotal);
      $wrap.append($hourRow).append($minuteRow);
      setTotal(total);
      return $wrap;
    }

    function closeChoiceEditPanel($row) {
      $row.removeClass('is-editing-choice');
      $row.find('.ai-choice-edit-panel').remove();
    }

    function showChoiceEditPanel($row) {
      var $btn = $row.find('> .ai-choice-btn').first();
      if (!$btn.length || $btn.prop('disabled')) return;
      var currentText = ($btn.attr('data-choice-base-text') || stripTimeFromChoice($btn.attr('data-choice-text') || '') || '').trim();
      var $timeDisplay = $btn.find('.ai-choice-time-editor').first();
      var currentMinutes = parseInt($timeDisplay.attr('data-minutes'), 10);
      if (!isFinite(currentMinutes) || isNaN(currentMinutes) || currentMinutes < 0) currentMinutes = inferDefaultTimeCost(currentText);
      $row.closest('.ai-choices-list').find('.ai-choice-edit-panel').each(function () {
        closeChoiceEditPanel($(this).closest('.ai-choice-row'));
      });
      $row.addClass('is-editing-choice');
      var $panel = $('<div class="ai-choice-edit-panel"></div>');
      var $main = $('<div class="ai-choice-edit-main"></div>');
      var $footer = $('<div class="ai-choice-edit-footer"></div>');
      var $input = $('<textarea class="ai-choice-edit-input" rows="3"></textarea>')
        .attr('aria-label', cfg.language === 'zh' ? '\u5fae\u8c03\u8fd9\u4e2a\u5267\u60c5\u9009\u9879' : 'Refine this story choice')
        .val(currentText);
      var $timeControls = createChoiceEditTimeControls(currentMinutes);
      var $actions = $('<div class="ai-choice-edit-actions"></div>');
      var $ok = $('<button type="button" class="ai-choice-edit-confirm"></button>').text(cfg.language === 'zh' ? '\u786e\u5b9a' : 'OK');
      var $cancel = $('<button type="button" class="ai-choice-edit-cancel"></button>').text(cfg.language === 'zh' ? '\u53d6\u6d88' : 'Cancel');
      var $reset = $('<button type="button" class="ai-choice-edit-reset"></button>').text(cfg.language === 'zh' ? '\u91cd\u7f6e' : 'Reset');
      function commitEdit() {
        var nextText = String($input.val() || '').trim();
        if (!nextText) nextText = currentText;
        if (!nextText) {
          closeChoiceEditPanel($row);
          return;
        }
        var timeCost = 0;
        try {
          timeCost = $timeControls.data('readMinutes')();
        } catch (_) {}
        $btn
          .attr('data-choice-base-text', nextText)
          .attr('data-choice-text', buildChoiceTextWithTime(nextText, timeCost));
        $btn.find('.ai-choice-label').text(nextText);
        $timeDisplay
          .attr('data-minutes', String(timeCost))
          .attr('aria-label', nextText + ' ' + (cfg.language === 'zh' ? '\u8017\u65f6\uff08\u5c0f\u65f6:\u5206\u949f\uff09' : 'Time cost (hours:minutes)'))
          .text('(' + formatChoiceTime(timeCost) + ')');
        closeChoiceEditPanel($row);
      }
      function resetEdit() {
        $input.val(currentText);
        if (typeof $timeControls.data('setMinutes') === 'function') {
          $timeControls.data('setMinutes')(currentMinutes);
        }
        try { $input.focus(); } catch (_) {}
      }
      bindInteractionShield($panel, 'choice-edit-panel');
      $ok.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        commitEdit();
      });
      $cancel.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        closeChoiceEditPanel($row);
      });
      $reset.on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        resetEdit();
      });
      $input.on('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
          e.preventDefault();
          commitEdit();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          closeChoiceEditPanel($row);
        }
      });
      $actions.append($ok).append($cancel).append($reset);
      $main.append($input);
      $footer.append($timeControls).append($actions);
      $panel.append($main).append($footer);
      $row.append($panel);
      setTimeout(function () {
        try {
          $input.focus();
          var el = $input[0];
          el.setSelectionRange(el.value.length, el.value.length);
        } catch (_) {}
      }, 0);
    }

    return {
      readChoiceTimeFromRow: readChoiceTimeFromRow,
      createChoiceTimeEditor: createChoiceTimeEditor,
      showChoiceEditPanel: showChoiceEditPanel
    };
  }

  var ChoiceUIModule = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    clampChoiceTimeInput: clampChoiceTimeInput,
    create: create
  };

  root.AIStoryGen.ChoiceUIModule = ChoiceUIModule;
  root.AIStoryGenChoiceUIModule = ChoiceUIModule;
})(typeof window !== 'undefined' ? window : globalThis);
