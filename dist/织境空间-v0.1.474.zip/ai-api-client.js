/* ============================================================
 * AIStoryGen API client helpers
 * Normalizes OpenAI-compatible chat responses and request flags.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 2;
  var nativeJSON = root.AIStoryGen.NativeJSON || root.AIStoryGenNativeJSON || {};
  var nativeStringify = typeof nativeJSON.stringify === 'function' ? nativeJSON.stringify : JSON.stringify.bind(JSON);
  var nativeParse = typeof nativeJSON.parse === 'function' ? nativeJSON.parse : JSON.parse.bind(JSON);

  function sanitizeForApiJSON(value, seen) {
    if (value == null) return value;
    var type = typeof value;
    if (type === 'string' || type === 'boolean') return value;
    if (type === 'number') return isFinite(value) ? value : null;
    if (type === 'undefined' || type === 'function' || type === 'symbol') return undefined;
    seen = seen || [];
    if (seen.indexOf(value) !== -1) return undefined;
    if (Array.isArray(value)) {
      if (value[0] === '(revive:eval)') return undefined;
      seen.push(value);
      var arr = value.map(function (item) {
        var cleaned = sanitizeForApiJSON(item, seen);
        return cleaned === undefined ? null : cleaned;
      });
      seen.pop();
      return arr;
    }
    if (type === 'object') {
      if (value instanceof Date) return value.toISOString();
      seen.push(value);
      var out = {};
      Object.keys(value).forEach(function (key) {
        var cleaned = sanitizeForApiJSON(value[key], seen);
        if (cleaned !== undefined) out[key] = cleaned;
      });
      seen.pop();
      return out;
    }
    return value;
  }

  function safeJsonStringify(value) {
    return nativeStringify(sanitizeForApiJSON(value));
  }

  function safeJsonParse(text) {
    return nativeParse(text);
  }

  function looksLikeJSON(text) {
    var trimmed = String(text || '').trimStart();
    return trimmed.charAt(0) === '{' || trimmed.charAt(0) === '[';
  }

  function isPlainJsonBody(body) {
    if (!body || typeof body !== 'object') return false;
    if (Array.isArray(body)) return true;
    return Object.prototype.toString.call(body) === '[object Object]';
  }

  function normalizeFetchInit(init) {
    if (!init) return init;
    var next = Object.assign({}, init);
    if (typeof next.body === 'string' && looksLikeJSON(next.body)) {
      try {
        next.body = safeJsonStringify(safeJsonParse(next.body));
      } catch (_) {}
    } else if (isPlainJsonBody(next.body)) {
      next.body = safeJsonStringify(next.body);
    }
    return next;
  }

  function safeFetch(input, init) {
    return root.fetch(input, normalizeFetchInit(init));
  }

  function contentToText(content) {
    if (typeof content === 'string') return content;
    if (Array.isArray(content)) {
      return content.map(function (part) {
        if (typeof part === 'string') return part;
        if (!part || typeof part !== 'object') return '';
        if (typeof part.text === 'string') return part.text;
        if (typeof part.content === 'string') return part.content;
        if (part.type === 'text' && typeof part.value === 'string') return part.value;
        return '';
      }).join('');
    }
    return '';
  }

  function responseErrorText(obj) {
    if (!obj || typeof obj !== 'object') return '';
    var err = obj.error || obj.errors || obj;
    if (typeof err === 'string') return err;
    if (Array.isArray(err)) {
      return err.map(responseErrorText).filter(Boolean).join('\n');
    }
    if (err && typeof err === 'object') {
      return [
        err.message,
        err.detail,
        err.type,
        err.code,
        err.param
      ].map(function (v) { return typeof v === 'string' || typeof v === 'number' ? String(v) : ''; }).filter(Boolean).join(' ');
    }
    return '';
  }

  function getPathValue(obj, path) {
    if (!obj || !path) return undefined;
    var cur = obj;
    var parts = String(path).split('.');
    for (var i = 0; i < parts.length; i++) {
      if (cur == null) return undefined;
      var part = parts[i];
      var m = part.match(/^([^\[\]]+)\[(\d+)\]$/);
      if (m) {
        cur = cur[m[1]];
        cur = Array.isArray(cur) ? cur[Number(m[2])] : undefined;
      } else {
        cur = cur[part];
      }
    }
    return cur;
  }

  function firstPathValue(obj, paths) {
    if (!Array.isArray(paths)) return undefined;
    for (var i = 0; i < paths.length; i++) {
      var value = getPathValue(obj, paths[i]);
      if (value != null && value !== '') return value;
    }
    return undefined;
  }

  function extractResponseText(payload, opts) {
    if (!payload) return '';
    var errText = responseErrorText(payload);
    if (errText && !payload.choices && !payload.output && !payload.output_text) return '';
    opts = opts || {};
    var pathValue = firstPathValue(payload, opts.responseTextPaths || opts.textPaths);
    var pathText = contentToText(pathValue);
    if (pathText) return pathText;
    var choice = payload.choices && payload.choices[0];
    if (choice) {
      var msg = choice.message || {};
      var out = contentToText(msg.content);
      if (out) return out;
      out = contentToText(choice.text);
      if (out) return out;
      out = contentToText(msg.output_text || msg.response || msg.text);
      if (out) return out;
    }
    if (typeof payload.output_text === 'string') return payload.output_text;
    if (Array.isArray(payload.output)) {
      var chunks = [];
      payload.output.forEach(function (item) {
        if (!item || typeof item !== 'object') return;
        chunks.push(contentToText(item.content));
        chunks.push(contentToText(item.text));
      });
      var text = chunks.join('');
      if (text) return text;
    }
    if (typeof payload.text === 'string') return payload.text;
    if (typeof payload.response === 'string') return payload.response;
    return '';
  }

  function extractFinishReason(payload, opts) {
    if (!payload) return '';
    opts = opts || {};
    var value = firstPathValue(payload, opts.finishReasonPaths || opts.finishPaths);
    if (value != null && value !== '') return String(value);
    var choice = payload.choices && payload.choices[0];
    return choice && (choice.finish_reason || choice.finishReason || choice.stop_reason || choice.stopReason) || payload.finish_reason || payload.finishReason || '';
  }

  function trimSlashes(url) {
    return String(url || '').trim().replace(/\/+$/, '');
  }

  function normalizeBaseEndpoint(endpoint) {
    endpoint = trimSlashes(endpoint);
    if (!endpoint) return '';
    return endpoint
      .replace(/\/chat\/completions$/i, '')
      .replace(/\/responses$/i, '')
      .replace(/\/models$/i, '');
  }

  function normalizeEndpointForPath(endpoint, path) {
    endpoint = trimSlashes(endpoint);
    path = String(path || '/chat/completions').trim();
    if (!endpoint) return '';
    if (!path) return endpoint;
    path = '/' + path.replace(/^\/+/, '').replace(/\/+$/, '');
    if (endpoint.toLowerCase().endsWith(path.toLowerCase())) return endpoint;
    if (/\/chat\/completions$/i.test(endpoint) || /\/responses$/i.test(endpoint) || /\/models$/i.test(endpoint)) {
      endpoint = normalizeBaseEndpoint(endpoint);
    }
    return endpoint + path;
  }

  function normalizeChatEndpoint(endpoint, opts) {
    opts = opts || {};
    if (opts.chatPath && opts.chatPath !== '/chat/completions') return normalizeEndpointForPath(endpoint, opts.chatPath);
    endpoint = trimSlashes(endpoint);
    if (!endpoint) return '';
    if (/\/chat\/completions$/i.test(endpoint) || /\/responses$/i.test(endpoint)) return endpoint;
    if (/\/models$/i.test(endpoint)) return endpoint.replace(/\/models$/i, '/chat/completions');
    return endpoint + '/chat/completions';
  }

  function normalizeModelsEndpoint(endpoint, opts) {
    opts = opts || {};
    var base = normalizeBaseEndpoint(endpoint);
    var path = String(opts.modelsPath || '/models').trim();
    path = '/' + path.replace(/^\/+/, '').replace(/\/+$/, '');
    return base ? base + path : '';
  }

  function isLocalEndpoint(endpoint) {
    return /^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?\//i.test(String(endpoint || ''));
  }

  function shouldDisableThinking(endpoint, model, opts) {
    if (opts && opts.enableThinking) return false;
    endpoint = String(endpoint || '');
    model = String(model || '');
    if (!/api\.deepseek\.com/i.test(endpoint)) return false;
    return /^deepseek-v4-/i.test(model);
  }

  function applyProviderOptions(body, endpoint, model, opts) {
    body = body || {};
    if (shouldDisableThinking(endpoint, model, opts)) {
      body.thinking = { type: 'disabled' };
    }
    return body;
  }

  function emptyResponseMessage(payload, lang, opts) {
    var zh = lang === 'zh';
    var finish = extractFinishReason(payload, opts);
    if (finish === 'content_filter') {
      return zh ? '\u0041\u0050\u0049 \u8fd4\u56de\u7a7a\u54cd\u5e94\uff1a\u5185\u5bb9\u88ab\u63a5\u53e3\u8fc7\u6ee4\u3002\u8bf7\u8c03\u6574\u63d0\u793a\u8bcd\u6216\u66f4\u6362\u5141\u8bb8\u8be5\u5185\u5bb9\u7684\u6a21\u578b\u002f\u670d\u52a1\u5546\u3002' : 'API returned empty response: content was filtered. Adjust the prompt or use a model/provider that allows it.';
    }
    if (finish === 'length') {
      return zh ? '\u0041\u0050\u0049 \u8fd4\u56de\u7a7a\u54cd\u5e94\uff1a\u8f93\u51fa\u957f\u5ea6\u4e0d\u8db3\uff0c\u5df2\u8fbe\u5230 max_tokens\u3002\u8bf7\u5728\u8bbe\u7f6e\u91cc\u63d0\u9ad8\u201c\u6700\u5927\u8f93\u51fa\u957f\u5ea6\u201d\uff0c\u6216\u964d\u4f4e\u5355\u6b21\u5267\u60c5\u8981\u6c42\u3002' : 'API returned empty response: max_tokens was reached. Increase max output length or shorten the request.';
    }
    if (finish) {
      return zh ? ('\u0041\u0050\u0049 \u8fd4\u56de\u7a7a\u54cd\u5e94\uff1afinish_reason=' + finish) : ('API returned empty response: finish_reason=' + finish);
    }
    return zh ? '\u0041\u0050\u0049 \u8fd4\u56de\u7a7a\u54cd\u5e94\uff1a\u63a5\u53e3\u6ca1\u6709\u8fd4\u56de\u53ef\u8bfb\u53d6\u6587\u672c\u3002\u8bf7\u68c0\u67e5\u6a21\u578b\u662f\u5426\u652f\u6301 OpenAI \u517c\u5bb9 chat/completions\uff0c\u6216\u5728\u8bbe\u7f6e\u4e2d\u66f4\u6362\u6a21\u578b\u3002' : 'API returned empty response: no readable text. Check whether the model supports OpenAI-compatible chat/completions or switch models.';
  }

  function emptyResponseDetail(payload, maxLen, opts) {
    maxLen = maxLen || 200;
    try {
      return safeJsonStringify({
        id: payload && payload.id,
        model: payload && payload.model,
        finish_reason: extractFinishReason(payload, opts),
        usage: payload && payload.usage
      }).slice(0, maxLen);
    } catch (_) {
      return '';
    }
  }

  function selectEndpointAndModel(cfg, opts, defaults) {
    cfg = cfg || {};
    opts = opts || {};
    defaults = defaults || {};
    var caps = opts.providerCapabilities || opts.capabilities || {};
    var useHighQuality = !!(opts.highQuality || opts.quality === 'high') && Number(cfg.highQualityMode || 0) > 0;
    var endpoint = useHighQuality ? (cfg.highQualityEndpoint || cfg.endpoint || '') : (cfg.endpoint || '');
    var model = useHighQuality ? (cfg.highQualityModel || cfg.model || defaults.highQualityModel) : (cfg.model || defaults.model);
    var rawEndpoint = endpoint;
    var baseEndpoint = normalizeBaseEndpoint(endpoint);
    endpoint = normalizeChatEndpoint(endpoint, { chatPath: caps.chatPath });
    return {
      endpoint: endpoint,
      rawEndpoint: rawEndpoint,
      baseEndpoint: baseEndpoint,
      modelsEndpoint: normalizeModelsEndpoint(rawEndpoint, { modelsPath: caps.modelsPath }),
      model: model,
      useHighQuality: useHighQuality,
      providerCapabilities: caps
    };
  }

  function addIfPresent(body, key, value) {
    if (value == null || value === '') return;
    if (typeof value === 'number' && !isFinite(value)) return;
    body[key] = value;
  }

  function buildChatBody(cfg, opts, defaults) {
    cfg = cfg || {};
    opts = opts || {};
    defaults = defaults || {};
    var selected = selectEndpointAndModel(cfg, opts, defaults);
    var caps = selected.providerCapabilities || {};
    var requestBodyStyle = String(caps.requestBodyStyle || 'openai-chat-completions');
    var body = {
      model: selected.model,
      messages: opts.messages || []
    };
    addIfPresent(body, 'temperature', (opts.temperature != null) ? opts.temperature : cfg.temperature);
    addIfPresent(body, 'max_tokens', (opts.max_tokens != null) ? opts.max_tokens : cfg.max_tokens);
    if (opts.stream != null) body.stream = !!opts.stream;
    else if (!opts.omitStreamFlag && requestBodyStyle !== 'google-openai-chat-completions') body.stream = false;
    applyProviderOptions(body, selected.endpoint, selected.model, opts);
    return Object.assign(selected, { body: body, requestBodyStyle: requestBodyStyle });
  }

  function buildHeaders(apiKey, extraHeaders) {
    var headers = Object.assign({ 'Content-Type': 'application/json', 'Accept': 'application/json' }, extraHeaders || {});
    if (apiKey) headers.Authorization = 'Bearer ' + apiKey;
    return headers;
  }

  function parseJsonMaybe(text) {
    if (!text) return null;
    try { return safeJsonParse(text); } catch (_) { return null; }
  }

  function normalizeModelId(value) {
    return String(value == null ? '' : value).trim();
  }

  function collectModelIdsFromValue(value, out, depth) {
    if (value == null || depth > 4) return;
    out = out || [];
    if (typeof value === 'string' || typeof value === 'number') {
      var raw = normalizeModelId(value);
      if (raw && out.indexOf(raw) === -1) out.push(raw);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach(function (item) { collectModelIdsFromValue(item, out, depth + 1); });
      return;
    }
    if (typeof value !== 'object') return;
    var direct = value.id || value.name || value.model || value.slug;
    if (direct) collectModelIdsFromValue(direct, out, depth + 1);
    ['data', 'models', 'items', 'result', 'available_models'].forEach(function (key) {
      if (value[key] != null) collectModelIdsFromValue(value[key], out, depth + 1);
    });
  }

  function extractModelIds(payload) {
    var out = [];
    collectModelIdsFromValue(payload, out, 0);
    return out;
  }

  function modelMatches(requestedModel, modelIds) {
    var requested = normalizeModelId(requestedModel);
    if (!requested || !Array.isArray(modelIds) || !modelIds.length) return false;
    var lower = requested.toLowerCase();
    return modelIds.some(function (id) {
      return normalizeModelId(id).toLowerCase() === lower;
    });
  }

  function suggestModels(requestedModel, modelIds, limit) {
    limit = limit || 8;
    var requested = normalizeModelId(requestedModel);
    var ids = Array.isArray(modelIds) ? modelIds.slice() : [];
    if (!ids.length) return [];
    var requestedLower = requested.toLowerCase();
    var tokens = requestedLower.split(/[^a-z0-9]+/i).filter(function (x) { return x && x.length >= 2; });
    var ranked = ids.map(function (id, index) {
      var text = normalizeModelId(id);
      var lower = text.toLowerCase();
      var score = 0;
      if (requestedLower && lower === requestedLower) score += 1000;
      if (requestedLower && (lower.indexOf(requestedLower) !== -1 || requestedLower.indexOf(lower) !== -1)) score += 200;
      tokens.forEach(function (token) {
        if (lower.indexOf(token) !== -1) score += token.length * 6;
      });
      if (/deepseek/i.test(requested) && /deepseek/i.test(text)) score += 60;
      if (/gemini/i.test(requested) && /gemini/i.test(text)) score += 60;
      if (/qwen/i.test(requested) && /qwen/i.test(text)) score += 60;
      if (/flash/i.test(requested) && /flash/i.test(text)) score += 20;
      if (/pro/i.test(requested) && /pro/i.test(text)) score += 20;
      return { id: text, score: score, index: index };
    }).filter(function (item) { return item.id; });
    ranked.sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return a.index - b.index;
    });
    return ranked.slice(0, limit).map(function (item) { return item.id; });
  }

  function buildModelProbe(payload, requestedModel, opts) {
    opts = opts || {};
    var ids = extractModelIds(payload);
    var found = modelMatches(requestedModel, ids);
    return {
      checked: true,
      requestedModel: normalizeModelId(requestedModel),
      modelFound: found,
      modelCount: ids.length,
      models: ids.slice(0, opts.keepLimit || 40),
      candidates: found ? [] : suggestModels(requestedModel, ids, opts.suggestionLimit || 8)
    };
  }

  function buildHttpError(status, bodyText) {
    var parsed = parseJsonMaybe(bodyText);
    var detail = responseErrorText(parsed) || String(bodyText || '').slice(0, 500);
    var err = new Error('HTTP ' + status + (detail ? ' ' + detail : ''));
    err.status = status;
    err.statusCode = status;
    err.responseBody = parsed || bodyText || '';
    return err;
  }

  var ApiClientModule = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    getPathValue: getPathValue,
    firstPathValue: firstPathValue,
    contentToText: contentToText,
    responseErrorText: responseErrorText,
    extractResponseText: extractResponseText,
    extractFinishReason: extractFinishReason,
    normalizeEndpointForPath: normalizeEndpointForPath,
    normalizeBaseEndpoint: normalizeBaseEndpoint,
    normalizeChatEndpoint: normalizeChatEndpoint,
    normalizeModelsEndpoint: normalizeModelsEndpoint,
    isLocalEndpoint: isLocalEndpoint,
    shouldDisableThinking: shouldDisableThinking,
    applyProviderOptions: applyProviderOptions,
    safeJsonStringify: safeJsonStringify,
    safeJsonParse: safeJsonParse,
    sanitizeForApiJSON: sanitizeForApiJSON,
    safeFetch: safeFetch,
    normalizeFetchInit: normalizeFetchInit,
    nativeJsonCapturedAt: nativeJSON.capturedAt || 'module_load',
    emptyResponseMessage: emptyResponseMessage,
    emptyResponseDetail: emptyResponseDetail,
    selectEndpointAndModel: selectEndpointAndModel,
    buildChatBody: buildChatBody,
    buildHeaders: buildHeaders,
    parseJsonMaybe: parseJsonMaybe,
    extractModelIds: extractModelIds,
    modelMatches: modelMatches,
    suggestModels: suggestModels,
    buildModelProbe: buildModelProbe,
    buildHttpError: buildHttpError
  };

  root.AIStoryGen.ApiClientModule = ApiClientModule;
  root.AIStoryGenApiClientModule = ApiClientModule;
})(typeof window !== 'undefined' ? window : globalThis);
