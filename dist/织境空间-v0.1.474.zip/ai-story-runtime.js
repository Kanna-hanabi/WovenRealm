/* ============================================================
 * AIStoryGen story runtime helpers
 * Pure helpers for choice parsing and prompt/runtime plumbing.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  function hasChoiceTimeAnnotation(text) {
    return /\(\s*\d+\s*:\s*\d{1,2}\s*\)\s*$/.test(String(text || ''));
  }

  function cleanChoiceText(text, opts) {
    opts = opts || {};
    text = String(text == null ? '' : text).trim();
    if (!text) return '';
    text = stripChoiceLinePrefix(text)
      .replace(/^(?:选项|choice)\s*\d*\s*[:：-]\s*/i, '')
      .replace(/^["'“”‘’]|["'“”‘’]$/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!text) return '';

    if (/^\s*(?:\[\/?(?:AI_|STATS|ITEMS?|LOC|REL|MEMORY|SCENE)|<|```)/i.test(text)) return '';
    if (/\[(?:AI_META|AI_EVENT|STATS|ITEMS?|AI_ITEMS_USED|LOC|RELATIONSHIP|MEMORY)[\s:\]]/i.test(text)) return '';
    if (/^(?:summary|eventType|location|targetLocation|locationStatus|sceneFocus|environmentDescription|visualAction|characters|presentCharacters|presentEntities|sexTargets|memoryTags|memoryImportance|itemsGained|itemsLost|moneyChange|statChanges|relationshipChanges)\s*=/i.test(text)) return '';
    if (/^(?:你决定|你可以|以下|正文|剧情|选项|返回结果|输出|json|you decide)\s*[:：]?\s*$/i.test(text)) return '';
    if (/^(?:here are(?: choices?)?|sure|ok|based on|the choices|return only|output|json|instruction|choices?)\s*[:：-]?\s*$/i.test(text)) return '';

    var timeAnnotated = hasChoiceTimeAnnotation(text);
    var maxLength = Number(opts.maxChoiceLength || 96);
    if (!timeAnnotated && text.length > 52) return '';
    if (text.length > maxLength) return '';

    var sentenceMarks = (text.match(/[。！？.!?]/g) || []).length;
    if (sentenceMarks > (timeAnnotated ? 2 : 1)) return '';
    return text;
  }

  function normalizeChoiceValue(item) {
    if (item == null) return '';
    if (Array.isArray(item)) {
      var parts = item.map(function (x) {
        return String(x == null ? '' : x).replace(/\s+/g, ' ').trim();
      }).filter(Boolean);
      if (!parts.length) return '';
      var time = '';
      var text = '';
      parts.forEach(function (part) {
        if (!time && /^\(?\s*\d+\s*:\s*\d{1,2}\s*\)?$/.test(part)) {
          time = part.charAt(0) === '(' ? part : '(' + part + ')';
        } else if (!text || part.length > text.length) {
          text = part;
        }
      });
      if (!text) text = parts.filter(function (part) { return part !== time; }).join(' ');
      return [text, time].filter(Boolean).join(' ');
    }
    if (typeof item === 'object') {
      var textValue = item.choice || item.text || item.label || item.action || item.option || item.title || item.name || '';
      var timeValue = item.time || item.duration || item.cost || item.minutes || '';
      textValue = String(textValue == null ? '' : textValue).replace(/\s+/g, ' ').trim();
      timeValue = String(timeValue == null ? '' : timeValue).replace(/\s+/g, ' ').trim();
      if (timeValue && /^\d+$/.test(timeValue)) timeValue = '0:' + String(timeValue).padStart(2, '0');
      if (timeValue && !/^\(/.test(timeValue)) timeValue = '(' + timeValue + ')';
      return [textValue, timeValue].filter(Boolean).join(' ');
    }
    return String(item);
  }

  function normalizeChoiceArray(value, opts) {
    opts = opts || {};
    var maxChoices = Math.max(2, Number(opts.maxChoices || 5));
    if (!Array.isArray(value) || value.length < 2) return null;
    var localize = typeof opts.localizeChoice === 'function' ? opts.localizeChoice : null;
    var arr = value.slice(0, maxChoices).map(function (item) {
      var text = cleanChoiceText(normalizeChoiceValue(item), opts);
      if (localize && text) text = localize(text);
      return cleanChoiceText(text, opts);
    }).filter(Boolean);
    return arr.length >= 2 ? arr : null;
  }

  function parseChoiceArray(content, opts) {
    opts = opts || {};
    var text = String(content || '').trim();
    var parsed;
    function normalize(value) {
      if (typeof opts.normalizeChoiceArray === 'function') return opts.normalizeChoiceArray(value);
      return normalizeChoiceArray(value, opts);
    }

    try {
      parsed = JSON.parse(text);
      var direct = normalize(parsed);
      if (direct) return direct;
    } catch (_) {}

    var fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fenceMatch) {
      try {
        parsed = JSON.parse(fenceMatch[1].trim());
        var fenced = normalize(parsed);
        if (fenced) return fenced;
      } catch (_) {}
    }

    var candidates = [];
    var start = -1;
    var depth = 0;
    var inString = false;
    var escape = false;
    for (var i = 0; i < text.length; i++) {
      var ch = text.charAt(i);
      if (inString) {
        if (escape) { escape = false; continue; }
        if (ch === '\\') { escape = true; continue; }
        if (ch === '"') inString = false;
        continue;
      }
      if (ch === '"') { inString = true; continue; }
      if (ch === '[') {
        if (depth === 0) start = i;
        depth++;
      } else if (ch === ']' && depth > 0) {
        depth--;
        if (depth === 0 && start >= 0) {
          candidates.push(text.slice(start, i + 1));
          start = -1;
        }
      }
    }
    for (var ci = candidates.length - 1; ci >= 0; ci--) {
      try {
        parsed = JSON.parse(candidates[ci]);
        var found = normalize(parsed);
        if (found) return found;
      } catch (_) {}
    }
    return null;
  }

  function stripChoiceLinePrefix(line) {
    return String(line || '')
      .replace(/^\(\s*\d+\s*\)\s*/, '')
      .replace(/^\d+[\.\)\u3001]\s*/, '')
      .replace(/^[-*\u2022]\s*/, '')
      .replace(/^["']|["']$/g, '')
      .trim();
  }

  function extractFallbackChoices(content, opts) {
    opts = opts || {};
    var maxChoices = Math.max(2, Number(opts.maxChoices || 5));
    var text = String(content || '');
    var lineChoices = text.split(/\r?\n/)
      .map(function (line) { return cleanChoiceText(line, opts); })
      .filter(function (line) {
        return line.length > 3;
      })
      .slice(0, maxChoices);
    if (lineChoices.length >= 2) return lineChoices;

    var sentenceChoices = text.split(/[.\u3002\uff01!\uff1f?]\s*/)
      .map(function (line) { return cleanChoiceText(line, opts); })
      .filter(function (line) { return line.length > 5; })
      .slice(0, maxChoices);
    return sentenceChoices.length >= 2 ? sentenceChoices : null;
  }

  function parseChoicesOrFallback(content, opts) {
    return parseChoiceArray(content, opts) || extractFallbackChoices(content, opts);
  }

  function parseChoiceTimeParts(text) {
    if (!text) return null;
    var m = String(text || '').match(/\(?\(\s*(\d+)\s*:\s*(\d{1,2})\s*\)\)?\s*$/);
    if (!m) return null;
    var hours = Math.max(0, parseInt(m[1], 10) || 0);
    var minutes = Math.max(0, Math.min(59, parseInt(m[2], 10) || 0));
    return { hours: hours, minutes: minutes, total: (hours * 60) + minutes };
  }

  function parseTimeFromChoice(text) {
    var parts = parseChoiceTimeParts(text);
    return parts ? parts.total : 0;
  }

  function stripTimeFromChoice(text) {
    return String(text || '').replace(/\s*\(?\(\s*\d+\s*:\s*\d{1,2}\s*\)\)?\s*$/, '').trim();
  }

  function formatChoiceTime(totalMinutes) {
    var total = Math.max(0, Math.round(Number(totalMinutes || 0)));
    var hours = Math.floor(total / 60);
    var minutes = total % 60;
    return hours + ':' + String(minutes).padStart(2, '0');
  }

  function buildChoiceTextWithTime(text, totalMinutes) {
    return stripTimeFromChoice(text) + ' (' + formatChoiceTime(totalMinutes) + ')';
  }

  function inferChoiceTimeBounds(text) {
    var raw = String(text || '').toLowerCase();
    var compact = raw.replace(/\s+/g, '');
    if (!compact) return { min: 1, max: 60, fallback: 5, reason: 'default' };
    if (/(\u6d17.{0,3}\u6fa1|\u6c90\u6d74|\u6dcb\u6d74|\u6ce1.{0,3}\u6fa1|\u51b2.{0,3}\u6fa1|bath|shower)/i.test(raw)) {
      return { min: 15, max: 45, fallback: 20, reason: 'wash' };
    }
    if (/(\u7761\u89c9|\u5165\u7761|\u5c0f\u7761|\u7761\u4e00\u4f1a|\u8fc7\u591c|sleep|nap)/i.test(raw)) {
      return { min: 30, max: 480, fallback: 120, reason: 'sleep' };
    }
    if (/(\u4f11\u606f|\u7b49\u5f85|\u53d1\u5446|\u8eba\u4e0b|\u5750\u4e0b|rest|wait|relax)/i.test(raw)) {
      return { min: 5, max: 120, fallback: 15, reason: 'rest' };
    }
    if (/(\u524d\u5f80|\u53bb\u5f80|\u8d70\u5230|\u5230\u8fbe|\u62b5\u8fbe|\u79bb\u5f00|\u8fd4\u56de|\u56de\u5230|\u8fdb\u5165|\u7a7f\u8fc7|\u8d76\u5230|\u79fb\u52a8|travel|walk to|go to|return to|enter|arrive|leave)/i.test(raw)) {
      return { min: 5, max: 90, fallback: 10, reason: 'move' };
    }
    if (/(\u804a\u5929|\u4ea4\u8c08|\u8be2\u95ee|\u95ee|\u544a\u8bc9|\u6253\u62db\u547c|\u642d\u8baa|talk|chat|ask|tell|greet)/i.test(raw)) {
      return { min: 3, max: 45, fallback: 10, reason: 'talk' };
    }
    if (/(\u67e5\u770b|\u89c2\u5bdf|\u68c0\u67e5|\u641c\u7d22|\u5bfb\u627e|\u7ffb\u627e|\u8c03\u67e5|look|inspect|search|examine)/i.test(raw)) {
      return { min: 2, max: 30, fallback: 5, reason: 'inspect' };
    }
    if (/(\u62ff\u8d77|\u62fe\u8d77|\u6361\u8d77|\u53d6\u51fa|\u62ff\u8d70|\u6536\u8d77|\u91c7\u6458|\u91c7\u96c6|\u6458|pick up|take|grab|collect|gather)/i.test(raw)) {
      return { min: 1, max: 10, fallback: 5, reason: 'quick_item' };
    }
    if (/(\u8dd1\u6b65|\u953b\u70bc|\u6e38\u6cf3|\u8bad\u7ec3|\u7ec3\u4e60|exercise|train|swim|jog|run)/i.test(raw)) {
      return { min: 10, max: 90, fallback: 20, reason: 'exercise' };
    }
    return { min: 1, max: 120, fallback: 5, reason: 'default' };
  }

  function normalizeChoiceTimeCost(text, minutes, opts) {
    opts = opts || {};
    var n = Math.round(Number(minutes));
    var bounds = inferChoiceTimeBounds(text);
    if (!isFinite(n) || isNaN(n) || n <= 0) n = bounds.fallback;
    if (opts.allowLong === true) return Math.max(0, n);
    if (n < bounds.min) n = bounds.min;
    if (n > bounds.max) n = bounds.max;
    return n;
  }

  function normalizeChoiceTimeAnnotation(choice, opts) {
    var base = stripTimeFromChoice(choice);
    var parsed = parseChoiceTimeParts(choice);
    var minutes = parsed ? parsed.total : 0;
    return buildChoiceTextWithTime(base, normalizeChoiceTimeCost(base, minutes, opts));
  }

  var StoryRuntimeModule = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    cleanChoiceText: cleanChoiceText,
    normalizeChoiceArray: normalizeChoiceArray,
    parseChoiceArray: parseChoiceArray,
    stripChoiceLinePrefix: stripChoiceLinePrefix,
    extractFallbackChoices: extractFallbackChoices,
    parseChoicesOrFallback: parseChoicesOrFallback,
    parseChoiceTimeParts: parseChoiceTimeParts,
    parseTimeFromChoice: parseTimeFromChoice,
    stripTimeFromChoice: stripTimeFromChoice,
    formatChoiceTime: formatChoiceTime,
    buildChoiceTextWithTime: buildChoiceTextWithTime,
    inferChoiceTimeBounds: inferChoiceTimeBounds,
    normalizeChoiceTimeCost: normalizeChoiceTimeCost,
    normalizeChoiceTimeAnnotation: normalizeChoiceTimeAnnotation
  };

  root.AIStoryGen.StoryRuntimeModule = StoryRuntimeModule;
  root.AIStoryGenStoryRuntimeModule = StoryRuntimeModule;
})(typeof window !== 'undefined' ? window : globalThis);
