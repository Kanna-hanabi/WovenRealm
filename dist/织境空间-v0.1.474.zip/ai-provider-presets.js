/* ============================================================
 * AIStoryGen provider presets
 * Centralizes known OpenAI-compatible endpoint/model presets,
 * lightweight diagnostics, and actionable repair advice.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 5;

  var PRESETS = {
    custom: {
      id: 'custom',
      label: '自定义 / 手动填写',
      endpoint: '',
      model: '',
      highQualityEndpoint: '',
      highQualityModel: '',
      note: '不自动改动接口地址或模型。适合其他 OpenAI 兼容服务。'
    },
    deepseek: {
      id: 'deepseek',
      label: 'DeepSeek 官方',
      endpoint: 'https://api.deepseek.com/v1',
      model: 'deepseek-v4-flash',
      highQualityEndpoint: 'https://api.deepseek.com/v1',
      highQualityModel: 'deepseek-v4-pro',
      note: '使用 DeepSeek 官方 OpenAI 兼容接口。'
    },
    siliconflow: {
      id: 'siliconflow',
      label: '硅基流动 SiliconFlow',
      endpoint: 'https://api.siliconflow.cn/v1',
      model: 'deepseek-ai/DeepSeek-V4-Flash',
      highQualityEndpoint: 'https://api.siliconflow.cn/v1',
      highQualityModel: 'deepseek-ai/DeepSeek-V4-Pro',
      note: '硅基流动模型名必须使用平台模型 ID，例如 deepseek-ai/DeepSeek-V4-Flash。'
    },
    openrouter: {
      id: 'openrouter',
      label: 'OpenRouter',
      endpoint: 'https://openrouter.ai/api/v1',
      model: 'openrouter/auto',
      highQualityEndpoint: 'https://openrouter.ai/api/v1',
      highQualityModel: 'openrouter/auto',
      note: 'OpenRouter 使用模型 slug；openrouter/auto 可由平台自动路由。'
    },
    gemini: {
      id: 'gemini',
      label: 'Google Gemini OpenAI 兼容',
      endpoint: 'https://generativelanguage.googleapis.com/v1beta/openai',
      model: 'gemini-3.5-flash',
      highQualityEndpoint: 'https://generativelanguage.googleapis.com/v1beta/openai',
      highQualityModel: 'gemini-3.5-flash',
      note: 'Gemini OpenAI 兼容接口使用 Google AI Studio 的 Gemini API Key。'
    },
    local: {
      id: 'local',
      label: '本地 / 局域网兼容端点',
      endpoint: 'http://127.0.0.1:11434/v1',
      model: 'local-model',
      highQualityEndpoint: 'http://127.0.0.1:11434/v1',
      highQualityModel: 'local-model',
      note: '适合 Ollama、LM Studio、LocalAI 等本地 OpenAI 兼容端点，通常可留空 API Key。'
    }
  };

  var ORDER = ['custom', 'deepseek', 'siliconflow', 'openrouter', 'gemini', 'local'];

  var CAPABILITIES = {
    custom: {
      supportsModelsEndpoint: 'unknown',
      supportsTemperature: true,
      supportsThinkingDisable: false,
      recommendedHeaders: [],
      note: '自定义端点能力未知；测试连接会尽量探测模型列表，失败后继续测试聊天接口。'
    },
    deepseek: {
      supportsModelsEndpoint: true,
      supportsTemperature: true,
      supportsThinkingDisable: true,
      recommendedHeaders: [],
      note: 'DeepSeek 官方兼容 OpenAI chat/completions；DeepSeek-V4 系列默认禁用 thinking 以减少兼容问题。'
    },
    siliconflow: {
      supportsModelsEndpoint: true,
      supportsTemperature: true,
      supportsThinkingDisable: false,
      recommendedHeaders: [],
      note: '硅基流动模型名必须使用平台模型 ID；如果模型不存在，优先参考 /models 候选。'
    },
    openrouter: {
      supportsModelsEndpoint: true,
      supportsTemperature: true,
      supportsThinkingDisable: false,
      recommendedHeaders: ['HTTP-Referer', 'X-Title'],
      note: 'OpenRouter 建议附带 HTTP-Referer 和 X-Title，方便平台识别应用来源。'
    },
    gemini: {
      supportsModelsEndpoint: true,
      supportsTemperature: true,
      supportsThinkingDisable: false,
      recommendedHeaders: [],
      note: 'Gemini OpenAI 兼容端点通常需要 /v1beta/openai 路径。'
    },
    local: {
      supportsModelsEndpoint: 'unknown',
      supportsTemperature: true,
      supportsThinkingDisable: false,
      recommendedHeaders: [],
      note: '本地兼容端点能力取决于 Ollama、LM Studio、LocalAI 等具体实现。'
    }
  };

  var CAPABILITY_MATRIX = {
    custom: {
      apiShape: 'openai-compatible',
      authScheme: 'bearer-or-provider-specific',
      endpointStyle: 'unknown',
      recommendedBaseEndpoint: '',
      chatPath: '/chat/completions',
      modelsPath: '/models',
      modelNameHint: '使用服务商文档中的完整模型 ID。',
      common404Hint: '通常是端点路径或模型名不匹配；先确认是 /v1 还是 /chat/completions。'
    },
    deepseek: {
      apiShape: 'openai-compatible',
      authScheme: 'bearer',
      endpointStyle: 'base-v1-or-chat-completions',
      recommendedBaseEndpoint: 'https://api.deepseek.com/v1',
      chatPath: '/chat/completions',
      modelsPath: '/models',
      modelNameHint: '使用 DeepSeek 官方模型名，例如 deepseek-v4-flash。',
      common404Hint: '多数情况是模型名不存在或当前 Key 没有该模型权限。'
    },
    siliconflow: {
      apiShape: 'openai-compatible',
      authScheme: 'bearer',
      endpointStyle: 'base-v1-or-chat-completions',
      recommendedBaseEndpoint: 'https://api.siliconflow.cn/v1',
      chatPath: '/chat/completions',
      modelsPath: '/models',
      modelNameHint: '必须使用平台模型 ID，常见格式是 vendor/model，例如 deepseek-ai/DeepSeek-V4-Flash。',
      common404Hint: '通常是模型 ID 不在平台列表或写成了官方模型名；先用 /models 获取候选。'
    },
    openrouter: {
      apiShape: 'openai-compatible-router',
      authScheme: 'bearer',
      endpointStyle: 'base-v1-or-chat-completions',
      recommendedBaseEndpoint: 'https://openrouter.ai/api/v1',
      chatPath: '/chat/completions',
      modelsPath: '/models',
      modelNameHint: '使用 OpenRouter slug，例如 openrouter/auto 或平台列表中的 provider/model。',
      common404Hint: '通常是 slug 不存在、路径不是 /api/v1，或路由模型暂时不可用。'
    },
    gemini: {
      apiShape: 'gemini-openai-compatible',
      authScheme: 'bearer',
      endpointStyle: 'google-openai-compat',
      recommendedBaseEndpoint: 'https://generativelanguage.googleapis.com/v1beta/openai',
      chatPath: '/chat/completions',
      modelsPath: '/models',
      modelNameHint: '使用 Gemini OpenAI 兼容模型名，例如 gemini-2.5-flash 或当前平台支持的 gemini-* ID。',
      common404Hint: '通常是端点缺少 /v1beta/openai，或模型名不是 OpenAI 兼容层支持的 ID。'
    },
    local: {
      apiShape: 'openai-compatible-local',
      authScheme: 'optional-bearer',
      endpointStyle: 'local-base-v1',
      recommendedBaseEndpoint: 'http://127.0.0.1:11434/v1',
      chatPath: '/chat/completions',
      modelsPath: '/models',
      modelNameHint: '使用本地服务中已加载的模型名，不同后端差异很大。',
      common404Hint: '通常是本地服务未启动、路径不兼容或模型未加载。'
    }
  };

  var DEFAULT_COMPATIBILITY = {
    requestBodyStyle: 'openai-chat-completions',
    responseTextPaths: ['choices[0].message.content', 'choices[0].text', 'output_text'],
    finishReasonPaths: ['choices[0].finish_reason', 'choices[0].finishReason'],
    modelListPaths: ['data[].id', 'data[].name', 'models[].id', 'items[].id', 'available_models[]'],
    supportsSystemMessages: true,
    supportsJsonResponseFormat: 'unknown',
    requiresOpenAICompatPath: false,
    extraHeadersAutoAdded: false
  };

  var COMPATIBILITY_OVERRIDES = {
    openrouter: {
      extraHeadersAutoAdded: true,
      routingModelSupported: true,
      responseTextPaths: ['choices[0].message.content', 'choices[0].text'],
      modelListPaths: ['data[].id', 'data[].name', 'data[].slug']
    },
    gemini: {
      requestBodyStyle: 'google-openai-chat-completions',
      requiresOpenAICompatPath: true,
      responseTextPaths: ['choices[0].message.content', 'choices[0].text'],
      modelListPaths: ['data[].id', 'models[].name', 'models[].id']
    },
    local: {
      requestBodyStyle: 'openai-compatible-local',
      modelListPaths: ['data[].id', 'models[].name', 'models[].model', 'available_models[]']
    }
  };

  function normalizeProviderId(id) {
    id = String(id || '').trim().toLowerCase();
    if (id === 'silicon' || id === 'silicon-flow' || id === 'sf') return 'siliconflow';
    if (id === 'google' || id === 'google-gemini') return 'gemini';
    if (id === 'open-router') return 'openrouter';
    if (id === 'ollama' || id === 'lmstudio' || id === 'lm-studio') return 'local';
    return PRESETS[id] ? id : 'custom';
  }

  function getPreset(id) {
    return PRESETS[normalizeProviderId(id)] || PRESETS.custom;
  }

  function listPresets() {
    return ORDER.map(function (id) {
      var p = PRESETS[id];
      return {
        id: p.id,
        label: p.label,
        endpoint: p.endpoint,
        model: p.model,
        highQualityEndpoint: p.highQualityEndpoint,
        highQualityModel: p.highQualityModel,
        note: p.note
      };
    });
  }

  function getSelectOptions() {
    return listPresets().map(function (p) {
      return { value: p.id, label: p.label };
    });
  }

  function getCapabilities(providerId) {
    providerId = normalizeProviderId(providerId);
    var caps = CAPABILITIES[providerId] || CAPABILITIES.custom;
    var matrix = CAPABILITY_MATRIX[providerId] || CAPABILITY_MATRIX.custom;
    var compat = Object.assign({}, DEFAULT_COMPATIBILITY, COMPATIBILITY_OVERRIDES[providerId] || {});
    return Object.assign({ provider: providerId }, matrix, compat, caps, {
      recommendedHeaders: (caps.recommendedHeaders || []).slice(),
      responseTextPaths: (compat.responseTextPaths || []).slice(),
      finishReasonPaths: (compat.finishReasonPaths || []).slice(),
      modelListPaths: (compat.modelListPaths || []).slice()
    });
  }

  function getCapabilityMatrix() {
    var out = {};
    ORDER.forEach(function (id) {
      out[id] = getCapabilities(id);
    });
    return out;
  }

  function summarizeCapabilities(providerId) {
    var caps = getCapabilities(providerId);
    return {
      provider: caps.provider,
      apiShape: caps.apiShape,
      endpointStyle: caps.endpointStyle,
      requestBodyStyle: caps.requestBodyStyle,
      authScheme: caps.authScheme,
      supportsModelsEndpoint: caps.supportsModelsEndpoint,
      supportsSystemMessages: caps.supportsSystemMessages,
      supportsJsonResponseFormat: caps.supportsJsonResponseFormat,
      requiresOpenAICompatPath: caps.requiresOpenAICompatPath,
      extraHeadersAutoAdded: caps.extraHeadersAutoAdded,
      recommendedBaseEndpoint: caps.recommendedBaseEndpoint,
      chatPath: caps.chatPath,
      modelsPath: caps.modelsPath,
      responseTextPaths: caps.responseTextPaths.slice(0, 4),
      modelListPaths: caps.modelListPaths.slice(0, 5),
      recommendedHeaders: caps.recommendedHeaders.slice()
    };
  }

  function inferProvider(endpoint, model) {
    var ep = String(endpoint || '').toLowerCase();
    var m = String(model || '').toLowerCase();
    if (/api\.deepseek\.com/.test(ep)) return 'deepseek';
    if (/api\.siliconflow\.(?:cn|com)/.test(ep)) return 'siliconflow';
    if (/openrouter\.ai/.test(ep)) return 'openrouter';
    if (/generativelanguage\.googleapis\.com/.test(ep) || /^gemini-/.test(m)) return 'gemini';
    if (/^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?\//i.test(String(endpoint || ''))) return 'local';
    return 'custom';
  }

  function resolveEffectiveProvider(cfg) {
    cfg = cfg || {};
    var selected = normalizeProviderId(cfg.apiProvider);
    var inferred = inferProvider(cfg.endpoint, cfg.model);
    var effective = selected;
    if (inferred !== 'custom' && inferred !== selected) effective = inferred;
    return {
      selected: selected,
      inferred: inferred,
      effective: effective,
      mismatch: inferred !== 'custom' && inferred !== selected
    };
  }

  function applyPresetToConfig(cfg, providerId, opts) {
    cfg = Object.assign({}, cfg || {});
    opts = opts || {};
    var preset = getPreset(providerId);
    cfg.apiProvider = preset.id;
    if (preset.id === 'custom') return cfg;
    cfg.endpoint = preset.endpoint;
    cfg.model = preset.model;
    if (opts.includeHighQuality !== false) {
      cfg.highQualityEndpoint = preset.highQualityEndpoint || preset.endpoint;
      cfg.highQualityModel = preset.highQualityModel || preset.model;
    }
    return cfg;
  }

  function normalizeConfigProvider(cfg) {
    cfg = cfg || {};
    var provider = normalizeProviderId(cfg.apiProvider);
    if (provider === 'custom' && !cfg.apiProvider) provider = inferProvider(cfg.endpoint, cfg.model);
    cfg.apiProvider = provider;
    return cfg;
  }

  function getConfigCapabilities(cfg) {
    cfg = normalizeConfigProvider(Object.assign({}, cfg || {}));
    return getCapabilities(resolveEffectiveProvider(cfg).effective);
  }

  function normalizeEndpointShape(endpoint) {
    endpoint = String(endpoint || '').trim().replace(/\/+$/, '');
    if (!endpoint) return '';
    return endpoint
      .replace(/\/chat\/completions$/i, '')
      .replace(/\/responses$/i, '')
      .replace(/\/models$/i, '');
  }

  function pushUnique(list, value, limit) {
    value = String(value || '').trim();
    if (!value || list.indexOf(value) !== -1) return;
    if (limit && list.length >= limit) return;
    list.push(value);
  }

  function getDefaultModelCandidates(providerId) {
    var preset = getPreset(providerId);
    var out = [];
    pushUnique(out, preset.model);
    pushUnique(out, preset.highQualityModel);
    if (preset.id === 'siliconflow') {
      pushUnique(out, 'deepseek-ai/DeepSeek-V4-Flash');
      pushUnique(out, 'deepseek-ai/DeepSeek-V4-Pro');
      pushUnique(out, 'deepseek-ai/DeepSeek-V3');
      pushUnique(out, 'Pro/deepseek-ai/DeepSeek-V3');
    } else if (preset.id === 'openrouter') {
      pushUnique(out, 'openrouter/auto');
    } else if (preset.id === 'deepseek') {
      pushUnique(out, 'deepseek-v4-flash');
      pushUnique(out, 'deepseek-v4-pro');
    } else if (preset.id === 'gemini') {
      pushUnique(out, 'gemini-2.5-flash');
      pushUnique(out, 'gemini-2.5-pro');
    }
    return out;
  }

  function buildProviderAdvice(cfg, probeResult, chatProbe) {
    cfg = normalizeConfigProvider(Object.assign({}, cfg || {}));
    probeResult = probeResult || {};
    chatProbe = chatProbe || null;
    var providerState = resolveEffectiveProvider(cfg);
    var selected = providerState.selected;
    var inferred = providerState.inferred;
    var preset = getPreset(selected);
    var caps = getCapabilities(selected);
    var endpoint = String(cfg.endpoint || '').trim();
    var model = String(cfg.model || '').trim();
    var lines = [];
    var severity = 'ok';
    var endpointSuggestion = '';
    var modelSuggestions = [];
    function add(level, text) {
      if (!text) return;
      pushUnique(lines, text, 8);
      if (level === 'error') severity = 'error';
      else if (level === 'warning' && severity !== 'error') severity = 'warning';
    }

    if (selected !== 'custom' && inferred !== 'custom' && inferred !== selected) {
      endpointSuggestion = getCapabilities(inferred).recommendedBaseEndpoint || getPreset(inferred).endpoint || '';
      add('warning', '当前地址更像“' + getPreset(inferred).label + '”，但设置选择的是“' + preset.label + '”。');
    }

    var currentBase = normalizeEndpointShape(endpoint);
    var recommendedBase = normalizeEndpointShape(caps.recommendedBaseEndpoint || preset.endpoint || '');
    if (!endpoint && recommendedBase) {
      endpointSuggestion = caps.recommendedBaseEndpoint || preset.endpoint;
      add('error', '接口地址为空，可一键填入推荐端点。');
    } else if (selected !== 'custom' && recommendedBase && currentBase && currentBase !== recommendedBase) {
      if ((selected === 'gemini' && !/\/openai$/i.test(currentBase)) || (selected === 'openrouter' && !/\/api\/v1$/i.test(currentBase)) || inferred === 'custom') {
        endpointSuggestion = caps.recommendedBaseEndpoint || preset.endpoint;
        add('warning', '端点格式可能不适合当前服务商，可改用推荐端点。');
      }
    }

    if (!model && preset.model) {
      pushUnique(modelSuggestions, preset.model, 8);
      add('error', '模型名为空，可一键填入服务商默认模型。');
    }

    var probe = probeResult.modelProbe || probeResult;
    if (probe && Array.isArray(probe.candidates)) {
      probe.candidates.forEach(function (candidate) { pushUnique(modelSuggestions, candidate, 8); });
    }
    if ((probeResult.status === 'model_not_found') || (probe && probe.modelCount && !probe.modelFound)) {
      getDefaultModelCandidates(selected).forEach(function (candidate) { pushUnique(modelSuggestions, candidate, 8); });
      add('error', '当前模型没有在模型列表中匹配到，可从候选模型中选择。');
    }
    if (chatProbe && !chatProbe.ok && /(?:404|model|not found|模型|找不到)/i.test(String(chatProbe.message || chatProbe.errorType || ''))) {
      getDefaultModelCandidates(selected).forEach(function (candidate) { pushUnique(modelSuggestions, candidate, 8); });
      if (caps.common404Hint) add('warning', '服务商 404 排查：' + caps.common404Hint);
    }
    if (chatProbe && /^(?:length|max_tokens|output_limit)$/i.test(String(chatProbe.finishReason || chatProbe.emptyReason || ''))) {
      add('warning', '聊天探测返回输出长度不足；请提高 max_tokens，或改用更短的测试提示词。');
    }
    return {
      schemaVersion: 1,
      provider: selected,
      inferredProvider: inferred,
      severity: severity,
      ok: severity === 'ok',
      endpointSuggestion: endpointSuggestion,
      highQualityEndpointSuggestion: endpointSuggestion,
      modelSuggestions: modelSuggestions,
      capabilitySummary: summarizeCapabilities(selected),
      lines: lines
    };
  }

  function getExtraHeaders(cfg, env) {
    cfg = normalizeConfigProvider(Object.assign({}, cfg || {}));
    var providerState = resolveEffectiveProvider(cfg);
    var caps = getCapabilities(providerState.effective);
    var headers = {};
    env = env || {};
    if (caps.provider === 'openrouter') {
      var href = String(env.href || (root.location && root.location.href) || '');
      var origin = String(env.origin || (root.location && root.location.origin) || '');
      if (!origin && href) {
        try { origin = new URL(href).origin; } catch (_) {}
      }
      headers['HTTP-Referer'] = origin || 'https://localhost';
      headers['X-Title'] = 'Woven Realm';
    }
    return headers;
  }

  function getNetworkProbeOptions(cfg, env) {
    cfg = normalizeConfigProvider(Object.assign({}, cfg || {}));
    var providerState = resolveEffectiveProvider(cfg);
    var caps = getCapabilities(providerState.effective);
    return {
      provider: caps.provider,
      selectedProvider: providerState.selected,
      inferredProvider: providerState.inferred,
      effectiveProvider: providerState.effective,
      providerMismatch: providerState.mismatch,
      capabilities: caps,
      advice: buildProviderAdvice(cfg),
      extraHeaders: getExtraHeaders(cfg, env),
      skipModelsProbe: caps.supportsModelsEndpoint === false
    };
  }

  function getDiagnostic(cfg) {
    cfg = normalizeConfigProvider(Object.assign({}, cfg || {}));
    var providerState = resolveEffectiveProvider(cfg);
    var inferred = providerState.inferred;
    var selected = providerState.selected;
    var effective = providerState.effective;
    var preset = getPreset(selected);
    var endpoint = String(cfg.endpoint || '');
    var model = String(cfg.model || '');
    var warnings = [];
    if (selected !== 'custom' && inferred !== 'custom' && inferred !== selected) {
      warnings.push('当前接口地址看起来像“' + getPreset(inferred).label + '”，但预设选择为“' + preset.label + '”。');
    }
    if (selected !== 'custom' && !endpoint) warnings.push('已选择服务商预设，但接口地址为空。');
    if (selected !== 'custom' && !model) warnings.push('已选择服务商预设，但模型为空。');
    if (selected === 'gemini' && endpoint && !/\/openai(?:\/|$)/i.test(endpoint)) {
      warnings.push('Gemini OpenAI 兼容端点通常需要包含 /v1beta/openai。');
    }
    if (selected === 'openrouter' && endpoint && !/\/api\/v1(?:\/|$)/i.test(endpoint)) {
      warnings.push('OpenRouter 端点通常是 https://openrouter.ai/api/v1。');
    }
    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      selected: selected,
      selectedLabel: preset.label,
      inferred: inferred,
      inferredLabel: getPreset(inferred).label,
      effective: effective,
      effectiveLabel: getPreset(effective).label,
      providerMismatch: providerState.mismatch,
      endpoint: endpoint,
      model: model,
      presetNote: preset.note,
      capabilities: getCapabilities(effective),
      capabilitySummary: summarizeCapabilities(effective),
      advice: buildProviderAdvice(cfg),
      warnings: warnings
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    presets: listPresets(),
    normalizeProviderId: normalizeProviderId,
    getPreset: getPreset,
    listPresets: listPresets,
    getSelectOptions: getSelectOptions,
    getCapabilities: getCapabilities,
    getCapabilityMatrix: getCapabilityMatrix,
    summarizeCapabilities: summarizeCapabilities,
    resolveEffectiveProvider: resolveEffectiveProvider,
    getConfigCapabilities: getConfigCapabilities,
    getExtraHeaders: getExtraHeaders,
    getNetworkProbeOptions: getNetworkProbeOptions,
    getDefaultModelCandidates: getDefaultModelCandidates,
    buildProviderAdvice: buildProviderAdvice,
    inferProvider: inferProvider,
    applyPresetToConfig: applyPresetToConfig,
    normalizeConfigProvider: normalizeConfigProvider,
    getDiagnostic: getDiagnostic
  };

  root.ProviderPresetsModule = api;
  root.AIStoryGenProviderPresetsModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
