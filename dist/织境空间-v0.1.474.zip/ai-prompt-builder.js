/* ============================================================
 * AIStoryGen prompt builder
 * Centralized prompt contract snippets for AI_EVENT, location
 * metadata, and high-risk structured output rules.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 5;

  function clean(value) {
    return String(value == null ? '' : value).trim();
  }

  function cleanLine(value, limit) {
    var text = clean(value).replace(/\s+/g, ' ');
    if (limit && text.length > limit) text = text.slice(0, limit).trim();
    return text;
  }

  function cloneValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function compactStatusEntry(entry) {
    if (!entry || typeof entry !== 'object') return entry;
    var out = {};
    ['value', 'max', 'ratio', 'level', 'label'].forEach(function (key) {
      if (entry[key] != null && entry[key] !== '') out[key] = entry[key];
    });
    return out;
  }

  function compactStatusDetail(detail) {
    detail = detail || {};
    var out = {};
    ['arousal', 'stress', 'trauma', 'control', 'pain', 'tiredness', 'hunger', 'awareness', 'lewdness'].forEach(function (key) {
      if (detail[key] != null) out[key] = compactStatusEntry(detail[key]);
    });
    var effects = {};
    Object.keys(detail.effects || {}).forEach(function (key) {
      var value = detail.effects[key];
      if (value === true || Number(value) > 0) effects[key] = value;
    });
    if (Object.keys(effects).length) out.effects = effects;
    return out;
  }

  function compactRelationshipMap(relationship) {
    var out = {};
    Object.keys(relationship || {}).forEach(function (key) {
      var value = relationship[key];
      if (value && typeof value === 'object') {
        out[key] = {};
        if (value.level != null && value.level !== '') out[key].level = value.level;
        if (value.value != null) out[key].value = value.value;
      } else if (value != null) {
        out[key] = value;
      }
    });
    return out;
  }

  function compactPresentNpc(row) {
    row = row || {};
    var out = {
      key: cleanLine(row.key || '', 80),
      name: cleanLine(row.name || row.title || row.key || '', 80),
      title: cleanLine(row.title || '', 100),
      gender: cleanLine(row.gender || '', 30),
      state: cleanLine(row.state || '', 80),
      presentSource: cleanLine(row.presentSource || '', 50),
      presentEvidence: cleanLine(row.presentEvidence || '', 180)
    };
    var relationship = compactRelationshipMap(row.relationship || row.relationships || {});
    if (!Object.keys(relationship).length) {
      ['love', 'lust', 'trust', 'dom', 'rage'].forEach(function (key) {
        if (row[key] != null) relationship[key] = row[key];
      });
    }
    if (Object.keys(relationship).length) out.relationship = relationship;
    if (row.extra && typeof row.extra === 'object') out.extra = cloneValue(row.extra);
    Object.keys(out).forEach(function (key) {
      if (out[key] === '' || out[key] == null) delete out[key];
    });
    return out;
  }

  function queryMentions(query, patterns) {
    query = cleanLine(query, 5000).toLowerCase();
    return (patterns || []).some(function (pattern) {
      return query.indexOf(String(pattern || '').toLowerCase()) >= 0;
    });
  }

  function compactSkillSummary(summary, query) {
    summary = summary || {};
    query = cleanLine(query, 5000);
    var includeGeneral = queryMentions(query, ['技能', 'skill', '潜行', '偷', '游泳', '舞', '运动', '农活', '家务', '照料']);
    var includeSchool = queryMentions(query, ['学校', '课堂', '课程', '考试', '学习', '图书馆', 'school', 'class', 'lesson', 'study', 'library']);
    var includeSex = queryMentions(query, ['亲密', '身体部位', '性', '插入', '自慰', 'intimate', 'sex']);
    var out = {};
    if (includeGeneral && summary.general) out.general = cloneValue(summary.general);
    if (includeSchool && summary.school) out.school = cloneValue(summary.school);
    if (includeSex && summary.sex) out.sex = cloneValue(summary.sex);
    return out;
  }

  function compactStateForPrompt(state, opts) {
    state = state || {};
    opts = opts || {};
    var query = cleanLine(opts.query || '', 5000);
    var out = {
      schemaVersion: MODULE_SCHEMA_VERSION,
      authority: 'mechanical_constraints_only_do_not_restate',
      world: cloneValue(state.world || {}),
      player: cloneValue(state.player || {}),
      condition: {
        stats: cloneValue(state.stats || {}),
        statusDetail: compactStatusDetail(state.statusDetail || {}),
        wornSummary: cleanLine(state.worn_summary || '', 900)
      }
    };
    if (!out.condition.wornSummary) delete out.condition.wornSummary;
    var present = (state.presentNpcDetails || []).slice(0, 6).map(compactPresentNpc);
    if (present.length) out.presentNpcDetails = present;
    if (Array.isArray(state.nearbyNpcs) && state.nearbyNpcs.length) {
      out.nearbyNpcs = state.nearbyNpcs.slice(0, 6).map(function (name) { return cleanLine(name, 100); }).filter(Boolean);
    }
    if (Array.isArray(state.nearbyNpcDetails) && state.nearbyNpcDetails.length) {
      out.nearbyNpcDetails = state.nearbyNpcDetails.slice(0, 6).map(function (row) {
        return compactPresentNpc(row);
      });
    }
    var skills = compactSkillSummary(state.skillSummary || {}, query);
    if (Object.keys(skills).length) out.relevantSkills = skills;
    if (state.pregnancy) out.pregnancy = cloneValue(state.pregnancy);
    if (state.transformations) out.transformations = cloneValue(state.transformations);
    if (queryMentions(query, ['金钱', '价格', '房租', '租金', '购买', '出售', '付款', '奖励', 'money', 'price', 'rent', 'buy', 'sell', 'pay', 'reward'])) {
      out.economy = { money: cloneValue(state.money) };
      if (state.quests) out.economy.quests = cloneValue(state.quests);
      if (state.activeQuests) out.economy.activeQuests = cloneValue(state.activeQuests);
    }
    if (queryMentions(query, ['任务', '约定', '期限', 'quest', 'appointment', 'deadline']) && state.activeQuests) {
      out.relevantQuests = cloneValue(state.activeQuests);
    }
    if (queryMentions(query, ['道具', '物品', '背包', '使用', 'item', 'inventory', 'bag', 'use']) && state.inventory) {
      out.relevantInventory = cloneValue(state.inventory);
    }
    return out;
  }

  var MEMORY_STOP_WORDS = {
    '\u73a9\u5bb6': 1, '\u5f53\u524d': 1, '\u5267\u60c5': 1, '\u5730\u70b9': 1, '\u4e8b\u4ef6': 1, '\u4f60\u7684': 1,
    '\u4e00\u4e2a': 1, '\u8fd9\u4e2a': 1, '\u4e4b\u540e': 1, '\u91cc\u9762': 1, '\u53ef\u4ee5': 1, 'current': 1, 'story': 1,
    'player': 1, 'scene': 1, 'event': 1, 'location': 1, 'passage': 1, 'the': 1, 'and': 1
  };

  function memoryTokens(value) {
    var text = cleanLine(value, 6000).toLowerCase();
    var matches = text.match(/[a-z][a-z0-9_'-]{2,}|[\u4e00-\u9fff]{2,8}/g) || [];
    var seen = {};
    return matches.filter(function (token) {
      token = token.toLowerCase();
      if (MEMORY_STOP_WORDS[token] || seen[token]) return false;
      seen[token] = 1;
      return true;
    }).slice(0, 80);
  }

  function memoryScore(entry, queryTokenMap, index, total) {
    entry = entry || {};
    var text = [entry.name, entry.tag, entry.text].join(' ');
    var tokens = memoryTokens(text);
    var score = 0;
    tokens.forEach(function (token) {
      if (queryTokenMap[token]) score += token.length >= 4 ? 4 : 2;
    });
    if (entry.locked) score += 8;
    if (/\[LTSummary\]|\u7cbe\u70bc|\u538b\u7f29\u91cd\u70b9/i.test(String(entry.name || '') + ' ' + String(entry.tag || ''))) score += 2;
    score += total > 1 ? (index / (total - 1)) * 1.5 : 1;
    return score;
  }

  function selectRelevantMemories(entries, query, opts) {
    entries = Array.isArray(entries) ? entries : [];
    opts = opts || {};
    var maxEntries = Math.max(0, Number(opts.maxEntries == null ? 6 : opts.maxEntries) || 0);
    var maxChars = Math.max(0, Number(opts.maxChars == null ? 3200 : opts.maxChars) || 0);
    if (!maxEntries || !maxChars || !entries.length) return [];
    var queryTokenMap = {};
    memoryTokens(query).forEach(function (token) { queryTokenMap[token] = 1; });
    var ranked = entries.map(function (entry, index) {
      return { entry: entry || {}, index: index, score: memoryScore(entry, queryTokenMap, index, entries.length) };
    }).filter(function (row) {
      return row.score >= 2 || row.entry.locked;
    }).sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return b.index - a.index;
    });
    if (!ranked.length) {
      ranked = entries.slice(-1).map(function (entry, offset) {
        return { entry: entry || {}, index: entries.length - 1 + offset, score: 0 };
      });
    }
    var selected = [];
    var used = 0;
    ranked.slice(0, maxEntries * 2).forEach(function (row) {
      if (selected.length >= maxEntries) return;
      var entry = row.entry || {};
      var text = cleanLine(entry.text || '', Number(opts.entryChars || 600));
      if (!text) return;
      var cost = text.length + cleanLine(entry.name || '', 100).length + 32;
      if (used + cost > maxChars && selected.length) return;
      selected.push({
        name: cleanLine(entry.name || '', 100),
        text: text,
        tag: cleanLine(entry.tag || '', 40),
        locked: !!entry.locked,
        score: Math.round(row.score * 10) / 10,
        sourceIndex: row.index
      });
      used += cost;
    });
    return selected.sort(function (a, b) { return a.sourceIndex - b.sourceIndex; });
  }

  function buildNarrativeDataPolicyBlock(language) {
    var zh = language === 'zh';
    return [
      '<narrative_data_policy>',
      zh ? '\u53ea\u6709 <scene>\u3001<current_native_page>\u3001\u5f53\u524d AI \u6b63\u6587\u548c\u73a9\u5bb6\u672c\u8f6e\u9009\u62e9\u662f\u53ef\u76f4\u63a5\u5199\u8fdb\u6b63\u6587\u7684\u5f53\u524d\u753b\u9762\u4e8b\u5b9e\u3002' : 'Only <scene>, <current_native_page>, the current AI story, and the selected action are directly narratable current-scene facts.',
      zh ? '<state> \u662f\u673a\u5236\u7ea6\u675f\uff0c\u53ea\u7528\u4e8e\u9632\u6b62\u77db\u76fe\u548c\u751f\u6210 AI_EVENT\uff1b\u7981\u6b62\u628a\u8d26\u6237\u4f59\u989d\u3001\u5c5e\u6027\u6570\u503c\u3001\u4efb\u52a1\u8ba1\u6570\u3001\u89d2\u8272\u5361\u6216\u201c\u72b6\u6001\u6570\u636e\u201d\u6210\u6bb5\u590d\u8ff0\u5230\u6b63\u6587\u3002' : '<state> is a mechanical constraint used to prevent contradictions and build AI_EVENT. Never narrate account balances, exact stat values, quest counters, character sheets, or "state data" as an exposition list.',
      zh ? '\u53ea\u6709\u73a9\u5bb6\u9009\u62e9\u6216\u5f53\u524d\u539f\u7248\u9875\u9762\u660e\u786e\u6d89\u53ca\u91d1\u94b1\u3001\u4efb\u52a1\u3001\u6280\u80fd\u6216\u7269\u54c1\u65f6\uff0c\u624d\u80fd\u5728\u6b63\u6587\u4e2d\u5199\u76f8\u5173\u7ed3\u679c\u3002' : 'Narrate money, quests, skills, or inventory only when the selected action or current native page explicitly concerns them.',
      zh ? '\u7a7f\u7740\u3001\u88c5\u5907\u3001\u7761\u7720/\u9192\u6765\u3001\u6218\u6597\u3001\u4ea4\u6613\u3001\u6d88\u8017\u7269\u54c1\u7b49\u539f\u7248\u673a\u5236\u72b6\u6001\u4ecd\u4ee5 <state> \u548c\u5f53\u524d\u539f\u7248\u9875\u9762\u4e3a\u51c6\u3002\u6ca1\u6709\u53ef\u6267\u884c\u539f\u7248\u5165\u53e3\u6216\u5df2\u6821\u9a8c\u4e8b\u52a1\u5b57\u6bb5\u65f6\uff0c\u6b63\u6587\u53ea\u80fd\u5199\u51c6\u5907\u3001\u5c1d\u8bd5\u6216\u6682\u65f6\u52a8\u4f5c\uff0c\u4e0d\u5f97\u5ba3\u79f0\u8fd9\u4e9b\u673a\u5236\u72b6\u6001\u5df2\u88ab\u6539\u5199\u3002' : 'Native mechanical state such as worn equipment, sleep/wake state, combat, transactions, and item consumption remains authoritative in <state> and the current native page. Without an executable native entry or validated transaction field, narrate only preparation, an attempt, or a temporary action; never claim that the mechanical state was changed.',
      zh ? '<recent_story> \u548c <long_term_memory> \u53ea\u63d0\u4f9b\u8fde\u7eed\u6027\uff0c\u4e0d\u8bc1\u660e\u4eba\u7269\u5f53\u524d\u5728\u573a\u3002\u4e0d\u5f97\u7f16\u9020\u5c4b\u5916\u4eba\u7269\u6b63\u5728\u505a\u4ec0\u4e48\uff1b\u53ef\u4ee5\u628a\u201c\u53bb\u67e5\u770b\u201d\u4f5c\u4e3a\u73a9\u5bb6\u884c\u52a8\uff0c\u4f46\u4e0d\u80fd\u5148\u5ba3\u5e03\u67e5\u770b\u7ed3\u679c\u3002' : 'Memory provides continuity, not current presence. Do not invent what off-screen characters are doing; offer checking on them as an action without pre-declaring the result.',
      zh ? '\u5e8a\u3001\u6905\u5b50\u3001\u7a97\u8fb9\u3001\u684c\u8fb9\u3001\u6dcb\u6d74\u533a\u7b49\u623f\u95f4\u5185\u5bb6\u5177/\u4f4d\u7f6e\u53ea\u662f\u59ff\u52bf\u6216\u753b\u9762\u4f4d\u7f6e\uff0c\u4e0d\u662f\u65b0\u7684\u7269\u7406\u5730\u70b9\u3002\u73a9\u5bb6\u4ec5\u5728\u540c\u4e00\u623f\u95f4\u5185\u5750\u4e0b\u3001\u8eba\u4e0b\u3001\u8d70\u5230\u7a97\u8fb9\u65f6\uff0ctargetLocation \u548c locationStatus \u5fc5\u987b\u4fdd\u6301 current\u3002' : 'Furniture and positions inside one room, such as a bed, chair, window, desk, or shower area, are pose/visual positions rather than new physical locations. Sitting, lying down, or moving within the same room must keep targetLocation and locationStatus as current.',
      zh ? '\u9664\u975e\u73a9\u5bb6\u9009\u62e9\u56de\u5fc6\u6216\u6574\u7406\u601d\u7eea\uff0c\u5426\u5219\u4e0d\u8981\u56de\u987e\u6574\u6bb5\u8def\u7ebf\u6216\u91cd\u590d\u65e7\u5267\u60c5\u3002' : 'Do not recap the whole route or repeat old story unless the selected action is explicitly remembering or reflecting.',
      '</narrative_data_policy>'
    ].join('\n');
  }

  function buildLocationResponseFormatBlock(defaultPassage) {
    var fallback = clean(defaultPassage) || 'current';
    return [
      '<response_format>',
      'Write normal narrative prose first.',
      'At the very end, append exactly one metadata block on its own lines:',
      '[AI_META]{"location":"' + fallback + '"}[/AI_META]',
      'The location value must be one raw passage id from <known_places>, such as "Bird Tower", "Hospital Foyer", "Farm Work", or "Temple".',
      'Prefer the current or adjacent places listed in <current_map>. Do not jump to an unrelated map unless the story clearly uses transport, abduction, rescue, or another special transition.',
      'Do not use location ids like "tower" or "hospital" when a matching raw passage exists; use the listed raw passage.',
      'Use "current" only if the character did not enter a new known place.',
      'Do not put location decisions in prose only; the game reads this metadata block.',
      '</response_format>'
    ].join('\n');
  }

  function buildLocationMarkerRule(language) {
    if (language === 'zh') {
      return '★★★ 位置标记规则：如果主角在行动中进入、抵达、站到上面任意已知地点或地点入口，必须在叙事末尾输出 [LOC: passage]，并在 AI_EVENT 中写 targetLocation=同一 passage、locationStatus=arrived。仍在路上才写 locationStatus=inTransit。';
    }
    return '★★★ LOCATION MARKER RULE: If the character enters, reaches, arrives at, or stands at any known place or entrance above during this action, you MUST append [LOC: passage] at the end and set AI_EVENT targetLocation to the same passage with locationStatus=arrived. Use locationStatus=inTransit only while still traveling.';
  }

  function buildAIEventResponseFormatBlock(opts) {
    opts = opts || {};
    var nonMoneyStatAllowlist = clean(opts.nonMoneyStatAllowlist) || 'arousal, stress, pain, trauma, tiredness, control';
    var statFieldLimitText = clean(opts.statFieldLimitText);
    var relationChance = Math.max(0, Math.min(100, Number(opts.relationChance) || 0));
    var relationLimit = Math.max(0, Math.min(10, Number(opts.relationLimit) || 0));
    var relationFieldLimitText = clean(opts.relationFieldLimitText);
    if (!relationFieldLimitText && opts.relationFieldLimits) {
      var parts = [];
      ['love', 'trust', 'lust', 'rage', 'dom'].forEach(function (key) {
        var limit = Math.max(0, Math.min(10, Number(opts.relationFieldLimits[key]) || 0));
        parts.push(key + (limit > 0 ? ' +/-' + limit : ' disabled'));
      });
      relationFieldLimitText = parts.join(', ');
    }
    if (!relationFieldLimitText && relationLimit > 0) {
      relationFieldLimitText = 'love +/-' + relationLimit + ', trust +/-' + relationLimit + ', lust +/-' + relationLimit + ', rage +/-' + relationLimit + ', dom +/-' + relationLimit;
    }
    var includeSexTargets = !!opts.includeSexTargets;
    var lines = [
      '<ai_event_format>',
      'After the prose and metadata markers, append exactly one hidden event block. This AI_EVENT block is the authoritative structured result used by the game:',
      '[AI_EVENT]',
      'summary=one concise factual sentence about what actually happened',
      'eventType=scene|travel|conversation|item|state|native_action|combat|other',
      'location=final physical location after this action. If unchanged or still in transit, copy <scene>.physicalLocation.passage; if arrived, use the same known raw passage as targetLocation. Never write furniture or a body position here.',
      'targetLocation=current if unchanged, otherwise destination raw passage',
      'locationStatus=current|inTransit|arrived. Use arrived only when the player has actually entered that known place; use inTransit when still on the way. If the prose says the player reached, entered, arrived at, or is standing at a known place/entrance, targetLocation must be that place and locationStatus must be arrived.',
      'A bed, chair, desk, window, shower area, doorway, or other furniture/position inside the same room is not a destination. For movement or posture changes within one physical room, use targetLocation=current and locationStatus=current.',
      'sceneFocus=short visual focus or in-room position such as bedside, doorway, window, desk, or empty. sceneFocus never changes the physical location and must not be copied into targetLocation.',
      'environmentDescription=MUST be one short literal description of the currently visible physical environment: room/area type, stable layout, and directly visible major fixtures or terrain. Describe only what can be seen now. Do not include character actions, thoughts, history, UI, hidden rooms, or a broad map area that is not visually present.',
      'visualAction=MUST be one short literal description of the final visible action/posture and the directly handled object or interacting character whenever the prose contains a drawable action. Leave empty only for a truly static scene. Describe only what can be drawn now; do not copy dialogue, thoughts, history, UI, or the whole prose.',
      'presentCharacters=physically present named characters only, separated by semicolons',
      'presentEntities=physically present animals, creatures, tentacles, or other entities only, separated by semicolons',
      'Do not output legacy characters or presentTargets fields; presentCharacters and presentEntities are the canonical presence fields.'
    ];
    if (includeSexTargets) {
      lines.push('sexTargets=only characters/entities currently present and suitable for native sex-mode entry, or empty');
    }
    lines = lines.concat([
      'memoryTags=主线顺序;地点状态;人物关系;任务线索;剧情物品;未完成目标 as applicable',
      'memoryImportance=0-3 where 0=ignore, 1=normal recent event, 2=important story route/relationship/clue/object/goal, 3=major long-term fact',
      'itemsGained=short concrete inventory item names only, or empty',
      'itemsLost=short concrete inventory item names only when items are consumed, broken, given away, or lost; otherwise empty',
      'moneyChange=signed pence amount such as -8000 or +250, or empty. Use this field only when the prose explicitly states the same exact money amount and the reason for the gain/loss. If the amount is not written in prose, or if you are guessing a challenge reward/cost, leave moneyChange empty.',
      'Visible prices, rent, fees, rewards, balances, or button labels from world_context/ruleFacts/visible controls are not completed transactions. Do not copy those amounts into moneyChange unless the prose says the player actually paid, received, bought, sold, earned, stole, or lost that amount in this AI scene.',
      'statChanges=arousal+500;stress-1600;tiredness+180;trauma+100;pain+3;control-5 etc, or empty. Empty is the default. Add a stat only when the narrated event has a direct, mechanically meaningful cause, and keep the delta proportional to the action duration and intensity. Brief routine actions (about 1-5 minutes), walking, looking around, washing the face, changing clothes, breathing, or merely feeling refreshed/relaxed usually produce no stat change. Reduce tiredness only after meaningful rest or sleep; change pain only after injury, treatment, or recovery; change trauma only after a genuinely traumatic or restorative event; change arousal only after clearly arousing contact; change stress only after a consequential stressor or relief. Never convert descriptive mood words into mechanics by themselves. Use native DoL-sized deltas for large meters: arousal/stress are usually hundreds to thousands; tiredness is usually tens to hundreds; trauma is usually tens for ordinary fear and hundreds to 1000 for severe story events; pain/control/skills/traits stay small. Non-money stats go here. Do not put money in statChanges unless it exactly matches moneyChange for legacy compatibility. Allowed non-money stat keys: ' + nonMoneyStatAllowlist + (statFieldLimitText ? '. Player-configured per-stat single-delta limits are hard ceilings, not suggested values: ' + statFieldLimitText + '. Do not output a stat whose limit is disabled or 0.' : ''),
      relationChance > 0 && relationLimit > 0
        ? ('relationshipChanges=NPCKeyOrVisibleName:love+1,trust+1 etc, or empty. Allowed relationship keys and per-field single-delta limits: ' + relationFieldLimitText + '. Do not output a relationship key whose limit is disabled or 0. Only use NPCs listed in <state>; never invent names. Relationship changes are optional, not routine: write them only for clear meaningful interaction, approximate chance ' + relationChance + '%.')
        : 'relationshipChanges=empty. NPC relationship/status value changes are disabled by player settings.',
      '[/AI_EVENT]',
      'If you also output legacy [STATS] or [ITEMS] markers, they must match AI_EVENT exactly. Never output conflicting values between prose, markers, and AI_EVENT. Never infer or invent money from words like found, discovered, searched, took, entered, challenge, or reward; money requires an explicit amount in prose and matching moneyChange.',
      'The event block is for the game system. Do not put UI text, buttons, HTML, menus, sidebars, feelings as items, open doors, rooms, scenery, or full sentences in item fields.',
      'If unsure about a structured field, leave it empty or use current. Do not invent presentCharacters, presentEntities, presentTargets, relationshipChanges, or targetLocation.',
      '</ai_event_format>'
    ]);
    return lines.join('\n');
  }

  var module = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    compactStateForPrompt: compactStateForPrompt,
    selectRelevantMemories: selectRelevantMemories,
    buildNarrativeDataPolicyBlock: buildNarrativeDataPolicyBlock,
    buildLocationResponseFormatBlock: buildLocationResponseFormatBlock,
    buildLocationMarkerRule: buildLocationMarkerRule,
    buildAIEventResponseFormatBlock: buildAIEventResponseFormatBlock
  };

  root.AIStoryGenPromptBuilderModule = module;
  root.AIStoryGen.PromptBuilderModule = module;
})(typeof window !== 'undefined' ? window : globalThis);
