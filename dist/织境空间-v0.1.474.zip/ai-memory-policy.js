/* ============================================================
 * AIStoryGen long-term memory policy
 * Shared duplicate detection and bounded rolling archive logic.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var ARCHIVE_NAME = '[长期归档]';

  function cleanText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function canonicalText(value) {
    return cleanText(value)
      .replace(/^(?:地点|事件|剧情顺序|旧剧情归档)\s*[:：]\s*/g, '')
      .replace(/[，。；：、,.!！?？"'“”‘’()\[\]【】<>《》\s_-]+/g, '')
      .toLowerCase();
  }

  function isAutomaticName(name) {
    return /(?:自动|重点|压缩|归档|AI)/i.test(cleanText(name));
  }

  function entriesEquivalent(left, right) {
    left = left || {};
    right = right || {};
    var a = canonicalText(left.text);
    var b = canonicalText(right.text);
    if (!a || !b) return false;
    if (a === b) return true;
    if (Math.min(a.length, b.length) < 28) return false;
    if (a.indexOf(b) < 0 && b.indexOf(a) < 0) return false;
    var ratio = Math.min(a.length, b.length) / Math.max(a.length, b.length);
    if (ratio < 0.72) return false;
    return cleanText(left.name) === cleanText(right.name) ||
      isAutomaticName(left.name) ||
      isAutomaticName(right.name);
  }

  function findDuplicateIndex(entries, candidate) {
    entries = Array.isArray(entries) ? entries : [];
    for (var i = 0; i < entries.length; i++) {
      if (entriesEquivalent(entries[i], candidate)) return i;
    }
    return -1;
  }

  function preferEntry(existing, candidate) {
    existing = existing || {};
    candidate = candidate || {};
    if (existing.locked && !candidate.locked) return existing;
    if (candidate.locked && !existing.locked) return candidate;
    var existingText = cleanText(existing.text);
    var candidateText = cleanText(candidate.text);
    return candidateText.length > existingText.length ? candidate : existing;
  }

  function dedupeEntries(entries) {
    var result = [];
    var removed = [];
    (Array.isArray(entries) ? entries : []).forEach(function (entry) {
      if (!entry || !cleanText(entry.text)) return;
      var index = findDuplicateIndex(result, entry);
      if (index < 0) {
        result.push(entry);
        return;
      }
      var preferred = preferEntry(result[index], entry);
      removed.push(preferred === entry ? result[index] : entry);
      result[index] = preferred;
    });
    return { entries: result, removed: removed };
  }

  function mergeArchiveText(existingText, newText, maxChars) {
    maxChars = Math.max(300, Math.min(2400, Number(maxChars) || 1200));
    var pieces = cleanText(existingText + '；' + newText)
      .split(/[；;]/)
      .map(cleanText)
      .filter(Boolean);
    var seen = {};
    var merged = [];
    pieces.forEach(function (piece) {
      var key = canonicalText(piece);
      if (!key || seen[key]) return;
      seen[key] = true;
      merged.push(piece);
    });
    var text = merged.join('；');
    if (text.length > maxChars) text = text.slice(text.length - maxChars);
    return text.replace(/^[；;，,\s]+/, '').trim();
  }

  function applyLimit(entries, options) {
    options = options || {};
    var list = Array.isArray(entries) ? entries.slice() : [];
    var max = Math.max(0, Math.min(300, Number(options.max) || 0));
    var archiveName = cleanText(options.archiveName) || ARCHIVE_NAME;
    if (!max || list.length <= max) {
      return { entries: list, archived: [], overLimit: false };
    }

    var archiveIndex = -1;
    for (var i = 0; i < list.length; i++) {
      if (cleanText(list[i] && list[i].name) === archiveName) {
        archiveIndex = i;
        break;
      }
    }

    var removeNeeded = list.length - max + (archiveIndex < 0 ? 1 : 0);
    var archived = [];
    for (var cursor = 0; cursor < list.length && archived.length < removeNeeded;) {
      var entry = list[cursor];
      if (!entry || entry.locked || cleanText(entry.name) === archiveName) {
        cursor++;
        continue;
      }
      archived.push(entry);
      list.splice(cursor, 1);
      if (archiveIndex > cursor) archiveIndex--;
    }

    if (!archived.length) {
      return { entries: list, archived: [], overLimit: list.length > max };
    }

    var summary = typeof options.summarize === 'function'
      ? cleanText(options.summarize(archived))
      : archived.map(function (entry) { return cleanText(entry.text); }).filter(Boolean).join('；');
    if (summary) {
      if (archiveIndex >= 0 && list[archiveIndex]) {
        list[archiveIndex].text = mergeArchiveText(list[archiveIndex].text, summary, options.maxArchiveChars);
        list[archiveIndex].savedAt = new Date().toISOString();
        list[archiveIndex].locked = true;
        list[archiveIndex].tag = '归档';
      } else {
        list.unshift({
          name: archiveName,
          text: mergeArchiveText('', summary, options.maxArchiveChars),
          tag: '归档',
          locked: true,
          savedAt: new Date().toISOString()
        });
      }
    }

    return {
      entries: list,
      archived: archived,
      overLimit: list.length > max
    };
  }

  var module = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    archiveName: ARCHIVE_NAME,
    canonicalText: canonicalText,
    entriesEquivalent: entriesEquivalent,
    findDuplicateIndex: findDuplicateIndex,
    dedupeEntries: dedupeEntries,
    applyLimit: applyLimit
  };

  root.AIStoryGenMemoryPolicyModule = module;
  root.AIStoryGen.MemoryPolicyModule = module;
})(typeof window !== 'undefined' ? window : globalThis);
