/* ============================================================
 * AIStoryGen - DoL AI Story Mod
 * Macros: <<aigen "instruction">>  <<aiconfig>>  <<aimemory>>
 * Config: localStorage key "aiStoryGen_cfg"
 * 
 * Integrates into the game's Settings page via JS injection.
 * Also provides standalone AIStoryGen_Config / _Demo passages.
 * ============================================================ */
(function () {
  'use strict';

  // ---------- 1. 默认配置 ----------
  const CFG_KEY = 'aiStoryGen_cfg';
  const IDB_NAME = 'AIStoryGen';
  const IDB_STORE = 'settings';
  var _idbReady = false;
  var _idbDB = null;

  // IndexedDB helpers
  function initIDB() {
    if (_idbDB) return Promise.resolve(_idbDB);
    return new Promise(function (resolve, reject) {
      var req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = function () {
        _idbDB = req.result;
        _idbReady = true;
        resolve(_idbDB);
      };
      req.onerror = function () { reject(req.error); };
    });
  }

  function idbGet(key) {
    return initIDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(IDB_STORE, 'readonly');
        var req = tx.objectStore(IDB_STORE).get(key);
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function idbSet(key, value) {
    return initIDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).put(value, key);
        tx.oncomplete = function () { resolve(); };
        tx.onerror = function () { reject(tx.error); };
      });
    });
  }
  window.AIStoryGen = window.AIStoryGen || {};
  var _aiErrorLog = [];
  function _recordAIError(type, error, extra) {
    try {
      var message = '';
      var stack = '';
      if (error && typeof error === 'object') {
        message = String(error.message || error.reason || error.type || error);
        stack = String(error.stack || '');
      } else {
        message = String(error || '');
      }
      _aiErrorLog.push({
        at: new Date().toISOString(),
        type: String(type || 'error'),
        message: message.slice(0, 1000),
        stack: stack.slice(0, 2000),
        passage: (typeof State !== 'undefined' && State && State.passage) || '',
        extra: extra || null,
      });
      if (_aiErrorLog.length > 80) _aiErrorLog.splice(0, _aiErrorLog.length - 80);
    } catch (_) {}
  }
  try {
    window.addEventListener('error', function (ev) {
      _recordAIError('window.error', ev && (ev.error || ev.message), {
        filename: ev && ev.filename || '',
        lineno: ev && ev.lineno || 0,
        colno: ev && ev.colno || 0,
      });
    });
    window.addEventListener('unhandledrejection', function (ev) {
      _recordAIError('unhandledrejection', ev && ev.reason);
    });
  } catch (_) {}
  const Core = window.AIStoryGenCore || window.AIStoryGen.Core;
  function _requireCore(name) {
    if (!Core || typeof Core[name] === 'undefined') {
      throw new Error('[AIStoryGen] ai-core.js must load before aiMacro.js: missing ' + name);
    }
    return Core[name];
  }
  const ApiClientModule = window.AIStoryGenApiClientModule || window.AIStoryGen.ApiClientModule;
  if (!ApiClientModule || !ApiClientModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-api-client.js must load before aiMacro.js');
  }
  const ProviderPresetsModule = window.AIStoryGenProviderPresetsModule || window.AIStoryGen.ProviderPresetsModule;
  if (!ProviderPresetsModule || !ProviderPresetsModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-provider-presets.js must load before aiMacro.js');
  }
  const RequestLogModule = window.AIStoryGenRequestLogModule || window.AIStoryGen.RequestLogModule;
  if (!RequestLogModule || !RequestLogModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-request-log.js must load before aiMacro.js');
  }
  const ErrorReportSummaryModule = window.AIStoryGenErrorReportSummaryModule || window.AIStoryGen.ErrorReportSummaryModule;
  if (!ErrorReportSummaryModule || !ErrorReportSummaryModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-error-report-summary.js must load before aiMacro.js');
  }
  const ErrorReportUIModule = window.AIStoryGenErrorReportUIModule || window.AIStoryGen.ErrorReportUIModule;
  if (!ErrorReportUIModule || typeof ErrorReportUIModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-error-report-ui.js must load before aiMacro.js');
  }
  const ChangeSummaryModule = window.AIStoryGenChangeSummaryModule || window.AIStoryGen.ChangeSummaryModule;
  if (!ChangeSummaryModule || !ChangeSummaryModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-change-summary.js must load before aiMacro.js');
  }
  const StoryRuntimeModule = window.AIStoryGenStoryRuntimeModule || window.AIStoryGen.StoryRuntimeModule;
  if (!StoryRuntimeModule || !StoryRuntimeModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-story-runtime.js must load before aiMacro.js');
  }
  const ChoiceUIModule = window.AIStoryGenChoiceUIModule || window.AIStoryGen.ChoiceUIModule;
  if (!ChoiceUIModule || !ChoiceUIModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-choice-ui.js must load before aiMacro.js');
  }
  const OptionalAddonBridgeModule = window.AIStoryGenOptionalAddonBridgeModule || window.AIStoryGen.OptionalAddonBridgeModule;
  if (!OptionalAddonBridgeModule || !OptionalAddonBridgeModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-optional-addon-bridge.js must load before aiMacro.js');
  }
  const RuntimeEventsModule = window.AIStoryGenRuntimeEventsModule || window.AIStoryGen.RuntimeEventsModule;
  if (!RuntimeEventsModule || !RuntimeEventsModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-runtime-events.js must load before aiMacro.js');
  }
  window.AIStoryGen.RuntimeEventsModule = RuntimeEventsModule;
  const RuntimeChangeObserverModule = window.AIStoryGenRuntimeChangeObserverModule || window.AIStoryGen.RuntimeChangeObserverModule;
  if (!RuntimeChangeObserverModule || !RuntimeChangeObserverModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-runtime-change-observer.js must load before aiMacro.js');
  }
  window.AIStoryGen.RuntimeChangeObserverModule = RuntimeChangeObserverModule;
  const MountControllerModule = window.AIStoryGenMountControllerModule || window.AIStoryGen.MountControllerModule;
  if (!MountControllerModule || !MountControllerModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-mount-controller.js must load before aiMacro.js');
  }
  const MobileCompatModule = window.AIStoryGenMobileCompatModule || window.AIStoryGen.MobileCompatModule;
  if (!MobileCompatModule || !MobileCompatModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-mobile-compat.js must load before aiMacro.js');
  }
  const ConfigSchemaModule = window.AIStoryGenConfigSchemaModule || window.AIStoryGen.ConfigSchemaModule;
  if (!ConfigSchemaModule || !ConfigSchemaModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-config-schema.js must load before aiMacro.js');
  }
  const ConfigStoreModule = window.AIStoryGenConfigStoreModule || window.AIStoryGen.ConfigStoreModule;
  if (!ConfigStoreModule || !ConfigStoreModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-config-store.js must load before aiMacro.js');
  }
  function _disabledNativeSexActionBridgeModule() {
    return {
      schemaVersion: 0,
      normalizeCandidates: function () { return []; },
      chooseAction: function () { return { action: null, mode: 'none', score: 0, candidates: [] }; },
      buildDraftText: function () { return ''; },
      statusText: function () { return ''; }
    };
  }
  function _getNativeSexActionBridgeModule() {
    return window.AIStoryGenNativeSexActionBridgeModule
      || window.AIStoryGen.NativeSexActionBridgeModule
      || _disabledNativeSexActionBridgeModule();
  }
  const DEFAULT_CFG = _requireCore('DEFAULT_CFG');
  const AI_PIXEL_TEMP_DISABLED = false;
  const _normalizeCfg = _requireCore('normalizeCfg');

  function _normalizeStoryConfig(value) {
    var cfg = _normalizeCfg(Object.assign({}, DEFAULT_CFG, value || {}));
    try { cfg = ProviderPresetsModule.normalizeConfigProvider(cfg); } catch (_) {}
    return cfg;
  }

  var _storyConfigStore = ConfigStoreModule.create({
    storage: window.localStorage,
    storageKey: CFG_KEY,
    defaults: DEFAULT_CFG,
    normalize: _normalizeStoryConfig
  });

  function loadCfg() {
    return _storyConfigStore.load();
  }
  function saveCfg(c) {
    var saved = _storyConfigStore.save(c || {});
    c = saved.value;
    // localStorage: immediate sync save (always works as fallback)
    // IndexedDB: async save (no size limit, no sync blocking)
    try {
      idbSet(CFG_KEY, c).catch(function (e) {
        console.warn('[AIStoryGen] IndexedDB save failed, using localStorage fallback', e);
      });
    } catch (e) { /* IndexedDB not available */ }
    try {
      if (typeof _syncSaveScopedConfigToCurrentMoment === 'function') {
        setTimeout(function () { _syncSaveScopedConfigToCurrentMoment('saveCfg'); }, 0);
      }
    } catch (e) { /* state not ready */ }
  }

  // Try to restore config from IndexedDB on startup. localStorage is the immediate
  // source of truth, so an older IndexedDB backup must not overwrite fresh UI edits.
  try {
    idbGet(CFG_KEY).then(function (stored) {
      if (stored && typeof stored === 'object' && stored.apiKey !== undefined) {
        var localCfg = ConfigStoreModule.readLocalJSON(window.localStorage, CFG_KEY, null);
        var hasLocalCfg = !!(localCfg && Object.keys(localCfg).length);
        var merged = _normalizeStoryConfig(Object.assign({}, DEFAULT_CFG, stored, localCfg || {}));
        ConfigStoreModule.writeLocalJSON(window.localStorage, CFG_KEY, merged);
        idbSet(CFG_KEY, merged).catch(function () {});
        console.log(hasLocalCfg ? '[AIStoryGen] config synced to IndexedDB from localStorage' : '[AIStoryGen] config restored from IndexedDB');
      }
    }).catch(function () {});
  } catch (e) { /* IndexedDB not available */ }

  window.AIStoryGen = window.AIStoryGen || {};
  window.AIStoryGen.EXPECTED_BOOT_VERSION = '0.1.474';
  window.AIStoryGen.EXPECTED_MACRO_FILE = 'aiMacro-0.1.474.js';
  window.AIStoryGen.VERSION = '0.1.474';
  try { console.log('[AIStoryGen] runtime version ' + window.AIStoryGen.VERSION); } catch (_) {}
  const ADULT_CONTENT_UNLOCK_KEY = 'aiStoryGen_adultContentUnlocked';

  function _getAiVersionDiagnostics() {
    var runtimeVersion = String(window.AIStoryGen && window.AIStoryGen.VERSION || 'unknown');
    var expectedBootVersion = String(window.AIStoryGen && window.AIStoryGen.EXPECTED_BOOT_VERSION || '');
    var expectedMacroFile = String(window.AIStoryGen && window.AIStoryGen.EXPECTED_MACRO_FILE || '');
    var ok = !!expectedBootVersion && runtimeVersion === expectedBootVersion;
    var diagnostics = {
      runtimeVersion: runtimeVersion,
      expectedBootVersion: expectedBootVersion || 'unknown',
      expectedMacroFile: expectedMacroFile || 'unknown',
      ok: ok,
      mismatch: !ok,
      pageUrl: String(location && location.href || '').slice(0, 300)
    };
    diagnostics.message = ok
      ? '运行版本与打包版本一致。'
      : '运行版本与打包版本不一致，可能仍在使用 ModLoader 合并缓存或旧版 zip。';
    return diagnostics;
  }
  window.AIStoryGen.getVersionDiagnostics = _getAiVersionDiagnostics;

  function _ensureClothingCnNameFallback(reason) {
    try {
      var st = (typeof setup !== 'undefined' && setup) ? setup : (window.SugarCube && window.SugarCube.setup) || window.setup;
      if (!st || !st.clothes || !Array.isArray(st.clothes.all)) return 0;
      var all = st.clothes.all;
      var byName = {};
      for (var i = 0; i < all.length; i++) {
        var item = all[i];
        if (!item || typeof item.name !== 'string' || !item.name) continue;
        byName[item.name] = item;
        if (item.cn_name_cap == null) item.cn_name_cap = item.cn_name || item.displayname || item.name;
        if (item.cn_name == null) item.cn_name = item.cn_name_cap || item.displayname || item.name;
      }
      var added = 0;
      var cnFallbackNames = {
        'bunny slippers': '兔子拖鞋'
      };
      function addName(name, template) {
        name = String(name || '').trim();
        if (!name || /^(?:none|naked|broken|split)$/i.test(name)) return;
        var fallbackCn = (template && (template.cn_name_cap || template.cn_name || template.displayname)) || cnFallbackNames[name] || name;
        if (byName[name]) {
          if (byName[name].cn_name_cap == null) byName[name].cn_name_cap = fallbackCn;
          if (byName[name].cn_name == null) byName[name].cn_name = byName[name].cn_name_cap || fallbackCn;
          return;
        }
        var fallback = {
          name: name,
          cn_name: fallbackCn,
          cn_name_cap: fallbackCn,
          displayname: fallbackCn,
          type: ['ai_fallback'],
          slot: ''
        };
        all.push(fallback);
        byName[name] = fallback;
        added++;
      }
      function addItem(item) {
        if (item && typeof item === 'object' && typeof item.name === 'string') addName(item.name, item);
      }
      Object.keys(st.clothes).forEach(function (slot) {
        var list = st.clothes[slot];
        if (Array.isArray(list)) list.forEach(addItem);
      });
      var V = null;
      try { V = (typeof State !== 'undefined' && State.variables) || (window.SugarCube && window.SugarCube.State && window.SugarCube.State.variables) || null; } catch (_) {}
      var clothingSlots = {
        over_upper: true, over_lower: true, upper: true, lower: true,
        under_upper: true, under_lower: true, over_head: true, head: true,
        face: true, neck: true, hands: true, legs: true, feet: true,
        genitals: true, handheld: true
      };
      function scanSlotObject(obj) {
        if (!obj || typeof obj !== 'object') return;
        Object.keys(obj).forEach(function (key) {
          var val = obj[key];
          if (Array.isArray(val)) val.forEach(addItem);
          else addItem(val);
        });
      }
      function scanOutfit(outfit) {
        if (!outfit || typeof outfit !== 'object') return;
        if (typeof outfit.name === 'string') addName(outfit.name);
        Object.keys(outfit).forEach(function (key) {
          var val = outfit[key];
          if (clothingSlots[key] && typeof val === 'string') addName(val);
          else if (val && typeof val === 'object' && (key === 'outfitPrimary' || key === 'outfitSecondary')) {
            Object.keys(val).forEach(function (slot) {
              if (clothingSlots[slot] && typeof val[slot] === 'string') addName(val[slot]);
            });
          }
        });
      }
      if (V) {
        scanSlotObject(V.worn);
        scanSlotObject(V.carried);
        scanSlotObject(V.wardrobe);
        if (Array.isArray(V.outfit)) V.outfit.forEach(scanOutfit);
        else if (V.outfit && typeof V.outfit === 'object') Object.keys(V.outfit).forEach(function (key) { scanOutfit(V.outfit[key]); });
      }
      if (added) {
        try { console.log('[AIStoryGen] added clothing translation fallback entries: ' + added + (reason ? ' (' + reason + ')' : '')); } catch (_) {}
      }
      return added;
    } catch (e) {
      try { console.warn('[AIStoryGen] clothing translation fallback failed', e); } catch (_) {}
      return 0;
    }
  }

  function _ensureLegacyDoLStateCompat(reason) {
    try {
      var V = null;
      try {
        V = (typeof State !== 'undefined' && State.variables)
          || (window.SugarCube && window.SugarCube.State && window.SugarCube.State.variables)
          || null;
      } catch (_) { V = null; }
      if (!V) return 0;
      var passageName = '';
      try {
        passageName = String((typeof State !== 'undefined' && State.passage) || (window.SugarCube && window.SugarCube.State && window.SugarCube.State.passage) || '');
      } catch (_) { passageName = ''; }
      if (/^(Start|Start2|Orphanage Intro|Intro|Settings|Options)$/i.test(passageName)) {
        return 0;
      }
      var changed = 0;
      var st = null;
      try { st = (typeof setup !== 'undefined' && setup) ? setup : (window.SugarCube && window.SugarCube.setup) || window.setup || null; } catch (_) { st = null; }

      function ensureObject(parent, key) {
        if (!parent[key] || typeof parent[key] !== 'object') {
          parent[key] = {};
          changed++;
        }
        return parent[key];
      }
      function ensureNumber(parent, key, value) {
        if (typeof parent[key] !== 'number' || !isFinite(parent[key])) {
          parent[key] = value;
          changed++;
        }
      }
      function ensureString(parent, key, value) {
        if (parent[key] == null || parent[key] === '') {
          parent[key] = value;
          changed++;
        }
      }
      function ensureArray(parent, key) {
        if (!Array.isArray(parent[key])) {
          parent[key] = [];
          changed++;
        }
        return parent[key];
      }
      function ensureCanvasFilter(parent, fallbackBlend) {
        if (!parent || typeof parent !== 'object') return;
        if (!parent.canvasfilter || typeof parent.canvasfilter !== 'object') {
          parent.canvasfilter = {};
          changed++;
        }
        if (parent.canvasfilter.blend == null || parent.canvasfilter.blend === '') {
          parent.canvasfilter.blend = fallbackBlend || '#888888';
          changed++;
        }
        if (parent.canvasfilter.brightness == null) {
          parent.canvasfilter.brightness = 0;
          changed++;
        }
        if (parent.canvasfilter.contrast == null) {
          parent.canvasfilter.contrast = 1;
          changed++;
        }
      }
      function hasCanvasFilter(map, key) {
        return !!(map && key != null && map[key] && typeof map[key] === 'object' && map[key].canvasfilter);
      }

      var weather = ensureObject(V, 'weatherObj');
      if (weather.value == null) {
        weather.value = weather.name || 'clear';
        changed++;
      }
      ensureString(weather, 'name', String(weather.value || 'clear'));
      ensureObject(weather, 'ice');

      if (!V.NPCName || !Array.isArray(V.NPCName)) {
        V.NPCName = [];
        changed++;
      }
      var npcNames = Array.isArray(V.NPCNameList) ? V.NPCNameList : [];
      if (!npcNames.length && st && Array.isArray(st.NPCNameList)) npcNames = st.NPCNameList;
      var npcCount = Math.max(V.NPCName.length, npcNames.length);
      for (var i = 0; i < npcCount; i++) {
        if (!V.NPCName[i] || typeof V.NPCName[i] !== 'object') {
          V.NPCName[i] = {};
          changed++;
        }
        var npc = V.NPCName[i];
        ensureString(npc, 'nam', npcNames[i] || npc.name || ('NPC ' + i));
        ensureString(npc, 'name', npc.nam || npcNames[i] || ('NPC ' + i));
        ensureString(npc, 'type', 'human');
        ensureString(npc, 'gender', npc.pronoun || 'n');
        ensureString(npc, 'penis', 'none');
        ensureString(npc, 'vagina', 'none');
        ensureNumber(npc, 'penissize', 0);
        ensureNumber(npc, 'pregnancyAvoidance', 0);
        ensureNumber(npc, 'love', 0);
        ensureNumber(npc, 'lust', 0);
        ensureNumber(npc, 'dom', 0);
        ensureNumber(npc, 'rage', 0);
        ensureNumber(npc, 'trust', 0);
        if (!npc.pregnancy || typeof npc.pregnancy !== 'object') {
          npc.pregnancy = {};
          changed++;
        }
        ensureObject(npc, 'chastity');
        ensureString(npc.chastity, 'penis', 'none');
        ensureString(npc.chastity, 'vagina', 'none');
        ensureString(npc.chastity, 'anus', 'none');
      }

      ensureObject(V, 'plants');
      var plantDefs = st && st.plants && typeof st.plants === 'object' ? st.plants : {};
      Object.keys(plantDefs).forEach(function (key) {
        if (!V.plants[key] || typeof V.plants[key] !== 'object') {
          V.plants[key] = {};
          changed++;
        }
        ensureString(V.plants[key], 'name', key);
        ensureNumber(V.plants[key], 'amount', 0);
        ensureNumber(V.plants[key], 'seeds', 0);
      });
      ensureObject(V, 'produce');
      Object.keys(plantDefs).forEach(function (key) {
        ensureNumber(V.produce, key, 0);
      });

      ensureObject(V, 'farm');
      ensureNumber(V.farm, 'tower_guard', 0);
      ensureNumber(V, 'farm_tower_guard', 0);

      if (V.custom_eyecolours != null && !Array.isArray(V.custom_eyecolours)) {
        V.custom_eyecolours = [];
        changed++;
      }
      if (Array.isArray(V.custom_eyecolours)) {
        V.custom_eyecolours.forEach(function (colour) {
          ensureCanvasFilter(colour, '#888888');
        });
      }
      var eyeMap = st && st.colours && st.colours.eyes_map ? st.colours.eyes_map : null;
      if (eyeMap) {
        var fallbackEyeColour = hasCanvasFilter(eyeMap, 'hazel') ? 'hazel' : (Object.keys(eyeMap)[0] || 'hazel');
        if (!hasCanvasFilter(eyeMap, V.leftEyeColour)) {
          V.leftEyeColour = fallbackEyeColour;
          changed++;
        }
        if (!hasCanvasFilter(eyeMap, V.rightEyeColour)) {
          V.rightEyeColour = hasCanvasFilter(eyeMap, V.leftEyeColour) ? V.leftEyeColour : fallbackEyeColour;
          changed++;
        }
      }
      var makeup = V.makeup && typeof V.makeup === 'object' ? V.makeup : null;
      if (makeup) {
        var ownedMakeup = makeup.owned && typeof makeup.owned === 'object' ? makeup.owned : null;
        if (ownedMakeup) {
          [
            'lipstick',
            'eyeshadow',
            'eyelenses',
            'custom_eyelenses',
            'hairdye',
            'mascara',
            'blusher'
          ].forEach(function (key) {
            ensureArray(ownedMakeup, key);
          });
        }
        var eyelenses = makeup.eyelenses && typeof makeup.eyelenses === 'object' ? makeup.eyelenses : null;
        var customEyeColours = Array.isArray(V.custom_eyecolours) ? V.custom_eyecolours : [];
        if (eyelenses && eyelenses.left && eyeMap && !hasCanvasFilter(eyeMap, eyelenses.left) && !customEyeColours.some(function (c) { return c && c.variable === eyelenses.left && c.canvasfilter; })) {
          eyelenses.left = 0;
          changed++;
        }
        if (eyelenses && eyelenses.right && eyeMap && !hasCanvasFilter(eyeMap, eyelenses.right) && !customEyeColours.some(function (c) { return c && c.variable === eyelenses.right && c.canvasfilter; })) {
          eyelenses.right = 0;
          changed++;
        }
      }

      if (changed) {
        window.AIStoryGen = window.AIStoryGen || {};
        window.AIStoryGen.legacyCompatApplied = (window.AIStoryGen.legacyCompatApplied || 0) + changed;
        try { console.log('[AIStoryGen] legacy DoL state compat filled ' + changed + ' fields' + (reason ? ' (' + reason + ')' : '')); } catch (_) {}
      }
      return changed;
    } catch (e) {
      try { console.warn('[AIStoryGen] legacy DoL state compat failed', e); } catch (_) {}
      return 0;
    }
  }

  try { _ensureLegacyDoLStateCompat('startup'); } catch (_) {}
  try { _ensureClothingCnNameFallback('startup'); } catch (_) {}
  try {
    setTimeout(function () { _ensureLegacyDoLStateCompat('startup delayed'); _ensureClothingCnNameFallback('startup delayed'); }, 100);
    setTimeout(function () { _ensureLegacyDoLStateCompat('startup late'); _ensureClothingCnNameFallback('startup late'); }, 1000);
  } catch (_) {}
  try {
    if (typeof $ !== 'undefined' && $.fn && $(document).on) {
      $(document).on(':passagestart :passageinit :passagerender :passagedisplay', function (ev) {
        var name = '';
        try { name = (ev && ev.passage && ev.passage.title) || (typeof State !== 'undefined' && State.passage) || ''; } catch (_) {}
        _ensureLegacyDoLStateCompat(name || 'passage');
        _ensureClothingCnNameFallback(name || 'passage');
      });
    }
  } catch (_) {}
  window.AIStoryGen.ensureLegacyDoLStateCompat = _ensureLegacyDoLStateCompat;
  window.AIStoryGen.ensureClothingCnNameFallback = _ensureClothingCnNameFallback;

  function _getIntimateCombatRuntime() {
    var runtime = window.AIStoryGenIntimateCombatRuntime;
    return runtime && Number(runtime.schemaVersion || 0) >= 1 ? runtime : null;
  }

  function _callIntimateCombatRuntime(method, args, fallback) {
    var runtime = _getIntimateCombatRuntime();
    if (!runtime || typeof runtime[method] !== 'function') return fallback;
    try { return runtime[method].apply(runtime, args || []); } catch (error) {
      try { console.warn('[AIStoryGen] intimate combat runtime call failed: ' + method, error); } catch (_) {}
      return fallback;
    }
  }

  var OptionalAddonBridge = OptionalAddonBridgeModule.create({
    $: $,
    getStateStoreReady: function () { return !!_aiStateStoreReady; },
    clearIntimateScene: function (reason) { return _clearAIIntimateScene(reason); },
    restoreOriginalCombatNarrative: function () { return _callIntimateCombatRuntime('restoreOriginalCombatNarrative', [], false); }
  });

  function _isIntimateAddonLoaded() {
    return OptionalAddonBridge.isLoaded();
  }

  function _isAdultContentUnlocked() {
    return _isIntimateAddonLoaded();
  }

  function _setAdultContentUnlocked(value) {
    try { localStorage.removeItem(ADULT_CONTENT_UNLOCK_KEY); } catch (_) {}
    try { window.AIStoryGen.adultContentUnlocked = _isAdultContentUnlocked(); } catch (_) {}
    if (!_isAdultContentUnlocked()) {
      try { _clearAISexModeUi(); } catch (_) {}
    }
    return _isAdultContentUnlocked();
  }

  window.AIStoryGen.isAdultContentUnlocked = _isAdultContentUnlocked;
  window.AIStoryGen.setAdultContentUnlocked = _setAdultContentUnlocked;
  window.AIStoryGen.isIntimateAddonLoaded = _isIntimateAddonLoaded;
  window.AIStoryGen.adultContentUnlocked = _isAdultContentUnlocked();
  if (!_isIntimateAddonLoaded()) {
    try { localStorage.removeItem(ADULT_CONTENT_UNLOCK_KEY); } catch (_) {}
    try { _clearAISexModeUi(); } catch (_) {}
  }
  window.AIStoryGen.isApiConfigured = _isApiConfigured;
  window.AIStoryGen.refreshApiWarnBar = _refreshApiWarnBar;
  window.AIStoryGen.loadCfg = loadCfg;
  window.AIStoryGen.saveCfg = saveCfg;
  window.AIStoryGen.DEFAULT_CFG = DEFAULT_CFG;
  window.AIStoryGen.configStore = _storyConfigStore;
  window.AIStoryGen.ConfigStoreModule = ConfigStoreModule;
  var RequestLog = RequestLogModule.create({ limit: 30 });
  window.AIStoryGen.requestLog = RequestLog;

  var MobileCompat = MobileCompatModule.create({
    getSetting: function () {
      var cfg = null;
      try { cfg = loadCfg(); } catch (_) { cfg = DEFAULT_CFG || {}; }
      return (cfg && cfg.uiLayoutMode) || 'auto';
    },
    getRootElements: function () {
      return [document.documentElement, document.body].filter(Boolean);
    }
  });

  function _resolveUILayoutMode(setting) {
    try { return MobileCompat.resolveMode(setting); } catch (_) {}
    return MobileCompatModule.resolveMode(setting);
  }

  function _applyUILayoutMode(reason) {
    try { return MobileCompat.apply(reason || ''); } catch (_) {}
    return { mode: _resolveUILayoutMode('auto'), setting: 'auto', reason: reason || '' };
  }
  window.AIStoryGen.applyUILayoutMode = _applyUILayoutMode;
  window.AIStoryGen.MobileCompat = MobileCompat;

  function _bindAiInteractionShield($target, reason) {
    try {
      if (MobileCompat && typeof MobileCompat.bindInteractionShield === 'function') {
        return MobileCompat.bindInteractionShield($target, {
          $: $,
          namespace: 'aiStoryGenShield' + String(reason || '').replace(/[^\w-]/g, '')
        });
      }
    } catch (_) {}
    try {
      if ($target && $target.on) {
        $target.on('click mousedown pointerdown touchstart touchend', function (e) {
          e.stopPropagation();
        });
        return true;
      }
    } catch (_) {}
    return false;
  }

  function _mountAiFloatingPanel($target, reason, opts) {
    opts = opts || {};
    try {
      if (MobileCompat && typeof MobileCompat.mountFloatingPanel === 'function') {
        return MobileCompat.mountFloatingPanel($target, Object.assign({
          $: $,
          namespace: reason || 'ai-floating-panel',
          className: opts.className || 'ai-mobile-floating-panel',
          mode: opts.mode || 'append',
          shield: opts.shield !== false
        }, opts));
      }
    } catch (_) {}
    try {
      var $root = typeof opts.getRoot === 'function' ? opts.getRoot() : $('body');
      if (!$root || !$root.length) $root = $('body');
      if (opts.mode === 'prepend') $root.prepend($target);
      else $root.append($target);
      if (opts.shield !== false) _bindAiInteractionShield($target, reason || 'ai-floating-panel');
      return true;
    } catch (_) {}
    return false;
  }

  function _mountAiPassageNotice($target, reason, opts) {
    opts = opts || {};
    if (!$target || !$target.length) return false;
    var mode = opts.mode === 'prepend' ? 'prepend' : 'append';
    var zoneId = opts.zoneId || 'wovenrealm-passage-notices';
    function doMount() {
      var $root = null;
      try {
        $root = typeof opts.getRoot === 'function' ? opts.getRoot() : $('#passages');
      } catch (_) {
        $root = null;
      }
      if (!$root || !$root.length) $root = $('#passages');
      if (!$root.length) $root = $('body');
      if (!$root.length) return false;
      if (opts.clearSelector) {
        try { $root.children(opts.clearSelector).remove(); } catch (_) {}
      }
      if (mode === 'prepend') $root.prepend($target);
      else $root.append($target);
      if (opts.shield) _bindAiInteractionShield($target, reason || 'passage notice');
      return true;
    }
    try {
      if (_aiMountController && typeof _aiMountController.mountZone === 'function') {
        return _aiMountController.mountZone(zoneId, { mount: doMount });
      }
    } catch (_) {}
    return doMount();
  }

  // ---------- 1b-1e. 核心工具来自 ai-core.js ----------
  var AIErrorType = _requireCore('AIErrorType');
  var AIError = _requireCore('AIError');
  var userErrorMessage = _requireCore('userErrorMessage');
  var classifyError = _requireCore('classifyError');
  var getSafeV = _requireCore('getSafeV');
  var safeRead = _requireCore('safeRead');
  var checkNetwork = _requireCore('checkNetwork');
  var applyPostProcess = _requireCore('applyPostProcess');

  window.AIStoryGen.classifyError = classifyError;
  window.AIStoryGen.checkNetwork = checkNetwork;
  window.AIStoryGen.getSafeV = getSafeV;

  // ---------- 2. 剧情记忆系统：近期记忆 + 长期记忆 ----------
  const MEM_KEY = 'aiStoryGen_recentBuf';
  const LONGTERM_KEY = 'aiStoryGen_longTermMem';
  const MEMORY_BACKUP_KEY = 'aiStoryGen_saveScopedMemoryBackup_v1';
  const MEMORY_BACKUP_MAX = 8;
  const AI_STATE_SCHEMA_VERSION = 2;
  var _aiStateStoreReady = false;

  // -- 近期记忆（环形缓冲，用于AI上下文） --
  const recentBuf = [];
  window.AIStoryGen.recentBuf = recentBuf;

  // -- 长期记忆（按游戏存档隔离，不跨存档继承） --
  const longTermMem = [];
  window.AIStoryGen.longTermMem = longTermMem;
  var _aiMemorySaveBound = false;
  var _aiMemorySaveId = '';

  function _memoryEntry(name, text) {
    return {
      name: String(name || '[记忆]'),
      text: String(text || '').trim(),
      tag: '剧情',
      locked: false,
      savedAt: new Date().toISOString()
    };
  }

  function _normalizeImportantMemoryEntry(entry) {
    entry = entry || {};
    return {
      name: String(entry.name || '[记忆]'),
      text: String(entry.text || '').trim(),
      tag: String(entry.tag || '剧情'),
      locked: !!entry.locked,
      savedAt: entry.savedAt || new Date().toISOString()
    };
  }

  function _currentPassageName() {
    try {
      return (typeof State !== 'undefined' && State.passage) || '';
    } catch (e) {
      return '';
    }
  }

  function _isStartOrMainMenuPassage(name) {
    name = String(name || _currentPassageName() || '');
    return !name || name === 'Start';
  }

  function _normalizeSaveMemory(mem) {
    return _aiStateStore.normalizeMemory(mem);
  }

  function _replaceMemoryFromSave(mem) {
    mem = _normalizeSaveMemory(mem);
    recentBuf.length = 0;
    mem.recentBuf.forEach(function (entry) { recentBuf.push(entry); });
    longTermMem.length = 0;
    mem.longTermMem.forEach(function (entry) { longTermMem.push(entry); });
    _sanitizeMemoryBuffers();
  }

  function _snapshotMemoryForSave() {
    _sanitizeMemoryBuffers();
    return {
      recentBuf: recentBuf.map(function (entry) {
        return { name: String(entry.name || ''), text: String(entry.text || '') };
      }),
      longTermMem: longTermMem.map(function (entry) {
        return _normalizeImportantMemoryEntry(entry);
      })
    };
  }

  const RoundSnapshotModule = window.AIStoryGenRoundSnapshotModule || window.AIStoryGen.RoundSnapshotModule;
  if (!RoundSnapshotModule || typeof RoundSnapshotModule.sanitizeGameSnapshot !== 'function') {
    throw new Error('[AIStoryGen] ai-round-snapshot.js must load before aiMacro.js');
  }
  const StateStoreModule = window.AIStoryGenStateStore || window.AIStoryGen.StateStoreModule;
  if (!StateStoreModule || typeof StateStoreModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-state-store.js must load before aiMacro.js');
  }
  const TransactionPlannerModule = window.AIStoryGenTransactionPlannerModule || window.AIStoryGen.TransactionPlannerModule;
  if (!TransactionPlannerModule || typeof TransactionPlannerModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-transaction-planner.js must load before aiMacro.js');
  }
  const TransactionModule = window.AIStoryGenTransactionModule || window.AIStoryGen.TransactionModule;
  if (!TransactionModule || typeof TransactionModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-transaction.js must load before aiMacro.js');
  }
  const TransactionAuditModule = window.AIStoryGenTransactionAuditModule || window.AIStoryGen.TransactionAuditModule;
  if (!TransactionAuditModule || typeof TransactionAuditModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-transaction-audit.js must load before aiMacro.js');
  }
  const LinkClassifierModule = window.AIStoryGenLinkClassifierModule || window.AIStoryGen.LinkClassifierModule;
  if (!LinkClassifierModule || typeof LinkClassifierModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-link-classifier.js must load before aiMacro.js');
  }
  const PageClassifierModule = window.AIStoryGenPageClassifierModule || window.AIStoryGen.PageClassifierModule;
  if (!PageClassifierModule || typeof PageClassifierModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-page-classifier.js must load before aiMacro.js');
  }
  const WorldKnowledgeModule = window.AIStoryGenWorldKnowledgeModule || window.AIStoryGen.WorldKnowledgeModule;
  if (!WorldKnowledgeModule || typeof WorldKnowledgeModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-world-knowledge.js must load before aiMacro.js');
  }
  const NpcContextModule = window.AIStoryGenNpcContextModule || window.AIStoryGen.NpcContextModule;
  if (!NpcContextModule || typeof NpcContextModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-npc-context.js must load before aiMacro.js');
  }
  const WorldContextModule = window.AIStoryGenWorldContextModule || window.AIStoryGen.WorldContextModule;
  if (!WorldContextModule || typeof WorldContextModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-world-context.js must load before aiMacro.js');
  }
  const EventParserModule = window.AIStoryGenEventParserModule || window.AIStoryGen.EventParserModule;
  if (!EventParserModule || typeof EventParserModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-event-parser.js must load before aiMacro.js');
  }
  const EventSchemaModule = window.AIStoryGenEventSchemaModule || window.AIStoryGen.EventSchemaModule;
  if (!EventSchemaModule || !EventSchemaModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-event-schema.js must load before aiMacro.js');
  }
  const StatSchemaModule = window.AIStoryGenStatSchemaModule || window.AIStoryGen.StatSchemaModule;
  if (!StatSchemaModule || !StatSchemaModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-stat-schema.js must load before aiMacro.js');
  }
  const PromptBuilderModule = window.AIStoryGenPromptBuilderModule || window.AIStoryGen.PromptBuilderModule;
  if (!PromptBuilderModule || !PromptBuilderModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-prompt-builder.js must load before aiMacro.js');
  }
  const ItemSchemaModule = window.AIStoryGenItemSchemaModule || window.AIStoryGen.ItemSchemaModule;
  if (!ItemSchemaModule || !ItemSchemaModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-item-schema.js must load before aiMacro.js');
  }
  const EventValidatorModule = window.AIStoryGenEventValidatorModule || window.AIStoryGen.EventValidatorModule;
  if (!EventValidatorModule || typeof EventValidatorModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-event-validator.js must load before aiMacro.js');
  }
  const ConsistencyGuardModule = window.AIStoryGenConsistencyGuardModule || window.AIStoryGen.ConsistencyGuardModule;
  if (!ConsistencyGuardModule || typeof ConsistencyGuardModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-consistency-guard.js must load before aiMacro.js');
  }
  const MemoryPolicyModule = window.AIStoryGenMemoryPolicyModule || window.AIStoryGen.MemoryPolicyModule;
  if (!MemoryPolicyModule || !MemoryPolicyModule.schemaVersion) {
    throw new Error('[AIStoryGen] ai-memory-policy.js must load before aiMacro.js');
  }
  const MemoryUIModule = window.AIStoryGenMemoryUIModule || window.AIStoryGen.MemoryUIModule;
  if (!MemoryUIModule || typeof MemoryUIModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-memory-ui.js must load before aiMacro.js');
  }
  const ConfigUIModule = window.AIStoryGenConfigUIModule || window.AIStoryGen.ConfigUIModule;
  if (!ConfigUIModule || typeof ConfigUIModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-config-ui.js must load before aiMacro.js');
  }
  const BarefootBuffsModule = window.AIStoryGenBarefootBuffsModule || window.AIStoryGen.BarefootBuffsModule;
  if (!BarefootBuffsModule || typeof BarefootBuffsModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-barefoot-buffs.js must load before aiMacro.js');
  }
  const _aiBarefootBuffs = BarefootBuffsModule.create({
    $: window.jQuery || window.$,
    document: document,
    loadCfg: loadCfg,
    getVariables: function () {
      try { return typeof State !== 'undefined' && State.variables ? State.variables : null; } catch (_) { return null; }
    }
  });
  window.AIStoryGen.barefootBuffs = _aiBarefootBuffs;
  _aiBarefootBuffs.install();
  const ExtraLongHairModule = window.AIStoryGenExtraLongHairModule || window.AIStoryGen.ExtraLongHairModule;
  if (!ExtraLongHairModule || typeof ExtraLongHairModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-extra-long-hair.js must load before aiMacro.js');
  }
  const _aiExtraLongHair = ExtraLongHairModule.create({
    loadCfg: loadCfg,
    getVariables: function () {
      try { return typeof State !== 'undefined' && State.variables ? State.variables : null; } catch (_) { return null; }
    }
  });
  window.AIStoryGen.extraLongHair = _aiExtraLongHair;
  _aiExtraLongHair.install();
  const PanelManagerModule = window.AIStoryGenPanelManagerModule || window.AIStoryGen.PanelManagerModule;
  if (!PanelManagerModule || typeof PanelManagerModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-panel-manager.js must load before aiMacro.js');
  }
  function _disabledNativeTargetDetectorModule() {
    return {
      schemaVersion: 0,
      create: function () {
        return {
          shouldShowOption: function () { return false; },
          getCandidateTemplates: function () { return []; },
          normalizeCustomTarget: function () { return null; },
          findTemplateByName: function () { return null; },
          collectTargets: function () { return []; },
          inferStart: function () { return false; }
        };
      }
    };
  }
  const NativeTargetDetectorModule = window.AIStoryGenNativeTargetDetectorModule || window.AIStoryGen.NativeTargetDetectorModule || _disabledNativeTargetDetectorModule();
  const NativeEventGuardModule = window.AIStoryGenNativeEventGuardModule || window.AIStoryGen.NativeEventGuardModule;
  if (!NativeEventGuardModule || typeof NativeEventGuardModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-native-event-guard.js must load before aiMacro.js');
  }
  function _disabledNativeSceneBridgeModule() {
    return {
      schemaVersion: 0,
      create: function () {
        return {
          schemaVersion: 0,
          moduleSchemaVersion: 0,
          getStatus: function () { return { schemaVersion: 0, disabled: true }; },
          isCombatActive: function () { return false; },
          isNativeSexOrCombatPassage: function () { return false; },
          shouldShowSexModeOption: function () { return false; },
          collectSexTargets: function () { return []; },
          collectSexTargetSummaries: function () { return []; },
          enterSexMode: function () { return false; },
          showSexTargetPicker: function () { return false; },
          jumpSexTargets: function () { return false; },
          clearTargetPicker: function () { return false; },
          prepareNativeModeJump: function () { return false; },
          dedupeSexModeButtons: function () { return false; },
          injectSexModeEntry: function () { return false; },
          refreshControls: function () { return false; },
          injectCombatIntentInputs: function () { return false; },
          ensureCombatControls: function () { return false; },
          injectEndCombatButton: function () { return false; },
          forceEndCombat: function () { return false; },
          syncCombatLifecycle: function () { return false; }
        };
      }
    };
  }
  const NativeSceneBridgeModule = window.AIStoryGenNativeSceneBridgeModule || window.AIStoryGen.NativeSceneBridgeModule || _disabledNativeSceneBridgeModule();

  const WorldKnowledge = WorldKnowledgeModule.create();
  const NpcContext = NpcContextModule.create({
    getKnownNpcNames: function () {
      var out = [];
      try {
        var list = _getAiNpcNameList();
        for (var i = 0; i < list.length; i++) {
          var key = String(list[i] || '').trim();
          if (!key) continue;
          out.push({ key: key, name: _toChineseName(key), title: _toChineseName(key) });
        }
      } catch (_) {}
      return out;
    }
  });
  const WorldContext = WorldContextModule.create({
    pageClassifier: PageClassifierModule,
    worldKnowledge: WorldKnowledge,
    npcContext: NpcContext,
    getLocationGraph: function () {
      return window.AIStoryGenLocationGraph || null;
    },
    resolveLocationLabel: function (passage, fallback) {
      try {
        var raw = String(passage || '').trim();
        if (raw) {
          for (var i = 0; i < (_aiCommonLocations || []).length; i++) {
            var loc = _aiCommonLocations[i] || {};
            if (loc.raw === raw && loc.label) return loc.label;
          }
        }
      } catch (_) {}
      return fallback || passage || '';
    },
    getKnownNpcNames: function () {
      var out = [];
      try {
        var list = _getAiNpcNameList();
        for (var i = 0; i < list.length; i++) {
          var key = String(list[i] || '').trim();
          if (!key) continue;
          out.push({ key: key, name: _toChineseName(key), title: _toChineseName(key) });
        }
      } catch (_) {}
      return out;
    }
  });
  window.AIStoryGen.worldContext = WorldContext;
  window.AIStoryGen.npcContext = NpcContext;

  const AIEventValidator = EventValidatorModule.create({
    canonicalAIEventKey: EventParserModule.canonicalAIEventKey,
    normaliseText: _normaliseAIEventText,
    normaliseEventType: _normaliseAIEventType,
    normaliseLocation: _normaliseAIEventLocationValue,
    normaliseStatus: _normaliseAIEventStatusStrict,
    normaliseNameList: _normaliseAIEventNameList,
    parseInt: _parseAiEventInt,
    normaliseItems: _normaliseAIEventItemsField,
    normaliseStats: _normaliseAIEventStatsField,
    normaliseRelationships: _normaliseAIEventRelationshipsField,
    normaliseMoney: _normaliseAIEventMoneyField
  });
  const ConsistencyGuard = ConsistencyGuardModule.create({
    worldContext: WorldContext,
    getKnownLocations: function () {
      return _aiCommonLocations || [];
    }
  });
  window.AIStoryGen.consistencyGuard = ConsistencyGuard;
  const MemoryUI = MemoryUIModule.create({
    $: window.jQuery || window.$,
    getRecentBuf: function () { return recentBuf; },
    getLongTermMem: function () { return longTermMem; },
    normalizeImportantMemoryEntry: _normalizeImportantMemoryEntry,
    memoryEntry: _memoryEntry,
    saveMemoryBuffer: saveMemoryBuffer,
    loadCfg: loadCfg,
    callAI: function (prompt, opts) { return callAI(prompt, opts); },
    isNoUsefulLongTermRefineOutput: _isNoUsefulLongTermRefineOutput,
    refineLongTermMemoryBulkText: _refineLongTermMemoryBulkText,
    previewLongTermMemoryBulkText: _previewLongTermMemoryBulkText,
    trimLongTermMem: _trimLongTermMem,
    enforceRecentMemoryLimit: enforceRecentMemoryLimit,
    exportMemoryBuffer: exportMemoryBuffer,
    importMemoryBuffer: importMemoryBuffer,
    addImportantMemory: addImportantMemory,
    confirm: function (message) { return window.confirm(message); }
  });
  window.AIStoryGen.MemoryUI = MemoryUI;

  function _getMemorySaveIdForStateStore() {
    return _aiMemorySaveId;
  }

  function _setMemorySaveIdForStateStore(id) {
    _aiMemorySaveId = String(id || '').trim();
    return _aiMemorySaveId;
  }

  var AI_STORY_LOCAL_ONLY_CFG_KEYS = {
    apiKey: true,
    endpoint: true,
    model: true,
    highQualityEndpoint: true,
    highQualityModel: true
  };

  var AI_PIXEL_LOCAL_ONLY_CFG_KEYS = {
    llmEndpoint: true,
    llmKey: true,
    llmModel: true,
    imgEndpoint: true,
    imgKey: true,
    imgModel: true,
    specialImgEndpoint: true,
    specialImgModel: true,
    specialPoseControlNetModel: true
  };

  var AI_STORY_PROMPT_CFG_KEYS = {
    jailbreak: true,
    systemPromptExtra: true,
    storyStylePrompt: true,
    playerStoryProfile: true,
    longTermRefinePrompt: true
  };

  function _copyConfigExceptLocalOnly(source, blocked) {
    return ConfigStoreModule.copyExcept(source, blocked);
  }

  function _loadPixelCfgForSaveScope() {
    try {
      if (window.AIPixelGen && typeof window.AIPixelGen.loadCfg === 'function') return window.AIPixelGen.loadCfg();
    } catch (_) {}
    try {
      var raw = localStorage.getItem('aiPixelGen_cfg');
      return raw ? JSON.parse(raw) : {};
    } catch (_) {
      return {};
    }
  }

  function _savePixelCfgForSaveScope(next) {
    try {
      if (window.AIPixelGen && typeof window.AIPixelGen.saveCfg === 'function') {
        window.AIPixelGen.saveCfg(next);
        return;
      }
    } catch (_) {}
    try { localStorage.setItem('aiPixelGen_cfg', JSON.stringify(next || {})); } catch (_) {}
  }

  function _captureSaveScopedConfig() {
    return {
      schemaVersion: 1,
      story: _copyConfigExceptLocalOnly(loadCfg(), AI_STORY_LOCAL_ONLY_CFG_KEYS),
      pixel: _copyConfigExceptLocalOnly(_loadPixelCfgForSaveScope(), AI_PIXEL_LOCAL_ONLY_CFG_KEYS)
    };
  }

  function _syncSaveScopedConfigToCurrentMoment(reason) {
    try {
      if (typeof State === 'undefined') return;
      var scoped = _captureSaveScopedConfig();
      function write(vars) {
        if (!vars || typeof vars !== 'object') return;
        vars.aiStoryGenConfig = _safeCloneForAiState(scoped);
        _patchAIStoryGenStateField(vars, 'config', scoped);
      }
      write(_getStateVariables());
      if (State.active && State.active.variables) write(State.active.variables);
      if (Array.isArray(State.history) && State.activeIndex != null && State.history[State.activeIndex] && State.history[State.activeIndex].variables) {
        write(State.history[State.activeIndex].variables);
      }
      if (Array.isArray(State._history) && State.activeIndex != null && State._history[State.activeIndex] && State._history[State.activeIndex].variables) {
        write(State._history[State.activeIndex].variables);
      }
    } catch (e) {
      try { console.warn('[AIStoryGen] sync save-scoped config failed' + (reason ? ' (' + reason + ')' : ''), e); } catch (_) {}
    }
  }

  function _normaliseSaveScopedConfig(config) {
    config = config && typeof config === 'object' ? config : {};
    return {
      schemaVersion: 1,
      story: _copyConfigExceptLocalOnly(config.story || {}, AI_STORY_LOCAL_ONLY_CFG_KEYS),
      pixel: _copyConfigExceptLocalOnly(config.pixel || {}, AI_PIXEL_LOCAL_ONLY_CFG_KEYS)
    };
  }

  function _restoreSaveScopedConfig(config) {
    config = _normaliseSaveScopedConfig(config || {});
    var story = config.story || {};
    var pixel = config.pixel || {};
    if (Object.keys(story).length) {
      var currentStory = loadCfg();
      Object.keys(AI_STORY_PROMPT_CFG_KEYS).forEach(function (k) {
        if (story[k] === '' && currentStory[k]) delete story[k];
      });
      saveCfg(ConfigStoreModule.mergeScoped(currentStory, story, AI_STORY_LOCAL_ONLY_CFG_KEYS));
    }
    if (Object.keys(pixel).length) {
      var currentPixel = _loadPixelCfgForSaveScope();
      _savePixelCfgForSaveScope(ConfigStoreModule.mergeScoped(currentPixel, pixel, AI_PIXEL_LOCAL_ONLY_CFG_KEYS));
    }
    try { $(document).trigger('AIStoryGen:configSaved', [loadCfg()]); } catch (_) {}
  }

  function _showConfigHelpText(text) {
    text = String(text || '').trim();
    if (!text) return;
    try {
      if (typeof Dialog !== 'undefined' && Dialog && typeof Dialog.setup === 'function') {
        Dialog.setup('说明');
        if (typeof Dialog.wiki === 'function') Dialog.wiki(text);
        else if (Dialog.body) $(Dialog.body()).text(text);
        Dialog.open();
        return;
      }
    } catch (_) {}
    try { window.alert(text); } catch (_) {}
  }

  function _installConfigHelpTapHandler() {
    if (window.AIStoryGen && window.AIStoryGen._configHelpTapInstalled) return;
    if (window.AIStoryGen) window.AIStoryGen._configHelpTapInstalled = true;
    try {
      if (MobileCompat && typeof MobileCompat.bindTapHelp === 'function') {
        var mounted = MobileCompat.bindTapHelp({
          $: $,
          document: document,
          selector: '.ai-cfg-help',
          namespace: 'aiStoryGenConfigHelp',
          show: _showConfigHelpText,
          getText: function (node) {
            return $(node).attr('data-help') || $(node).attr('title') || '';
          }
        });
        if (mounted) return;
      }
    } catch (_) {}
    var lastTouchAt = 0;
    $(document)
      .off('touchend.aiStoryGenConfigHelp click.aiStoryGenConfigHelp keydown.aiStoryGenConfigHelp')
      .on('touchend.aiStoryGenConfigHelp', '.ai-cfg-help', function (ev) {
        lastTouchAt = Date.now();
        ev.preventDefault();
        ev.stopPropagation();
        _showConfigHelpText($(this).attr('data-help') || $(this).attr('title') || '');
      })
      .on('click.aiStoryGenConfigHelp', '.ai-cfg-help', function (ev) {
        if (Date.now() - lastTouchAt < 500) return;
        ev.preventDefault();
        ev.stopPropagation();
        _showConfigHelpText($(this).attr('data-help') || $(this).attr('title') || '');
      })
      .on('keydown.aiStoryGenConfigHelp', '.ai-cfg-help', function (ev) {
        if (ev.key !== 'Enter' && ev.key !== ' ') return;
        ev.preventDefault();
        ev.stopPropagation();
        _showConfigHelpText($(this).attr('data-help') || $(this).attr('title') || '');
      });
  }

  _installConfigHelpTapHandler();

  const _aiStateStore = StateStoreModule.create({
    schemaVersion: AI_STATE_SCHEMA_VERSION,
    memoryBackupKey: MEMORY_BACKUP_KEY,
    memoryBackupMax: MEMORY_BACKUP_MAX,
    normalizeImportantMemoryEntry: _normalizeImportantMemoryEntry,
    snapshotMemory: _snapshotMemoryForSave,
    getStateVariables: _getStateVariables,
    currentPassageName: _currentPassageName,
    clone: function (value) {
      try {
        if (typeof _cloneForAiSnapshot === 'function') return _cloneForAiSnapshot(value);
      } catch (_) {}
      try {
        return JSON.parse(JSON.stringify(value));
      } catch (_) {
        return value;
      }
    },
    normalizeItemStoreArray: _normaliseAiItemStoreArray,
    normalizeScene: _normaliseAISavedScene,
    getItemStore: _getAiItemStore,
    captureScene: _captureAISaveStateForSave,
    captureIntimateScene: _captureAIIntimateSceneForSave,
    captureSaveScopedConfig: _captureSaveScopedConfig,
    normalizeSaveScopedConfig: _normaliseSaveScopedConfig,
    idbSet: idbSet,
    getMemorySaveId: _getMemorySaveIdForStateStore,
    setMemorySaveId: _setMemorySaveIdForStateStore
  });
  window.AIStoryGen.stateStore = _aiStateStore;
  _aiStateStoreReady = true;

  function _memoryHasContent(mem) {
    return _aiStateStore.memoryHasContent(mem);
  }

  function _safeCloneForAiState(value) {
    return _aiStateStore.clone(value);
  }

  function _ensureMemorySaveId(vars) {
    return _aiStateStore.ensureMemorySaveId(vars);
  }

  function _persistMemoryEmergencyBackup(mem, reason) {
    return _aiStateStore.persistMemoryEmergencyBackup(mem, reason);
  }

  function _normaliseAiStateEventLog(log) {
    return _aiStateStore.normalizeEventLog(log);
  }

  function _patchAIStoryGenStateField(vars, field, value) {
    return _aiStateStore.patchField(vars, field, value);
  }

  function _legacyAIStoryGenStateFromSave(save) {
    return _aiStateStore.readFromSave(save);
  }

  function _buildAIStoryGenStateForSave(reason) {
    return _aiStateStore.build(reason);
  }

  function _writeAIStoryGenStateToCurrentMoment(aiState) {
    return _aiStateStore.writeToCurrentMoment(aiState);
  }

  function _writeAIStoryGenStateToSave(save, aiState) {
    return _aiStateStore.writeToSave(save, aiState);
  }

  function _syncAIStoryGenStateToCurrentSave(reason) {
    return _aiStateStore.syncCurrent(reason);
  }

  function _stripHtmlForAiRecord(text) {
    text = String(text || '');
    text = text.replace(/<\s*br\s*\/?>/gi, '。 ');
    text = text.replace(/<[^>]+>/g, ' ');
    var map = { '&nbsp;': ' ', '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'" };
    text = text.replace(/&(nbsp|amp|lt|gt|quot|#39);/g, function (m) { return map[m] || ' '; });
    return text.replace(/\s+/g, ' ').trim();
  }

  function _removeAIEventBlocks(text) {
    return EventParserModule.removeAIEventBlocks(text);
  }

  function _cleanRecordText(text) {
    text = _removeAIEventBlocks(text);
    text = _stripHtmlForAiRecord(text);
    text = text
      .replace(/\[(?:ITEMS?|AI_ITEMS_USED|LOC|AI_META)[^\]]*\]/gi, ' ')
      .replace(/\[STATS:\s*[^\]]+\]/gi, ' ')
      .replace(/\[[^\]]*(?:压力|疲劳|兴奋|性奋|疼痛|创伤|诱惑|自控|金钱|arousal|stress|pain|trauma|money)[^\]]*\]/gi, ' ')
      .replace(/🔄\s*刷新剧情|🔁\s*刷新选项|☆\s*收藏剧情进长期记忆|使用道具|纠正地点|强制调整剧情地点|手动选择到达地点|返回游戏|返回原版章节/g, ' ')
      .replace(/\[可拾取AI道具\][^。！？.!?]*(?:收入AI库存|不拿)?/g, ' ')
      .replace(/收入AI库存|不拿/g, ' ')
      .replace(/\s*\|\s*/g, '；')
      .replace(/\s+/g, ' ')
      .trim();
    return text;
  }

  function _isRecordPollutionText(text) {
    var raw = String(text || '');
    var clean = _cleanRecordText(raw);
    if (!clean) return true;
    if (/<[^>]+>|style\s*=|color\s*:\s*#|<\/span/i.test(raw) && !/(你|主角|玩家|到达|进入|前往|离开|回到|遇见|交谈|获得|得到|找到|发现|捡到|拾起|支付|选择|决定|伊甸|罗宾|贝利|艾弗里|Alex|Robin|Bailey|Eden)/i.test(clean)) return true;
    if (/^(?:[\[\]【】\s;；,，。|+-]*)(?:压力|疲劳|兴奋|性奋|疼痛|创伤|诱惑|自控|金钱|arousal|stress|pain|trauma|money)\s*[+-]?\d+(?:\s*[;；,，|]\s*(?:压力|疲劳|兴奋|性奋|疼痛|创伤|诱惑|自控|金钱|arousal|stress|pain|trauma|money)\s*[+-]?\d+)*[\s;；,，。|+-]*$/i.test(clean)) return true;
    if (/^(?:刷新剧情|刷新选项|收藏剧情进长期记忆|使用道具|纠正地点|强制调整剧情地点|手动选择到达地点|返回游戏|返回原版章节|收入AI库存|不拿)+$/i.test(clean.replace(/\s+/g, ''))) return true;
    return false;
  }

  function _parseListField(value) {
    return EventParserModule.parseListField(value);
  }

  function _parseAIEventBlock(text) {
    var parsed = EventParserModule.parseAIEventBlock(text);
    return _validateAIEventData(parsed, String(text || ''));
  }

  function _normaliseAIEventText(value, maxLen) {
    var clean = _cleanRecordText(value);
    clean = clean.replace(/^\s*[:=]\s*/, '').replace(/\s+/g, ' ').trim();
    if (!clean || _isRecordPollutionText(clean)) return '';
    if (maxLen && clean.length > maxLen) clean = clean.slice(0, maxLen).trim();
    return clean;
  }

  function _normaliseAIEventNameList(value, maxItems, maxLen) {
    var out = [];
    _parseListField(value).forEach(function (part) {
      part = _normaliseAIEventText(cleanLabel(part), maxLen || 40);
      if (!part) return;
      if (/^(?:none|null|unknown|current|same|n\/a)$/i.test(part)) return;
      if (/^(?:ui|menu|button|sidebar|log|inventory|journal)$/i.test(part)) return;
      out.push(part);
    });
    return _dedupeTextList(out).slice(0, maxItems || 10).join(';');
  }

  function _isInvalidAIEventLocationValue(value) {
    var raw = cleanLabel(String(value || '')).replace(/\s+/g, ' ').trim();
    if (!raw) return true;
    var compact = raw.replace(/\s+/g, '');
    if (/^(?:跑|逃|逃跑|躲|躲避|避开|移动|行动|前进|继续|离开|返回|回去|走|走路|赶路|行走|奔跑|run|flee|escape|hide|move|walk|go|leave|return|continue|action)$/i.test(compact)) return true;
    if (/^(?:跑去|跑到|逃到|躲到|前往|去|进入|到达|抵达)$/i.test(compact)) return true;
    if (/^(?:跑|逃|躲|走|去|到|进|回)[\s:：-]*$/i.test(raw)) return true;
    return false;
  }

  // Recent DoL builds keep SugarCube internals under window.SugarCube, while
  // older builds also expose global Story/Engine. Keep one compatibility path
  // so location, event settlement, and recovery routines agree on the runtime.
  function _getNativeStory() {
    try {
      if (typeof Story !== 'undefined' && Story) return Story;
      return (typeof window !== 'undefined' && window.SugarCube && window.SugarCube.Story) || null;
    } catch (_) {
      return null;
    }
  }

  function _getNativeEngine() {
    try {
      if (typeof Engine !== 'undefined' && Engine) return Engine;
      return (typeof window !== 'undefined' && window.SugarCube && window.SugarCube.Engine) || null;
    } catch (_) {
      return null;
    }
  }

  // DoL exposes story variables differently across SugarCube builds. Several
  // runtime and diagnostic paths need the same guarded lookup.
  function getV() {
    try { if (typeof V !== 'undefined' && V) return V; } catch (_) {}
    try { if (typeof State !== 'undefined' && State && State.variables) return State.variables; } catch (_) {}
    try {
      if (typeof window !== 'undefined' && window.SugarCube && window.SugarCube.State && window.SugarCube.State.variables) {
        return window.SugarCube.State.variables;
      }
    } catch (_) {}
    return null;
  }

  function _nativeStoryHas(passageName) {
    var story = _getNativeStory();
    try { return !!(story && typeof story.has === 'function' && story.has(passageName)); } catch (_) { return false; }
  }

  function _normaliseAIEventLocationValue(value) {
    var raw = String(value || '').replace(/^["'`]+|["'`]+$/g, '').replace(/\s+/g, ' ').trim();
    raw = cleanLabel(raw);
    if (!raw || /^(?:current|same|unchanged|none|null|unknown|here|n\/a)$/i.test(raw)) return '';
    if (/^(?:\u5f53\u524d|\u539f\u5730|\u4e0d\u53d8|\u672a\u77e5|\u65e0|\u8fd9\u91cc|\u672c\u5730)$/.test(raw)) return '';
    if (_isInvalidAIEventLocationValue(raw)) return '';
    var common = _findCommonLocation(raw);
    if (common && common.narrativeArrival === false && common.containerRaw) {
      common = _findCommonLocationByRaw(common.containerRaw) || { raw: common.containerRaw };
    }
    if (common && common.raw && !_isUnsafeDirectPassage(common.raw)) return common.raw;
    var graphLoc = _findGraphLocation(raw);
    if (graphLoc) {
      var canonical = graphLoc.locId ? _findCommonLocationByLocId(graphLoc.locId) : null;
      if (!canonical && graphLoc.passage) canonical = _findCommonLocationByRaw(graphLoc.passage) || _findCommonLocationByPrefix(graphLoc.passage);
      if (canonical && canonical.narrativeArrival === false && canonical.containerRaw) {
        canonical = _findCommonLocationByRaw(canonical.containerRaw) || { raw: canonical.containerRaw };
      }
      var graphRaw = (canonical && canonical.raw) || graphLoc.passage || raw;
      graphRaw = _normalizePassageName(graphRaw);
      if (graphRaw && !_isUnsafeDirectPassage(graphRaw)) return graphRaw;
    }
    var normal = _normalizePassageName(raw);
    if (!normal || _isUnsafeDirectPassage(normal)) return '';
    try {
      var nativeStory = _getNativeStory();
      if (nativeStory && !_nativeStoryHas(normal)) return '';
    } catch (_) {}
    return normal;
  }

  function _normaliseAIEventStatusStrict(value) {
    var status = _normaliseAiEventStatus(value);
    return /^(arrived|inTransit|current)$/.test(status) ? status : '';
  }

  function _normaliseAIEventType(value) {
    var type = String(value || '').replace(/\s+/g, '_').toLowerCase().trim();
    var allowed = {
      scene: 1,
      travel: 1,
      conversation: 1,
      item: 1,
      state: 1,
      native_action: 1,
      combat: 1,
      other: 1
    };
    return allowed[type] ? type : '';
  }

  function _normaliseAIEventItemsField(value) {
    var items = [];
    _parseListField(value).forEach(function (token) {
      _expandAiItemTokens(token).forEach(function (part) {
        var item = _parseAiItemToken(part);
        if (item) items.push(item);
      });
    });
    return _mergeAiItemListByName(items).slice(0, 8).map(_formatRuntimeItemForEvent).filter(Boolean).join(';');
  }

  function _normaliseAIEventStatsField(value, rawText) {
    var out = [];
    var seen = {};
    var explicitMoneyDelta = _inferExplicitMoneyDeltaFromNarrative(rawText);
    _parseListField(value).forEach(function (part) {
      if (/^\s*(?:money|\u91d1\u94b1|\u94b1)\s*[+-]/i.test(String(part || ''))) return;
      _pushNormalisedAiStatPart(out, seen, part, explicitMoneyDelta);
    });
    return out.join(';');
  }

  function _normaliseAIEventRelationshipsField(value) {
    var cfg;
    try { cfg = loadCfg(); } catch (_) { cfg = DEFAULT_CFG || {}; }
    var relationChance = Math.max(0, Math.min(100, Number(cfg.npcRelationChangeChance == null ? DEFAULT_CFG.npcRelationChangeChance : cfg.npcRelationChangeChance) || 0));
    var relationLimits = _getAiNpcRelationFieldLimits(cfg);
    if (relationChance <= 0 || !_hasAnyAiNpcRelationFieldLimit(relationLimits)) return '';
    var schema = _getAiNpcRelationSchema();
    var out = [];
    var seen = {};
    String(value || '').split(/[;\uff1b]/).forEach(function (entry) {
      entry = String(entry || '').trim();
      if (!entry) return;
      var npcName = '';
      var body = entry;
      var colon = entry.match(/^(.+?)\s*[:=]\s*(.+)$/);
      if (colon) {
        npcName = colon[1];
        body = colon[2];
      } else {
        var first = entry.match(/^([A-Za-z\u4e00-\u9fff][A-Za-z\u4e00-\u9fff\s_\-]{0,32})\s+(.+)$/);
        if (first) {
          npcName = first[1];
          body = first[2];
        }
      }
      var npcKey = _resolveAiNpcKey(npcName);
      if (!npcKey) return;
      String(body || '').split(/[,\uff0c\u3001|]/).forEach(function (part) {
        var m = String(part || '').trim().match(/^(\w+)\s*([+-]\d+)/);
        if (!m) return;
        var spec = schema[m[1].toLowerCase()];
        if (!spec) return;
        var delta = parseInt(m[2], 10);
        if (!delta) return;
        var fieldLimit = Number(relationLimits[spec.key] || 0);
        if (fieldLimit <= 0) return;
        delta = Math.max(-fieldLimit, Math.min(fieldLimit, delta));
        if (!delta) return;
        var dedupe = npcKey + ':' + spec.key;
        if (seen[dedupe]) return;
        seen[dedupe] = true;
        out.push(npcKey + ':' + spec.key + (delta >= 0 ? '+' : '') + delta);
      });
    });
    return out.join(';');
  }

  function _normaliseAIEventMoneyField(value, rawText) {
    var raw = String(value || '').replace(/\s+/g, '').trim();
    var m = raw.match(/^[+-]?\d+$/);
    if (!m) return '';
    var val = parseInt(raw, 10);
    if (!val) return '';
    var explicitMoneyDelta = _inferExplicitMoneyDeltaFromNarrative(rawText);
    if (!explicitMoneyDelta) return '';
    if (Math.sign(explicitMoneyDelta) !== Math.sign(val)) return '';
    if (Math.abs(explicitMoneyDelta) !== Math.abs(val)) return '';
    return String(val);
  }

  function _validateAIEventData(data, rawText) {
    var validated = AIEventValidator.validate(data, rawText);
    try {
      var cfg = loadCfg();
      var guarded = ConsistencyGuard.check(validated, {
        rawText: rawText,
        choiceText: _lastChoiceText || '',
        cfg: cfg,
        state: buildState(cfg),
        scene: buildScene(),
        pageText: _getCurrentNativePageText(1800)
      });
      _lastConsistencyDiagnostics = Array.isArray(guarded && guarded._diagnostics)
        ? guarded._diagnostics.slice(-20)
        : [];
      _lastConsistencyBlockedEffects = Array.isArray(guarded && guarded._blockedEffects)
        ? guarded._blockedEffects.slice(-20)
        : [];
      if (guarded && guarded._diagnostics) delete guarded._diagnostics;
      if (guarded && guarded._blockedEffects) delete guarded._blockedEffects;
      return guarded || validated;
    } catch (e) {
      _lastConsistencyDiagnostics = [{ level: 'error', code: 'consistency_guard_failed', message: String(e && e.message || e) }];
      _lastConsistencyBlockedEffects = [];
      try { console.warn('[AIStoryGen] consistency guard failed', e); } catch (_) {}
      return validated;
    }
  }

  function _parseStatsChangesFromText(text) {
    var changes = [];
    String(text || '').replace(/\[STATS:\s*([^\]]+)\]/gi, function (_, body) {
      String(body || '').split(/[,\uff0c;\uff1b\u3001|]/).forEach(function (part) {
        part = part.trim();
        if (/^[\w\u4e00-\u9fff]+\s*[+-]\d+/.test(part)) changes.push(part.replace(/\s+/g, ''));
      });
      return '';
    });
    return changes;
  }

  function _collectAiRuntimeItems(rawText, eventData) {
    var items = [];
    eventData = eventData || _parseAIEventBlock(rawText);
    _parseListField(eventData.itemsGained || eventData.items || '').forEach(function (token) {
      _expandAiItemTokens(token).forEach(function (part) {
        var item = _parseAiItemToken(part);
        if (item) items.push(item);
      });
    });
    String(rawText || '').replace(/\[ITEMS?:\s*([^\]]+)\]/gi, function (_, body) {
      String(body || '').split(/[;\uff1b,\uff0c\u3001]/).forEach(function (token) {
        _expandAiItemTokens(token).forEach(function (part) {
          var item = _parseAiItemToken(part);
          if (item) items.push(item);
        });
      });
      return '';
    });
    return _filterAiRuntimeItems(_mergeAiItemListByName(items));
  }

  function _collectAiRuntimeLostItems(rawText, eventData) {
    var items = [];
    eventData = eventData || _parseAIEventBlock(rawText);
    _parseListField(eventData.itemsLost || '').forEach(function (token) {
      _expandAiItemTokens(token).forEach(function (part) {
        var item = _parseAiItemToken(part);
        if (item) items.push(item);
      });
    });
    String(rawText || '').replace(/\[AI_ITEMS_USED:\s*([^\]]+)\]\s*/gi, function (_, body) {
      String(body || '').split(/[;\uff1b,\uff0c\u3001]/).forEach(function (token) {
        _expandAiItemTokens(token).forEach(function (part) {
          var item = _parseAiItemToken(part);
          if (item) items.push(item);
        });
      });
      return '';
    });
    return _filterAiRuntimeItems(_mergeAiItemListByName(items));
  }

  function _formatRuntimeItemForEvent(item) {
    return ItemSchemaModule.formatRuntimeItemForEvent(item);
  }

  function _getAiNpcRelationSchema() {
    return EventSchemaModule.getNpcRelationSchema();
  }

  function _getAiNpcRelationLimitFieldDefs() {
    return [
      { field: 'love', key: 'npcRelationChangeLimitLove', label: '好感' },
      { field: 'trust', key: 'npcRelationChangeLimitTrust', label: '信任' },
      { field: 'lust', key: 'npcRelationChangeLimitLust', label: '欲望' },
      { field: 'rage', key: 'npcRelationChangeLimitRage', label: '愤怒' },
      { field: 'dom', key: 'npcRelationChangeLimitDom', label: '支配' }
    ];
  }

  function _clampAiNpcRelationLimit(value, fallback) {
    var num = Number(value == null || value === '' ? fallback : value);
    if (!isFinite(num)) num = Number(fallback) || 0;
    return Math.max(0, Math.min(10, Math.round(num)));
  }

  function _getAiNpcRelationBaseLimit(cfg) {
    cfg = cfg || {};
    return _clampAiNpcRelationLimit(cfg.npcRelationChangeLimit, DEFAULT_CFG.npcRelationChangeLimit);
  }

  function _getAiNpcRelationFieldLimit(cfg, field) {
    cfg = cfg || {};
    var base = _getAiNpcRelationBaseLimit(cfg);
    var defs = _getAiNpcRelationLimitFieldDefs();
    for (var i = 0; i < defs.length; i++) {
      if (defs[i].field === field) return _clampAiNpcRelationLimit(cfg[defs[i].key], base);
    }
    return base;
  }

  function _getAiNpcRelationFieldLimits(cfg) {
    var out = {};
    _getAiNpcRelationLimitFieldDefs().forEach(function (def) {
      out[def.field] = _getAiNpcRelationFieldLimit(cfg, def.field);
    });
    return out;
  }

  function _hasAnyAiNpcRelationFieldLimit(limits) {
    limits = limits || {};
    return ['love', 'trust', 'lust', 'rage', 'dom'].some(function (field) {
      return Number(limits[field] || 0) > 0;
    });
  }

  function _formatAiNpcRelationFieldLimitText(cfg) {
    var limits = _getAiNpcRelationFieldLimits(cfg);
    return _getAiNpcRelationLimitFieldDefs().map(function (def) {
      var limit = Number(limits[def.field] || 0);
      return def.field + (limit > 0 ? ' +/-' + limit : ' disabled');
    }).join(', ');
  }

  function _getAiNpcRoot() {
    try {
      if (typeof C !== 'undefined' && C && C.npc) return C.npc;
      if (window.C && window.C.npc) return window.C.npc;
    } catch (_) {}
    return null;
  }

  function _getAiNpcNameList() {
    try {
      var st = (typeof setup !== 'undefined' && setup) ? setup : (window.SugarCube && window.SugarCube.setup) || window.setup;
      if (st && Array.isArray(st.NPCNameList)) return st.NPCNameList.slice();
    } catch (_) {}
    var root = _getAiNpcRoot();
    return root ? Object.keys(root) : [];
  }

  function _normaliseNpcLookupText(text) {
    return String(text || '').toLowerCase().replace(/[\s_\-·・'"\u2018\u2019\u201c\u201d]/g, '').trim();
  }

  function _resolveAiNpcKey(name) {
    var needle = _normaliseNpcLookupText(name);
    if (!needle) return '';
    var list = _getAiNpcNameList();
    var root = _getAiNpcRoot();
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
    for (var i = 0; i < list.length; i++) {
      var key = String(list[i] || '');
      var npc = (root && root[key]) || (V && V[key]) || {};
      var aliases = [
        key,
        _toChineseName(key),
        npc.title,
        npc.name,
        npc.fullDescription,
        npc.description
      ];
      for (var j = 0; j < aliases.length; j++) {
        var alias = _normaliseNpcLookupText(aliases[j]);
        if (alias && alias === needle) return key;
      }
    }
    return '';
  }

  function _collectAiNpcRelationshipChanges(rawText, eventData) {
    eventData = eventData || _parseAIEventBlock(rawText);
    var schema = _getAiNpcRelationSchema();
    var raw = String(
      eventData.relationshipChanges ||
      eventData.npcRelationshipChanges ||
      eventData.npcRelations ||
      eventData.relationships ||
      ''
    ).trim();
    if (!raw) return [];
    var cfg;
    try { cfg = loadCfg(); } catch (_) { cfg = DEFAULT_CFG || {}; }
    var relationChance = Math.max(0, Math.min(100, Number(cfg.npcRelationChangeChance == null ? DEFAULT_CFG.npcRelationChangeChance : cfg.npcRelationChangeChance) || 0));
    var relationLimits = _getAiNpcRelationFieldLimits(cfg);
    if (relationChance <= 0 || !_hasAnyAiNpcRelationFieldLimit(relationLimits)) return [];
    var out = [];
    var seen = {};
    String(raw || '').split(/[;\uff1b]/).forEach(function (entry) {
      entry = String(entry || '').trim();
      if (!entry) return;
      var npcName = '';
      var body = entry;
      var colon = entry.match(/^(.+?)\s*[:=]\s*(.+)$/);
      if (colon) {
        npcName = colon[1];
        body = colon[2];
      } else {
        var first = entry.match(/^([A-Za-z\u4e00-\u9fff][A-Za-z\u4e00-\u9fff\s_\-·・']{0,32})\s+(.+)$/);
        if (first) {
          npcName = first[1];
          body = first[2];
        }
      }
      var npcKey = _resolveAiNpcKey(npcName);
      if (!npcKey) return;
      String(body || '').split(/[,\uff0c\u3001|]/).forEach(function (part) {
        var m = String(part || '').trim().match(/^(\w+)\s*([+-]\d+)/);
        if (!m) return;
        var field = m[1].toLowerCase();
        var spec = schema[field];
        if (!spec) return;
        var delta = parseInt(m[2], 10);
        if (!delta) return;
        var fieldLimit = Number(relationLimits[spec.key] || 0);
        if (fieldLimit <= 0) return;
        delta = Math.max(-fieldLimit, Math.min(fieldLimit, delta));
        if (!delta) return;
        if (!_passesAiNpcRelationChance(rawText, npcKey, spec.key, delta, relationChance)) return;
        var dedupe = npcKey + ':' + spec.key;
        if (seen[dedupe]) return;
        seen[dedupe] = true;
        out.push({ npc: npcKey, field: spec.key, delta: delta, label: _toChineseName(npcKey) || npcKey });
      });
    });
    return out;
  }

  function _formatNpcRelationshipChangeForEvent(change) {
    return EventSchemaModule.formatNpcRelationshipChange(change);
  }

  function _hashAiStringForChance(text) {
    var hash = 2166136261;
    text = String(text || '');
    for (var i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
    }
    return hash >>> 0;
  }

  function _passesAiNpcRelationChance(rawText, npcKey, field, delta, chance) {
    chance = Math.max(0, Math.min(100, Number(chance) || 0));
    if (chance >= 100) return true;
    if (chance <= 0) return false;
    var seed = [npcKey, field, delta, String(rawText || '').slice(0, 1200)].join('|');
    return (_hashAiStringForChance(seed) % 100) < chance;
  }

  function _dedupeTextList(list) {
    var out = [];
    var seen = {};
    (list || []).forEach(function (value) {
      value = String(value || '').replace(/\s+/g, ' ').trim();
      if (!value) return;
      var key = value.toLowerCase();
      if (seen[key]) return;
      seen[key] = 1;
      out.push(value);
    });
    return out;
  }

  function _parseAiEventInt(value, min, max, fallback) {
    var n = parseInt(value, 10);
    if (!isFinite(n)) return fallback;
    if (min != null && n < min) n = min;
    if (max != null && n > max) n = max;
    return n;
  }

  function _normaliseAiEventStatus(value) {
    value = String(value || '').replace(/\s+/g, '').toLowerCase();
    if (!value) return '';
    if (/^(arrived|enter|entered|reached|changed|destination|done|到达|进入|抵达|已到达|已进入|地点变化)$/.test(value)) return 'arrived';
    if (/^(intransit|transit|moving|travel|travelling|traveling|ontheway|途中|路上|前往中|移动中)$/.test(value)) return 'inTransit';
    if (/^(current|same|unchanged|nochange|none|null|unknown|当前|原地|不变|未知)$/.test(value)) return 'current';
    return value;
  }

  function _aiEventIndicatesArrival(eventData) {
    var status = _normaliseAiEventStatus(eventData && (eventData.locationStatus || eventData.location_status || eventData.travelStatus || eventData.arrivalStatus));
    if (!status) return true;
    return status === 'arrived';
  }

  function _aiEventSuppressesLocationFallback(text) {
    var data = _parseAIEventBlock(text);
    var hasMarker = /\[AI_EVENT\]|\[AI_EVENT:/i.test(String(text || ''));
    if (!data || !Object.keys(data).length) return !!hasMarker;
    var status = _normaliseAiEventStatus(data.locationStatus || data.location_status || data.travelStatus || data.arrivalStatus);
    return status !== 'arrived';
  }

  function _lastAiEventSuppressesLocationFallback() {
    var log = _getAiEventLog();
    if (!log || !log.length) return false;
    var last = log[log.length - 1] || {};
    var status = _normaliseAiEventStatus(last.locationStatus || '');
    return status === 'current' || status === 'inTransit';
  }

  function _lastAiEventLocationStatus() {
    var log = _getAiEventLog();
    if (!log || !log.length) return '';
    var last = log[log.length - 1] || {};
    return _normaliseAiEventStatus(last.locationStatus || '');
  }

  function _aiEventPresentTargets(eventData) {
    eventData = eventData || {};
    return _dedupeTextList(
      _parseListField(eventData.sexTargets || eventData.sex_targets || eventData.presentTargets || eventData.present_targets || '')
        .concat(_parseListField(eventData.presentCharacters || eventData.present_characters || ''))
        .concat(_parseListField(eventData.presentEntities || eventData.present_entities || ''))
    );
  }

  function _inferPresentTargetsFromEventText(text) {
    text = String(text || '').replace(/\s+/g, ' ');
    var out = { characters: [], entities: [] };
    if (!text) return out;
    var presentCue = /(身旁|旁边|面前|怀抱|肩|触碰|靠向|看着|望着|说|问|回答|微笑|回抱|拉住|牵住|站在|坐在|蹲在|走近|靠近|一起|正在|appears?|stands?|sits?|beside|near|with you|says?|asks?|smiles?|looks?|holds?|touches?)/i;
    var absentCue = /(离开|不在|回忆|想起|想象|梦|纸条|信|照片|日志|库存|left|gone|not here|remember|memory|dream|note|letter|photo|journal|inventory)/i;
    try {
      var candidates = typeof _getNativeSexCandidateTemplates === 'function' ? _getNativeSexCandidateTemplates() : [];
      candidates.forEach(function (candidate) {
        if (!candidate || !candidate.re || !candidate.re.test(text)) return;
        var match = text.match(candidate.re);
        var idx = match ? text.indexOf(match[0]) : -1;
        var ctx = idx >= 0 ? text.slice(Math.max(0, idx - 50), Math.min(text.length, idx + 70)) : text;
        if (absentCue.test(ctx) || !presentCue.test(ctx)) return;
        if (/触手|狗|犬|狼|tentacle|dog|wolf/i.test(candidate.label || candidate.npc || '')) out.entities.push(candidate.label || candidate.npc);
        else out.characters.push(candidate.label || candidate.npc);
      });
    } catch (_) {}
    out.characters = _dedupeTextList(out.characters);
    out.entities = _dedupeTextList(out.entities);
    return out;
  }

  function _eventSummaryFromText(text, eventData) {
    var summary = _cleanRecordText((eventData && (eventData.summary || eventData.memory || eventData.eventSummary)) || '');
    if (!summary) {
      var clean = _cleanRecordText(text);
      var sentences = clean.split(/(?<=[。！？!?])\s+|[；;]/).map(function (s) { return s.trim(); }).filter(Boolean);
      summary = sentences.slice(0, 2).join(' ');
    }
    summary = summary.replace(/\s+/g, ' ').trim();
    if (_isRecordPollutionText(summary)) return '';
    if (summary.length > 220) summary = summary.slice(0, 220) + '...';
    return summary;
  }

  function _visualActionFromNarrative(text) {
    var clean = _cleanRecordText(text || '')
      .replace(/\[[^\]]{1,120}\]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!clean) return '';
    var sentences = clean.split(/(?<=[。！？.!?])\s*/).map(function (part) {
      return String(part || '').replace(/^["'“”「」]+|["'“”「」]+$/g, '').trim();
    }).filter(Boolean).slice(0, 8);
    var visibleVerb = /(?:走|跑|坐|躺|蹲|跪|站|蜷缩|倚|靠|起身|转身|侧身|伸手|抬手|拿|握|抱|触|碰|摸|抚|拉|推|打开|关上|穿|脱|洗|剪|摘|捡|放|倒|吃|喝|看|观察|检查|walk|run|sit|lie|kneel|stand|curl|lean|turn|reach|hold|touch|stroke|pull|push|open|close|wear|remove|wash|cut|pick|place|eat|drink|look|inspect)/i;
    var persistentPosture = /(?:躺|坐|蹲|跪|站|蜷缩|倚|靠|抱着|握着|拿着|穿着|赤裸|lie|lying|sit|sitting|kneel|kneeling|stand|standing|curl|lean|holding|wearing|naked)/i;
    var nonVisual = /(?:想起|回忆|认为|觉得|决定|计划|希望|remember|recall|think|decide|plan|hope)/i;
    var best = '';
    var bestScore = -999;
    sentences.forEach(function (sentence, index) {
      var score = visibleVerb.test(sentence) ? 6 : 0;
      if (/^(?:你|the player|player)/i.test(sentence)) score += 2;
      if (/(?:手|身体|床|桌|门|窗|椅|水|食物|衣物|道具|物品|hand|body|bed|table|door|window|chair|water|food|clothes|item|object)/i.test(sentence)) score += 2;
      if (persistentPosture.test(sentence)) score += 5;
      if (/(?:随后|最后|最终|此刻|现在|这时|then|finally|now|at this moment)/i.test(sentence)) score += 2;
      if (nonVisual.test(sentence)) score -= 5;
      score += Math.min(4, index * 0.75);
      if (score > bestScore) {
        bestScore = score;
        best = sentence;
      }
    });
    if (bestScore < 3) return '';
    return best.replace(/[\s。！？.!?]+$/g, '').slice(0, 180).trim();
  }

  function _environmentDescriptionFromNarrative(text, physicalLabel, sceneFocus) {
    var clean = _cleanRecordText(text || '')
      .replace(/\[[^\]]{1,120}\]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    var sentences = clean.split(/(?<=[。！？.!?])\s*/).map(function (part) {
      return String(part || '').replace(/^["'“”「」]+|["'“”「」]+$/g, '').trim();
    }).filter(Boolean).slice(0, 10);
    var environmentNoun = /(?:房间|卧室|浴室|厨房|走廊|教室|图书馆|小屋|洞穴|森林|街道|花园|农场|神殿|床|窗|门|墙|地板|天花板|壁炉|桌|椅|柜|架|树|道路|溪|泉|room|bedroom|bathroom|kitchen|hall|classroom|library|cabin|cave|forest|street|garden|farm|temple|bed|window|door|wall|floor|ceiling|hearth|table|chair|cabinet|shelf|tree|path|stream|spring)/i;
    var stableDetail = /(?:光|月光|灯|阴影|木|石|砖|窗帘|家具|陈设|布局|室内|室外|狭窄|宽敞|昏暗|明亮|lighting|moonlight|lamp|shadow|wood|stone|brick|curtain|furniture|interior|exterior|dim|bright)/i;
    var nonVisual = /(?:想起|回忆|认为|觉得|决定|计划|希望|意识|remember|recall|think|decide|plan|hope|realize)/i;
    var best = '';
    var bestScore = -999;
    sentences.forEach(function (sentence, index) {
      var score = environmentNoun.test(sentence) ? 6 : 0;
      if (stableDetail.test(sentence)) score += 3;
      if (physicalLabel && sentence.indexOf(physicalLabel) >= 0) score += 3;
      if (sceneFocus && sentence.indexOf(sceneFocus) >= 0) score += 2;
      if (nonVisual.test(sentence)) score -= 6;
      score -= index * 0.25;
      if (score > bestScore) {
        bestScore = score;
        best = sentence;
      }
    });
    if (bestScore >= 4) return best.replace(/[\s。！？.!?]+$/g, '').slice(0, 220).trim();
    return [physicalLabel, sceneFocus].filter(Boolean).join('，').slice(0, 220);
  }

  function _sanitizeAiPresenceLists(characters, entities, authoritativeNames) {
    characters = Array.isArray(characters) ? characters : _parseListField(characters);
    entities = Array.isArray(entities) ? entities : _parseListField(entities);
    authoritativeNames = Array.isArray(authoritativeNames) ? authoritativeNames : _parseListField(authoritativeNames);
    var allowedKeys = {};
    var allowedText = {};
    _dedupeTextList(authoritativeNames || []).forEach(function (name) {
      var key = _resolveAiNpcKey(name);
      if (key) allowedKeys[String(key).toLowerCase()] = true;
      allowedText[_normaliseNpcLookupText(name)] = true;
    });
    var cleanCharacters = _dedupeTextList(characters || []).filter(function (name) {
      var key = _resolveAiNpcKey(name);
      if (key) return !!allowedKeys[String(key).toLowerCase()];
      return !!allowedText[_normaliseNpcLookupText(name)];
    });
    var cleanEntities = _dedupeTextList(entities || []).filter(function (name) {
      return !_resolveAiNpcKey(name);
    });
    return { characters: cleanCharacters, entities: cleanEntities };
  }

  function _resolveAiEventSceneContract(data, opts) {
    data = data || {};
    opts = opts || {};
    var nativePhysical = _normalizePassageName(_currentPassageName() || '');
    var graphPhysical = _normalizePassageName(_currentGraphPassage() || '');
    var currentPhysical = opts.originalEventMode ? nativePhysical : (graphPhysical || nativePhysical);
    var currentCanonical = _canonicalizeAiLocationStateTarget(currentPhysical, '');
    currentPhysical = currentCanonical.raw || currentPhysical;
    var status = _normaliseAiEventStatus(data.locationStatus || data.location_status || data.travelStatus || data.arrivalStatus || (data && Object.keys(data).length ? '' : 'current')) || 'current';
    var location = _normaliseAIEventLocationValue(data.location || data.currentLocation || opts.location || currentPhysical) || currentPhysical;
    var targetLocation = _normaliseAIEventLocationValue(data.targetLocation || data.target_location || data.loc || '');
    var focus = String(data.sceneFocus || data.scene_focus || data.currentFocus || '').replace(/\s+/g, ' ').trim().slice(0, 80);
    var focusRaw = _normalizePassageName(opts.location || (opts.originalEventMode ? _aiReplaceTargetPassage : '') || '');
    var focusCommon = focusRaw ? (_findCommonLocationByRaw(focusRaw) || _findCommonLocation(focusRaw)) : null;
    if (focusCommon && focusCommon.narrativeArrival === false) {
      var container = _normalizePassageName(focusCommon.containerRaw || currentPhysical);
      var containerCanonical = _canonicalizeAiLocationStateTarget(container, '');
      location = containerCanonical.raw || container || currentPhysical;
      targetLocation = 'current';
      status = 'current';
      if (!focus) focus = _resolveLocationDisplay(focusRaw, focusCommon.label || '') || focusCommon.label || focusRaw;
      return { location: location, targetLocation: targetLocation, locationStatus: status, sceneFocus: focus, focusPassage: focusRaw };
    }
    if (!location) location = currentPhysical;
    if (status === 'arrived' && targetLocation) location = targetLocation;
    if (!targetLocation || targetLocation === location || targetLocation === currentPhysical) {
      targetLocation = 'current';
      if (status === 'arrived' && location === currentPhysical) status = 'current';
    }
    return { location: location, targetLocation: targetLocation, locationStatus: status, sceneFocus: focus, focusPassage: '' };
  }

  function _normaliseAiSceneNarrativeIdentity(text) {
    return _cleanRecordText(text || '')
      .toLowerCase()
      .replace(/[“”"'‘’]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 1200);
  }

  function _fingerprintAiSceneNarrative(text) {
    var normalized = _normaliseAiSceneNarrativeIdentity(text);
    if (!normalized) return '';
    return 'v1:' + normalized.length + ':' + _hashAiStringForChance(normalized).toString(36);
  }

  function _aiSceneEventMatchesCurrentStory(event, currentStoryText) {
    if (!event || !currentStoryText) return false;
    var currentNormalized = _normaliseAiSceneNarrativeIdentity(currentStoryText);
    var eventNormalized = _normaliseAiSceneNarrativeIdentity(event.narrative || event.summary || '');
    if (!currentNormalized || !eventNormalized) return false;
    var currentFingerprint = _fingerprintAiSceneNarrative(currentNormalized);
    var storedFingerprint = String(event.narrativeFingerprint || '').trim();
    if (storedFingerprint && storedFingerprint === currentFingerprint) return true;
    if (eventNormalized === currentNormalized) return true;

    var prefixLength = Math.min(160, eventNormalized.length, currentNormalized.length);
    if (prefixLength >= 48) {
      var eventPrefix = eventNormalized.slice(0, prefixLength);
      var currentPrefix = currentNormalized.slice(0, prefixLength);
      if (currentNormalized.indexOf(eventPrefix) >= 0 || eventNormalized.indexOf(currentPrefix) >= 0) return true;
    }

    var summaryNormalized = _normaliseAiSceneNarrativeIdentity(event.summary || '');
    if (summaryNormalized.length >= 32) {
      var summaryProbe = summaryNormalized.slice(0, Math.min(96, summaryNormalized.length));
      if (currentNormalized.indexOf(summaryProbe) >= 0) return true;
    }
    return false;
  }

  window.AIStoryGen.sceneProvenance = {
    schemaVersion: 1,
    fingerprintNarrative: _fingerprintAiSceneNarrative,
    matchesCurrentStory: _aiSceneEventMatchesCurrentStory
  };

  function _buildAiStoryEvent(rawText, displayText, opts) {
    opts = opts || {};
    var data = _parseAIEventBlock(rawText);
    var hasStructuredEvent = !!(data && typeof data === 'object' && Object.keys(data).length);
    var runtimeItems = _collectAiRuntimeItems(rawText, data);
    var runtimeStats = _collectAiRuntimeStatChanges(rawText, data, true);
    var plannedStats = opts.transactionPlan && opts.transactionPlan.stats && Array.isArray(opts.transactionPlan.stats.parts)
      ? opts.transactionPlan.stats.parts.slice()
      : runtimeStats.parts;
    var runtimeNpcRelations = _collectAiNpcRelationshipChanges(rawText, data);
    var summary = _eventSummaryFromText(displayText || rawText, data);
    var sceneContract = _resolveAiEventSceneContract(data, opts);
    var eventLocationStatus = sceneContract.locationStatus;
    var targetLoc = sceneContract.targetLocation;
    var loc = sceneContract.location;
    var inferredPresent = hasStructuredEvent ? { characters: [], entities: [] } : _inferPresentTargetsFromEventText(displayText || rawText);
    var nativePresence = _aiNativeEncounterNpcContext(_getStateVariables() || {}).names;
    var sanitizedPresence = _sanitizeAiPresenceLists(
      _parseListField(data.presentCharacters || data.present_characters || data.characters || data.npcs || '').concat(inferredPresent.characters),
      _parseListField(data.presentEntities || data.present_entities || data.entities || '').concat(inferredPresent.entities),
      nativePresence
    );
    var presentCharacters = sanitizedPresence.characters;
    var presentEntities = sanitizedPresence.entities;
    var allowedTargetText = {};
    presentCharacters.concat(presentEntities).forEach(function (name) { allowedTargetText[_normaliseNpcLookupText(name)] = true; });
    var sexTargets = _dedupeTextList(_parseListField(data.sexTargets || data.sex_targets || data.presentTargets || data.present_targets || '')).filter(function (name) {
      return !!allowedTargetText[_normaliseNpcLookupText(name)];
    });
    var visualAction = String(data.visualAction || data.visual_action || data.currentAction || data.action || '').replace(/\s+/g, ' ').trim().slice(0, 180);
    if (!visualAction) visualAction = _visualActionFromNarrative(displayText || rawText);
    var sceneFocus = sceneContract.sceneFocus;
    var environmentDescription = String(data.environmentDescription || data.environment_description || data.sceneDescription || data.environment || '').replace(/\s+/g, ' ').trim().slice(0, 220);
    if (!environmentDescription) environmentDescription = _environmentDescriptionFromNarrative(displayText || rawText, _resolveLocationDisplay(loc, '') || loc, sceneFocus);
    var recordedNarrative = _cleanRecordText(displayText || rawText).slice(0, 1200);
    var event = {
      schemaVersion: 4,
      id: 'aievt_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7),
      passage: _currentPassageName(),
      sourcePassage: _currentPassageName(),
      sourceStateIndex: (typeof State !== 'undefined' && State.activeIndex != null) ? State.activeIndex : null,
      narrativeFingerprint: _fingerprintAiSceneNarrative(recordedNarrative),
      structuredEvent: hasStructuredEvent,
      eventType: String(data.eventType || data.event_type || (hasStructuredEvent ? 'story' : 'fallback')).trim(),
      locationStatus: eventLocationStatus,
      location: loc,
      targetLocation: targetLoc,
      sceneFocus: sceneFocus,
      sceneFocusPassage: sceneContract.focusPassage || '',
      environmentDescription: environmentDescription,
      visualAction: visualAction,
      choiceText: String(opts.choiceText || data.choice || '').trim(),
      narrative: recordedNarrative,
      summary: summary,
      characters: presentCharacters,
      presentCharacters: presentCharacters,
      presentEntities: presentEntities,
      sexTargets: sexTargets,
      memoryTags: _parseListField(data.memoryTags || data.tags || ''),
      memoryImportance: _parseAiEventInt(data.memoryImportance || data.importance, 0, 3, 1),
      itemsGained: _dedupeTextList(runtimeItems.map(_formatRuntimeItemForEvent).filter(Boolean)),
      itemsLost: _parseListField(data.itemsLost || ''),
      statChanges: _dedupeTextList(plannedStats),
      relationshipChanges: _dedupeTextList(runtimeNpcRelations.map(_formatNpcRelationshipChangeForEvent).filter(Boolean)),
      moneyChange: String(data.moneyChange || '').trim(),
      source: String(opts.source || 'ai'),
      createdAt: Date.now()
    };
    return event;
  }

  function _aiEventMemoryTags(event) {
    var tags = {};
    _parseListField(event && event.memoryTags || '').forEach(function (tag) {
      tag = String(tag || '').replace(/\s+/g, '').trim();
      if (tag) tags[tag] = true;
    });
    return tags;
  }

  function _isAiEventDurableMemory(event) {
    if (!event || !event.summary || event.memoryImportance <= 0) return false;
    var tags = _aiEventMemoryTags(event);
    var summary = String(event.summary || '');
    var hasRoute = !!(event.targetLocation && !/^(current|same|unknown)$/i.test(event.targetLocation) && event.targetLocation !== event.location);
    var hasRelationship = !!(event.relationshipChanges && event.relationshipChanges.length);
    var hasStoryItem = !!((event.itemsGained && event.itemsGained.length) || (event.itemsLost && event.itemsLost.length));
    var isReflectionOnly = /(想起|想到|思考|回想|回忆|想象|琢磨|担心|惦记)/.test(summary) &&
      !/(决定|答应|承诺|约好|接受|拒绝|邀请|拥抱|亲吻|交给|获得|失去|发现|到达|进入|离开|前往|回到)/.test(summary);
    var hasConcreteRelationship = hasRelationship || /(关系(?:改善|恶化|改变)|信任(?:增加|降低)|变得亲近|拥抱|亲吻|邀请|默许|拒绝|接纳|原谅|争吵|背叛)/.test(summary);
    var hasConcreteGoal = /(决定|答应|承诺|约好|准备|计划|需要|仍需|尚未|下次|明天).{0,32}(前往|寻找|调查|完成|见面|探索|归还|交付|询问|帮助|处理)/.test(summary);
    var hasUsefulTag = !!(tags['主线顺序'] || (tags['地点状态'] && hasRoute) || (tags['人物关系'] && hasConcreteRelationship) || ((tags['任务线索'] || tags['剧情物品']) && (hasStoryItem || /(线索|证据|地图|笔记|钥匙|原石|硬币|遗迹|名片|石板)/.test(summary))) || (tags['未完成目标'] && hasConcreteGoal));
    var hasUsefulText = /(约定|承诺|答应|拒绝|计划|目标|线索|调查|发现|秘密|证据|地图|笔记|钥匙|原石|硬币|到达|进入|前往|离开|回到|关系|信任|亲近|拥抱|邀请|等待|寻找|需要|尚未|仍需|下次)/.test(summary);
    if (_isNativeDataMemoryFact(summary)) return false;
    if (isReflectionOnly && !hasRelationship && !hasRoute && !hasStoryItem) return false;
    if (hasRelationship || hasRoute) return true;
    if (event.memoryImportance >= 2 && (hasUsefulTag || hasUsefulText || hasStoryItem)) return true;
    if (event.memoryImportance >= 3 && !tags['资源状态']) return true;
    return false;
  }

  function _aiEventDurableMemoryName(event) {
    var tags = _aiEventMemoryTags(event);
    var summary = String(event && event.summary || '');
    var hasConcreteRelationship = !!(event.relationshipChanges && event.relationshipChanges.length) || /(关系(?:改善|恶化|改变)|信任(?:增加|降低)|变得亲近|拥抱|亲吻|邀请|默许|拒绝|接纳|原谅|争吵|背叛)/.test(summary);
    if ((tags['人物关系'] && hasConcreteRelationship) || hasConcreteRelationship) return '[人物关系]';
    if (tags['任务线索'] || tags['剧情物品'] || (event.itemsGained && event.itemsGained.length) || (event.itemsLost && event.itemsLost.length) || /(线索|证据|地图|笔记|钥匙|原石|硬币|遗迹|名片|石板)/.test(summary)) return '[线索道具]';
    if (tags['未完成目标'] || /(未完成|待|需要|下次|约定|承诺|计划|仍需|尚未|寻找|调查)/.test(summary)) return '[未完成目标]';
    if (tags['地点状态'] || (event.targetLocation && !/^(current|same|unknown)$/i.test(event.targetLocation))) return '[地点路线]';
    return '[重点剧情]';
  }

  function _buildAiEventDurableMemoryText(event) {
    if (!event || !event.summary) return '';
    var parts = [];
    var from = _zhPlaceLabelForMemory(event.location || '');
    var to = _zhPlaceLabelForMemory(event.targetLocation || '');
    if (to && from && to !== from && !/^(current|same|unknown)$/i.test(event.targetLocation || '')) {
      parts.push('地点路线：' + from + ' → ' + to);
    } else if (to && !/^(current|same|unknown)$/i.test(event.targetLocation || '')) {
      parts.push('地点：' + to);
    } else if (from && !/^(current|same|unknown)$/i.test(event.location || '')) {
      parts.push('地点：' + from);
    }
    parts.push('事件：' + event.summary);
    if (event.relationshipChanges && event.relationshipChanges.length) {
      parts.push('关系变化：' + event.relationshipChanges.join('；'));
    }
    if (event.itemsGained && event.itemsGained.length) {
      parts.push('剧情物品：获得 ' + event.itemsGained.join('；'));
    }
    if (event.itemsLost && event.itemsLost.length) {
      parts.push('剧情物品：失去 ' + event.itemsLost.join('；'));
    }
    var text = parts.join('。').replace(/\s+/g, ' ').trim();
    if (!text || _isNativeDataMemoryFact(text)) return '';
    return _shortenMemoryFact(text, 180);
  }

  function _recordDurableAiEventMemory(event) {
    if (!_isAiEventDurableMemory(event)) return false;
    var text = _buildAiEventDurableMemoryText(event);
    if (!text) return false;
    return addImportantMemory(_aiEventDurableMemoryName(event), text, { silent: true, tag: '自动重点', auto: true }) !== false;
  }

  function _getAiEventLog() {
    var V = _getStateVariables();
    if (!V) return [];
    if (!Array.isArray(V.aiStoryGenEventLog)) V.aiStoryGenEventLog = [];
    return V.aiStoryGenEventLog;
  }

  function _saveAiEventToCurrentMoment(event) {
    var log = _getAiEventLog();
    if (!log || !event || !event.summary) return;
    log.push(event);
    if (log.length > 80) log.splice(0, log.length - 80);
    try { _patchAIStoryGenStateField(_getStateVariables(), 'eventLog', _normaliseAiStateEventLog(log)); } catch (_) {}
    try {
      if (typeof State !== 'undefined' && State.active && State.active.variables) {
        State.active.variables.aiStoryGenEventLog = _cloneForAiSnapshot(log);
        _patchAIStoryGenStateField(State.active.variables, 'eventLog', _normaliseAiStateEventLog(log));
      }
    } catch (_) {}
  }

  function _recordAiEventMemory(rawText, displayText, opts, cfg) {
    cfg = cfg || loadCfg();
    _bindMemoryToCurrentStateIfNeeded();
    var event = _buildAiStoryEvent(rawText, displayText, opts);
    event.memoryApplied = false;
    event.recentMemoryApplied = false;
    event.durableMemoryApplied = false;
    _saveAiEventToCurrentMoment(event);
    if (event.memoryImportance <= 0) return event;
    var durableChanged = _recordDurableAiEventMemory(event);
    event.durableMemoryApplied = !!durableChanged;
    if (!event.summary || cfg.recentMax <= 0) {
      event.memoryApplied = !!durableChanged;
      if (durableChanged) saveMemoryBuffer();
      return event;
    }
    var label = opts && opts.name ? opts.name : '[AI]';
    var entryText = event.summary;
    if (event.location && entryText.indexOf('地点：') !== 0) entryText = '地点：' + event.location + '。事件：' + entryText;
    recentBuf.push({ name: label, text: entryText });
    event.recentMemoryApplied = true;
    event.memoryApplied = true;
    var reason = opts && opts.reason || 'AI剧情事件';
    var compressionStarted = compressMemories(cfg, reason);
    if (!compressionStarted) enforceRecentMemoryLimit(cfg, reason);
    saveMemoryBuffer();
    return event;
  }

  function _recordNativeCombatActionMemory(partLabel, actionText) {
    try {
      var cfg = loadCfg();
      if (!cfg || !cfg.recentMax || cfg.recentMax <= 0) return;
      partLabel = String(partLabel || '').replace(/\s+/g, '').trim();
      actionText = String(actionText || '').replace(/\s+/g, '').trim();
      if (!actionText) return;
      var now = Date.now();
      var key = partLabel + '|' + actionText;
      var last = window.AIStoryGen._lastNativeCombatActionMemory || {};
      if (last.key === key && now - Number(last.at || 0) < 5000) return;
      window.AIStoryGen._lastNativeCombatActionMemory = { key: key, at: now };
      var display = '战斗动作：' + (partLabel ? partLabel + '选择' : '选择') + '“' + actionText + '”。';
      var lastEntry = recentBuf.length ? recentBuf[recentBuf.length - 1] : null;
      if (lastEntry && String(lastEntry.name || '') === '[战斗动作]' && String(lastEntry.text || '').indexOf(display) >= 0) return;
      _recordAiEventMemory(display, display, {
        name: '[战斗动作]',
        reason: '战斗动作',
        choiceText: actionText,
        source: 'nativeCombatAction'
      }, cfg);
    } catch (e) {
      try { console.warn('[AIStoryGen] native combat action memory failed', e); } catch (_) {}
    }
  }

  function _clearRuntimeMemory() {
    recentBuf.length = 0;
    longTermMem.length = 0;
  }

  function _getStateVariables() {
    try {
      return (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    } catch (e) {
      return null;
    }
  }

  function _getUniqueCurrentMomentVariableObjects() {
    var out = [];
    function add(vars) {
      if (!vars || typeof vars !== 'object' || out.indexOf(vars) >= 0) return;
      out.push(vars);
    }
    add(_getStateVariables());
    try { if (typeof State !== 'undefined' && State.active) add(State.active.variables); } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State.history) && State.activeIndex != null && State.history[State.activeIndex]) {
        add(State.history[State.activeIndex].variables);
      }
    } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State._history) && State.activeIndex != null && State._history[State.activeIndex]) {
        add(State._history[State.activeIndex].variables);
      }
    } catch (_) {}
    return out;
  }

  function _readAuthoritativeMemoryFromVariables(vars) {
    vars = vars && typeof vars === 'object' ? vars : {};
    var state = vars.aiStoryGenState && typeof vars.aiStoryGenState === 'object' ? vars.aiStoryGenState : {};
    var mem = state.memory || vars.aiStoryGenMemory || {};
    return _normalizeSaveMemory(mem);
  }

  function _currentMemoryStateSignature(vars) {
    vars = vars && typeof vars === 'object' ? vars : {};
    var state = vars.aiStoryGenState && typeof vars.aiStoryGenState === 'object' ? vars.aiStoryGenState : {};
    var meta = state.meta && typeof state.meta === 'object' ? state.meta : {};
    var memory = _readAuthoritativeMemoryFromVariables(vars);
    return [
      String(state.memoryId || vars.aiStoryGenMemoryId || _aiMemorySaveId || ''),
      String(meta.updatedAt || vars.aiStoryGenMemoryUpdatedAt || ''),
      String(memory.recentBuf.length),
      String(memory.longTermMem.length),
      String(_currentPassageName() || '')
    ].join('|');
  }

  var _aiLastMemoryStateSignature = '';

  function _restoreRuntimeMemoryFromCurrentState(reason, force) {
    if (_isStartOrMainMenuPassage()) return false;
    var V = _getStateVariables();
    if (!V) return false;
    var sig = _currentMemoryStateSignature(V);
    if (!force && sig && sig === _aiLastMemoryStateSignature) return false;
    var mem = _readAuthoritativeMemoryFromVariables(V);
    _aiMemorySaveId = String(
      (V.aiStoryGenState && V.aiStoryGenState.memoryId) ||
      V.aiStoryGenMemoryId ||
      _aiMemorySaveId ||
      ''
    ).trim();
    _replaceMemoryFromSave(mem);
    _aiMemorySaveBound = true;
    _aiLastMemoryStateSignature = sig;
    _recordAiRuntimeCheckpoint('memory-restored-from-state', {
      reason: reason || '',
      force: !!force,
      memoryId: _aiMemorySaveId,
      recentCount: recentBuf.length,
      longTermCount: longTermMem.length,
      signature: sig
    });
    try {
      console.log('[AIStoryGen] AI memory restored from current save state' + (reason ? ' (' + reason + ')' : '') + ' (recent=' + recentBuf.length + ', longTerm=' + longTermMem.length + ')');
    } catch (_) {}
    return true;
  }

  function _readAuthoritativeAISceneFromVariables(vars) {
    vars = vars && typeof vars === 'object' ? vars : {};
    var state = vars.aiStoryGenState && typeof vars.aiStoryGenState === 'object' ? vars.aiStoryGenState : {};
    var scene = state.scene || vars.aiStoryGenNavState || null;
    if (scene && typeof scene === 'object' && scene.aiHTML && scene.passage) {
      return _normaliseAISavedScene(scene);
    }
    return null;
  }

  function _restorePendingAISaveStateFromCurrentState(reason) {
    if (_isStartOrMainMenuPassage()) {
      _pendingAISaveState = null;
      return false;
    }
    var V = _getStateVariables();
    if (!V) {
      _pendingAISaveState = null;
      return false;
    }
    var scene = _readAuthoritativeAISceneFromVariables(V);
    _pendingAISaveState = scene ? _normaliseAISavedScene(scene) : null;
    _recordAiRuntimeCheckpoint('ai-scene-restored-from-state', {
      reason: reason || '',
      hasScene: !!scene,
      passage: scene && scene.passage || '',
      rawPassage: scene && scene.rawPassage || '',
      locationLabel: scene && scene.currentLocationLabel || ''
    });
    return !!scene;
  }

  function _readAuthoritativeAIIntimateSceneFromVariables(vars) {
    // Public Woven Realm no longer owns AI intimate scene persistence.
    // Old save mirrors are ignored here; the optional addon owns its own
    // runtime/session state and passage renderer.
    return null;
  }

  function _restoreAIIntimateRuntimeFromCurrentState(reason) {
    return false;
  }

  function _syncMemoryToCurrentSave(reason) {
    var V = _getStateVariables();
    if (!V || !_aiMemorySaveBound || _isStartOrMainMenuPassage()) return;
    var memoryId = _ensureMemorySaveId(V);
    var mem = _snapshotMemoryForSave();
    _getUniqueCurrentMomentVariableObjects().forEach(function (vars) {
      var state = vars.aiStoryGenState && typeof vars.aiStoryGenState === 'object'
        ? vars.aiStoryGenState
        : { schemaVersion: AI_STATE_SCHEMA_VERSION, meta: {} };
      state.schemaVersion = AI_STATE_SCHEMA_VERSION;
      state.memoryId = memoryId;
      state.memory = _cloneForAiSnapshot(mem);
      state.meta = state.meta && typeof state.meta === 'object' ? state.meta : {};
      state.meta.reason = String(reason || 'memory-sync');
      state.meta.passage = _currentPassageName();
      state.meta.savedAt = Date.now();
      vars.aiStoryGenState = state;
      vars.aiStoryGenMemoryId = memoryId;
      vars.aiStoryGenMemoryUpdatedAt = state.meta.savedAt;
      vars.aiStoryGenMemory = _cloneForAiSnapshot(mem);
    });
    try { _aiLastMemoryStateSignature = _currentMemoryStateSignature(_getStateVariables()); } catch (_) {}
    _persistMemoryEmergencyBackup(mem, 'sync');
    _recordAiRuntimeCheckpoint('memory-synced-to-state', {
      reason: reason || '',
      memoryId: _aiMemorySaveId,
      recentCount: recentBuf.length,
      longTermCount: longTermMem.length
    });
  }

  function _bindMemoryToCurrentStateIfNeeded() {
    if (_isStartOrMainMenuPassage()) {
      _aiMemorySaveBound = false;
      _aiMemorySaveId = '';
      _clearRuntimeMemory();
      return;
    }
    var V = _getStateVariables();
    if (!V || _aiMemorySaveBound) return;
    _aiMemorySaveBound = true;
    _ensureMemorySaveId(V);
    _restoreRuntimeMemoryFromCurrentState('bind', true);
  }

  for (var _ltmInitIdx = 0; _ltmInitIdx < longTermMem.length; _ltmInitIdx++) {
    longTermMem[_ltmInitIdx] = _normalizeImportantMemoryEntry(longTermMem[_ltmInitIdx]);
  }

  function _trimLongTermMem(cfg) {
    cfg = cfg || loadCfg();
    var result = MemoryPolicyModule.applyLimit(longTermMem, {
      max: Number(cfg.longTermMax || 0),
      archiveName: '[长期归档]',
      maxArchiveChars: 1200,
      summarize: function (entries) {
        return _summarizeMemoryEntries(entries, '旧剧情归档');
      }
    });
    if (!result || !Array.isArray(result.entries)) return { archived: [], overLimit: false };
    if (result.entries.length !== longTermMem.length || result.archived.length) {
      longTermMem.length = 0;
      result.entries.forEach(function (entry) {
        longTermMem.push(_normalizeImportantMemoryEntry(entry));
      });
    }
    return result;
  }

  function addImportantMemory(name, text, opts) {
    opts = opts || {};
    text = _cleanRecordText(text);
    if (!text) return false;
    if (opts.auto) {
      text = _refineLongTermMemoryText(text, name);
      if (!text) return false;
    }
    var entry = _memoryEntry(name || '[重点]', text);
    entry.tag = String(opts.tag || entry.tag || '剧情');
    entry.locked = !!opts.locked;
    if (MemoryPolicyModule.findDuplicateIndex(longTermMem, entry) >= 0) return false;
    longTermMem.push(entry);
    _trimLongTermMem(loadCfg());
    if (!opts.silent) saveMemoryBuffer();
    return true;
  }

  function _summarizeMemoryEntries(entries, label) {
    var refined = entries.map(function (e) {
      return _refineLongTermMemoryText(String(e.text || ''), e.name);
    }).filter(function (text) {
      text = String(text || '').replace(/\s+/g, ' ').trim();
      if (!text) return false;
      return !/^地点[:：]\s*[^。；]+[。；]?$/.test(text);
    });
    var text = refined.join('；').replace(/\s+/g, ' ').trim();
    var limit = Math.max(300, Number(loadCfg().recentLimit || 600));
    if (text.length > limit) text = text.slice(0, limit) + '...';
    return text ? ((label || '剧情顺序') + '：' + text) : '';
  }

  function _stripMemoryBoilerplate(text) {
    text = _cleanRecordText(text);
    text = text.replace(/\b0\.5\.8\.10\b[\s\S]*?(?=(?:你|主角|玩家|AI|$))/g, '');
    text = text.replace(/\s*-?\(ML-v[\d.]+\)\s*/g, ' ');
    text = text.replace(/\b\.5\.8\.10\b/g, '');
    text = text.replace(/小贴士[：:][\s\S]*?(?=(?:你正|你的|疼痛|性奋|属性|$))/g, '');
    text = text.replace(/属性 社交 特质 日志 统计 成就 作弊 选项 存档/g, '');
    text = text.replace(/\(\d+\)[\s\S]*?(?=(?:\(\d+\)|Shift|$))/g, '');
    return text.replace(/\s+/g, ' ').trim();
  }

  function _isStaticSceneMemory(name, text) {
    name = String(name || '');
    text = _stripMemoryBoilerplate(text);
    if (/^(Bedroom|Bathroom|Kitchen|Hall|Orphanage|Wardrobe|Mirror|Sextoys Inventory)$/i.test(name)) {
      var hasEvent = /(获得|得到|找到|发现|捡到|失去|花费|支付|偷|拿走|收下|遇见|交谈|答应|拒绝|到达|离开|进入|前往|受伤|疼痛|压力|金钱|钱|现金|道具|钥匙|药|任务|约会|Robin|罗宾|Bailey|贝利|Avery|艾弗里|Eden|伊甸)/.test(text);
      var mostlyRoom = /(你正待在你的卧室|波浪形图案的壁纸|古董桌|超大熊玩偶|猫头鹰玩偶|兔耳多肉|猫咪的海报|你的床占据|衣服正放在|外面的走廊)/.test(text);
      if (mostlyRoom && !hasEvent) return true;
    }
    return false;
  }

  function _refineLongTermMemoryText(text, name) {
    var safeText = _refineLongTermMemoryTextSafe(text, name);
    if (safeText) return safeText;
    text = _stripMemoryBoilerplate(text);
    if (!text || _isNonStoryMemoryText(name, text) || _isStaticSceneMemory(name, text)) return '';

    var sentences = text.split(/(?<=[。！？!?])\s+|[；;]/).map(function (s) {
      return s.replace(/\s+/g, ' ').trim();
    }).filter(Boolean);
    var keepers = [];
    var eventRe = /(获得|得到|找到|发现|捡到|拾起|失去|花费|支付|偷|拿走|收下|遇见|交谈|答应|拒绝|到达|离开|进入|前往|决定|选择|回到|返回|受伤|疼痛|压力|创伤|金钱|钱|现金|零钱|硬币|钞票|£|道具|钥匙|药|任务|约会|关系|好感|Robin|罗宾|Bailey|贝利|Avery|艾弗里|Eden|伊甸)/i;
    sentences.forEach(function (s) {
      if (eventRe.test(s)) keepers.push(s);
    });
    if (!keepers.length && /^\[AI\]/.test(String(name || ''))) keepers = sentences.slice(0, 2);
    var out = keepers.join(' ').trim();
    if (!out) return '';
    if (out.length > 260) out = out.slice(0, 260) + '...';
    return out;
  }

  function _longTermHasHan(text) {
    return /[\u4e00-\u9fff]/.test(String(text || ''));
  }

  function _normalizeLongTermRefineSource(text) {
    text = String(text || '');
    text = text.replace(/<\s*br\s*\/?>/gi, '\n');
    text = text.replace(/<[^>]+>/g, ' ');
    text = text.replace(/&(nbsp|amp|lt|gt|quot|#39);/g, ' ');
    text = _removeAIEventBlocks(text);
    text = text.replace(/\[(?:STATS|ITEMS?|AI_ITEMS_USED|LOC|AI_META)[^\]]*\]/gi, ' ');
    text = text.replace(/\b0\.5\.8\.10\b|\b\.5\.8\.10\b|\s*-?\(ML-v[\d.]+\)\s*/gi, ' ');
    text = text.replace(/\ud83d\udd04\s*\u5237\u65b0\u5267\u60c5|\ud83d\udd01\s*\u5237\u65b0\u9009\u9879|\u2606\s*\u6536\u85cf\u5267\u60c5\u8fdb\u957f\u671f\u8bb0\u5fc6|\u4f7f\u7528\u9053\u5177|\u7ea0\u6b63\u5730\u70b9|\u8fd4\u56de\u6e38\u620f/g, ' ');
    text = text.replace(/\s+/g, ' ').trim();
    return text;
  }

  function _zhPlaceLabelForMemory(place) {
    place = String(place || '').trim();
    var map = {
      current: '',
      same: '',
      unknown: '',
      cabin: '\u4f0a\u7538\u5c0f\u5c4b',
      'Forest Cabin': '\u4f0a\u7538\u5c0f\u5c4b',
      'Eden Clearing': '\u4f0a\u7538\u5c0f\u5c4b\u5916\u7a7a\u5730',
      Forest: '\u68ee\u6797',
      Farm: '\u519c\u573a',
      'Bird Tower': '\u5de8\u9e70\u9ad8\u5854'
    };
    return map[place] != null ? map[place] : place;
  }

  function _memoryBucketForRefinedFact(text, title) {
    var hay = String(title || '') + ' ' + String(text || '');
    if (/(\u672a\u5b8c\u6210|\u5f85|\u9700\u8981|\u4e0b\u6b21|\u7ea6\u5b9a|\u627f\u8bfa|\u8ba1\u5212|\u76ee\u6807|\u8c03\u67e5|\u4ecd\u9700|\u5c1a\u672a|\u660e\u5929|\u51c6\u5907)/.test(hay)) return '\u672a\u5b8c\u6210\u76ee\u6807';
    if (/(\u5730\u70b9|\u8def\u7ebf|\u8def\u5f84|\u5230\u8fbe|\u8fdb\u5165|\u79bb\u5f00|\u524d\u5f80|\u56de\u5230|\u51fa\u53d1|\u6f5c\u5165|Cliff Street|Cafe Pancakes|Police|Barb Street|Forest Cabin|Eden Cabin|Wolf Cave|Bird Tower|town|Orphanage)/i.test(hay)) return '\u5730\u70b9\u4e0e\u8def\u7ebf';
    if (/(\u7ebf\u7d22|\u539f\u77f3|\u514b\u6717\u5e01|\u786c\u5e01|\u65e7\u7b14\u8bb0|\u730e\u4eba\u7b14\u8bb0|\u5730\u56fe|\u540d\u7247|\u77f3\u677f|\u9057\u8ff9|\u5730\u57fa|\u5c0f\u5f84|\u94c1\u7f50|\u90ae\u7968|\u5267\u60c5\u7269\u54c1|\u8bc1\u636e)/.test(hay)) return '\u7ebf\u7d22\u4e0e\u5267\u60c5\u7269\u54c1';
    if (/(NPC|\u5173\u7cfb|\u597d\u611f|\u4eb2\u8fd1|\u89e6\u78b0|\u62e5\u62b1|\u56de\u62b1|\u73af\u4f4f|\u56de\u5e94|\u62d2\u7edd|\u9ed8\u8bb8|\u63a5\u7eb3|\u7b49\u4f60|\u6ce8\u89c6|\u9080\u8bf7|\u64e6\u8fc7|\u4e0d\u518d\u62d2\u7edd)/i.test(hay)) return '\u4eba\u7269\u5173\u7cfb\u53d8\u5316';
    return '\u5f53\u524d\u5267\u60c5\u72b6\u6001';
  }

  function _cleanRefinedMemoryMeta(text) {
    text = _normalizeLongTermRefineSource(text);
    text = text.replace(/^###\s*/g, '');
    text = text.replace(/^\[[^\]]*(?:\u538b\u7f29\u91cd\u70b9|\u81ea\u52a8\u6574\u7406|\u7cbe\u70bc)[^\]]*\]\s*(?:\/\s*[^\n]+)?/g, '');
    text = text.replace(/^\[\d+\]\s*/g, '');
    text = text.replace(/^\(\s*(?:\u4e3b\u7ebf\u987a\u5e8f|\u5730\u70b9\u53d8\u5316|\u4eba\u7269\u5173\u7cfb|\u5f53\u524d\u5267\u60c5\u72b6\u6001|\u4eba\u7269\u5173\u7cfb\u53d8\u5316|\u672a\u5b8c\u6210\u7ebf\u7d22)[^)]*\)\s*-?\s*/g, '');
    text = text.replace(/^(?:\u4e3b\u7ebf\u987a\u5e8f|\u5730\u70b9\u53d8\u5316|\u4eba\u7269\u5173\u7cfb|\u5f53\u524d\u5267\u60c5\u72b6\u6001|\u4eba\u7269\u5173\u7cfb\u53d8\u5316|\u672a\u5b8c\u6210\u7ebf\u7d22)\s*\/\s*\u7cbe\u70bc\s*/g, '');
    text = text.replace(/\btag\s*:\s*[\w\u4e00-\u9fff-]+/gi, ' ');
    text = text.replace(/^\s*[-*]\s*/, '').replace(/\s+/g, ' ').trim();
    return text;
  }

  function _isNativeDataMemoryFact(text) {
    text = _normalizeLongTermRefineSource(text);
    if (!text) return true;
    if (/(\u6027\u522b|\u6280\u80fd|\u6ee1\u7ea7|\u66b4\u9732\u7656|\u6deb\u4e71|\u53d8\u6001|\u7a7f\u5deb\u5973\u670d|\u8349\u5c65|\u8db3\u888b|\u5934\u6234|\u9888\u6234|\u624b\u6234)/.test(text)) return true;
    if (/(\u623f\u79df\u4efb\u52a1|\u81ea\u7531\u4efb\u52a1|\u5269\u4f59\d+\u5929|\u91d1\u989d\d+|\u8fdb\u5ea6\d+)/.test(text)) return true;
    if (/(\u65e0|\u6ca1\u6709).{0,8}(\u91d1\u94b1|\u9053\u5177).{0,8}\u53d8\u5316/.test(text)) return true;
    if (/(\u538b\u529b|\u75b2\u52b3|\u6027\u594b|\u75bc\u75db|\u521b\u4f24|\u81ea\u63a7)\s*[+\-]\s*\d+/.test(text)) return true;
    if (/^(\u65e0)?(\u91d1\u94b1|\u9053\u5177|\u538b\u529b|\u75b2\u52b3|\u6027\u594b|\u75bc\u75db|\u521b\u4f24|\u81ea\u63a7|arousal|stress|pain|trauma|money)[+\-\d\uff0c, /\u65e0\u53d8\u5316]*$/i.test(text)) return true;
    if (/(\u6240\u6709\u6280\u80fd|\u793e\u4ea4|\u8fd0\u52a8|\u5b66\u4e1a|\u72af\u7f6a|\u62a4\u7406).*(1000|\u6ee1\u7ea7)/.test(text)) return true;
    return false;
  }

  function _shortenMemoryFact(text, limit) {
    text = _cleanRefinedMemoryMeta(text);
    limit = limit || 90;
    if (text.length > limit) text = text.slice(0, limit).trim() + '...';
    return text;
  }

  function _isNoUsefulLongTermRefineOutput(text) {
    text = _normalizeLongTermRefineSource(text);
    if (!text) return true;
    if (text.length <= 120 && /(\u6ca1\u6709|\u65e0|\u4e0d\u5b58\u5728).*(\u53ef\u4fdd\u7559|\u5173\u952e|\u5fc5\u8981|\u6570\u636e|\u4fe1\u606f)/.test(text)) return true;
    if (text.length <= 120 && /(no useful|no key|nothing to keep|no important)/i.test(text)) return true;
    return false;
  }

  function _refineLongTermMemoryTextSafe(text, name) {
    if (_isNoUsefulLongTermRefineOutput(text)) return '';
    var src = _normalizeLongTermRefineSource(text);
    if (!src || !_longTermHasHan(src)) return '';
    if (/(\u7248\u672c\u53f7|\u5b58\u6863\u540d|\u5f53\u524d\u8bbe\u7f6e|\u8bf7\u9009\u62e9\u6e38\u620f\u6a21\u5f0f)/.test(src)) return '';
    if (_isNativeDataMemoryFact(src)) return '';

    var place = '';
    var eventText = src;
    var locationOnlyMatch = src.match(/(?:AI\u5267\u60c5\u4e8b\u4ef6|AI\u5730\u70b9\u5267\u60c5)\s*[:\uff1a]\s*\u5730\u70b9\s*[:\uff1a]\s*([^\u3002.\n]+)\s*[\u3002.]?\s*$/);
    if (locationOnlyMatch) {
      place = _zhPlaceLabelForMemory(locationOnlyMatch[1]);
      return _shortenMemoryFact('\u5730\u70b9\uff1a' + place, 80);
    }
    var eventMatch = src.match(/AI\u5267\u60c5\u4e8b\u4ef6\s*[:\uff1a]\s*\u5730\u70b9\s*[:\uff1a]\s*([^\u3002.\n]+?)\s*[\u3002.]\s*\u4e8b\u4ef6\s*[:\uff1a]\s*([\s\S]*)/);
    if (eventMatch) {
      place = _zhPlaceLabelForMemory(eventMatch[1]);
      eventText = eventMatch[2] || '';
    }
    if (!eventText) eventText = src;

    var sentences = eventText.split(/(?<=[\u3002\uff01\uff1f!?])\s*/).map(function (s) {
      return s.replace(/\s+/g, ' ').trim();
    }).filter(Boolean);
    var chosen = [];
    var importantRe = /(\u4f0a\u7538|\u7f57\u5bbe|\u4e9a\u5386\u514b\u65af|\u8d1d\u5229|\u60e0\u7279\u5c3c|\u5730\u70b9|\u8def\u7ebf|\u8def\u5f84|\u5230\u8fbe|\u8fdb\u5165|\u56de\u5230|\u79bb\u5f00|\u524d\u5f80|\u51fa\u53d1|\u5e2e|\u9664\u8349|\u6e05\u7406|\u91c7|\u62ff|\u62fe|\u83b7\u5f97|\u5f97\u5230|\u89e6\u78b0|\u62e5\u62b1|\u56de\u62b1|\u7b49\u4f60|\u9080\u8bf7|\u8be2\u95ee|\u62d2\u7edd|\u9ed8\u8bb8|\u730e\u5200|\u7089\u8fb9|\u6cc9\u6c34|\u5c0f\u5c4b|\u7a7a\u5730|\u539f\u77f3|\u514b\u6717\u5e01|\u786c\u5e01|\u65e7\u7b14\u8bb0|\u730e\u4eba\u7b14\u8bb0|\u5730\u56fe|\u540d\u7247|\u77f3\u677f|\u9057\u8ff9|\u5730\u57fa|\u5c0f\u5f84|\u94c1\u7f50|\u90ae\u7968|Cliff Street|Cafe Pancakes|Police|Barb Street|Forest Cabin|Eden Cabin|Wolf Cave|Bird Tower|town|Orphanage)/i;
    sentences.forEach(function (s) {
      if (chosen.length >= 2) return;
      if (importantRe.test(s)) chosen.push(s);
    });
    if (!chosen.length && /^\[?AI\]?/.test(String(name || ''))) chosen = sentences.slice(0, 1);
    if (!chosen.length) chosen = sentences.slice(0, 1);

    var body = chosen.join('');
    if (!body) return '';
    body = body.replace(/\s+/g, ' ').trim();
    if (_isNativeDataMemoryFact(body)) return '';
    if (place && !/^(current|same|unknown)$/i.test(place)) body = '\u5730\u70b9\uff1a' + place + '\u3002' + body;
    return _shortenMemoryFact(body, 120);
  }
  function _refineLongTermMemoryBulkText(raw) {
    var safeBulk = _refineLongTermMemoryBulkTextSafe(raw);
    if (safeBulk) return safeBulk;
    raw = _stripMemoryBoilerplate(raw);
    if (!raw) return '';
    var parts = raw.split(/\n(?=###\s+)|\n{2,}/).map(function (s) { return s.trim(); }).filter(Boolean);
    var buckets = {
      '当前剧情状态': [],
      '人物关系变化': [],
      '未完成线索': []
    };
    var seen = {};
    function add(bucket, text) {
      text = _refineLongTermMemoryText(text, bucket);
      if (!text) return;
      text.split(/(?<=[。！？!?])\s+/).forEach(function (s) {
        s = s.replace(/^[-*]\s*/, '').replace(/\s+/g, ' ').trim();
        if (!s || s.length < 4) return;
        if (s.length > 90) s = s.slice(0, 90) + '...';
        var key = bucket + '|' + s;
        if (seen[key]) return;
        seen[key] = true;
        buckets[bucket].push(s);
      });
    }
    parts.forEach(function (part) {
      var text = part.replace(/^###\s*[^\n]+\n?/, '').trim();
      if (!text || _isNativeDataMemoryFact(text)) return;
      if (/(线索|未完成|待|需要|下次|约定|承诺|计划|目标|调查|仍需|尚未)/i.test(text)) add('未完成线索', text);
      else if (/(关系|好感|亲密|触碰|拥抱|回抱|环住|回应|拒绝|默许|接纳|等你|注视|邀请|擦过|Robin|Bailey|Avery|Eden|伊甸|罗宾|贝利|艾弗里)/i.test(text)) add('人物关系变化', text);
      else add('当前剧情状态', text);
    });
    return Object.keys(buckets).map(function (bucket) {
      var lines = buckets[bucket].slice(0, 8);
      if (!lines.length) return '';
      return '### ' + bucket + ' / 精炼\n' + lines.map(function (s) { return '- ' + s; }).join('\n');
    }).filter(Boolean).join('\n\n');
  }

  function _previewLongTermMemoryBulkText(raw) {
    raw = String(raw || '').trim();
    if (!raw) return '';
    return _refineLongTermMemoryBulkText(raw);
  }

  function _isNonStoryMemoryText(name, text) {
    name = String(name || '').trim();
    text = String(text || '').replace(/\s+/g, ' ').trim();
    if (_isRecordPollutionText(text)) return true;
    if (!name && !text) return true;
    if (name.indexOf('AIStoryGen_') === 0) return true;
    try {
      if (typeof _isGameMenuPassage === 'function' && _isGameMenuPassage(name)) return true;
    } catch (e) { /* menu blacklist not initialized yet */ }
    if (/^(Start|Settings|Attitudes|Traits|Social|Characteristics|Journal|Statistics|Save|Load|Cheats)$/i.test(name)) return true;

    var startSignals = 0;
    if (/本作品为虚构创作|成年受众|不得在任何缺乏年龄验证机制的平台上传播/.test(text)) startSignals++;
    if (/请选择游戏模式|基础开局|推荐初学者选择/.test(text)) startSignals++;
    if (/存档名[：:]|存档文件储存在浏览器缓存中/.test(text)) startSignals++;
    if (/当前设置[：:]|NPC性别|兽类外观|成就加成/.test(text)) startSignals++;
    if (startSignals >= 2) return true;

    if (/^(游戏设置|选项|存档|读档|统计|成就|作弊|态度|特质)\s*$/.test(text)) return true;
    return false;
  }

  function _sanitizeMemoryBuffers() {
    function keep(entry) {
      if (!entry || _isNonStoryMemoryText(entry.name, entry.text)) return false;
      entry.text = _cleanRecordText(entry.text);
      return !!entry.text;
    }
    var changed = false;
    for (var i = recentBuf.length - 1; i >= 0; i--) {
      if (!keep(recentBuf[i])) {
        recentBuf.splice(i, 1);
        changed = true;
      }
    }
    for (var j = longTermMem.length - 1; j >= 0; j--) {
      if (!keep(longTermMem[j])) {
        longTermMem.splice(j, 1);
        changed = true;
      }
    }
    return changed;
  }

  _sanitizeMemoryBuffers();

  function enforceRecentMemoryLimit(cfg, reason) {
    cfg = cfg || loadCfg();
    var max = Math.max(0, Number(cfg.recentMax || 0));
    var allowLongTerm = String(reason || '').indexOf('原版') !== 0;
    if (max <= 0) {
      if (recentBuf.length) {
        var removedAll = recentBuf.splice(0);
        if (allowLongTerm) {
          addImportantMemory('[自动整理]', _summarizeMemoryEntries(removedAll, reason || '短期记忆'), { silent: true, tag: '自动整理', auto: true });
        }
      }
      return;
    }
    if (recentBuf.length <= max) return;
    var overflow = recentBuf.splice(0, recentBuf.length - max);
    if (allowLongTerm) {
      var summary = _summarizeMemoryEntries(overflow, reason || '剧情顺序');
      if (summary) addImportantMemory('[自动整理]', summary, { silent: true, tag: '自动整理', auto: true });
    }
  }

  var _legacyMemoryStorageCleanupStarted = false;

  function _clearLegacyMemoryStorageOnce() {
    if (_legacyMemoryStorageCleanupStarted) return false;
    _legacyMemoryStorageCleanupStarted = true;
    try {
      localStorage.removeItem(MEM_KEY);
      localStorage.removeItem(LONGTERM_KEY);
    } catch (_) {}
    try {
      idbSet(MEM_KEY, []).catch(function () {});
      idbSet(LONGTERM_KEY, []).catch(function () {});
    } catch (_) {}
    return true;
  }

  function saveMemoryBuffer() {
    try {
      _bindMemoryToCurrentStateIfNeeded();
      _sanitizeMemoryBuffers();
      _trimLongTermMem(loadCfg());
      _syncMemoryToCurrentSave();
      _clearLegacyMemoryStorageOnce();
    } catch (e) {
      console.warn('[AIStoryGen] failed to save memory to current save', e);
    }
  }

  // -- Memory summarization: compress oldest entries when buffer grows too large --
  var _summarizeBusy = false;
  function compressMemories(cfg, reason) {
    cfg = cfg || loadCfg();
    if (_summarizeBusy) return false;
    var max = Math.max(0, Number(cfg.recentMax || 0));
    var configuredTrigger = (cfg.summarizeTrigger != null && cfg.summarizeTrigger >= 0) ? Number(cfg.summarizeTrigger) : 3;
    var trigger = max > 0 ? Math.min(configuredTrigger, max) : 0;
    if (trigger <= 0 || recentBuf.length < trigger) return false;
    var toCompress = recentBuf.slice(0, Math.min(3, recentBuf.length));
    if (toCompress.length < 2) return false;
    _summarizeBusy = true;
    var sourceText = toCompress.map(function(e){return e.text.slice(0, 200);}).join(' | ');
    var sumPrompt = cfg.language === 'zh'
      ? '将以下游戏剧情事件合并成一句简短中文摘要（30字以内，只陈述事实）：' + sourceText
      : 'Merge these game story events into one short English summary (under 20 words, facts only): ' + sourceText;
    callAI(sumPrompt, { highQuality: true, temperature: 0.2, max_tokens: 220 }).then(function(summary){
      var clean = (summary || '').replace(/^["']|["']$/g, '').trim();
      if (!clean || clean.length < 5) {
        var hasCurrentEntries = toCompress.some(function (entry) { return recentBuf.indexOf(entry) >= 0; });
        _summarizeBusy = false;
        if (hasCurrentEntries) {
          enforceRecentMemoryLimit(cfg, reason || '记忆压缩空响应');
          saveMemoryBuffer();
        }
        return;
      }
      var stillCurrent = toCompress.every(function (entry) { return recentBuf.indexOf(entry) >= 0; });
      if (!stillCurrent) { _summarizeBusy = false; return; }
      for (var idx = toCompress.length - 1; idx >= 0; idx--) {
        var at = recentBuf.indexOf(toCompress[idx]);
        if (at >= 0) recentBuf.splice(at, 1);
      }
      recentBuf.unshift({ name: '[摘要]', text: clean });
      enforceRecentMemoryLimit(cfg, reason || '记忆压缩');
      saveMemoryBuffer();
      console.log('[AIStoryGen] memory compressed: ' + toCompress.length + ' → 1 rolling summary');
      _summarizeBusy = false;
    }).catch(function(){
      var stillCurrent = toCompress.some(function (entry) { return recentBuf.indexOf(entry) >= 0; });
      _summarizeBusy = false;
      if (stillCurrent) {
        enforceRecentMemoryLimit(cfg, reason || '记忆压缩失败');
        saveMemoryBuffer();
      }
    });
    return true;
  }

  /** Export memory buffer as downloadable JSON file (includes recent + long-term) */
  function exportMemoryBuffer() {
    var json = JSON.stringify({ recentBuf: recentBuf, longTermMem: longTermMem, playerStoryProfile: loadCfg().playerStoryProfile || '' }, null, 2);
    var blob = new Blob([json], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'AIStoryGen_memory_' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /** Import memory from a JSON file, replace current buffer */
  function importMemoryBuffer(callback) {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = function () {
      var file = input.files && input.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function (e) {
        try {
          var data = JSON.parse(e.target.result);
          // Support both old format (array) and new format ({ recentBuf, longTermMem })
          if (Array.isArray(data)) {
            recentBuf.length = 0;
            data.forEach(function (entry) {
              if (entry && typeof entry.name === 'string' && typeof entry.text === 'string') {
                recentBuf.push({ name: entry.name, text: entry.text });
              }
            });
          } else if (data && typeof data === 'object') {
            if (Array.isArray(data.recentBuf)) {
              recentBuf.length = 0;
              data.recentBuf.forEach(function (entry) {
                if (entry && typeof entry.name === 'string' && typeof entry.text === 'string') {
                  recentBuf.push({ name: entry.name, text: entry.text });
                }
              });
            }
            if (Array.isArray(data.longTermMem)) {
              longTermMem.length = 0;
              data.longTermMem.forEach(function (entry) {
                if (entry && typeof entry.name === 'string' && typeof entry.text === 'string') {
                  longTermMem.push(_normalizeImportantMemoryEntry(entry));
                }
              });
            }
            if (typeof data.playerStoryProfile === 'string') {
              var cfg = loadCfg();
              cfg.playerStoryProfile = data.playerStoryProfile;
              saveCfg(cfg);
            }
          }
          _trimLongTermMem(loadCfg());
          saveMemoryBuffer();
          if (callback) callback(null, recentBuf.length + longTermMem.length);
        } catch (err) {
          if (callback) callback(err);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  }
  window.AIStoryGen.exportMemory = exportMemoryBuffer;
  window.AIStoryGen.importMemory = importMemoryBuffer;
  window.AIStoryGen.addLongTermMemory = addLongTermMemory;
  window.AIStoryGen.addImportantMemory = addImportantMemory;
  window.AIStoryGen.removeLongTermMemory = removeLongTermMemory;
  window.AIStoryGen.compressLongTermMemories = compressLongTermMemories;
  window.AIStoryGen.longTermMem = longTermMem;
  window.AIStoryGen.refineLongTermMemoryBulkText = _refineLongTermMemoryBulkText;
  window.AIStoryGen.getEventLog = _getAiEventLog;
  window.AIStoryGen.parseAIEventBlock = _parseAIEventBlock;



  function _getAISaveTitle() {
    try {
      var $src = $('#passages .passage .ai-replaced-content, #passages .passage .ai-narrative-wrap').last();
      var text = '';
      if ($src.length) {
        var $clone = $src.clone();
        $clone.find('a, button, input, select, textarea, script, style, .ai-choices, .ai-choices-end, .ai-nav-wrap, .ai-narrative-toolbar, .ai-item-use-panel, .ai-pickup-line, .ai-gen-loading').remove();
        text = ($clone.text() || '').replace(/\s+/g, ' ').trim();
      }
      if (!text && _aiReplaceSessionHTML) {
        var tmp = document.createElement('div');
        tmp.innerHTML = _aiReplaceSessionHTML;
        $(tmp).find('a, button, input, select, textarea, script, style, .ai-choices, .ai-choices-end, .ai-nav-wrap, .ai-narrative-toolbar, .ai-item-use-panel, .ai-pickup-line, .ai-gen-loading').remove();
        text = (tmp.textContent || '').replace(/\s+/g, ' ').trim();
      }
      if (!text) return '';
      text = text.replace(/^(?:\u5237\u65b0\u5267\u60c5|\u2606\s*\u6536\u85cf[^\s]*|\u2605\s*\u5df2\u6536\u85cf[^\s]*)\s*/g, '').trim();
      var firstSentence = text.split(/(?<=[\u3002\uff01\uff1f.!?])\s*/).filter(Boolean)[0] || text;
      if (firstSentence.length >= 18) text = firstSentence;
      if (text.length > 90) text = text.slice(0, 90).trim() + '\u2026';
      return text ? '[AI\u5267\u60c5] ' + text : '';
    } catch (_) {
      return '';
    }
  }

  function _refineLongTermMemoryBulkTextSafe(raw) {
    raw = String(raw || '').trim();
    if (!raw || !_longTermHasHan(raw)) return '';
    var parts = raw.split(/\n(?=###\s+)|\n{2,}/).map(function (s) { return s.trim(); }).filter(Boolean);
    if (!parts.length) parts = [raw];
    var buckets = {
      '\u5f53\u524d\u5267\u60c5\u72b6\u6001': [],
      '\u5730\u70b9\u4e0e\u8def\u7ebf': [],
      '\u4eba\u7269\u5173\u7cfb\u53d8\u5316': [],
      '\u7ebf\u7d22\u4e0e\u5267\u60c5\u7269\u54c1': [],
      '\u672a\u5b8c\u6210\u76ee\u6807': []
    };
    var seen = {};
    function addFact(title, body) {
      var fact = _refineLongTermMemoryTextSafe(body, title);
      if (!fact) return;
      fact = _cleanRefinedMemoryMeta(fact);
      if (_isNativeDataMemoryFact(fact)) return;
      var bucket = _memoryBucketForRefinedFact(fact, title);
      if (!buckets[bucket]) bucket = '\u5f53\u524d\u5267\u60c5\u72b6\u6001';
      var key = bucket + '|' + fact;
      if (seen[key]) return;
      seen[key] = true;
      if (buckets[bucket].length < 6) buckets[bucket].push(fact);
    }
    parts.forEach(function (part) {
      var lines = part.split(/\n/);
      var title = '';
      if (/^###\s+/.test(lines[0] || '')) title = String(lines.shift() || '').replace(/^###\s*/, '').trim();
      var body = lines.join('\n').trim() || part;
      var candidates = [];
      lines.forEach(function (line) {
        line = String(line || '').replace(/^[-*]\s*/, '').trim();
        if (!line) return;
        line.split(/\s+-\s+(?=(?:\[\d+\]|\(?[\u4e00-\u9fff]))/).forEach(function (piece) {
          piece = piece.replace(/^[-*]\s*/, '').trim();
          if (piece) candidates.push(piece);
        });
      });
      if (!candidates.length) candidates = [body];
      candidates.forEach(function (piece) { addFact(title, piece); });
    });
    return Object.keys(buckets).map(function (bucket) {
      var lines = buckets[bucket];
      if (!lines.length) return '';
      return '### ' + bucket + ' / \u7cbe\u70bc\n' + lines.map(function (s) { return '- ' + s; }).join('\n');
    }).filter(Boolean).join('\n\n');
  }

  function _writeAISaveTitleToVariables(vars, title) {
    if (!vars || typeof vars !== 'object') return;
    if (title) vars.aiStoryGenSaveTitle = title;
    else delete vars.aiStoryGenSaveTitle;
  }

  function _syncAISaveTitleToCurrentState(title) {
    title = title || _getAISaveTitle();
    try { _writeAISaveTitleToVariables(_getStateVariables(), title); } catch (_) {}
    try { if (typeof State !== 'undefined' && State.active && State.active.variables) _writeAISaveTitleToVariables(State.active.variables, title); } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State.history) && State.activeIndex != null && State.history[State.activeIndex] && State.history[State.activeIndex].variables) {
        _writeAISaveTitleToVariables(State.history[State.activeIndex].variables, title);
      }
    } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State._history) && State.activeIndex != null && State._history[State.activeIndex] && State._history[State.activeIndex].variables) {
        _writeAISaveTitleToVariables(State._history[State.activeIndex].variables, title);
      }
    } catch (_) {}
    return title;
  }

  function _patchDolSaveDetailTitle(saveSlot, title) {
    title = title || _getAISaveTitle();
    if (!title) return false;
    try {
      var raw = localStorage.getItem('dolSaveDetails');
      if (!raw) return false;
      var details = JSON.parse(raw);
      if (!details || typeof details !== 'object') return false;
      var target = null;
      if (saveSlot === 'autosave' || saveSlot === 'auto') {
        if (!details.autosave) details.autosave = {};
        target = details.autosave;
      } else {
        var slot = parseInt(saveSlot, 10);
        if (isNaN(slot)) return false;
        if (!Array.isArray(details.slots)) details.slots = [];
        if (!details.slots[slot]) details.slots[slot] = {};
        target = details.slots[slot];
      }
      var targetStory = _getNativeStory();
      target.id = (targetStory && targetStory.domId) || target.id || '';
      target.title = title;
      target.date = Date.now();
      if (!target.metadata) target.metadata = {};
      target.metadata.aiStoryGen = true;
      target.metadata.aiStoryGenTitle = title;
      localStorage.setItem('dolSaveDetails', JSON.stringify(details));
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] patch save detail title failed', e); } catch (_) {}
      return false;
    }
  }

  function _patchRecentAISaveDetailTitle(saveSlot) {
    var title = _syncAISaveTitleToCurrentState();
    if (!title) return;
    setTimeout(function () { _patchDolSaveDetailTitle(saveSlot, title); }, 0);
    setTimeout(function () { _patchDolSaveDetailTitle(saveSlot, title); }, 120);
  }

  function _guessRecentSaveSlotFromElement(el) {
    try {
      var node = el;
      while (node && node !== document) {
        var attrs = [node.getAttribute && node.getAttribute('data-save-slot'), node.getAttribute && node.getAttribute('data-slot'), node.id, node.name, node.className].join(' ');
        var m = String(attrs || '').match(/(?:slot|save)[^\d]{0,8}(\d+)/i) || String(attrs || '').match(/\b([0-7])\b/);
        if (m) return parseInt(m[1], 10);
        node = node.parentNode;
      }
    } catch (_) {}
    return null;
  }

  function _installAISaveRuntimeHooks() {
    window.AIStoryGen._saveRuntimeHooksInstalled = true;
    if (!window.AIStoryGen._saveCaptureHookInstalled) {
      window.AIStoryGen._saveCaptureHookInstalled = true;
      document.addEventListener('click', function (ev) {
        try {
          var el = ev && ev.target;
          if (!el || !el.closest) return;
          var btn = el.closest('a, button, input');
          if (!btn) return;
          var txt = ((btn.innerText || btn.textContent || btn.value || '') + ' ' + (btn.id || '') + ' ' + (btn.name || '')).replace(/\s+/g, ' ').trim();
          if (/(\u5b58\u6863|\u4fdd\u5b58|save)/i.test(txt)) {
            setTimeout(function () { _patchRecentAISaveDetailTitle(_guessRecentSaveSlotFromElement(btn)); }, 80);
          }
        } catch (_) {}
      }, true);
    }
    try {
      if (typeof Save !== 'undefined' && Save.slots && typeof Save.slots.save === 'function' && !Save.slots.save._aiStoryGenWrapped) {
        var slotDesc = Object.getOwnPropertyDescriptor(Save.slots, 'save');
        if (!slotDesc || slotDesc.writable !== false) {
          var originalSlotSave = Save.slots.save;
          var wrappedSlotSave = function (slot, title, metadata) {
            _syncAIStateBeforePossibleSave('slot-save');
            var result = originalSlotSave.apply(this, arguments);
            if (result) _patchRecentAISaveDetailTitle(slot);
            return result;
          };
          wrappedSlotSave._aiStoryGenWrapped = true;
          Save.slots.save = wrappedSlotSave;
        }
      }
    } catch (e1) { try { console.warn('[AIStoryGen] slot save hook failed', e1); } catch (_) {} }
    try {
      if (typeof Save !== 'undefined' && Save.autosave && typeof Save.autosave.save === 'function' && !Save.autosave.save._aiStoryGenWrapped) {
        var autoDesc = Object.getOwnPropertyDescriptor(Save.autosave, 'save');
        if (!autoDesc || autoDesc.writable !== false) {
          var originalAutoSave = Save.autosave.save;
          var wrappedAutoSave = function () {
            _syncAIStateBeforePossibleSave('autosave');
            var result = originalAutoSave.apply(this, arguments);
            if (result) _patchRecentAISaveDetailTitle('autosave');
            return result;
          };
          wrappedAutoSave._aiStoryGenWrapped = true;
          Save.autosave.save = wrappedAutoSave;
        }
      }
    } catch (e2) { try { console.warn('[AIStoryGen] autosave hook failed', e2); } catch (_) {} }
    try {
      if (typeof Save !== 'undefined' && typeof Save.serialize === 'function' && !Save.serialize._aiStoryGenWrapped) {
        var serializeDesc = Object.getOwnPropertyDescriptor(Save, 'serialize');
        if (!serializeDesc || serializeDesc.writable !== false) {
          var originalSerialize = Save.serialize;
          var wrappedSerialize = function () {
            _syncAIStateBeforePossibleSave('serialize');
            return originalSerialize.apply(this, arguments);
          };
          wrappedSerialize._aiStoryGenWrapped = true;
          Save.serialize = wrappedSerialize;
        }
      }
    } catch (e3) { try { console.warn('[AIStoryGen] serialize hook failed', e3); } catch (_) {} }
    try {
      if (window.idb && typeof window.idb.saveState === 'function' && !window.idb.saveState._aiStoryGenWrapped) {
        var idbDesc = Object.getOwnPropertyDescriptor(window.idb, 'saveState');
        if (!idbDesc || idbDesc.writable !== false) {
          var originalIdbSave = window.idb.saveState;
          var wrappedIdbSave = function (slot) {
            _syncAIStateBeforePossibleSave('idb-save');
            var result = originalIdbSave.apply(this, arguments);
            _patchRecentAISaveDetailTitle(slot === 0 || slot === '0' ? 'autosave' : slot);
            return result;
          };
          wrappedIdbSave._aiStoryGenWrapped = true;
          window.idb.saveState = wrappedIdbSave;
        }
      }
    } catch (e4) { try { console.warn('[AIStoryGen] idb save hook failed', e4); } catch (_) {} }
  }
  _installAISaveRuntimeHooks();
  // === 存档系统集成：AI记忆随 DoL 游戏存档一起读写 ===
  // 将 AI 记忆注入 SugarCube save 对象中，实现按存档隔离的记忆持久化。
  // On save: inject current AI memory into the save object
  if (typeof Save !== 'undefined' && Save.onSave) {
    Save.onSave.add(function (save) {
      try {
        var aiState = _syncAIStateBeforePossibleSave('onSave') || _buildAIStoryGenStateForSave('onSave-fallback');
        _writeAIStoryGenStateToSave(save, aiState);
        if (aiState.scene) {
          var aiSaveTitle = _syncAISaveTitleToCurrentState();
          if (aiSaveTitle) {
            save.title = aiSaveTitle;
            save.state.aiStoryGenSaveTitle = aiSaveTitle;
            if (!save.metadata) save.metadata = {};
            save.metadata.aiStoryGen = true;
            save.metadata.aiStoryGenTitle = aiSaveTitle;
          }
        }
      } catch (e) { /* ignore */ }
    });
  }
  // On load: restore AI memory from the save object (fires via DoL's custom :onloadsave event)
  $(document).on(':onloadsave', function (ev) {
    try {
      var save = ev && ev.save;
      var aiState = _legacyAIStoryGenStateFromSave(save);
      _restoreSaveScopedConfig(aiState.config);
      if (aiState.memoryId) _aiMemorySaveId = aiState.memoryId;
      if (_memoryHasContent(aiState.memory)) {
        _replaceMemoryFromSave(aiState.memory);
        _aiMemorySaveBound = true;
        console.log('[AIStoryGen] AI memory restored from save (recent=' + recentBuf.length + ', longTerm=' + longTermMem.length + ')');
      } else {
        _replaceMemoryFromSave({});
        _aiMemorySaveBound = true;
        console.log('[AIStoryGen] save has no AI memory; started empty memory for this save');
      }
      _replaceAiItemStoreFromSave(aiState.items || []);
      _writeAIStoryGenStateToCurrentMoment(aiState);
      try { _aiLastMemoryStateSignature = _currentMemoryStateSignature(_getStateVariables()); } catch (_) {}
      _persistAiItemStore();
      _replaceAISaveStateFromSave(aiState.scene || null);
      console.log('[AIStoryGen] AI item inventory restored from save (items=' + _getAiItemStore().length + ')');
    } catch (e) {
      console.warn('[AIStoryGen] onloadsave restore error', e);
    }
  });

  // -- 长期记忆管理 --
  /** Add a narrative entry to long-term memory (player manually bookmarks) */
  function addLongTermMemory(name, text) {
    addImportantMemory(name, text, { tag: '收藏' });
    console.log('[AIStoryGen] long-term memory added: ' + name);
  }
  /** Remove a long-term memory by index */
  function removeLongTermMemory(index) {
    if (index >= 0 && index < longTermMem.length) {
      longTermMem.splice(index, 1);
      saveMemoryBuffer();
    }
  }
  /** Compress long-term memories: AI summarizes multiple entries into one */
  function compressLongTermMemories(cfg) {
    var trigger = cfg.longTermCompressTrigger || 5;
    if (longTermMem.length < trigger * 2) return;
    // Only compress non-summary entries
    var toCompress = longTermMem.filter(function (e) { return e.name.indexOf('[LTSummary]') !== 0; });
    if (toCompress.length < trigger * 2) return;
    var batch = toCompress.slice(0, trigger);
    var sourceText = batch.map(function (e) { return e.text.slice(0, 150); }).join(' | ');
    var sumPrompt = cfg.language === 'zh'
      ? '将以下游戏剧情事件合并成一句简短中文摘要（50字以内，只陈述关键事实）：' + sourceText
      : 'Merge these game story events into one short English summary (under 30 words, facts only): ' + sourceText;
    return callAI(sumPrompt, { highQuality: true, temperature: 0.2, max_tokens: 260 }).then(function (summary) {
      var clean = (summary || '').replace(/^["']|["']$/g, '').trim();
      if (!clean || clean.length < 5) return;
      // Remove compressed entries
      for (var i = 0; i < trigger && longTermMem.length > 0; i++) {
        longTermMem.shift();
      }
      longTermMem.push(_normalizeImportantMemoryEntry({ name: '[LTSummary]', text: clean, tag: '压缩', savedAt: new Date().toISOString() }));
      saveMemoryBuffer();
      console.log('[AIStoryGen] long-term memory compressed: ' + trigger + ' → 1 summary');
    }).catch(function () {});
  }

  function _refreshOriginalEventModeFromLink() {
    var id = String(_aiReplaceOriginalLinkId || '');
    if (!id) return _aiReplaceOriginalEventMode;
    var $orig = $('[data-ai-origid]').filter(function () {
      return String($(this).attr('data-ai-origid') || '') === id && !$(this).hasClass('ai-injected-link');
    }).first();
    if ($orig.length) {
      _aiReplaceOriginalEventMode = _isOriginalEventActionLink($orig, _aiReplaceTargetPassage, _aiReplaceTargetLabel);
    }
    return _aiReplaceOriginalEventMode;
  }

  function _repairStaleEventModeUI($scope) {
    if (_aiReplaceOriginalEventMode) return;
    ($scope || $('#passages')).find('.ai-continue-link,.ai-back-link').each(function () {
      var $a = $(this);
      var txt = ($a.text() || '').trim();
      if (/\u786e\u8ba4\u6267\u884c|Confirm/i.test(txt)) {
        var $wrap = $a.closest('.ai-nav-wrap');
        if ($wrap.length) $wrap.remove();
        else $a.remove();
      }
    });
  }

  $(document).on(':passagedisplay', function (ev) {
    try {
      _installAISaveRuntimeHooks();
      var name = (ev && ev.passage && ev.passage.title) || _currentPassageName();
      _clearStaleMoorEventQueue('passagedisplay ' + name);
      _clearOrphanedNativeEventQueueAfterPassageDisplay('passagedisplay ' + name);
      if (_isStartOrMainMenuPassage(name)) {
        _aiMemorySaveBound = false;
        _clearRuntimeMemory();
        try {
          localStorage.removeItem(MEM_KEY);
          localStorage.removeItem(LONGTERM_KEY);
        } catch (_) {}
        return;
      }
      _bindMemoryToCurrentStateIfNeeded();
      _restoreRuntimeMemoryFromCurrentState('passagedisplay');
      _restorePendingAISaveStateFromCurrentState('passagedisplay');
      _restoreAIIntimateRuntimeFromCurrentState('passagedisplay');
      _syncTransientAIItemRuntimeWithCurrentState('passagedisplay');
      setTimeout(_renderAiItemsInLog, 50);
      setTimeout(function () { NativeSceneBridge.refreshControls('passagedisplay early'); }, 120);
      setTimeout(function () { NativeSceneBridge.refreshControls('passagedisplay late'); }, 500);
    } catch (e) {
      console.warn('[AIStoryGen] save-scoped memory bind error', e);
    }
  });

  $(document).off('click.AIStoryGenSexModeEntry').on('click.AIStoryGenSexModeEntry', 'a, button', function (ev) {
    try {
      var $el = $(this);
      var txt = ($el.text() || '').replace(/\s+/g, ' ').trim();
      var isAiGenerate = OptionalAddonBridge.isAIEntryElement($el, txt);
      var isNativeEntry = OptionalAddonBridge.isNativeEntryElement($el, txt);
      if (!isAiGenerate && !isNativeEntry) return;
      ev.preventDefault();
      if (!_isAISexModeEnabled()) {
        _clearAISexModeUi();
        return;
      }
      if (isAiGenerate) _enterAIIntimateMode();
      else NativeSceneBridge.enterSexMode();
    } catch (e) {
      try { console.warn('[AIStoryGen] sex mode entry click failed', e); } catch (_) {}
    }
  });

  $(document).on(':passagedisplay', function (ev) {
    try {
      const cfg = loadCfg();
      if (!cfg.recentMax || cfg.recentMax <= 0) return;
      const name = (ev && ev.passage && ev.passage.title) || (typeof State !== 'undefined' && State.passage) || '';
      if (!name) return;
      if (name.indexOf('AIStoryGen_') === 0) return;
      if (_isNonStoryMemoryText(name, '')) return;

      const $body = $('#passages .passage');
      if (!$body.length) return;
      const $clone = $body.clone();
      // Remove interactive elements and AI-story artifacts
      $clone.find('a, button, img, input, select, script, style, .macro-link, .gameplayLinks, .sidebar, #storyBanner, .ai-choices, .ai-replaced-content, .ai-narrative-wrap, .ai-narrative-section, .ai-original-wrap[style*="display:none"], .ai-gen, .ai-memory-section, .ai-memory-inline, .ai-injected-row, .ai-choices-end, .ai-nav-wrap, .ai-back-to-game').remove();
      let text = ($clone.text() || '').replace(/\s+/g, ' ').trim();
      if (!text) return;
      // Strip known boilerplate / notification text
      text = text.replace(/本游戏完全免费[\s\S]*?举报他[！!]/g, '');
      text = text.replace(/你已经有段时间没导出存档了[\s\S]*?/g, '');
      text = text.replace(/\|\s*\|\s*\|/g, '');
      text = _cleanRecordText(text);
      if (!text || text.length < 5) return;
      if (_isNonStoryMemoryText(name, text)) return;
      if (_isStaticSceneMemory(name, text)) return;
      if (_isRecordPollutionText(text)) return;

      const limit = cfg.recentLimit || 600;
      if (text.length > limit) text = text.slice(0, limit) + '…';

      recentBuf.push({ name: name, text: text });
      enforceRecentMemoryLimit(cfg, '原版剧情顺序');
      saveMemoryBuffer();
    } catch (e) {
      console.warn('[AIStoryGen] recent capture error', e);
    }
  });

  // Auto-inject <<aichoices>> at bottom of every passage when enabled
  var _autoChoicesBusy = false;
  var _autoChoicesBusyTimer = null; // timeout protection for lock
  var _sessionAutoPaused = false; // 会话级暂停自动生成
  var _autoChoicesSuppressedUntil = 0; // temporary suppression after pure native return
  var _lastChoicesData = null;  // saved choices for re-render on cancel
  var _currentAbortController = null;  // AbortController for active API call

  function _createTimedAbortController(timeoutMs) {
    var controller = new AbortController();
    timeoutMs = Math.max(5000, parseInt(timeoutMs, 10) || 45000);
    var timer = setTimeout(function () {
      try { controller.abort(); } catch (_) {}
    }, timeoutMs);
    return {
      controller: controller,
      signal: controller.signal,
      clear: function () {
        try { clearTimeout(timer); } catch (_) {}
      }
    };
  }

  function _abortCurrentAIRequest(reason) {
    if (!_currentAbortController) return;
    try {
      _currentAbortController.abort();
      try { console.log('[AIStoryGen] aborted active AI request' + (reason ? ': ' + reason : '')); } catch (_) {}
    } catch (_) {}
    _currentAbortController = null;
  }

  function _captureAutoChoiceContext(name, targetLabel, targetPassage, container) {
    return {
      passage: String(name || ''),
      targetLabel: String(targetLabel || ''),
      targetPassage: String(targetPassage || ''),
      replaceActive: !!_aiReplaceActive,
      replaceRoundCount: _aiReplaceRoundCount,
      replaceTargetPassage: _aiReplaceTargetPassage || '',
      currentLocationPassage: _aiCurrentLocationPassage || '',
      container: container || null
    };
  }

  function _isAutoChoiceContextCurrent(ctx) {
    if (!ctx) return false;
    if (ctx.container && !document.documentElement.contains(ctx.container)) return false;
    var currentPassage = (typeof State !== 'undefined' && State.passage) ? String(State.passage) : '';
    if (!!_aiReplaceActive !== !!ctx.replaceActive) return false;
    if (ctx.replaceActive) {
      if (_aiReplaceRoundCount !== ctx.replaceRoundCount) return false;
      if (ctx.replaceTargetPassage && _aiReplaceTargetPassage && ctx.replaceTargetPassage !== _aiReplaceTargetPassage) return false;
      return true;
    }
    return !ctx.passage || !currentPassage || ctx.passage === currentPassage;
  }

  function _suppressAutoChoices(reason, ms) {
    _autoChoicesSuppressedUntil = Date.now() + (ms || 4500);
    if (_autoChoicesEnsureTimer) {
      clearTimeout(_autoChoicesEnsureTimer);
      _autoChoicesEnsureTimer = null;
    }
    try { console.log('[AIStoryGen] suppress auto choices' + (reason ? ': ' + reason : '') + ' until ' + _autoChoicesSuppressedUntil); } catch (_) {}
  }
  function _isAutoChoicesSuppressed() {
    return _autoChoicesSuppressedUntil && Date.now() < _autoChoicesSuppressedUntil;
  }
  window.AIStoryGen.isNativeExitSuppressed = _isAutoChoicesSuppressed;
  function _releaseAutoChoicesBusy(reason) {
    if (_autoChoicesBusy) {
      console.log('[AIStoryGen] _autoChoicesBusy released' + (reason ? ': ' + reason : ''));
    }
    _autoChoicesBusy = false;
    if (_autoChoicesBusyTimer) {
      clearTimeout(_autoChoicesBusyTimer);
      _autoChoicesBusyTimer = null;
    }
  }
  // AI replace mode: intercept game links and replace passage with AI content
  var _aiReplaceActive = false;      // true when AI has replaced passage content
  var _aiReplaceRoundCount = 0;      // rounds of AI narrative in current replace session
  var _aiReplaceTargetLabel = '';    // Q1-4: destination label (e.g. "住宅区街道")
  var _aiReplaceTargetPassage = '';  // Q1-4: destination passage name
  var _aiReplaceOriginPassage = '';  // passage name when AI replace started (reset on sidebar nav)
  var _aiReplaceSessionHTML = '';    // cached overlay HTML — survives same-passage DOM rebuild
  var DEFAULT_REPLACE_MAX_ROUNDS = Infinity; // AI exploration is unlimited; the counter is kept for history only.

  // -- Game menu passages: blacklisted from AI link injection / auto choices --
  function _isGameMenuPassage(name) {
    return !!LinkClassifierModule.isGameMenuPassage(name);
  }

  // DOM-level detection: check if current page is a shop/UI page (not story content)
  // Only uses high-confidence signals to avoid false positives on story passages.
  function _isShopOrUIPage() {
    var $passage = $('#passages .passage');
    if (!$passage.length) return false;
    var links = [];
    $passage.find('a').each(function () {
      links.push({
        text: $(this).text(),
        passage: String($(this).attr('data-passage') || '')
      });
    });
    return PageClassifierModule.isShopOrUIPage({
      passageName: (typeof State !== 'undefined' && State.passage) || '',
      pageText: ($passage.text() || '').replace(/\s+/g, ' ').trim(),
      markers: {
        wardrobeLike: $passage.find('#wardrobe, #mirror-container, .wardrobe, #clothing, .clothing-manager, #outfit').length > 0,
        shopTableLike: $passage.find('table.shop, table.store, table.inventory, #shop-table').length > 0
      },
      links: links
    });
  }

  // -- DoL location index for LOC tracking. `raw` is always a playable passage. --
  // Built from the original game's passage/location scan; `locId` is the game's $location value.
  var _aiCommonLocations = [
    { raw: 'Bedroom', label: '\u5367\u5ba4', locId: 'home', aliases: ['\u5367\u5ba4', '\u623f\u95f4', '\u5bb6\u91cc', 'bedroom', 'home'] },
    { raw: 'Bed', label: '\u5e8a\u4e0a', locId: 'home', aliases: ['\u5e8a\u4e0a', '\u5e8a', 'bed'], narrativeArrival: false, containerRaw: 'Bedroom' },
    { raw: 'Sleep', label: '\u7761\u7720', locId: 'home', aliases: ['\u7761\u7720', '\u7761\u89c9', 'sleep'], isLocation: false, manualCandidate: false, manualRelated: false, stableManual: false },
    { raw: 'Bathroom', label: '\u6d74\u5ba4', locId: 'home', aliases: ['\u6d74\u5ba4', '\u6d17\u624b\u95f4', '\u6d17\u6fa1\u95f4', 'bathroom'] },
    { raw: "Robin's Room Entrance", label: '\u7f57\u5bbe\u7684\u623f\u95f4', locId: 'home', aliases: ['\u7f57\u5bbe\u7684\u623f\u95f4', '\u7f57\u5bbe\u623f\u95f4', "Robin's room", 'Robin room'] },
    { raw: 'Kitchen', label: '\u53a8\u623f', locId: 'home', aliases: ['\u53a8\u623f', 'kitchen'] },
    { raw: 'Garden', label: '\u82b1\u56ed', locId: 'home', aliases: ['\u82b1\u56ed', '\u9662\u5b50', 'garden'] },
    { raw: 'Garden Flowers', label: '\u82b1\u56ed\u82b1\u5703', locId: 'home', aliases: ['\u82b1\u56ed\u82b1\u5703', '\u82b1\u5703', '\u82b1\u575b', 'garden flowers', 'flower bed'] },
    { raw: 'Orphanage', label: '\u5b64\u513f\u9662\u5927\u5385', locId: 'home', aliases: ['\u5b64\u513f\u9662', '\u5b64\u513f\u9662\u5927\u5385', '\u5927\u5385', 'orphanage', 'orphanage hall'] },
    { raw: 'Orphanage Ward', label: '\u5b64\u513f\u9662\u5bbf\u820d', locId: 'home', aliases: ['\u5b64\u513f\u9662\u5bbf\u820d', '\u5b64\u513f\u9662\u623f\u95f4', '\u5bbf\u820d', 'orphanage ward', 'orphanage dormitory'] },
    { raw: 'Orphanage Loft', label: '\u5b64\u513f\u9662\u9601\u697c', locId: 'home', aliases: ['\u5b64\u513f\u9662\u9601\u697c', '\u9601\u697c', 'orphanage loft', 'loft'] },
    { raw: 'Orphanage Loft Kitchen', label: '\u5b64\u513f\u9662\u9601\u697c\u5c0f\u53a8\u623f', locId: 'home', aliases: ['\u5b64\u513f\u9662\u9601\u697c\u5c0f\u53a8\u623f', '\u9601\u697c\u5c0f\u53a8\u623f', '\u79d8\u5bc6\u53a8\u623f', 'orphanage loft kitchen', 'secret kitchen'] },
    { raw: 'Domus Street', label: '\u5b85\u90b8\u8857', locId: 'town', aliases: ['\u5b85\u90b8\u8857', 'domus', 'domus street'] },
    { raw: 'Barb Street', label: '\u5012\u94a9\u8857', locId: 'town', aliases: ['\u5012\u94a9\u8857', 'barb', 'barb street'] },
    { raw: 'Elk Street', label: '\u9e8b\u9e7f\u8857', locId: 'town', aliases: ['\u9e8b\u9e7f\u8857', '\u9e8b\u9e7f\u8857\u516c\u5bd3', 'elk', 'elk street'] },
    { raw: 'Danube Street', label: '\u591a\u7459\u6cb3\u8857', locId: 'town', aliases: ['\u591a\u7459\u6cb3\u8857', '\u591a\u7459\u6cb3\u516c\u5bd3', 'danube', 'danube street'] },
    { raw: 'Mansion Enter', label: '\u827e\u5f17\u91cc\u5b85\u90b8\u5165\u53e3', locId: 'avery_mansion', aliases: ['\u827e\u5f17\u91cc\u5b85\u90b8', '\u827e\u5f17\u91cc\u5b85\u90b8\u5165\u53e3', '\u827e\u5f17\u91cc\u5e84\u56ed', 'avery mansion', 'mansion enter'] },
    { raw: 'High Street', label: '\u9ad8\u8857', locId: 'town', aliases: ['\u9ad8\u8857', 'high street'] },
    { raw: 'Doren Entrance', label: '\u591a\u4f26\u516c\u5bd3\u5165\u53e3', locId: 'flats', aliases: ['\u591a\u4f26\u516c\u5bd3', '\u591a\u4f26\u516c\u5bd3\u5165\u53e3', '\u591a\u4f26\u4f4f\u5904', 'doren entrance', 'doren flat', 'doren apartment'] },
    { raw: 'Residential Alleyways', label: '\u4f4f\u5b85\u533a\u5c0f\u5df7', locId: 'alley', aliases: ['\u5c0f\u5df7', '\u5df7\u5b50', '\u4f4f\u5b85\u5c0f\u5df7', 'alley', 'residential alley'] },
    { raw: 'Commercial Alleyways', label: '\u5546\u4e1a\u533a\u5c0f\u5df7', locId: 'alley', aliases: ['\u5546\u4e1a\u8857\u5c0f\u5df7', '\u5546\u4e1a\u533a\u5c0f\u5df7', 'commercial alley'] },
    { raw: 'Industrial Alleyways', label: '\u5de5\u4e1a\u533a\u5c0f\u5df7', locId: 'alley', aliases: ['\u5de5\u4e1a\u533a', '\u5de5\u4e1a\u5c0f\u5df7', 'industrial alley'] },
    { raw: 'Drain Water', label: '\u6392\u6c34\u6e20', locId: 'drain', aliases: ['\u6392\u6c34\u6e20', '\u6c9f\u6e20', '\u6392\u6c34\u9053', 'drain'] },
    { raw: 'Shopping Centre', label: '\u8d2d\u7269\u4e2d\u5fc3', locId: 'shopping_centre', aliases: ['\u5546\u573a', '\u8d2d\u7269\u4e2d\u5fc3', 'shopping centre', 'mall'] },
    { raw: 'Shopping Centre Top', label: '\u8d2d\u7269\u4e2d\u5fc3\u4e8c\u697c', locId: 'shopping_centre', aliases: ['\u8d2d\u7269\u4e2d\u5fc3\u4e8c\u697c', '\u5546\u573a\u4e8c\u697c', '\u8d2d\u7269\u4e2d\u5fc3\u697c\u4e0a', 'shopping centre top', 'mall upstairs'] },
    { raw: 'Shopping Centre Restroom', label: '\u8d2d\u7269\u4e2d\u5fc3\u6d17\u624b\u95f4', locId: 'shopping_centre', aliases: ['\u8d2d\u7269\u4e2d\u5fc3\u6d17\u624b\u95f4', '\u5546\u573a\u6d17\u624b\u95f4', '\u8d2d\u7269\u4e2d\u5fc3\u5395\u6240', 'shopping centre restroom', 'mall restroom'] },
    { raw: 'Adult Shop', label: '\u60c5\u8da3\u7528\u54c1\u5e97', locId: 'adult_shop', aliases: ['\u60c5\u8da3\u7528\u54c1\u5e97', '\u6027\u7528\u54c1\u5e97', 'sex shop', 'adult shop'] },
    { raw: 'Cafe Pancakes', label: '\u5496\u5561\u9986', locId: 'cafe', aliases: ['\u5496\u5561\u9986', '\u5496\u5561\u5385', '\u5496\u5561\u5e97', 'cafe', 'pancakes'] },
    { raw: 'Dance Studio', label: '\u821e\u8e48\u5ba4', locId: 'dance_studio', aliases: ['\u821e\u8e48\u5ba4', '\u821e\u8e48\u6559\u5ba4', 'dance studio'] },
    { raw: 'Police Station', label: '\u8b66\u5bdf\u5c40', locId: 'police_station', aliases: ['\u8b66\u5bdf\u5c40', '\u8b66\u5c40', 'police station'] },
    { raw: 'Hospital front', label: '\u533b\u9662\u95e8\u53e3', locId: 'hospital', aliases: ['\u533b\u9662\u95e8\u53e3', '\u533b\u9662\u5916', 'hospital front', 'hospital entrance'] },
    { raw: 'Hospital Foyer', label: '\u533b\u9662', locId: 'hospital', aliases: ['\u533b\u9662', '\u533b\u9662\u5927\u5385', 'hospital', 'hospital foyer'] },
    { raw: 'Hospital Bed', label: '\u533b\u9662\u75c5\u623f', locId: 'hospital', aliases: ['\u533b\u9662\u75c5\u623f', '\u75c5\u623f', '\u75c5\u5e8a', 'hospital bed', 'hospital ward'] },
    { raw: 'Hospital Wait', label: '\u533b\u9662\u5019\u8bca\u533a', locId: 'hospital', aliases: ['\u533b\u9662\u5019\u8bca\u533a', '\u5019\u8bca\u533a', '\u7b49\u5019\u533a', 'hospital wait', 'waiting room'] },
    { raw: 'Hospital cupboard', label: '\u533b\u9662\u50a8\u7269\u95f4', locId: 'hospital', aliases: ['\u533b\u9662\u50a8\u7269\u95f4', '\u533b\u9662\u50a8\u85cf\u95f4', '\u533b\u9662\u6742\u7269\u95f4', 'hospital cupboard', 'hospital storage'] },
    { raw: "Doctor Harper's Office", label: '\u54c8\u73c0\u533b\u751f\u8bca\u5ba4', locId: 'hospital', aliases: ['\u8bca\u5ba4', '\u54c8\u73c0\u533b\u751f\u8bca\u5ba4', 'doctor office', "doctor harper's office"] },
    { raw: 'School Front Courtyard', label: '\u5b66\u6821\u524d\u9662', locId: 'school', aliases: ['\u5b66\u6821', '\u5b66\u6821\u524d\u9662', '\u6821\u95e8', '\u5b66\u6821\u95e8\u53e3', 'school', 'school front courtyard', 'school gate'] },
    { raw: 'School Rear Courtyard', label: '\u5b66\u6821\u540e\u9662', locId: 'school_rear_courtyard', aliases: ['\u5b66\u6821\u540e\u9662', '\u540e\u9662', '\u5b66\u6821\u540e\u95e8', 'school rear courtyard', 'rear courtyard'] },
    { raw: 'School Library', label: '\u5b66\u6821\u56fe\u4e66\u9986', locId: 'school', aliases: ['\u56fe\u4e66\u9986', '\u5b66\u6821\u56fe\u4e66\u9986', 'school library'] },
    { raw: 'School Pool', label: '\u5b66\u6821\u6cf3\u6c60', locId: 'pool', aliases: ['\u6cf3\u6c60', '\u5b66\u6821\u6cf3\u6c60', 'school pool'] },
    { raw: 'School Toilets', label: '\u5b66\u6821\u5395\u6240', locId: 'school', aliases: ['\u5b66\u6821\u5395\u6240', '\u5395\u6240', '\u536b\u751f\u95f4', 'school toilets', 'school bathroom'] },
    { raw: "School Boy's Toilets", label: '\u5b66\u6821\u7537\u5395', locId: 'school', aliases: ['\u7537\u5395', '\u5b66\u6821\u7537\u5395', "boys' toilets", 'boys toilets'] },
    { raw: "School Girl's Toilets", label: '\u5b66\u6821\u5973\u5395', locId: 'school', aliases: ['\u5973\u5395', '\u5b66\u6821\u5973\u5395', "girls' toilets", 'girls toilets'] },
    { raw: 'School Boy Changing Room', label: '\u5b66\u6821\u7537\u66f4\u8863\u5ba4', locId: 'pool', aliases: ['\u7537\u66f4\u8863\u5ba4', '\u5b66\u6821\u7537\u66f4\u8863\u5ba4', 'boy changing room', 'boys changing room'] },
    { raw: 'School Girl Changing Room', label: '\u5b66\u6821\u5973\u66f4\u8863\u5ba4', locId: 'pool', aliases: ['\u5973\u66f4\u8863\u5ba4', '\u5b66\u6821\u5973\u66f4\u8863\u5ba4', 'girl changing room', 'girls changing room'] },
    { raw: 'School Infirmary', label: '\u5b66\u6821\u533b\u52a1\u5ba4', locId: 'school', aliases: ['\u533b\u52a1\u5ba4', '\u5b66\u6821\u533b\u52a1\u5ba4', '\u4fdd\u5065\u5ba4', 'school infirmary', 'infirmary'] },
    { raw: 'School Lockers', label: '\u5b66\u6821\u50a8\u7269\u67dc\u533a', locId: 'school', aliases: ['\u50a8\u7269\u67dc', '\u5b66\u6821\u50a8\u7269\u67dc', '\u50a8\u7269\u67dc\u533a', 'school lockers', 'lockers'] },
    { raw: 'Science Classroom', label: '\u5b66\u6821\u79d1\u5b66\u6559\u5ba4', locId: 'school', aliases: ['\u6559\u5ba4', '\u79d1\u5b66\u6559\u5ba4', '\u5b66\u6821\u6559\u5ba4', '\u5b66\u6821\u79d1\u5b66\u6559\u5ba4', 'classroom', 'science classroom'] },
    { raw: 'School Pool Entrance', label: '\u5b66\u6821\u6cf3\u6c60\u5165\u53e3', locId: 'school', aliases: ['\u5b66\u6821\u6cf3\u6c60\u5165\u53e3', '\u6cf3\u6c60\u5165\u53e3', 'school pool entrance', 'pool entrance'] },
    { raw: 'School Infirmary Bed', label: '\u5b66\u6821\u533b\u52a1\u5ba4\u75c5\u5e8a', locId: 'school', aliases: ['\u5b66\u6821\u533b\u52a1\u5ba4\u75c5\u5e8a', '\u533b\u52a1\u5ba4\u75c5\u5e8a', '\u4fdd\u5065\u5ba4\u75c5\u5e8a', 'school infirmary bed', 'infirmary bed'] },
    { raw: 'School Infirmary Cabinet', label: '\u5b66\u6821\u533b\u52a1\u5ba4\u836f\u67dc', locId: 'school', aliases: ['\u5b66\u6821\u533b\u52a1\u5ba4\u836f\u67dc', '\u533b\u52a1\u5ba4\u836f\u67dc', '\u4fdd\u5065\u5ba4\u836f\u67dc', 'school infirmary cabinet', 'infirmary cabinet'] },
    { raw: 'School Detention', label: '\u5b66\u6821\u7559\u6821\u5ba4', locId: 'school', aliases: ['\u7559\u6821\u5ba4', '\u5b66\u6821\u7559\u6821\u5ba4', '\u7559\u6821\u5904\u7f5a\u5ba4', 'school detention', 'detention room'] },
    { raw: 'School Roof', label: '\u5b66\u6821\u5c4b\u9876', locId: 'school', aliases: ['\u5c4b\u9876', '\u5b66\u6821\u5c4b\u9876', 'school roof', 'roof'] },
    { raw: 'School Green', label: '\u5b66\u6821\u8349\u5730', locId: 'school_rear_courtyard', aliases: ['\u5b66\u6821\u8349\u5730', '\u8349\u5730', 'school green'] },
    { raw: 'School Stump', label: '\u5b66\u6821\u6811\u6869', locId: 'school_rear_courtyard', aliases: ['\u5b66\u6821\u6811\u6869', '\u6811\u6869', 'school stump'] },
    { raw: 'Temple', label: '\u795e\u6bbf', locId: 'temple', aliases: ['\u795e\u6bbf', '\u4fee\u9053\u9662', '\u6559\u5802', 'temple'] },
    { raw: 'Temple Jordan', label: '\u7ea6\u65e6\u7684\u795e\u6bbf\u623f\u95f4', locId: 'temple', aliases: ['\u7ea6\u65e6\u7684\u623f\u95f4', '\u7ea6\u65e6\u7684\u795e\u6bbf\u623f\u95f4', 'temple jordan'] },
    { raw: 'Temple Jordan Room', label: '\u7ea6\u65e6\u7684\u623f\u95f4', locId: 'temple', aliases: ['\u7ea6\u65e6\u623f\u95f4', '\u7ea6\u65e6\u7684\u623f\u95f4', 'temple jordan room'] },
    { raw: 'Temple Cloister', label: '\u795e\u6bbf\u56de\u5eca', locId: 'temple', aliases: ['\u795e\u6bbf\u56de\u5eca', '\u56de\u5eca', '\u4fee\u9053\u9662\u56de\u5eca', 'temple cloister', 'cloister'] },
    { raw: 'Temple Quarters', label: '\u795e\u6bbf\u5bbf\u820d\u533a', locId: 'temple', aliases: ['\u795e\u6bbf\u5bbf\u820d\u533a', '\u5bbf\u820d\u533a', '\u4fee\u9053\u9662\u5bbf\u820d', 'temple quarters', 'quarters'] },
    { raw: 'Temple Bunk', label: '\u795e\u6bbf\u5e8a\u94fa', locId: 'temple', aliases: ['\u795e\u6bbf\u5e8a\u94fa', '\u5e8a\u94fa', '\u5bbf\u820d\u5e8a\u94fa', 'temple bunk', 'bunk'] },
    { raw: 'Temple Cloister Showers', label: '\u795e\u6bbf\u6dcb\u6d74\u95f4', locId: 'temple', aliases: ['\u795e\u6bbf\u6dcb\u6d74\u95f4', '\u6dcb\u6d74\u95f4', '\u4fee\u9053\u9662\u6dcb\u6d74\u95f4', 'temple showers', 'cloister showers'] },
    { raw: 'Temple Confess', label: '\u795e\u6bbf\u5fcf\u6094\u5ba4', locId: 'temple', aliases: ['\u795e\u6bbf\u5fcf\u6094\u5ba4', '\u5fcf\u6094\u5ba4', 'temple confess', 'confessional'] },
    { raw: 'Temple Chastity', label: '\u795e\u6bbf\u8d1e\u64cd\u88c5\u7f6e\u5ba4', locId: 'temple', aliases: ['\u795e\u6bbf\u8d1e\u64cd\u88c5\u7f6e\u5ba4', '\u8d1e\u64cd\u88c5\u7f6e\u5ba4', '\u8d1e\u64cd\u5ba4', 'temple chastity', 'chastity room'] },
    { raw: 'Temple Garden', label: '\u795e\u6bbf\u82b1\u56ed', locId: 'temple', aliases: ['\u795e\u6bbf\u82b1\u56ed', '\u4fee\u9053\u9662\u82b1\u56ed', 'temple garden'] },
    { raw: 'Temple Library', label: '\u795e\u6bbf\u56fe\u4e66\u9986', locId: 'temple', aliases: ['\u795e\u6bbf\u56fe\u4e66\u9986', '\u4fee\u9053\u9662\u56fe\u4e66\u9986', 'temple library'] },
    { raw: 'Churchyard', label: '\u6559\u5802\u5ead\u9662', locId: 'churchyard', aliases: ['\u6559\u5802\u5ead\u9662', '\u6559\u5802', '\u5893\u5730', 'churchyard', 'church'] },
    { raw: 'Dilapidated Temple', label: '\u8352\u5e9f\u795e\u6bbf', locId: 'old_temple', aliases: ['\u8352\u5e9f\u795e\u6bbf', '\u65e7\u795e\u6bbf', 'dilapidated temple', 'old temple'] },
    { raw: 'Dilapidated Shop', label: '\u5e9f\u5f03\u5546\u5e97', locId: 'dilapidated_shop', aliases: ['\u5e9f\u5f03\u5546\u5e97', '\u7834\u65e7\u5546\u5e97', 'dilapidated shop', 'abandoned shop'] },
    { raw: 'Brothel', label: '\u5993\u9662', locId: 'brothel', aliases: ['\u5993\u9662', 'brothel'] },
    { raw: "Briar's Office", label: '\u5e03\u8d56\u5c14\u529e\u516c\u5ba4', locId: 'brothel', aliases: ['\u5e03\u8d56\u5c14\u529e\u516c\u5ba4', "briar's office"] },
    { raw: 'Brothel Bathroom', label: '\u5993\u9662\u6d74\u5ba4', locId: 'brothel', aliases: ['\u5993\u9662\u6d74\u5ba4', '\u5993\u9662\u6d17\u6fa1\u95f4', 'brothel bathroom'] },
    { raw: 'Brothel Shower', label: '\u5993\u9662\u6dcb\u6d74\u95f4', locId: 'brothel', aliases: ['\u5993\u9662\u6dcb\u6d74\u95f4', '\u5993\u9662\u6dcb\u6d74', 'brothel shower'] },
    { raw: 'Brothel Dressing Room', label: '\u5993\u9662\u5316\u5986\u95f4', locId: 'brothel', aliases: ['\u5993\u9662\u5316\u5986\u95f4', '\u5993\u9662\u66f4\u8863\u5ba4', 'brothel dressing room'] },
    { raw: 'Brothel Basement', label: '\u5993\u9662\u5730\u4e0b\u5ba4', locId: 'brothel', aliases: ['\u5993\u9662\u5730\u4e0b\u5ba4', '\u5993\u9662\u5730\u4e0b\u5c42', 'brothel basement'] },
    { raw: 'Brothel Stage', label: '\u5993\u9662\u821e\u53f0', locId: 'brothel', aliases: ['\u5993\u9662\u821e\u53f0', '\u5993\u9662\u540e\u53f0', 'brothel stage'] },
    { raw: 'Brothel Private', label: '\u5993\u9662\u79c1\u5bc6\u623f\u95f4', locId: 'brothel', aliases: ['\u5993\u9662\u79c1\u5bc6\u623f\u95f4', '\u5993\u9662\u79c1\u5ba4', 'brothel private room'] },
    { raw: 'Strip Club', label: '\u8131\u8863\u821e\u4ff1\u4e50\u90e8', locId: 'strip_club', aliases: ['\u8131\u8863\u821e\u4ff1\u4e50\u90e8', '\u4ff1\u4e50\u90e8', 'strip club'] },
    { raw: 'Strip Club Bathroom', label: '\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u6d74\u5ba4', locId: 'strip_club', aliases: ['\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u6d74\u5ba4', '\u4ff1\u4e50\u90e8\u6d74\u5ba4', 'strip club bathroom'] },
    { raw: 'Strip Club Shower', label: '\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u6dcb\u6d74\u95f4', locId: 'strip_club', aliases: ['\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u6dcb\u6d74\u95f4', '\u4ff1\u4e50\u90e8\u6dcb\u6d74\u95f4', 'strip club shower'] },
    { raw: 'Strip Club Dressing Room', label: '\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u5316\u5986\u95f4', locId: 'strip_club', aliases: ['\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u5316\u5986\u95f4', '\u4ff1\u4e50\u90e8\u5316\u5986\u95f4', '\u4ff1\u4e50\u90e8\u66f4\u8863\u5ba4', 'strip club dressing room'] },
    { raw: 'Strip Club Management', label: '\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u7ba1\u7406\u5ba4', locId: 'strip_club', aliases: ['\u8131\u8863\u821e\u4ff1\u4e50\u90e8\u7ba1\u7406\u5ba4', '\u4ff1\u4e50\u90e8\u7ba1\u7406\u5ba4', '\u7ba1\u7406\u5ba4', 'strip club management'] },
    { raw: 'Pub', label: '\u9152\u5427', locId: 'pub', aliases: ['\u9152\u5427', '\u9152\u9986', 'pub', 'bar'] },
    { raw: 'Pub Drink', label: '\u9152\u5427\u5427\u53f0', locId: 'pub', aliases: ['\u9152\u5427\u5427\u53f0', '\u9152\u9986\u5427\u53f0', 'pub bar counter', 'pub drink'] },
    { raw: 'Pub Music', label: '\u9152\u5427\u821e\u53f0', locId: 'pub', aliases: ['\u9152\u5427\u821e\u53f0', '\u9152\u5427\u8868\u6f14\u533a', 'pub stage', 'pub music'] },
    { raw: 'Pub Box', label: '\u9152\u5427\u5305\u95f4', locId: 'pub', aliases: ['\u9152\u5427\u5305\u95f4', '\u9152\u5427\u5c0f\u623f\u95f4', 'pub box', 'pub booth'] },
    { raw: 'Pub Exposed Kitchen', label: '\u9152\u5427\u53a8\u623f', locId: 'pub', aliases: ['\u9152\u5427\u53a8\u623f', '\u9152\u9986\u53a8\u623f', 'pub kitchen'] },
    { raw: 'Connudatus Markets', label: '\u5eb7\u52aa\u8fbe\u56fe\u65af\u5e02\u573a', locId: 'market', aliases: ['\u5eb7\u52aa\u8fbe\u56fe\u65af\u5e02\u573a', '\u5e02\u573a', 'connudatus markets', 'market'] },
    { raw: 'Spa', label: '\u6c34\u7597\u4e2d\u5fc3', locId: 'spa', aliases: ['\u6c34\u7597\u4e2d\u5fc3', '\u6c34\u7597', 'spa'] },
    { raw: 'Park', label: '\u516c\u56ed', locId: 'park', aliases: ['\u516c\u56ed', 'park'] },
    { raw: 'Park Run', label: '\u516c\u56ed\u8dd1\u9053', locId: 'park', aliases: ['\u516c\u56ed\u8dd1\u9053', '\u516c\u56ed\u6162\u8dd1\u8def\u7ebf', 'park run', 'park jogging path'] },
    { raw: 'Park Exercise Heels', label: '\u516c\u56ed\u953b\u70bc\u533a', locId: 'park', aliases: ['\u516c\u56ed\u953b\u70bc\u533a', '\u516c\u56ed\u8fd0\u52a8\u533a', 'park exercise area', 'park exercise heels'] },
    { raw: 'Beach', label: '\u6d77\u6ee9', locId: 'beach', aliases: ['\u6d77\u6ee9', '\u6d77\u8fb9', 'beach'] },
    { raw: 'Beach Cave Entrance', label: '\u6d77\u6ee9\u6d1e\u7a74\u5165\u53e3', locId: 'underground', aliases: ['\u6d77\u6ee9\u6d1e\u7a74\u5165\u53e3', '\u6d77\u8fb9\u6d1e\u53e3', 'beach cave entrance'] },
    { raw: 'Beach Cave', label: '\u6d77\u6ee9\u6d1e\u7a74', locId: 'underground', aliases: ['\u6d77\u6ee9\u6d1e\u7a74', '\u6d77\u8fb9\u6d1e\u7a74', 'beach cave'] },
    { raw: 'Beach Cave Pub Entrance', label: '\u6d77\u6ee9\u6d1e\u7a74\u9152\u5427\u5165\u53e3', locId: 'underground', aliases: ['\u6d77\u6ee9\u6d1e\u7a74\u9152\u5427\u5165\u53e3', '\u6d1e\u7a74\u9152\u5427\u5165\u53e3', 'beach cave pub entrance'] },
    { raw: 'Docks', label: '\u7801\u5934', locId: 'docks', aliases: ['\u7801\u5934', '\u6e2f\u53e3', 'docks'] },
    { raw: 'Museum', label: '\u535a\u7269\u9986', locId: 'museum', aliases: ['\u535a\u7269\u9986', 'museum'] },
    { raw: 'Museum Horse', label: '\u535a\u7269\u9986\u6728\u9a6c\u5c55\u533a', locId: 'museum', aliases: ['\u535a\u7269\u9986\u6728\u9a6c\u5c55\u533a', '\u6728\u9a6c\u5c55\u533a', 'museum horse', 'museum wooden horse'] },
    { raw: 'Museum Secret', label: '\u535a\u7269\u9986\u9690\u79d8\u5c55\u5ba4', locId: 'museum', aliases: ['\u535a\u7269\u9986\u9690\u79d8\u5c55\u5ba4', '\u9690\u79d8\u5c55\u5ba4', 'museum secret room', 'museum secret'] },
    { raw: 'Museum Sell', label: '\u535a\u7269\u9986\u9274\u5b9a\u5904', locId: 'museum', aliases: ['\u535a\u7269\u9986\u9274\u5b9a\u5904', '\u535a\u7269\u9986\u51fa\u552e\u5904', 'museum appraisal', 'museum sell'] },
    { raw: 'Photo', label: '\u6444\u5f71\u5de5\u4f5c\u5ba4', locId: 'studio', aliases: ['\u6444\u5f71\u5de5\u4f5c\u5ba4', '\u6444\u5f71\u68da', '\u7167\u76f8\u9986', 'photo', 'studio'] },
    { raw: 'Office Agency', label: '\u529e\u516c\u697c', locId: 'office', aliases: ['\u529e\u516c\u697c', '\u529e\u516c\u5ba4', 'office'] },
    { raw: 'Forest', label: '\u68ee\u6797', locId: 'forest', aliases: ['\u68ee\u6797', 'forest'] },
    { raw: 'Forest Cabin', label: '\u4f0a\u7538\u5c0f\u5c4b', locId: 'cabin', aliases: ['\u4f0a\u7538\u5c0f\u5c4b', '\u68ee\u6797\u5c0f\u5c4b', '\u5c0f\u6728\u5c4b', 'eden cabin', 'forest cabin', 'cabin'] },
    { raw: 'Eden Clearing', label: '\u4f0a\u7538\u5c0f\u5c4b\u5916\u7a7a\u5730', locId: 'cabin', aliases: ['\u4f0a\u7538\u5c0f\u5c4b\u5916\u7a7a\u5730', '\u4f0a\u7538\u5c0f\u5c4b\u7a7a\u5730', '\u4f0a\u7538\u7a7a\u5730', 'eden clearing', 'cabin clearing'] },
    { raw: 'Forest Shop Entrance', label: '\u68ee\u6797\u5546\u5e97', locId: 'forest_shop', aliases: ['\u68ee\u6797\u5546\u5e97', '\u683c\u5a01\u5170\u5546\u5e97', 'forest shop'] },
    { raw: 'Wolf Cave', label: '\u72fc\u6d1e', locId: 'wolf_cave', aliases: ['\u72fc\u6d1e', '\u72fc\u7a74', 'wolf cave', 'forest wolf cave'] },
    { raw: 'Wolf Cave Clearing', label: '\u72fc\u6d1e\u7a7a\u5730', locId: 'wolf_cave', aliases: ['\u72fc\u6d1e\u7a7a\u5730', '\u72fc\u7a74\u7a7a\u5730', '\u7a7a\u5730', 'wolf cave clearing', 'cave clearing'] },
    { raw: 'Wolf Cave Bed', label: '\u72fc\u6d1e\u5e8a\u94fa', locId: 'wolf_cave', aliases: ['\u72fc\u6d1e\u5e8a\u94fa', '\u72fc\u7a74\u5e8a\u94fa', 'wolf cave bed', 'cave bed'] },
    { raw: 'Wolf Cave Wash', label: '\u72fc\u6d1e\u6eaa\u6d41', locId: 'wolf_cave', aliases: ['\u72fc\u6d1e\u6eaa\u6d41', '\u72fc\u6d1e\u6d17\u6d74\u5904', '\u6eaa\u6d41', 'wolf cave wash', 'cave stream'] },
    { raw: 'Wolf Cave Plots', label: '\u72fc\u6d1e\u83dc\u5730', locId: 'wolf_cave', aliases: ['\u72fc\u6d1e\u83dc\u5730', '\u72fc\u6d1e\u8015\u5730', '\u83dc\u5730', 'wolf cave plots', 'cave plots'] },
    { raw: 'Wolf Cave Plant', label: '\u72fc\u6d1e\u690d\u7269\u4e1b', locId: 'wolf_cave', aliases: ['\u72fc\u6d1e\u690d\u7269\u4e1b', '\u72fc\u6d1e\u690d\u7269', '\u690d\u7269\u4e1b', 'wolf cave plant', 'cave plants'] },
    { raw: 'Wolf Cave Rank', label: '\u72fc\u6d1e\u7b49\u7ea7', locId: 'wolf_cave', aliases: ['\u72fc\u6d1e\u7b49\u7ea7', '\u72fc\u7fa4\u5730\u4f4d', 'wolf cave rank'] },
    { raw: 'Lake Shore', label: '\u6e56\u8fb9', locId: 'lake', aliases: ['\u6e56\u6cca', '\u6e56\u8fb9', '\u6e56\u5cb8', 'lake', 'lake shore'] },
    { raw: 'Lake Ruin', label: '\u6e56\u4e2d\u9057\u8ff9', locId: 'lake_ruin', aliases: ['\u6e56\u4e2d\u9057\u8ff9', '\u6e56\u5e95\u9057\u8ff9', 'lake ruin'] },
    { raw: 'Lake Ruin Deep', label: '\u6e56\u4e2d\u9057\u8ff9\u6df1\u5904', locId: 'lake_ruin', aliases: ['\u6e56\u4e2d\u9057\u8ff9\u6df1\u5904', '\u6e56\u5e95\u9057\u8ff9\u6df1\u5904', 'lake ruin deep'] },
    { raw: 'Lake Ruin Door', label: '\u6e56\u4e2d\u9057\u8ff9\u77f3\u95e8', locId: 'lake_ruin', aliases: ['\u6e56\u4e2d\u9057\u8ff9\u77f3\u95e8', '\u9057\u8ff9\u77f3\u95e8', 'lake ruin door'] },
    { raw: 'Lake Ruin Plinth', label: '\u6e56\u4e2d\u9057\u8ff9\u77f3\u5ea7', locId: 'lake_ruin', aliases: ['\u6e56\u4e2d\u9057\u8ff9\u77f3\u5ea7', '\u9057\u8ff9\u77f3\u5ea7', 'lake ruin plinth'] },
    { raw: 'Lake Ruin Box', label: '\u6e56\u4e2d\u9057\u8ff9\u7bb1\u5323', locId: 'lake_ruin', aliases: ['\u6e56\u4e2d\u9057\u8ff9\u7bb1\u5323', '\u9057\u8ff9\u7bb1\u5323', '\u6e56\u5e95\u7bb1\u5323', 'lake ruin box'] },
    { raw: 'Lake Ruin Symbol', label: '\u6e56\u4e2d\u9057\u8ff9\u58c1\u753b\u7b26\u53f7', locId: 'lake_ruin', aliases: ['\u6e56\u4e2d\u9057\u8ff9\u58c1\u753b\u7b26\u53f7', '\u9057\u8ff9\u7b26\u53f7', '\u58c1\u753b\u7b26\u53f7', 'lake ruin symbol'] },
    { raw: 'Lake Ruin Sit', label: '\u6e56\u4e2d\u9057\u8ff9\u9759\u5750\u5904', locId: 'lake_ruin', aliases: ['\u6e56\u4e2d\u9057\u8ff9\u9759\u5750\u5904', '\u9057\u8ff9\u9759\u5750\u5904', '\u6e56\u5e95\u9759\u5750\u5904', 'lake ruin sit'] },
    { raw: 'Moor', label: '\u8352\u539f', locId: 'moor', aliases: ['\u8352\u539f', 'moor'] },
    { raw: 'Bog', label: '\u6cbc\u6cfd', locId: 'bog', aliases: ['\u6cbc\u6cfd', '\u6ce5\u6cbc', 'bog'] },
    { raw: 'Meadow', label: '\u8349\u5730', locId: 'meadow', aliases: ['\u8349\u5730', '\u7267\u8349\u5730', 'meadow'] },
    { raw: 'Castle', label: '\u57ce\u5821', locId: 'castle', aliases: ['\u57ce\u5821', '\u57ce\u5821\u5ead\u9662', 'castle'] },
    { raw: 'Bird Tower', label: '\u9ad8\u5854', locId: 'tower', aliases: ['\u9ad8\u5854', '\u5854\u697c', '\u77f3\u5854', '\u96c4\u9e70\u5de2\u7a74', '\u96c4\u9e70\u9ad8\u5854', '\u5de8\u9e70\u9ad8\u5854', '\u5927\u9e70\u9ad8\u5854', '\u5927\u9e70\u5de2', '\u9e70\u5de2', '\u66f4\u9ad8\u7684\u77f3\u5854', 'tower', 'bird tower', 'great hawk tower'] },
    { raw: 'Manor Garden', label: '\u51ef\u62c9\u5c14\u5e84\u56ed\u524d\u82b1\u56ed', locId: 'kylar_manor', aliases: ['\u51ef\u62c9\u5c14\u5e84\u56ed', '\u51ef\u62c9\u5c14\u5bb6', '\u5e84\u56ed\u82b1\u56ed', 'manor garden', 'kylar manor'] },
    { raw: 'Manor Lab', label: '\u51ef\u62c9\u5c14\u5e84\u56ed\u5b9e\u9a8c\u5ba4', locId: 'kylar_manor', aliases: ['\u51ef\u62c9\u5c14\u5b9e\u9a8c\u5ba4', '\u5e84\u56ed\u5b9e\u9a8c\u5ba4', 'manor lab'] },
    { raw: 'Manor Lab Clean', label: '\u51ef\u62c9\u5c14\u5e84\u56ed\u5b9e\u9a8c\u5ba4\u6e05\u7406', locId: 'kylar_manor', aliases: ['\u6e05\u7406\u51ef\u62c9\u5c14\u5b9e\u9a8c\u5ba4', 'manor lab clean'] },
    { raw: 'Manor Kylar Room', label: '\u51ef\u62c9\u5c14\u5367\u5ba4', locId: 'kylar_manor', aliases: ['\u51ef\u62c9\u5c14\u7684\u623f\u95f4', '\u51ef\u62c9\u5c14\u5367\u5ba4', 'kylar room', 'manor kylar room'] },
    { raw: 'Manor Garden Trim', label: '\u51ef\u62c9\u5c14\u5e84\u56ed\u4fee\u526a\u6811\u7bf1', locId: 'kylar_manor', aliases: ['\u4fee\u526a\u6811\u7bf1', '\u5e84\u56ed\u4fee\u526a\u6811\u7bf1', 'manor garden trim'] },
    { raw: 'Farm Work', label: '\u4e9a\u5386\u514b\u65af\u519c\u573a', locId: 'alex_farm', aliases: ['\u519c\u573a', '\u519c\u820d', '\u9e21\u820d', '\u72ac\u820d', '\u72d7\u820d', '\u725b\u68da', '\u8c37\u4ed3', '\u7267\u573a', '\u827e\u5229\u514b\u65af', '\u4e9a\u5386\u514b\u65af', 'farm', 'alex farm', 'Alex'] },
    { raw: 'Farm Cottage', label: '\u4e9a\u5386\u514b\u65af\u5c0f\u5c4b', locId: 'alex_cottage', aliases: ['\u4e9a\u5386\u514b\u65af\u5c0f\u5c4b', '\u519c\u573a\u5c0f\u5c4b', 'farm cottage', 'alex cottage'] },
    { raw: 'Farm Woodland', label: '\u519c\u573a\u6797\u5730', locId: 'alex_farm', aliases: ['\u519c\u573a\u6797\u5730', '\u519c\u573a\u5c0f\u6811\u6797', '\u6797\u5730', 'farm woodland', 'woodland'] },
    { raw: 'Farmland', label: '\u519c\u7530', locId: 'farm', aliases: ['\u519c\u7530', '\u5730\u4e0b\u519c\u573a', 'farmland'] },
    { raw: 'Farm Barn', label: '\u8c37\u4ed3', locId: 'farm', aliases: ['\u8c37\u4ed3', '\u519c\u573a\u8c37\u4ed3', 'barn', 'farm barn'] },
    { raw: 'Farm Kennel', label: '\u519c\u573a\u72ac\u820d', locId: 'alex_farm', aliases: ['\u519c\u573a\u72ac\u820d', '\u72ac\u820d', '\u72d7\u820d', 'farm kennel', 'kennel'] },
    { raw: 'Farm Shed', label: '\u519c\u573a\u6dcb\u6d74\u95f4', locId: 'alex_farm', aliases: ['\u519c\u573a\u6dcb\u6d74\u95f4', '\u6dcb\u6d74\u68da', '\u6dcb\u6d74\u95f4', 'farm shed', 'shower shed'] },
    { raw: 'Farm Still', label: '\u519c\u573a\u5b9e\u9a8c\u5ba4', locId: 'alex_farm', aliases: ['\u519c\u573a\u5b9e\u9a8c\u5ba4', '\u519c\u573a\u84b8\u998f\u5ba4', '\u5b9e\u9a8c\u5ba4', 'farm still', 'farm lab'] },
    { raw: 'Estate', label: '\u5e84\u56ed', locId: 'estate', aliases: ['\u5e84\u56ed', '\u519c\u573a\u5e84\u56ed', 'estate'] },
    { raw: 'Riding School', label: '\u9a91\u672f\u5b66\u6821', locId: 'riding_school', aliases: ['\u9a91\u672f\u5b66\u6821', '\u9a6c\u672f\u5b66\u6821', 'riding school'] },
    { raw: 'Farmers Centre', label: '\u519c\u592b\u4e2d\u5fc3', locId: 'factory', aliases: ['\u519c\u592b\u4e2d\u5fc3', '\u5de5\u5382', 'farmers centre', 'factory'] },
    { raw: 'Sewers Commercial', label: '\u4e0b\u6c34\u9053', locId: 'sewers', aliases: ['\u4e0b\u6c34\u9053', '\u5546\u4e1a\u533a\u4e0b\u6c34\u9053', 'sewers', 'commercial sewers'] },
    { raw: 'Sewers Industrial', label: '\u5de5\u4e1a\u533a\u4e0b\u6c34\u9053', locId: 'sewers', aliases: ['\u5de5\u4e1a\u533a\u4e0b\u6c34\u9053', 'industrial sewers'] },
    { raw: 'Sewers Residential', label: '\u4f4f\u5b85\u533a\u4e0b\u6c34\u9053', locId: 'sewers', aliases: ['\u4f4f\u5b85\u533a\u4e0b\u6c34\u9053', '\u4f4f\u5b85\u4e0b\u6c34\u9053', 'residential sewers'] },
    { raw: 'Sewers Lake', label: '\u4e0b\u6c34\u9053\u6e56\u6cca', locId: 'sewers', aliases: ['\u4e0b\u6c34\u9053\u6e56\u6cca', '\u5730\u4e0b\u6e56', 'sewers lake'] },
    { raw: 'Sewers Morgan', label: '\u6469\u6839\u7684\u4e0b\u6c34\u9053\u636e\u70b9', locId: 'sewers', aliases: ['\u6469\u6839\u7684\u4e0b\u6c34\u9053\u636e\u70b9', '\u6469\u6839\u636e\u70b9', 'sewers morgan', "morgan's sewers"] },
    { raw: 'Sewers Ruins', label: '\u4e0b\u6c34\u9053\u9057\u8ff9\u901a\u9053', locId: 'sewers', aliases: ['\u4e0b\u6c34\u9053\u9057\u8ff9\u901a\u9053', '\u9057\u8ff9\u901a\u9053', 'sewers ruins'] },
    { raw: 'Sewers Waterfall', label: '\u4e0b\u6c34\u9053\u7011\u5e03', locId: 'sewers', aliases: ['\u4e0b\u6c34\u9053\u7011\u5e03', '\u5730\u4e0b\u7011\u5e03', 'sewers waterfall'] },
    { raw: 'Sewers Workshop', label: '\u4e0b\u6c34\u9053\u5de5\u4f5c\u95f4', locId: 'sewers', aliases: ['\u4e0b\u6c34\u9053\u5de5\u4f5c\u95f4', '\u5730\u4e0b\u5de5\u4f5c\u95f4', 'sewers workshop'] },
    { raw: 'Trash', label: '\u5783\u573e\u573a', locId: 'landfill', aliases: ['\u5783\u573e\u573a', '\u5e9f\u54c1\u573a', 'landfill', 'trash'] },
    { raw: 'Elk Compound', label: '\u9e8b\u9e7f\u8857\u636e\u70b9', locId: 'compound', aliases: ['\u9e8b\u9e7f\u8857\u636e\u70b9', '\u636e\u70b9', 'elk compound', 'compound'] },
    { raw: 'Underground Cell', label: '\u5730\u4e0b\u533a\u57df', locId: 'underground', aliases: ['\u5730\u4e0b\u533a\u57df', '\u5730\u4e0b\u7262\u623f', 'underground'] },
    { raw: 'Asylum', label: '\u7cbe\u795e\u75c5\u9662', locId: 'asylum', aliases: ['\u7cbe\u795e\u75c5\u9662', '\u75af\u4eba\u9662', 'asylum'] },
    { raw: 'Prison Yard', label: '\u76d1\u72f1', locId: 'prison', aliases: ['\u76d1\u72f1', '\u76d1\u72f1\u9662\u5b50', 'prison', 'prison yard'] },
    { raw: 'Pirate Deck', label: '\u6d77\u76d7\u8239', locId: 'pirate_ship', aliases: ['\u6d77\u76d7\u8239', '\u8239\u7532\u677f', 'pirate ship', 'pirate deck'] },
    { raw: 'Arcade', label: '\u8857\u673a\u5385', locId: 'arcade', aliases: ['\u8857\u673a\u5385', '\u6e38\u620f\u5385', 'arcade'] },
    { raw: 'Pillory', label: '\u67b7\u5211\u53f0', locId: 'town', aliases: ['\u67b7\u5211\u53f0', 'pillory'] },
    { raw: 'Bus', label: '\u516c\u4ea4\u8f66', locId: 'bus', aliases: ['\u516c\u4ea4\u8f66', '\u5df4\u58eb', 'bus'] },
  ];
  var _aiAvailableDestinations = [];   // [{ raw, label }] populated at AI start
  var _aiCurrentLocationLabel = '';    // dynamic AI current location label
  var _aiCurrentLocationPassage = '';  // dynamic AI current location passage name
  var _aiLocationArrived = false;      // true when AI has indicated arrival at a known location
  var _aiLastLocationDecision = null;  // last LocationController arrival decision
  var _aiReplaceOriginalLinkId = '';    // original game link to trigger after AI narration
  var _aiReplaceOriginalEventMode = false; // true for original event/action links that must resolve immediately
  var _lastChoiceText = '';            // last user-chosen option text for LOC inference
  var _lastNarrativePrompt = '';       // last prompt used for narrative (for regen button)
  var _lastConsistencyDiagnostics = [];
  var _lastConsistencyBlockedEffects = [];
  var _lastAiTransactionPlan = null;
  var _aiNarrativeWrap = null;         // dedicated container for AI narrative in normal mode (page-turn)

  function _clipConsistencySummaryText(value, limit) {
    limit = Math.max(20, parseInt(limit, 10) || 80);
    if (value == null) return '';
    var text = '';
    try {
      text = typeof value === 'object' ? JSON.stringify(value) : String(value);
    } catch (_) {
      text = String(value || '');
    }
    text = text.replace(/\s+/g, ' ').trim();
    return text.length > limit ? text.slice(0, limit - 1) + '…' : text;
  }

  function _formatConsistencyBlockedEffect(effect, index) {
    effect = effect || {};
    var code = String(effect.code || '');
    var field = String(effect.field || '');
    var value = _clipConsistencySummaryText(effect.value, 96);
    var replacement = _clipConsistencySummaryText(effect.replacement, 64);
    var subject = value ? '“' + value + '”' : '该变化';
    var prefix = (index != null ? String(index + 1) + '. ' : '');
    switch (code) {
      case 'money_without_matching_text_amount':
        return prefix + '金钱变化 ' + subject + ' 已拦截：正文没有明确相同金额。';
      case 'visible_money_without_transaction_cue':
        return prefix + '金钱变化 ' + subject + ' 已拦截：页面只显示价格/租金/奖励等金额，正文没有明确完成支付或获得。';
      case 'item_gain_without_text_evidence_suppressed':
        return prefix + '获得道具 ' + subject + ' 已拦截：正文或道具字段没有对应依据。';
      case 'item_lost_without_text_evidence_suppressed':
        return prefix + '失去/消耗道具 ' + subject + ' 已拦截：正文或使用道具字段没有对应依据。';
      case 'present_character_not_visible_suppressed':
        return prefix + '在场角色 ' + subject + ' 已拦截：当前原版页面没有确认该角色在场。';
      case 'relationship_npc_not_visible_suppressed':
        return prefix + 'NPC关系变化 ' + subject + ' 已拦截：目标 NPC 不在当前原版页面。';
      case 'unknown_target_location_reset':
        return prefix + '到达地点 ' + subject + ' 已重置为当前地点：不是已知或可达的原版地点。';
      case 'action_like_target_location_reset':
        return prefix + '到达地点 ' + subject + ' 已重置为当前地点：AI 把动作词当成地点。';
      case 'action_like_location_reset':
        return prefix + '当前地点已重置为 ' + (replacement ? '“' + replacement + '”' : '当前地点') + '：AI 把动作词当成地点。';
      case 'target_location_without_movement_cue_reset':
        return prefix + '到达地点 ' + subject + ' 已重置为当前地点：正文没有明确到达、进入或离开的语义。';
      case 'ui_page_items_gained_suppressed':
        return prefix + '获得道具 ' + subject + ' 已拦截：当前页面更像菜单/设置/状态页，不应用剧情变化。';
      case 'ui_page_items_lost_suppressed':
        return prefix + '失去/消耗道具 ' + subject + ' 已拦截：当前页面更像菜单/设置/状态页，不应用剧情变化。';
      case 'ui_page_relationship_changes_suppressed':
        return prefix + 'NPC关系变化 ' + subject + ' 已拦截：当前页面更像菜单/设置/状态页，不应用剧情变化。';
      case 'ui_page_money_change_suppressed':
        return prefix + '金钱变化 ' + subject + ' 已拦截：当前页面更像菜单/设置/状态页，不应用剧情变化。';
      case 'ui_page_target_location_reset':
        return prefix + '到达地点 ' + subject + ' 已重置为当前地点：当前页面更像菜单/设置/状态页。';
      case 'restricted_business_items_gained_suppressed':
        return prefix + '获得道具 ' + subject + ' 已拦截：当前原版规则显示店铺关闭、夜间或临近打烊，不能按正常购物获得物品。';
      case 'restricted_business_items_lost_suppressed':
        return prefix + '失去/消耗道具 ' + subject + ' 已拦截：当前原版规则显示店铺关闭、夜间或临近打烊，不能按正常购物消耗物品。';
      case 'restricted_business_money_change_suppressed':
        return prefix + '金钱变化 ' + subject + ' 已拦截：当前原版规则显示店铺关闭、夜间或临近打烊，不能按正常购物扣款或收款。';
      case 'special_event_target_location_reset':
        return prefix + '到达地点 ' + subject + ' 已重置为当前地点：当前原版页面是梦境、镜面、启动页或其他特殊事件页，不能直接当作普通稳定地点到达。';
      default:
        return prefix + '字段 ' + (field || 'unknown') + ' 的变化 ' + subject + ' 已拦截：' + (code || 'unknown_reason') + '。';
    }
  }

  function _formatConsistencyBlockedEffects(effects) {
    if (!Array.isArray(effects) || !effects.length) return [];
    return effects.slice(-20).map(function (effect, index) {
      return _formatConsistencyBlockedEffect(effect, index);
    }).filter(Boolean);
  }

  function _getConsistencyBlockedEffectSummary() {
    return _formatConsistencyBlockedEffects(_lastConsistencyBlockedEffects || []);
  }

  const LocationControllerModule = window.AIStoryGenLocationControllerModule || window.AIStoryGen.LocationControllerModule;
  if (!LocationControllerModule || typeof LocationControllerModule.create !== 'function') {
    throw new Error('[AIStoryGen] ai-location-controller.js must load before aiMacro.js');
  }

  function _getLocationRuntimeState() {
    var statePassage = '';
    try { statePassage = (typeof State !== 'undefined' && State.passage) || ''; } catch (_) {}
    return {
      currentLocationPassage: _aiCurrentLocationPassage || '',
      replaceTargetPassage: _aiReplaceTargetPassage || '',
      replaceOriginPassage: _aiReplaceOriginPassage || '',
      statePassage: statePassage
    };
  }

  const _aiLocationTools = LocationControllerModule.create({
    commonLocations: _aiCommonLocations,
    cleanLabel: cleanLabel,
    currentState: _getLocationRuntimeState,
    getAvailableDestinations: function () { return _aiAvailableDestinations; },
    getLocationGraph: function () {
      try {
        return (typeof window !== 'undefined' && window.AIStoryGenLocationGraph && window.AIStoryGenLocationGraph.nodes)
          ? window.AIStoryGenLocationGraph
          : null;
      } catch (_) {
        return null;
      }
    },
    storyHas: function (raw) { return _nativeStoryHas(raw); },
    isUnsafeDirectPassage: function (raw) {
      return _isUnsafeDirectPassage(raw);
    }
  });
  window.AIStoryGen.locationTools = _aiLocationTools;

  // Clean label text: strip hotkey annotations e.g. "(Shift+3)", "(0:01)", "(A)", "(4)"
  function cleanLabel(text) {
    if (!text) return '';
    return text.replace(/\(Shift\+\d+\)/gi, '')
               .replace(/\(\d+:\d+\)/g, '')
               .replace(/\([A-F]\)/g, '')
               .replace(/\((£)?\d+(\.\d+)?(\s?£)?\)/g, '')  // (4), (£1.50) etc.
               .replace(/\([^)]{1,6}\)/g, '')   // short parenthetical annotations like "(富人区)"
               .replace(/\s+/g, ' ')
               .trim();
  }

  function _getAiLocationState() {
    return {
      passage: _aiCurrentLocationPassage || '',
      label: _aiCurrentLocationLabel || '',
      arrived: !!_aiLocationArrived
    };
  }

  function _canonicalizeAiLocationStateTarget(rawPassage, label) {
    rawPassage = _normalizePassageName(rawPassage || '');
    label = label || '';
    if (!rawPassage) return { raw: '', label: label };
    var stableRaw = _stableLocationForActionPassage(rawPassage);
    if (stableRaw) {
      var stableCommon = _findCommonLocationByRaw(stableRaw) || _findCommonLocation(stableRaw);
      return { raw: stableRaw, label: (stableCommon && stableCommon.label) || label };
    }
    var common = _findCommonLocationByRaw(rawPassage) || _findCommonLocation(rawPassage) || _findCommonLocationByPrefix(rawPassage);
    if (common && common.narrativeArrival === false && common.containerRaw) {
      var containerRaw = _normalizePassageName(common.containerRaw);
      var containerCommon = _findCommonLocationByRaw(containerRaw) || _findCommonLocation(containerRaw);
      if (containerRaw && !_isUnsafeDirectPassage(containerRaw)) {
        return { raw: containerRaw, label: (containerCommon && containerCommon.label) || label };
      }
    }
    if (common && common.raw && !_isUnsafeDirectPassage(common.raw)) {
      return { raw: common.raw, label: common.label || label };
    }
    var graphLoc = _findGraphLocation(rawPassage);
    if (graphLoc && graphLoc.locId) {
      var canonical = _findCommonLocationByLocId(graphLoc.locId);
      if (canonical && canonical.raw && !_isUnsafeDirectPassage(canonical.raw)) {
        return { raw: canonical.raw, label: canonical.label || label };
      }
    }
    return { raw: rawPassage, label: label };
  }

  function _stableLocationForActionPassage(rawPassage) {
    rawPassage = _normalizePassageName(rawPassage || '');
    if (!rawPassage) return '';
    var map = {
      'Clearing Debris': 'Eden Clearing'
    };
    return map[rawPassage] || '';
  }

  function _setAiLocationState(rawPassage, label, reason, opts) {
    opts = opts || {};
    rawPassage = _normalizePassageName(rawPassage || '');
    if (!rawPassage) return false;
    var canonicalTarget = _canonicalizeAiLocationStateTarget(rawPassage, label || '');
    rawPassage = canonicalTarget.raw || rawPassage;
    label = canonicalTarget.label || label || '';
    if (_isInvalidAIEventLocationValue(rawPassage) || (label && _isInvalidAIEventLocationValue(label))) {
      try { console.warn('[AIStoryGen] ignored action-like location state: ' + (label || rawPassage)); } catch (_) {}
      return false;
    }
    _aiCurrentLocationPassage = rawPassage;
    _aiCurrentLocationLabel = _resolveLocationDisplay(rawPassage, label || '') || rawPassage;
    _aiLocationArrived = opts.arrived !== false;
    try {
      console.log('[AIStoryGen] location set' + (reason ? ' (' + reason + ')' : '') + ': ' + _aiCurrentLocationLabel + ' (' + _aiCurrentLocationPassage + '), arrived=' + _aiLocationArrived);
    } catch (_) {}
    return true;
  }

  function _setAiLocationLabelOnly(label, reason, opts) {
    opts = opts || {};
    label = _resolveLocationDisplay('', label || '') || cleanLabel(label || '') || String(label || '').trim();
    if (!label) return false;
    if (_isInvalidAIEventLocationValue(label)) {
      try { console.warn('[AIStoryGen] ignored action-like location label: ' + label); } catch (_) {}
      return false;
    }
    _aiCurrentLocationPassage = '';
    _aiCurrentLocationLabel = label;
    _aiLocationArrived = opts.arrived !== false;
    try {
      console.log('[AIStoryGen] location label set' + (reason ? ' (' + reason + ')' : '') + ': ' + _aiCurrentLocationLabel + ', arrived=' + _aiLocationArrived);
    } catch (_) {}
    return true;
  }

  function _clearAiLocationState(reason) {
    _aiCurrentLocationLabel = '';
    _aiCurrentLocationPassage = '';
    _aiLocationArrived = false;
    try { if (reason) console.log('[AIStoryGen] location state cleared: ' + reason); } catch (_) {}
  }

  function _markAiLocationInTransit(reason) {
    if (_aiReplaceActive) {
      _aiLocationArrived = false;
      try { if (reason) console.log('[AIStoryGen] location state in transit: ' + reason); } catch (_) {}
      return;
    }
    _clearAiLocationState(reason || 'location in transit');
  }

  function _getArriveTargetPassage() {
    if (_aiLocationArrived && _aiCurrentLocationPassage) return _normalizePassageName(_aiCurrentLocationPassage);
    if (_aiReplaceActive && _aiReplaceTargetPassage) return _normalizePassageName(_aiReplaceTargetPassage);
    try {
      if (typeof State !== 'undefined' && State.passage) return _normalizePassageName(State.passage);
    } catch (_) {}
    return '';
  }

  function _resolveLocationLabel(passageName) {
    return _aiLocationTools.resolveLabel(passageName);
  }

  function _resolveLocationDisplay(raw, label) {
    return _aiLocationTools.resolveDisplay(raw, label);
  }

  function _findCommonLocation(rawOrLabel) {
    return _aiLocationTools.findCommon(rawOrLabel);
  }

  function _findCommonLocationByRaw(rawPassage) {
    return _aiLocationTools.findCommonByRaw(rawPassage);
  }

  function _findCommonLocationByLocId(locId) {
    return _aiLocationTools.findCommonByLocId(locId);
  }

  function _findCommonLocationByPrefix(rawPassage) {
    return _aiLocationTools.findCommonByPrefix(rawPassage);
  }

  function _findGraphLocation(rawOrLabel) {
    return _aiLocationTools.findGraph(rawOrLabel);
  }

  function _getAvailableDestination(raw) {
    return _aiLocationTools.getAvailableDestination(raw);
  }

  function _evaluateAiLocationArrival(rawPassage, opts) {
    return _aiLocationTools.evaluateArrivalCandidate(rawPassage, opts || {});
  }

  function _rememberLocationDecision(decision) {
    _aiLastLocationDecision = decision ? Object.assign({}, decision, { at: Date.now() }) : null;
    return decision;
  }

  function _recordAiTransactionLocationDecision(transactionPlan, detail) {
    try {
      if (!transactionPlan || !transactionPlan.location) return;
      detail = detail || {};
      var loc = transactionPlan.location;
      loc.lastAttempt = {
        source: String(detail.source || ''),
        rawPassage: _normalizePassageName(detail.rawPassage || ''),
        label: cleanLabel(detail.label || ''),
        reason: String(detail.reason || ''),
        applied: !!detail.applied,
        at: Date.now()
      };
      if (detail.decision) {
        loc.decision = _cloneForAiSnapshot(detail.decision);
        loc.decisionReason = String(detail.decision.reason || '');
        loc.decisionAllowed = !!detail.decision.allowed;
        loc.decisionArrived = !!detail.decision.arrived;
      }
      if (detail.rawPassage) loc.resolvedPassage = _normalizePassageName(detail.rawPassage || '');
      if (detail.label) loc.resolvedLabel = _resolveLocationDisplay(detail.rawPassage || '', detail.label || '') || cleanLabel(detail.label || '');
      if (detail.failureReason) loc.failureReason = String(detail.failureReason || '');
      if (detail.fallbackMode) loc.fallbackMode = String(detail.fallbackMode || '');
    } catch (_) {}
  }

  function _recordAiReturnButtonModel(model, detail) {
    try {
      if (!_lastAiTransactionPlan) return;
      _lastAiTransactionPlan.location = _lastAiTransactionPlan.location || {};
      detail = detail || {};
      _lastAiTransactionPlan.location.returnButtonModel = {
        source: String(detail.source || 'renderChoices'),
        text: String(model && model.text || ''),
        rawPassage: _normalizePassageName(model && model.rawPassage || ''),
        rawLabel: cleanLabel(model && model.rawLabel || ''),
        destLabel: cleanLabel(model && model.destLabel || ''),
        hasPendingNativeTarget: !!(model && model.hasPendingNativeTarget),
        canNavigateNative: !!(model && model.canNavigateNative),
        shouldRestoreOriginal: !!(model && model.shouldRestoreOriginal),
        replaceActive: !!detail.replaceActive,
        replaceOriginalEventMode: !!detail.replaceOriginalEventMode,
        locationArrived: !!detail.locationArrived,
        statePassage: _normalizePassageName(detail.statePassage || ''),
        at: Date.now()
      };
    } catch (_) {}
  }

  function _recordAiNavigationAttempt(phase, detail) {
    try {
      if (!_lastAiTransactionPlan) return;
      _lastAiTransactionPlan.location = _lastAiTransactionPlan.location || {};
      var loc = _lastAiTransactionPlan.location;
      loc.returnButtonModel = loc.returnButtonModel || {};
      var attempt = loc.returnButtonModel.navigationAttempt || {
        samples: []
      };
      var target = _normalizePassageName(detail && detail.targetPassage || '');
      attempt.phase = String(phase || '');
      attempt.source = String(detail && detail.source || attempt.source || '');
      attempt.targetPassage = target || attempt.targetPassage || '';
      attempt.reason = String(detail && detail.reason || attempt.reason || '');
      attempt.usedEnginePlay = !!(detail && detail.usedEnginePlay);
      attempt.usedOriginalLink = !!(detail && detail.usedOriginalLink);
      attempt.ok = !!(detail && detail.ok);
      attempt.error = String(detail && detail.error || '');
      attempt.currentPassage = _normalizePassageName((typeof State !== 'undefined' && State.passage) || '');
      attempt.at = Date.now();
      if (target && attempt.currentPassage) attempt.reachedTarget = attempt.currentPassage === target;
      loc.returnButtonModel.navigationAttempt = attempt;
      return attempt;
    } catch (_) {
      return null;
    }
  }

  function _sampleAiNavigationResult(targetPassage, source, delays) {
    try {
      var target = _normalizePassageName(targetPassage || '');
      var attempt = _recordAiNavigationAttempt('scheduled', {
        source: source || '',
        targetPassage: target,
        reason: 'post-navigation sampling scheduled'
      });
      if (!attempt) return;
      delays = delays || [0, 120, 450];
      delays.forEach(function (delay, index) {
        setTimeout(function () {
          try {
            var current = _normalizePassageName((typeof State !== 'undefined' && State.passage) || '');
            var latest = _recordAiNavigationAttempt(index === delays.length - 1 ? 'settled' : 'sample', {
              source: source || '',
              targetPassage: target,
              reason: 'post-navigation sample',
              ok: !!(target && current === target)
            });
            if (latest) {
              latest.samples = latest.samples || [];
              latest.samples.push({
                delay: delay,
                passage: current,
                reachedTarget: !!(target && current === target),
                at: Date.now()
              });
              latest.reachedTarget = latest.samples.some(function (sample) { return !!sample.reachedTarget; });
            }
          } catch (_) {}
        }, delay);
      });
    } catch (_) {}
  }

  function _applyAiLocationCandidate(rawPassage, label, reason, opts) {
    opts = opts || {};
    rawPassage = _normalizePassageName(rawPassage || '');
    if (!rawPassage) {
      _recordAiTransactionLocationDecision(opts.transactionPlan, {
        source: opts.source || '',
        rawPassage: rawPassage,
        label: label || '',
        reason: reason || 'location candidate',
        applied: false,
        failureReason: 'empty location candidate'
      });
      return false;
    }
    var decision = _rememberLocationDecision(_evaluateAiLocationArrival(rawPassage, opts));
    var display = _resolveLocationDisplay(rawPassage, label || '') || rawPassage;
    _recordAiTransactionLocationDecision(opts.transactionPlan, {
      source: opts.source || '',
      rawPassage: rawPassage,
      label: display,
      reason: reason || 'location candidate',
      applied: true,
      decision: decision,
      fallbackMode: opts.fallbackMode || ''
    });
    if (decision.allowed && decision.arrived) {
      _setAiLocationState(rawPassage, display, reason || 'location candidate', { arrived: true });
      return true;
    }
    _setAiLocationState(rawPassage, display, (reason || 'location candidate') + ' (pending)', { arrived: false });
    try {
      console.log('[AIStoryGen] location kept pending: ' + display + ' (' + rawPassage + '), reason=' + decision.reason);
    } catch (_) {}
    return true;
  }

  function _collectManualArriveCandidates(primaryPassage) {
    return _aiLocationTools.collectManualArriveCandidates(primaryPassage);
  }

  function _isStableManualArrivePassage(rawPassage) {
    rawPassage = _normalizePassageName(rawPassage || '');
    if (!rawPassage || _isUnsafeDirectPassage(rawPassage)) return false;
    var exactCommon = _findCommonLocationByRaw(rawPassage);
    if (exactCommon) return exactCommon.isLocation !== false && exactCommon.stableManual !== false;
    var graphLoc = _findGraphLocation(rawPassage);
    if (graphLoc && graphLoc.locId) {
      var canonical = _findCommonLocationByLocId(graphLoc.locId);
      if (canonical && canonical.raw === rawPassage) return true;
    }
    var available = _getAvailableDestination(rawPassage);
    if (available && /^(page|graph|manual)$/i.test(String(available.source || ''))) return true;
    return false;
  }

  function _selectManualArriveTargetInAi(rawPassage) {
    rawPassage = _normalizePassageName(rawPassage || '');
    if (!rawPassage) return null;
    var fallbackRaw = _safeManualArriveFallback(rawPassage);
    if (fallbackRaw && fallbackRaw !== rawPassage) {
      rawPassage = fallbackRaw;
    }
    if (_isUnsafeDirectPassage(rawPassage)) {
      _warnUnsafeDirectPassage(rawPassage);
      return null;
    }
    var label = _resolveLocationDisplay(rawPassage, _resolveLocationLabel(rawPassage) || rawPassage) || rawPassage;
    var arrived = _isStableManualArrivePassage(rawPassage);
    _setAiLocationState(rawPassage, label, 'manual arrive target selected', { arrived: arrived });
    _showAIUserMessage((loadCfg().language === 'zh')
      ? ('已把当前 AI 剧情地点修正为「' + label + '」。点击下方“到达 ' + label + '”才会返回原版章节。')
      : ('Updated the current AI story destination to "' + label + '". Click the arrive button below to return to the native passage.'), false);
    return {
      raw: rawPassage,
      label: label,
      arrived: arrived
    };
  }

  function _forceManualArriveTo(rawPassage) {
    rawPassage = _normalizePassageName(rawPassage || '');
    if (!rawPassage) return false;
    var fallbackRaw = _safeManualArriveFallback(rawPassage);
    if (fallbackRaw && fallbackRaw !== rawPassage) {
      rawPassage = fallbackRaw;
    }
    if (_isUnsafeDirectPassage(rawPassage)) {
      _warnUnsafeDirectPassage(rawPassage);
      return false;
    }
    if (!_isStableManualArrivePassage(rawPassage)) {
      var cfgStable = loadCfg();
      var stableLabel = _resolveLocationDisplay(rawPassage, '') || rawPassage;
      _setAiLocationState(rawPassage, stableLabel, 'manual arrive target only', { arrived: false });
      _showAIUserMessage(cfgStable.language === 'zh'
        ? ('已把目标地点标记为「' + stableLabel + '」，但没有直接跳转：这个目标不像稳定原版地点入口，直接进入可能缺少前置数据。')
        : ('Marked "' + stableLabel + '" as the target, but did not jump directly because it does not look like a stable native location entry.'), true);
      return false;
    }
    try {
      if (_getNativeStory() && !_nativeStoryHas(rawPassage)) {
        _showAIUserMessage((loadCfg().language === 'zh' ? '\u65e0\u6cd5\u5230\u8fbe\uff1a' : 'Cannot arrive at: ') + rawPassage, true);
        return false;
      }
    } catch (_) {}
    _pushCurrentToAiRoundHistory();
    _setAiLocationState(rawPassage, '', 'manual arrive correction');
    try { console.log('[AIStoryGen] manual arrive correction: ' + _aiCurrentLocationLabel + ' (' + rawPassage + ')'); } catch (_) {}
    if (_aiReplaceActive) {
      _finishAiReplaceAndGo(rawPassage, {
        skipOriginal: true,
        keepAIFunctionality: true,
        preserveRoundHistory: true,
        discardNativeEventQueue: true,
        suppressAutoChoices: false
      });
    } else {
      _finishNormalAiAndGo(rawPassage, {
        keepAIFunctionality: true,
        preserveRoundHistory: true,
        discardNativeEventQueue: true,
        suppressAutoChoices: false
      });
    }
    return true;
  }

  function _normalizePassageName(passageName) {
    return _aiLocationTools.normalizePassage(passageName);
  }

  function _syncAiLocationToNativePassage(rawPassage, reason) {
    rawPassage = _normalizePassageName(rawPassage || '');
    if (!rawPassage || _aiReplaceActive) return false;
    if (_isUnsafeDirectPassage(rawPassage)) return false;
    try {
      if (_getNativeStory() && !_nativeStoryHas(rawPassage)) return false;
    } catch (_) {}
    var label = _resolveLocationDisplay(rawPassage, _resolveLocationLabel(rawPassage) || rawPassage) || rawPassage;
    return _setAiLocationState(rawPassage, label, reason || 'native passage sync', { arrived: true });
  }

  var LocationController = {
    schemaVersion: 2,
    getState: _getAiLocationState,
    setCurrent: function (rawPassage, label, reason, opts) {
      return _setAiLocationState(rawPassage, label, reason || 'controller', opts);
    },
    syncNativePassage: function (rawPassage, reason) {
      return _syncAiLocationToNativePassage(rawPassage, reason || 'controller native sync');
    },
    setLabelOnly: function (label, reason, opts) {
      return _setAiLocationLabelOnly(label, reason || 'controller label', opts);
    },
    clear: function (reason) {
      _clearAiLocationState(reason || 'controller');
    },
    normalizePassage: _normalizePassageName,
    resolveLabel: _resolveLocationLabel,
    resolveDisplay: _resolveLocationDisplay,
    findCommon: _findCommonLocation,
    findGraph: _findGraphLocation,
    collectManualArriveCandidates: _collectManualArriveCandidates,
    forceManualArriveTo: _forceManualArriveTo,
    evaluateArrivalCandidate: function (rawPassage, opts) {
      return _evaluateAiLocationArrival(rawPassage, opts || {});
    },
    getLastDecision: function () {
      return _cloneForAiSnapshot(_aiLastLocationDecision || null);
    },
    canDirectPlayPassage: _canDirectPlayPassage,
    navigateToNativePassage: function (targetPassage, opts) {
      return _navigateToNativePassage(targetPassage, opts || {});
    },
    getArriveTargetPassage: function () {
      return _getArriveTargetPassage();
    },
    parseMarker: function (text, transactionPlan) {
      return parseLocationMarker(text, transactionPlan || null);
    },
    inferFromText: function (choiceText, aiText, opts) {
      return inferLocationFromText(choiceText, aiText, opts || {});
    },
    syncOriginalPassage: function () {
      return syncOriginalPassageToCurrentLocation();
    }
  };
  window.AIStoryGen.locationController = LocationController;
  window.AIStoryGen.LocationController = LocationController;

  function _inferPriorityLocationFromText(text) {
    text = String(text || '').replace(/\s+/g, ' ').trim();
    if (!text) return false;
    var hasHawk = /(\u5de8\u9e70|\u5927\u9e70|\u96c4\u9e70|\u9e70\u96bc|\u9e70\u5de2|\u7fbd\u6bdb|great\s*hawk|hawk|eagle)/i.test(text);
    var hasTower = /(\u9ad8\u5854|\u5854\u697c|\u77f3\u5854|\u5854\u9876|\u5de2\u7a74|tower)/i.test(text);
    if (hasHawk && hasTower) {
      var tower = _findCommonLocation('Bird Tower');
      return tower ? _applyAiLocationCandidate(tower.raw, tower.label, 'bird tower narrative', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    if (/(\u66f4\u9ad8\u7684\u77f3\u5854|\u5854\u9876\u7684\u5e73\u53f0|\u91d1\u8272\u7684\u773c\u775b|\u5c55\u5f00\u53cc\u7ffc)/.test(text)) {
      var tower2 = _findCommonLocation('Bird Tower');
      return tower2 ? _applyAiLocationCandidate(tower2.raw, tower2.label, 'bird tower details', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    var hasTempleWord = /(\u795e\u6bbf|\u4fee\u9053\u9662|Temple|temple)/i.test(text);
    var hasTempleLibraryWord = /(\u795e\u6bbf\u56fe\u4e66\u9986|\u4fee\u9053\u9662\u56fe\u4e66\u9986|temple\s+library)/i.test(text);
    var hasLibraryEvidence = /(\u56fe\u4e66\u9986|\u4e66\u67b6|\u65e7\u7eb8\u5f20|\u5178\u7c4d|\u62c9\u4e01\u6587|\u6a61\u6728\u95e8|\u62f1\u5f62\u77f3\u724c|library|bookshelf|bookshelves|old\s+books|latin)/i.test(text);
    var explicitLibraryMove = /(\u8d70\u5411|\u8fdb\u5165|\u63a8\u5f00|\u6765\u5230|\u7a7f\u8fc7|\u5bfb\u627e)[^。！？]{0,48}(\u56fe\u4e66\u9986|\u4e66\u67b6|\u6a61\u6728\u95e8|library|bookshelf|bookshelves)/i.test(text);
    var templeLibrary = hasTempleLibraryWord || (hasTempleWord && hasLibraryEvidence) || explicitLibraryMove;
    if (templeLibrary) {
      var templeLibraryLoc = _findCommonLocation('Temple Library');
      return templeLibraryLoc ? _applyAiLocationCandidate(templeLibraryLoc.raw, templeLibraryLoc.label, 'temple library narrative', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    var currentPriorityPassage = _normalizePassageName(_aiCurrentLocationPassage || '');
    var hasTempleShowerWord = /(\u795e\u6bbf\u6dcb\u6d74\u95f4|\u4fee\u9053\u9662\u6dcb\u6d74\u95f4|temple\s+showers?|cloister\s+showers?)/i.test(text);
    var hasShowerEvidence = /(\u6dcb\u6d74|\u6dcb\u6d74\u95f4|\u6d74\u5ba4|\u83b2\u84ec\u5934|\u6c34\u6c7d|\u70ed\u6c34|\u6d74\u5dfe|\u6728\u94a9|shower|showers|steam|towel)/i.test(text);
    var hasTempleShowerContext = hasTempleWord || /(\u4fee\u58eb|\u56de\u5eca|\u77f3\u677f|\u70db\u53f0|\u58c1\u706f|\u795e\u6bbf)/.test(text) || /^Temple(?:\s|$)/i.test(currentPriorityPassage);
    if ((hasTempleShowerWord || (hasShowerEvidence && hasTempleShowerContext)) && !/(\u5bb6\u4e2d\u6d74\u5ba4|\u5bb6\u91cc\u6d74\u5ba4|home\s+bathroom|Bathroom)/i.test(text)) {
      var templeShowersLoc = _findCommonLocation('Temple Cloister Showers');
      return templeShowersLoc ? _applyAiLocationCandidate(templeShowersLoc.raw, templeShowersLoc.label, 'temple shower narrative', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    var hasTempleCloisterWord = /(\u795e\u6bbf\u56de\u5eca|\u4fee\u9053\u9662\u56de\u5eca|temple\s+cloister|cloister)/i.test(text);
    var hasCloisterArchitectureWord = /(\u56de\u5eca|\u62f1\u5eca|\u58c1\u9f9b|\u77f3\u780c\u7684\u62f1\u5eca|arcade|colonnade)/i.test(text);
    var explicitCloisterMove = /(\u79bb\u5f00|\u9000\u56de|\u56de\u5230|\u8fdb\u5165|\u8d70\u5411|\u5faa\u7740|\u6765\u5230|\u7a7f\u8fc7)[^。！？]{0,40}(\u56de\u5eca|\u62f1\u5eca|cloister|arcade|colonnade)/i.test(text);
    var templeCloister = hasTempleCloisterWord || (hasTempleWord && hasCloisterArchitectureWord) || (hasCloisterArchitectureWord && explicitCloisterMove);
    if (templeCloister) {
      var templeCloisterLoc = _findCommonLocation('Temple Cloister');
      return templeCloisterLoc ? _applyAiLocationCandidate(templeCloisterLoc.raw, templeCloisterLoc.label, 'temple cloister narrative', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    var hasJordanWord = /(\u7ea6\u65e6|Jordan)/i.test(text);
    var hasJordanRoomEvidence = /(\u7ea6\u65e6[^。！？]{0,80}(\u623f\u95f4|\u6728\u95e8|\u95e8\u677f|\u95e8\u540e|\u95e8\u628a|\u4e66\u684c|\u7ecf\u4e66|\u7f8a\u76ae\u7eb8|\u6cb9\u706f)|(\u623f\u95f4|\u6728\u95e8|\u95e8\u677f|\u95e8\u540e|\u95e8\u628a|\u4e66\u684c|\u7ecf\u4e66|\u7f8a\u76ae\u7eb8|\u6cb9\u706f)[^。！？]{0,80}\u7ea6\u65e6|temple\s+jordan\s+room|Jordan'?s\s+room)/i.test(text);
    if (hasJordanWord && hasJordanRoomEvidence) {
      var jordanRoomLoc = _findCommonLocation('Temple Jordan Room');
      return jordanRoomLoc ? _applyAiLocationCandidate(jordanRoomLoc.raw, jordanRoomLoc.label, 'temple jordan room narrative', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    var hasTempleGardenWord = /(\u82b1\u56ed|\u55b7\u6cc9|\u77f3\u5f84|\u5ead\u9662|\u6811\u7bf1|garden|fountain|courtyard|hedge)/i.test(text);
    var explicitGardenMove = /(\u56de\u5230|\u8fd4\u56de|\u8d70\u5411|\u6765\u5230|\u7a7f\u8fc7)[^。！？]{0,24}(\u82b1\u56ed|\u55b7\u6cc9|\u77f3\u5f84|\u5ead\u9662|\u6811\u7bf1|garden|fountain|courtyard)/i.test(text);
    var templeGarden = /(\u795e\u6bbf.{0,48}(\u82b1\u56ed|\u55b7\u6cc9|\u77f3\u5f84|\u5ead\u9662|\u6811\u7bf1)|(\u82b1\u56ed|\u55b7\u6cc9|\u77f3\u5f84|\u5ead\u9662|\u6811\u7bf1)[^。！？]{0,64}\u795e\u6bbf|Temple\s+Garden|temple\s+garden|temple\s+fountain|temple\s+courtyard)/i.test(text)
      || (hasTempleWord && hasTempleGardenWord && explicitGardenMove);
    if (templeGarden) {
      var templeGardenLoc = _findCommonLocation('Temple Garden');
      return templeGardenLoc ? _applyAiLocationCandidate(templeGardenLoc.raw, templeGardenLoc.label, 'temple garden narrative', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    var templeInterior = /(\u8fdb\u5165\u795e\u6bbf|\u56de\u5230\u795e\u6bbf|\u8d70\u8fdb\u795e\u6bbf|\u795e\u6bbf\u5185\u90e8|\u795e\u6bbf\u5185|\u540e\u6bbf|\u5723\u575b|\u4fa7\u5eca|\u5f69\u8272\u73bb\u7483\u7a97|\u70db\u5149[^。！？]*\u795e\u6bbf|temple\s+interior|inside\s+the\s+temple|altar|sanctuary|nave)/i.test(text);
    if (templeInterior) {
      var temple = _findCommonLocation('Temple');
      return temple ? _applyAiLocationCandidate(temple.raw, temple.label, 'temple interior narrative', {
        source: 'priority-text',
        status: 'arrived',
        sourceText: text
      }) : false;
    }
    return false;
  }

  function _rescueLegacyPassageIfNeeded(passageName) {
    var raw = String(passageName || '').trim();
    try {
      if (raw && _nativeStoryHas(raw)) return false;
    } catch (_) {}
    var normalized = _normalizePassageName(raw);
    if (!raw || normalized === raw) return false;
    try {
      var rescuedEngine = _getNativeEngine();
      if (_nativeStoryHas(normalized) && rescuedEngine && rescuedEngine.play) {
        console.log('[AIStoryGen] rescued legacy passage "' + raw + '" -> "' + normalized + '"');
        setTimeout(function () { rescuedEngine.play(normalized); }, 0);
        return true;
      }
    } catch (_) {}
    return false;
  }

  function _isInvalidPrisonDirectState(passageName) {
    var raw = _normalizePassageName(passageName || '');
    if (!/^Prison\b/i.test(raw)) return false;
    try {
      var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
      if (!V) return false;
      return !V.prison || typeof V.prison !== 'object';
    } catch (_) {
      return false;
    }
  }

  function _clearUnsafePrisonAiState() {
    try {
      _pendingAISaveState = null;
      _aiReplaceActive = false;
      _aiReplaceOriginPassage = '';
      _aiReplaceTargetLabel = '';
      _aiReplaceTargetPassage = '';
      _aiReplaceOriginalLinkId = '';
      _aiReplaceOriginalEventMode = false;
      _clearAiLocationState('unsafe prison direct state');
      _clearAiRoundHistory();
      var V = _getStateVariables();
      if (V && V.aiStoryGenNavState && /^Prison\b/i.test(String(V.aiStoryGenNavState.passage || ''))) {
        delete V.aiStoryGenNavState;
      }
    } catch (_) {}
  }

  function _rescueInvalidPrisonDirectState(passageName, phase) {
    if (!_isInvalidPrisonDirectState(passageName)) return false;
    _clearUnsafePrisonAiState();
    try {
      console.warn('[AIStoryGen] rescued invalid Prison direct state from ' + passageName + ' during ' + (phase || 'unknown'));
    } catch (_) {}
    try {
      var safe = 'Beach';
      var rescueStory = _getNativeStory();
      var rescueEngine = _getNativeEngine();
      if (rescueStory && !_nativeStoryHas(safe)) safe = 'Domus Street';
      if (rescueEngine && rescueEngine.play && (!rescueStory || _nativeStoryHas(safe))) {
        setTimeout(function () {
          try {
            _markAISaveRestoreSuppressed(2500);
            rescueEngine.play(safe);
            _showAIUserMessage('\u5df2\u963b\u6b62\u76f4\u63a5\u8fdb\u5165\u539f\u7248\u76d1\u72f1\u4e8b\u4ef6\u94fe\uff0c\u5e76\u5c06\u9875\u9762\u6062\u590d\u5230\u6d77\u6ee9\u3002', false);
          } catch (_) {}
        }, 0);
        return true;
      }
    } catch (_) {}
    return true;
  }

  function _isOriginalEventActionLink($link, targetPassage, linkText) {
    var rowText = '';
    try {
      var $parent = $link && $link.parent ? $link.parent() : null;
      rowText = $parent && $parent.length ? ($parent.text() || '') : '';
    } catch (_) {}
    var text = (String(linkText || '') + ' ' + rowText).replace(/\s+/g, ' ');
    var target = _normalizePassageName(targetPassage || '');
    var targetCommon = _findCommonLocationByRaw(target) || _findCommonLocation(target);
    if (targetCommon && targetCommon.narrativeArrival === false) return true;
    // Original action-result passages need their native link to settle time,
    // inventory, and quest state after the AI lead-in. Treat common action
    // result names as events instead of arrival destinations.
    if (/(?:^|\s)(?:Pick(?:ing)?|Harvest(?:ing)?|Gather(?:ing)?|Collect(?:ion|ing)?|Search(?:ing)?|Trim(?:ming)?|Clean(?:ing)?|Sweep(?:ing)?|Wash(?:ing)?|Shower(?:ing)?|Eat(?:ing)?|Drink(?:ing)?|Cook(?:ing)?|Buy(?:ing)?|Sell(?:ing)?|Pay(?:ing)?|Work(?:ing)?|Train(?:ing)?|Study(?:ing)?|Sleep(?:ing)?|Rest(?:ing)?|Use|Repair(?:ing)?|Craft(?:ing)?|Make|Sew(?:ing)?|Exercise|Fight(?:ing)?|Escape|Weed(?:ing)?|Mushrooms?|Debris)(?:\s|$)/i.test(target)) return true;
    if (/(\u91c7\u6458|\u6536\u96c6|\u6e05\u7406|\u4fee\u526a|\u6e05\u626b|\u6e05\u6d17|\u6d17\u6fa1|\u4f11\u606f|\u7761\u89c9|\u4f7f\u7528|\u5236\u4f5c|\u4fee\u7406|\u5de5\u4f5c|\u8bad\u7ec3|\u5b66\u4e60|\u4ed8\u8d39|\u8d2d\u4e70|\u51fa\u552e|\u6218\u6597|\u9003\u8dd1)/.test(target)) return true;
    return /(\u4fe1\u4efb|\u5de5\u8d44|\u652f\u4ed8|\u4ed8\u94b1|\u6ca1\u94b1|\u91d1\u94b1|\u00a3|\$|trust|wage|pay|money)/i.test(text);
  }

  function _shouldSkipAIStoryLink($link, targetPassage, linkText) {
    var classifierRowText = '';
    try {
      classifierRowText = ($link && $link.parent && $link.parent().text ? $link.parent().text() : '') || '';
    } catch (_) {}
    return LinkClassifierModule.shouldSkipAIStoryLink({
      targetPassage: targetPassage,
      linkText: linkText,
      rowText: classifierRowText
    });
  }

  $(document).on(':passagedisplay', function (ev) {
    var name = (ev && ev.passage && ev.passage.title) || (typeof State !== 'undefined' && State.passage) || '';
    if (_rescueInvalidPrisonDirectState(name, 'passagedisplay legacy rescue')) return;
    _rescueLegacyPassageIfNeeded(name);
  });

  function _applyGenericStreetLocation(raw, sourceText) {
    raw = String(raw || '').trim();
    sourceText = String(sourceText || '');
    if (!/(街道|街上|路边|巷口|地面|地上|地表|街角|street|surface|road|alley)/i.test(raw + ' ' + sourceText)) return false;
    var dest = null;
    for (var i = 0; i < _aiAvailableDestinations.length; i++) {
      var d = _aiAvailableDestinations[i];
      if (/街|Street|Road/i.test(d.label + ' ' + d.raw)) { dest = d; break; }
    }
    if (dest) {
      _setAiLocationState(dest.raw, dest.label, 'generic street destination');
    } else if (_aiReplaceOriginPassage) {
      _setAiLocationState(_aiReplaceOriginPassage, _resolveLocationLabel(_aiReplaceOriginPassage) || '街道', 'generic street origin');
    } else {
      _setAiLocationLabelOnly('街道', 'generic street label');
    }
    console.log('[AIStoryGen] location matched (generic street): ' + _aiCurrentLocationLabel + (_aiCurrentLocationPassage ? ' (' + _aiCurrentLocationPassage + ')' : ''));
    return true;
  }

  // Parse time annotation from choice text: "前往公园散步 (0:10)" → 10
  function parseChoiceTimeParts(text) {
    return StoryRuntimeModule.parseChoiceTimeParts(text);
  }

  function parseTimeFromChoice(text) {
    return StoryRuntimeModule.parseTimeFromChoice(text);
  }

  function stripTimeFromChoice(text) {
    return StoryRuntimeModule.stripTimeFromChoice(text);
  }

  function formatChoiceTime(totalMinutes) {
    return StoryRuntimeModule.formatChoiceTime(totalMinutes);
  }

  function buildChoiceTextWithTime(text, totalMinutes) {
    return StoryRuntimeModule.buildChoiceTextWithTime(text, totalMinutes);
  }

  function normalizeGeneratedChoiceTimeCost(text, totalMinutes) {
    if (StoryRuntimeModule && typeof StoryRuntimeModule.normalizeChoiceTimeCost === 'function') {
      return StoryRuntimeModule.normalizeChoiceTimeCost(text, totalMinutes);
    }
    return Math.max(0, Math.round(Number(totalMinutes || 0)));
  }

  // Infer default time cost from action keywords
  function inferDefaultTimeCost(text) {
    if (!text) return 5;
    var t = text.toLowerCase();
    if (/移动|前往|去|走到|到达|离开|返回|跑去|走去|赶到/.test(t)) return 10;
    if (/查看|看|观察|检查|搜索|寻找/.test(t)) return 5;
    if (/聊天|交谈|说|问|告诉|打招呼|搭讪/.test(t)) return 10;
    if (/休息|等待|躺|坐|睡|发呆/.test(t)) return 15;
    if (/游泳|跑步|锻炼/.test(t)) return 20;
    return 5;
  }

  function getCurrentGameClock() {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
    var hour = null;
    var minute = null;
    try {
      if (typeof Time !== 'undefined' && Time) {
        if (Time.hour != null) hour = Number(Time.hour);
        if (Time.minute != null) minute = Number(Time.minute);
      }
    } catch (_) {}
    if (!Number.isFinite(hour) && V && V.hour != null) hour = Number(V.hour);
    if (!Number.isFinite(minute) && V && V.minute != null) minute = Number(V.minute);
    if (!Number.isFinite(hour)) hour = 0;
    if (!Number.isFinite(minute)) minute = 0;
    hour = Math.max(0, Math.min(23, Math.floor(hour)));
    minute = Math.max(0, Math.min(59, Math.floor(minute)));
    return {
      hour: hour,
      minute: minute,
      text: String(hour).padStart(2, '0') + ':' + String(minute).padStart(2, '0')
    };
  }

  function _readVisibleGameClockFromDom() {
    try {
      if (typeof $ === 'undefined') return null;
      var selectors = MobileCompatModule.getSidebarTextSelectors ? MobileCompatModule.getSidebarTextSelectors() : '#stats, #ui-bar, #ui-bar-body, #storyCaption, #storyCaptionContent, #sidebardescription';
      var found = null;
      $(selectors).each(function () {
        if (found) return false;
        var text = String($(this).text() || '');
        var match = text.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
        if (match) {
          found = {
            hour: Math.max(0, Math.min(23, parseInt(match[1], 10))),
            minute: Math.max(0, Math.min(59, parseInt(match[2], 10)))
          };
          found.text = String(found.hour).padStart(2, '0') + ':' + String(found.minute).padStart(2, '0');
          return false;
        }
        return true;
      });
      return found;
    } catch (_) {
      return null;
    }
  }

  function refreshGameClockDom() {
    try {
      var clock = getCurrentGameClock();
      var selectors = MobileCompatModule.getSidebarTextSelectors ? MobileCompatModule.getSidebarTextSelectors() : '#stats, #ui-bar, #ui-bar-body, #storyCaption, #storyCaptionContent, #sidebardescription';
      $(selectors).each(function () {
        $(this).contents().add($(this).find('*').contents()).filter(function () {
          return this.nodeType === 3 && /\b\d{1,2}:\d{2}\b/.test(this.textContent || '');
        }).each(function () {
          this.textContent = this.textContent.replace(/\b\d{1,2}:\d{2}\b/g, clock.text);
        });
      });
      try {
        $(document).trigger('AIStoryGen:timeAdvanced', [clock]);
      } catch (_) {}
      return clock;
    } catch (_) {
      return getCurrentGameClock();
    }
  }

  var _aiRefreshingOriginalSidebar = false;
  function refreshOriginalStatsSidebar(reason) {
    if (_aiRefreshingOriginalSidebar) return false;
    try {
      if (typeof Wikifier === 'undefined' || !Wikifier.wikifyEval) return false;
      var refreshPlan = MobileCompat && typeof MobileCompat.getSidebarRefreshPlan === 'function'
        ? MobileCompat.getSidebarRefreshPlan()
        : (MobileCompatModule.getSidebarRefreshPlan ? MobileCompatModule.getSidebarRefreshPlan(document) : null);
      var hasDesktopStats = !!(refreshPlan && refreshPlan.hasDesktopStats);
      var hasMobileStats = !!(refreshPlan && refreshPlan.hasMobileStats);
      if (!refreshPlan || !refreshPlan.canRefresh) return false;
      if (_aiMountController && typeof _aiMountController.mountZone === 'function') {
        _aiMountController.mountZone('wovenrealm-mobile-stats-refresh', {
          mount: function () { return !!(hasDesktopStats || hasMobileStats); }
        });
      }
      _aiRefreshingOriginalSidebar = true;
      if (hasDesktopStats) {
        Wikifier.wikifyEval(refreshPlan.desktopMacro || '<<replace #stats>><<statsCaption>><</replace>>');
      }
      if (hasMobileStats) {
        Wikifier.wikifyEval(refreshPlan.mobileMacro || MobileCompatModule.getMobileStatsRefreshMacro());
      }
      try {
        $(document).trigger('AIStoryGen:originalSidebarRefreshed', [{ reason: reason || 'state' }]);
      } catch (_) {}
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] original sidebar refresh failed:', e); } catch (_) {}
      return false;
    } finally {
      _aiRefreshingOriginalSidebar = false;
    }
  }

  // Advance game time using the game's built-in <<pass>> macro
  function advanceGameTime(minutes) {
    if (!minutes || minutes <= 0) return;
    try {
      // Use game's <<pass N>> macro for correct time advancement
      // This properly updates Time.hour, Time.minute, timeStamp, and all game internals
      var d = document.createElement('span');
      new Wikifier(d, '<<pass ' + Math.round(minutes) + '>>');
      try {
        var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
        if (V && typeof Time !== 'undefined' && Time) {
          if (Number.isFinite(Number(Time.hour))) V.hour = Number(Time.hour);
          if (Number.isFinite(Number(Time.minute))) V.minute = Number(Time.minute);
          if (Number.isFinite(Number(Time.days)) && V.days != null) V.days = Number(Time.days);
        }
      } catch (_) {}

      var refreshResult = _notifyAiTimeChange(minutes, { reason: 'time', delays: [50, 250] });
      var clock = (refreshResult && refreshResult.clock) || getCurrentGameClock();
      // Flash visual indicator
      var $indicator = $('#ai-time-indicator');
      if (!$indicator.length) {
        $indicator = $('<div id="ai-time-indicator" style="position:fixed;top:50px;left:50%;transform:translateX(-50%);background:rgba(100,140,220,0.9);color:#fff;padding:4px 12px;border-radius:4px;font-size:0.85em;z-index:99999;opacity:0;transition:opacity 0.3s;pointer-events:none;"></div>');
        _mountAiPassageNotice($indicator, 'time-indicator', {
          zoneId: 'wovenrealm-runtime-notices',
          mode: 'append',
          getRoot: function () { return $('body'); }
        });
      }
      $indicator.text('⏱ +' + minutes + ' min → ' + clock.text).css('opacity', '1');
      setTimeout(function () { $indicator.css('opacity', '0'); }, 1500);
      console.log('[AIStoryGen] time advanced: +' + minutes + 'min → ' + clock.text);
    } catch (e) {
      console.warn('[AIStoryGen] advanceGameTime error:', e);
    }
  }

  // Parse [LOC: passage_name] or [LOC: 中文名] from AI output
  // Returns true if location was updated
  function _extractAIMetadataLocation(text) {
    return EventParserModule.extractAIMetadataLocation(text);
  }

  function _stripAIMetadataMarkers(text) {
    return EventParserModule.stripAIMetadataMarkers(text);
  }

  function parseLocationMarker(text, transactionPlan) {
    text = String(text || '');
    var eventData = _parseAIEventBlock(text);
    var plannedLocation = transactionPlan && transactionPlan.location ? transactionPlan.location : null;
    var eventStatus = plannedLocation
      ? _normaliseAiEventStatus(plannedLocation.locationStatus || '') || ''
      : _normaliseAiEventStatus(eventData && (eventData.locationStatus || eventData.location_status || eventData.travelStatus || eventData.arrivalStatus || '')) || '';
    var eventLoc = plannedLocation
      ? String(plannedLocation.targetLocation || '')
      : eventData && (eventData.targetLocation || eventData.target_location || eventData.loc || '');
    var isStructuredArrival = plannedLocation
      ? !!plannedLocation.structuredArrival
      : !!(eventLoc && _aiEventIndicatesArrival(eventData) && !/^(none|null|current|same|unknown|无|当前|不变)$/i.test(String(eventLoc)));
    function applyRawLocation(rawValue, tag, structuredArrival) {
      var raw = _normalizePassageName(String(rawValue || '').trim());
      if (!raw) return false;
      var source = structuredArrival ? 'ai-event' : tag;
      var reasonPrefix = structuredArrival ? 'AI_EVENT targetLocation' : 'LOC';
      // Try exact match in available destinations first
      for (var i = 0; i < _aiAvailableDestinations.length; i++) {
        var d = _aiAvailableDestinations[i];
        if (raw === d.raw || raw === d.label) {
          _applyAiLocationCandidate(d.raw, d.label, reasonPrefix + ' available destination', {
            source: structuredArrival ? 'ai-event' : (d.source || 'available'),
            status: eventStatus || 'arrived',
            eventData: eventData,
            sourceText: text,
            structuredArrival: structuredArrival,
            transactionPlan: transactionPlan
          });
          console.log('[AIStoryGen] location moved to: ' + d.label + ' (' + d.raw + ')');
          return true;
        }
      }
      // Try fuzzy match in destinations: raw contains label or vice versa
      for (var i = 0; i < _aiAvailableDestinations.length; i++) {
        var d = _aiAvailableDestinations[i];
        if (raw.indexOf(d.label) !== -1 || d.label.indexOf(raw) !== -1) {
          _applyAiLocationCandidate(d.raw, d.label, reasonPrefix + ' fuzzy destination', {
            source: structuredArrival ? 'ai-event' : (d.source || 'available-fuzzy'),
            status: eventStatus || 'arrived',
            eventData: eventData,
            sourceText: text,
            structuredArrival: structuredArrival,
            transactionPlan: transactionPlan
          });
          console.log('[AIStoryGen] location matched (fuzzy): ' + d.label + ' (' + d.raw + ')');
          return true;
        }
      }
      // Try common locations table (works in both replace and normal mode)
      for (var i = 0; i < _aiCommonLocations.length; i++) {
        var loc = _aiCommonLocations[i];
        if (raw === loc.raw || raw === loc.label) {
          _applyAiLocationCandidate(loc.raw, loc.label, reasonPrefix + ' common location', {
            source: source || 'common',
            status: eventStatus || 'arrived',
            eventData: eventData,
            sourceText: text,
            structuredArrival: structuredArrival,
            transactionPlan: transactionPlan
          });
          console.log('[AIStoryGen] location matched (common): ' + loc.label + ' (' + loc.raw + ')');
          return true;
        }
        for (var j = 0; j < (loc.aliases || []).length; j++) {
          if (raw === loc.aliases[j]) {
            _applyAiLocationCandidate(loc.raw, loc.label, reasonPrefix + ' common alias', {
              source: structuredArrival ? 'ai-event' : 'common-alias',
              status: eventStatus || 'arrived',
              eventData: eventData,
              sourceText: text,
              structuredArrival: structuredArrival,
              transactionPlan: transactionPlan
            });
            console.log('[AIStoryGen] location matched (common alias): ' + loc.label + ' (' + loc.raw + ')');
            return true;
          }
        }
      }
      // Check Story.has as last resort
      if (_nativeStoryHas(raw)) {
        _applyAiLocationCandidate(raw, _resolveLocationLabel(raw), reasonPrefix + ' Story.has', {
          source: structuredArrival ? 'ai-event' : 'story',
          status: eventStatus || 'arrived',
          eventData: eventData,
          sourceText: text,
          structuredArrival: structuredArrival,
          transactionPlan: transactionPlan
        });
        console.log('[AIStoryGen] location moved to: ' + _aiCurrentLocationLabel + ' (via Story.has)');
        return true;
      }
      if (!structuredArrival && _applyGenericStreetLocation(raw, text)) {
        _recordAiTransactionLocationDecision(transactionPlan, {
          source: 'generic-street',
          rawPassage: _aiCurrentLocationPassage || '',
          label: _aiCurrentLocationLabel || '',
          reason: reasonPrefix + ' generic street fallback',
          applied: true,
          fallbackMode: 'generic-street'
        });
        return true;
      }
      _recordAiTransactionLocationDecision(transactionPlan, {
        source: source || tag || '',
        rawPassage: raw,
        label: raw,
        reason: reasonPrefix + ' marker',
        applied: false,
        failureReason: 'not matched'
      });
      console.log('[AIStoryGen] ' + reasonPrefix + ' marker ignored (not matched): ' + raw);
      return false;
    }
    if (isStructuredArrival && applyRawLocation(eventLoc, 'ai-event', true)) {
      return true;
    }
    var metaLoc = _extractAIMetadataLocation(text);
    if (metaLoc) text += '\n[LOC: ' + metaLoc + ']';
    var match = text.match(/\[LOC:\s*([^\]]+)\]/i);
    if (!match) return false;
    return applyRawLocation(match[1], 'common', false);
  }

  // Infer location from user choice + AI narrative text when AI didn't emit [LOC]
  function inferLocationFromText(choiceText, aiText, opts) {
    opts = opts || {};
    // Always try to detect — allow overriding stale location from previous round
    var text = (choiceText || '') + ' ' + (aiText || '');
    if (_inferPriorityLocationFromText(text)) {
      _recordAiTransactionLocationDecision(opts.transactionPlan, {
        source: 'priority-text',
        rawPassage: _aiCurrentLocationPassage || '',
        label: _aiCurrentLocationLabel || '',
        reason: 'priority narrative location',
        applied: true,
        fallbackMode: 'priority-text',
        decision: _aiLastLocationDecision || null
      });
      return true;
    }
    var fallbackTarget = null;
    if (_aiReplaceActive && _aiReplaceTargetPassage) {
      var targetRaw = _normalizePassageName(_aiReplaceTargetPassage || '');
      var targetLabel = cleanLabel(_aiReplaceTargetLabel || '') || _resolveLocationLabel(targetRaw);
      var targetAliases = [];
      for (var ti = 0; ti < _aiCommonLocations.length; ti++) {
        if (_aiCommonLocations[ti].raw === targetRaw || _aiCommonLocations[ti].label === targetLabel) {
          targetAliases = _aiCommonLocations[ti].aliases || [];
          if (!targetLabel) targetLabel = _aiCommonLocations[ti].label;
          break;
        }
      }
      var targetMentioned = (targetRaw && text.indexOf(targetRaw) !== -1) || (targetLabel && text.indexOf(targetLabel) !== -1);
      for (var ta = 0; !targetMentioned && ta < targetAliases.length; ta++) {
        if (targetAliases[ta] && text.indexOf(targetAliases[ta]) !== -1) targetMentioned = true;
      }
      if (targetMentioned) {
        _applyAiLocationCandidate(targetRaw, targetLabel || targetRaw, 'clicked target mention', {
          source: 'clicked-target',
          status: 'arrived',
          sourceText: text,
          transactionPlan: opts.transactionPlan,
          fallbackMode: 'clicked-target'
        });
        console.log('[AIStoryGen] location inferred from clicked target: ' + _aiCurrentLocationLabel + ' (' + _aiCurrentLocationPassage + ')');
        return true;
      }
      if (/(\u5230\u8fbe|\u8fdb\u5165|\u8d70\u8fdb|\u6765\u5230|arrive|enter|reach)/i.test(text)) {
        fallbackTarget = { raw: targetRaw, label: targetLabel || targetRaw };
      }
    }
    for (var i = 0; i < _aiAvailableDestinations.length; i++) {
      var d = _aiAvailableDestinations[i];
      if (text.indexOf(d.label) !== -1 || text.indexOf(d.raw) !== -1) {
        _applyAiLocationCandidate(d.raw, d.label, 'text available destination', {
          source: d.source || 'available',
          status: 'arrived',
          sourceText: text,
          transactionPlan: opts.transactionPlan,
          fallbackMode: 'available-text'
        });
        console.log('[AIStoryGen] location inferred from text: ' + d.label + ' (' + d.raw + ')');
        return true;
      }
      var aliases = d.aliases || [];
      for (var j = 0; j < aliases.length; j++) {
        if (text.indexOf(aliases[j]) !== -1) {
          _applyAiLocationCandidate(d.raw, d.label, 'text available alias', {
            source: d.source || 'available-alias',
            status: 'arrived',
            sourceText: text,
            transactionPlan: opts.transactionPlan,
            fallbackMode: 'available-alias'
          });
          console.log('[AIStoryGen] location inferred (alias): ' + d.label + ' (' + d.raw + ')');
          return true;
        }
      }
    }
    // Also check common locations table (handles normal mode)
    for (var i = 0; i < _aiCommonLocations.length; i++) {
      var loc = _aiCommonLocations[i];
      if (text.indexOf(loc.label) !== -1 || text.indexOf(loc.raw) !== -1) {
        _applyAiLocationCandidate(loc.raw, loc.label, 'text common location', {
          source: 'common',
          status: 'arrived',
          sourceText: text,
          transactionPlan: opts.transactionPlan,
          fallbackMode: 'common-text'
        });
        console.log('[AIStoryGen] location inferred (common): ' + loc.label + ' (' + loc.raw + ')');
        return true;
      }
      for (var j = 0; j < (loc.aliases || []).length; j++) {
        if (text.indexOf(loc.aliases[j]) !== -1) {
          _applyAiLocationCandidate(loc.raw, loc.label, 'text common alias', {
            source: 'common-alias',
            status: 'arrived',
            sourceText: text,
            transactionPlan: opts.transactionPlan,
            fallbackMode: 'common-alias'
          });
          console.log('[AIStoryGen] location inferred (common alias): ' + loc.label + ' (' + loc.raw + ')');
          return true;
        }
      }
    }
    if (_applyGenericStreetLocation('', text)) {
      _recordAiTransactionLocationDecision(opts.transactionPlan, {
        source: 'generic-street',
        rawPassage: _aiCurrentLocationPassage || '',
        label: _aiCurrentLocationLabel || '',
        reason: 'text generic street fallback',
        applied: true,
        fallbackMode: 'generic-street'
      });
      return true;
    }
    if (fallbackTarget && fallbackTarget.raw) {
      _applyAiLocationCandidate(fallbackTarget.raw, fallbackTarget.label, 'fallback target', {
        source: 'fallback-target',
        status: 'arrived',
        sourceText: text,
        transactionPlan: opts.transactionPlan,
        fallbackMode: 'fallback-target'
      });
      console.log('[AIStoryGen] location inferred from fallback target: ' + fallbackTarget.label + ' (' + fallbackTarget.raw + ')');
      return true;
    }
    return false;
  }

  // Collect available destinations from passage links + common locations (shared helper)
  function _pushAvailableDestination(raw, label, loc, source) {
    raw = _normalizePassageName(raw || '');
    if (!raw) return;
    if (_isUnsafeDirectPassage(raw)) return;
    loc = loc || _findCommonLocation(raw);
    var graphLoc = _findGraphLocation(raw);
    label = _resolveLocationDisplay(raw, label || (loc && loc.label) || (graphLoc && graphLoc.label)) || raw;
    var aliases = loc && loc.aliases ? loc.aliases : (graphLoc && graphLoc.aliases ? graphLoc.aliases : []);
    source = source || 'unknown';
    for (var di = 0; di < _aiAvailableDestinations.length; di++) {
      if (_aiAvailableDestinations[di].raw === raw) {
        if (!_aiAvailableDestinations[di].label && label) _aiAvailableDestinations[di].label = label;
        if (!_aiAvailableDestinations[di].aliases && aliases.length) _aiAvailableDestinations[di].aliases = aliases;
        if (!_aiAvailableDestinations[di].source || _aiAvailableDestinations[di].source === 'common' || source === 'page' || source === 'graph') {
          _aiAvailableDestinations[di].source = source;
        }
        return;
      }
    }
    _aiAvailableDestinations.push({
      raw: raw,
      label: label || raw,
      aliases: aliases,
      locId: (loc && loc.locId) || (graphLoc && graphLoc.locId) || '',
      source: source
    });
  }

  function _currentGraphPassage() {
    if (_aiLocationArrived && _aiCurrentLocationPassage) return _normalizePassageName(_aiCurrentLocationPassage);
    if (_aiReplaceActive && _aiReplaceTargetPassage) return _normalizePassageName(_aiReplaceTargetPassage);
    try {
      if (typeof State !== 'undefined' && State.passage) return _normalizePassageName(State.passage);
    } catch (_) {}
    return '';
  }

  function _pushGraphExitsFor(raw) {
    var graphLoc = _findGraphLocation(raw);
    if (!graphLoc || !graphLoc.exits || !graphLoc.exits.length) return 0;
    var count = 0;
    for (var i = 0; i < graphLoc.exits.length; i++) {
      var e = graphLoc.exits[i];
      if (!e || !e.passage) continue;
      if (_isUnsafeDirectPassage(e.passage)) continue;
      _pushAvailableDestination(e.passage, e.label || e.passage, null, 'graph');
      count++;
    }
    return count;
  }

  function _collectDestinations($passage) {
    _aiAvailableDestinations = [];
    $passage.find('a[data-passage], .link-internal[data-passage]').each(function () {
      var $a = $(this);
      var raw = _normalizePassageName(($a.attr('data-passage') || '').trim());
      var label = cleanLabel($a.text());
      if (raw && label && !_isGameMenuPassage(raw) && raw.indexOf('AIStoryGen_') !== 0) {
        _pushAvailableDestination(raw, label, null, 'page');
      }
    });
    _pushGraphExitsFor(_currentGraphPassage());
    // Merge common locations (filtered by Story.has existence)
    for (var ci = 0; ci < _aiCommonLocations.length; ci++) {
      var loc = _aiCommonLocations[ci];
      if (loc.isLocation === false) continue;
      try {
        if (_nativeStoryHas(loc.raw)) {
          _pushAvailableDestination(loc.raw, loc.label, loc, 'common');
        }
      } catch (_) {}
    }
  }

  // Build a block listing known places to the AI for LOC instruction
  function buildKnownPlacesBlock(opts) {
    opts = opts || {};
    var lines = [];
    var seen = {};
    var required = Array.isArray(opts.required) ? opts.required : [];
    var includeCommon = opts.includeCommon === true;
    var currentRaw = _currentGraphPassage();
    var currentNode = _findGraphLocation(currentRaw);
    if (currentNode) {
      lines.push('<current_map>');
      lines.push('current: ' + (currentNode.label || currentNode.passage || currentRaw) + ' -> [LOC: ' + (currentNode.passage || currentRaw) + ']' + (currentNode.locId ? ' (location: ' + currentNode.locId + ')' : ''));
      if (currentNode.exits && currentNode.exits.length) {
        lines.push('adjacent_places:');
        for (var gi = 0; gi < currentNode.exits.length && gi < 12; gi++) {
          var ge = currentNode.exits[gi];
          if (!ge || !ge.passage) continue;
          lines.push('  - ' + (ge.label || ge.passage) + ' -> [LOC: ' + ge.passage + ']' + (ge.via && ge.via.length ? ' via ' + ge.via.join(' / ') : ''));
          seen[ge.passage] = true;
        }
      }
      lines.push('</current_map>');
    }
    lines.push('<known_places>');
    for (var ri = 0; ri < required.length; ri++) {
      var req = required[ri] || {};
      var reqRaw = _normalizePassageName(String(req.raw || req.passage || '').trim());
      if (!reqRaw || seen[reqRaw]) continue;
      var reqNode = _findGraphLocation(reqRaw);
      var reqLabel = cleanLabel(req.label || (reqNode && reqNode.label) || reqRaw);
      var reqLocId = req.locId || (reqNode && reqNode.locId) || '';
      seen[reqRaw] = true;
      lines.push('  ' + reqLabel + ' -> [LOC: ' + reqRaw + ']' + (reqLocId ? ' (location: ' + reqLocId + ')' : ''));
    }
    // Add captured destinations from the current native page.
    for (var i = 0; i < _aiAvailableDestinations.length && i < 12; i++) {
      var d = _aiAvailableDestinations[i];
      if (!d.raw || seen[d.raw]) continue;
      seen[d.raw] = true;
      lines.push('  ' + d.label + ' -> [LOC: ' + d.raw + ']' + (d.locId ? ' (location: ' + d.locId + ')' : ''));
    }
    if (includeCommon) {
      for (var ci = 0; ci < _aiCommonLocations.length && ci < 24; ci++) {
        var loc = _aiCommonLocations[ci];
        if (loc.isLocation === false) continue;
        var ok = false;
        try { if (_nativeStoryHas(loc.raw)) ok = true; } catch (_) {}
        if (ok && !seen[loc.raw]) {
          seen[loc.raw] = true;
          lines.push('  ' + loc.label + ' -> [LOC: ' + loc.raw + ']' + (loc.locId ? ' (location: ' + loc.locId + ')' : ''));
        }
      }
    }
    lines.push('</known_places>');
    return lines.join('\n');
  }

  function buildKnownNpcNamesBlock(query) {
    var list = _getAiNpcNameList();
    var map = _getRuntimeChineseNameMap();
    var queryText = String(query || '').toLowerCase();
    var lines = [];
    var seen = {};
    for (var i = 0; i < list.length; i++) {
      var key = String(list[i] || '').trim();
      if (!key || seen[key]) continue;
      var zh = map[key] || map[key.replace(/\s+/g, '')] || '';
      if (!zh || zh === key || !_hasChineseText(zh)) continue;
      if (!queryText || (queryText.indexOf(key.toLowerCase()) < 0 && queryText.indexOf(String(zh).toLowerCase()) < 0)) continue;
      seen[key] = true;
      lines.push('  ' + key + ' = ' + zh);
      if (lines.length >= 16) break;
    }
    if (!lines.length) return '';
    return [
      '<npc_name_aliases>',
      'Use these canonical Chinese NPC names exactly. Do not invent alternate translations.',
      lines.join('\n'),
      '</npc_name_aliases>'
    ].join('\n');
  }

  function buildLocationResponseFormatBlock(defaultPassage) {
    var fallback = defaultPassage || (_aiReplaceActive ? _aiReplaceTargetPassage : '') || 'current';
    return PromptBuilderModule.buildLocationResponseFormatBlock(fallback);
  }

  function buildAIEventResponseFormatBlock() {
    var cfg;
    try { cfg = loadCfg(); } catch (_) { cfg = DEFAULT_CFG || {}; }
    var relationChance = Math.max(0, Math.min(100, Number(cfg.npcRelationChangeChance == null ? DEFAULT_CFG.npcRelationChangeChance : cfg.npcRelationChangeChance) || 0));
    var relationLimits = _getAiNpcRelationFieldLimits(cfg);
    var relationLimit = _hasAnyAiNpcRelationFieldLimit(relationLimits)
      ? Math.max(relationLimits.love || 0, relationLimits.trust || 0, relationLimits.lust || 0, relationLimits.rage || 0, relationLimits.dom || 0)
      : 0;
    return PromptBuilderModule.buildAIEventResponseFormatBlock({
      nonMoneyStatAllowlist: _formatAiRuntimeNonMoneyStatAllowlist(),
      statFieldLimitText: _formatAiStatFieldLimitText(cfg),
      relationChance: relationChance,
      relationLimit: relationLimit,
      relationFieldLimits: relationLimits,
      relationFieldLimitText: _formatAiNpcRelationFieldLimitText(cfg),
      includeSexTargets: _isIntimateAddonLoaded()
    });
  }

  // Show dynamic "end exploration" button that follows AI's current location
  function ensureStandaloneSexModeButton() {
    OptionalAddonBridge.clearStandalone();
  }

  function _isNativeCombatActive() {
    try {
      var V = getV();
      return !!(V && safeRead(function () { return V.combat; }, 0) === 1);
    } catch (e) {
      return false;
    }
  }

  function _isAISexModeEnabled(cfg) {
    if (!_isIntimateAddonLoaded()) return false;
    // Public Woven Realm no longer owns intimate entry rendering. When the
    // optional addon is loaded, AIStoryGenIntimateAddon injects its own entry,
    // settings tab, and native bridge. Keep this legacy path disabled so the
    // public script cannot create duplicate "enter/custom" buttons.
    return false;
  }

  function _getIntimateAddonApi() {
    return OptionalAddonBridge.getApi();
  }

  function _clearAISexModeUi() {
    return OptionalAddonBridge.clearLegacyUi('clear sex mode ui');
  }

  function _isNativeCombatFinishPassage(name) {
    name = String(name || (typeof State !== 'undefined' ? State.passage : '') || '').trim();
    if (!name) return false;
    if (/\b(?:Fight|Combat|Tentacles?)\b.*\bFinish\b/i.test(name)) return true;
    if (/^(?:Forest Tentacles Finish|Wolf Cave Fight(?: Duo)? Finish)$/i.test(name)) return true;
    return false;
  }

  function _isNativeSexOrCombatPassage(name) {
    if (_isNativeCombatActive()) return true;
    name = String(name || (typeof State !== 'undefined' ? State.passage : '') || '').trim();
    if (!name) return false;
    if (_isNativeCombatFinishPassage(name)) return true;
    if (/^(?:Beast Sex|Beast Rape|Tentacle Sex|Street Tentacle Sex|Farm Alex Sex|Bed .* Sex|Combat|Start Combat|End Combat)$/i.test(name)) return true;
    if (/(?:\bSex\b|\bRape\b|\bCombat\b)/i.test(name) && !/^Sex Shop$/i.test(name)) return true;
    return false;
  }

  function _dedupeSexModeButtons() {
    _clearAISexModeUi();
  }

  // Sync the underlying game passage to match AI's current location
  function syncOriginalPassageToCurrentLocation() {
    if (!_aiReplaceActive || !_aiLocationArrived) return;
    var targetPassage = _normalizePassageName(_aiCurrentLocationPassage);
    if (!targetPassage) return;
    var syncEngine = _getNativeEngine();
    if (!syncEngine || !syncEngine.play) return;

    console.log('[AIStoryGen] syncing origin passage → ' + targetPassage);
    try {
      // Save current AI overlay DOM before switching
      var $aiWrap = $('#passages .passage .ai-replaced-content');
      var aiHTML = $aiWrap.length ? $aiWrap.html() : '';
      var $choicesPanels = $('#passages .ai-choices, #passages .ai-choices-end').detach();

      // Set resync flag so :passagedisplay hook knows to re-overlay
      _aiResyncTarget = targetPassage;
      _aiResyncAIHTML = aiHTML;
      if (_isUnsafeDirectPassage(targetPassage)) {
        _warnUnsafeDirectPassage(targetPassage);
        return;
      }
      if (_triggerOriginalLinkToPassage(targetPassage, 'sync original passage')) return;
      syncEngine.play(targetPassage);
    } catch (e) {
      console.warn('[AIStoryGen] sync failed', e);
    }
  }
  var _aiResyncTarget = '';
  var _aiResyncAIHTML = '';

  // -- AI navigation history: persist AI replace state across backward/forward --
  // _aiNavHistory: passage-level save for cross-passage restore
  // _aiRoundHistory: AI-internal backward stack (each entry = one AI narrative round)
  // _aiForwardStack: AI-internal forward stack
  var _aiNavHistory = {};
  var _aiRoundHistory = [];
  var _aiForwardStack = [];
  var _aiRoundHistoryPrePushedForAdvance = false;
  var _aiNativeHandoffArchive = null;
  var _pendingAISaveState = null;
  var _suppressAISaveRestoreUntil = 0;

  function _isAISaveRestoreSuppressed() {
    var now = Date.now();
    if (_suppressAISaveRestoreUntil && now < _suppressAISaveRestoreUntil) return true;
    try {
      var sessionUntil = Number(sessionStorage.getItem('AIStoryGenSuppressRestoreUntil') || 0);
      if (sessionUntil && now < sessionUntil) return true;
      if (sessionUntil) sessionStorage.removeItem('AIStoryGenSuppressRestoreUntil');
    } catch (_) {}
    try {
      var V = _getStateVariables();
      var stateUntil = Number(V && V.aiStoryGenSuppressRestoreUntil || 0);
      if (stateUntil && now < stateUntil) return true;
      if (stateUntil && V) delete V.aiStoryGenSuppressRestoreUntil;
    } catch (_) {}
    return false;
  }

  function _clearAISaveNavigationState(reason, opts) {
    opts = opts || {};
    _pendingAISaveState = null;
    _aiNavHistory = {};
    _aiResyncTarget = '';
    _aiResyncAIHTML = '';
    if (!opts.preserveRoundHistory) _clearAiRoundHistory();
    _markAISaveRestoreSuppressed(2500);

    function clearVars(vars) {
      if (!vars || typeof vars !== 'object') return;
      delete vars.aiStoryGenNavState;
      delete vars.aiStoryGenSaveTitle;
      _patchAIStoryGenStateField(vars, 'scene', null);
      vars.aiStoryGenSuppressRestoreUntil = _suppressAISaveRestoreUntil;
    }

    try { clearVars(_getStateVariables()); } catch (_) {}
    try { if (typeof State !== 'undefined' && State.active && State.active.variables) clearVars(State.active.variables); } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State.history) && State.activeIndex != null && State.history[State.activeIndex] && State.history[State.activeIndex].variables) {
        clearVars(State.history[State.activeIndex].variables);
      }
    } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State._history) && State.activeIndex != null && State._history[State.activeIndex] && State._history[State.activeIndex].variables) {
        clearVars(State._history[State.activeIndex].variables);
      }
    } catch (_) {}
      try { console.log('[AIStoryGen] cleared AI navigation save state: ' + (reason || 'exit AI')); } catch (_) {}
  }

  function _restoreOriginalFromNormalAIOverlay(reason) {
    try {
      var $passage = $('#passages .passage');
      if (!$passage.length) return false;
      var changed = false;
      if (_aiNarrativeWrap && _aiNarrativeWrap.parentNode) {
        _aiNarrativeWrap.parentNode.removeChild(_aiNarrativeWrap);
        changed = true;
      }
      _aiNarrativeWrap = null;
      var $origWrap = $passage.find('.ai-original-wrap');
      if ($origWrap.length) {
        $origWrap.replaceWith($origWrap.contents());
        changed = true;
      }
      if (changed) {
        _suppressAutoChoices(reason || 'restore original page', 5000);
        $('#passages .ai-choices, #passages .ai-choices-end').remove();
        $passage.find('.ai-injected-row, .ai-injected-link').remove();
        _clearAiRoundHistory();
        _clearAISaveNavigationState(reason || 'restore original page');
        setTimeout(function () { injectAILinkClones(); }, 50);
      }
      return changed;
    } catch (e) {
      try { console.warn('[AIStoryGen] restore original from normal AI overlay failed', e); } catch (_) {}
      return false;
    }
  }

  function _markAISaveRestoreSuppressed(ms) {
    _suppressAISaveRestoreUntil = Date.now() + (ms || 2500);
    try { sessionStorage.setItem('AIStoryGenSuppressRestoreUntil', String(_suppressAISaveRestoreUntil)); } catch (_) {}
    try { console.log('[AIStoryGen] suppress restore until ' + _suppressAISaveRestoreUntil); } catch (_) {}
  }

  var _aiSnapshotKeys = [
    'timeStamp', 'hour', 'minute', 'days', 'day', 'weekday', 'month', 'year',
    'arousal', 'stress', 'pain', 'trauma', 'awareness', 'lewdity',
    'tiredness', 'fatigue', 'control', 'drunk', 'drugged', 'hallucinogen',
    'money', 'purity', 'beauty', 'charm', 'lust',
    'aiStoryGenItems',
    'aiStoryGenMemory', 'aiStoryGenMemoryId', 'aiStoryGenEventLog',
    'skulduggery', 'danceskill', 'swimmingskill', 'athletics', 'tending', 'housekeeping',
    'seductionskill', 'oralskill', 'vaginalskill', 'analskill', 'handskill', 'feetskill',
    'penileskill', 'chestskill', 'thighskill', 'bottomskill',
    'science', 'maths', 'english', 'history'
  ];

  function _cloneForAiSnapshot(value) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (_) {
      return value;
    }
  }

  function _captureGameSnapshot() {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    if (!V) return null;
    var snap = {};
    _aiSnapshotKeys.forEach(function (key) {
      if (V[key] !== undefined) snap[key] = _cloneForAiSnapshot(V[key]);
    });
    _captureGameTimeRuntimeSnapshot(snap, V);
    snap.__aiNpcRelations = _captureAiNpcRelationSnapshot();
    return RoundSnapshotModule.sanitizeGameSnapshot(snap, _aiSnapshotKeys);
  }

  function _captureGameTimeRuntimeSnapshot(snap, V) {
    if (!snap || !V) return;
    try {
      var visibleClock = _readVisibleGameClockFromDom();
      if (visibleClock) {
        snap.hour = Number(visibleClock.hour);
        snap.minute = Number(visibleClock.minute);
      } else if (typeof Time !== 'undefined' && Time) {
        if (Number.isFinite(Number(Time.hour))) snap.hour = Number(Time.hour);
        if (Number.isFinite(Number(Time.minute))) snap.minute = Number(Time.minute);
      }
      if (typeof Time !== 'undefined' && Time && Number.isFinite(Number(Time.days))) snap.days = Number(Time.days);
      if (Number.isFinite(Number(snap.hour))) V.hour = Number(snap.hour);
      if (Number.isFinite(Number(snap.minute))) V.minute = Number(snap.minute);
      if (Number.isFinite(Number(snap.days))) V.days = Number(snap.days);
    } catch (_) {}
  }

  function _captureAiNpcRelationSnapshot() {
    var schema = _getAiNpcRelationSchema();
    var fields = Object.keys(schema);
    var root = _getAiNpcRoot();
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
    var snap = {};
    _getAiNpcNameList().forEach(function (name) {
      var row = {};
      var hasAny = false;
      var cNpc = root && root[name];
      var vNpc = V && V[name];
      fields.forEach(function (field) {
        row[field] = {};
        if (cNpc && cNpc[field] !== undefined) {
          row[field].c = _cloneForAiSnapshot(cNpc[field]);
          hasAny = true;
        }
        if (vNpc && vNpc[field] !== undefined) {
          row[field].v = _cloneForAiSnapshot(vNpc[field]);
          hasAny = true;
        }
      });
      if (hasAny) snap[name] = row;
    });
    return snap;
  }

  function _restoreAiNpcRelationSnapshot(snap) {
    if (!snap || typeof snap !== 'object') return;
    var root = _getAiNpcRoot();
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
    Object.keys(snap).forEach(function (name) {
      var row = snap[name] || {};
      Object.keys(row).forEach(function (field) {
        var value = row[field] || {};
        if (root && root[name] && Object.prototype.hasOwnProperty.call(value, 'c')) root[name][field] = _cloneForAiSnapshot(value.c);
        if (V && V[name] && Object.prototype.hasOwnProperty.call(value, 'v')) V[name][field] = _cloneForAiSnapshot(value.v);
      });
    });
  }

  function _refreshGameVisualState(reason) {
    var clock = null;
    try {
      var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
      refreshOriginalStatsSidebar(reason || 'state');
      clock = refreshGameClockDom();
      if (V && V.money != null) {
        var moneyStr = _aiFormatMoneyPence(V.money);
        $('#stats, #ui-bar, #ui-bar-body, #storyCaption, #storyCaptionContent, #sidebardescription').each(function () {
          $(this).contents().add($(this).find('*').contents()).filter(function () {
            return this.nodeType === 3 && /£\s*[\d,]+(?:\.\d+)?/.test(this.textContent);
          }).each(function () {
            this.textContent = this.textContent.replace(/£\s*[\d,]+(?:\.\d+)?/g, moneyStr);
          });
        });
        var statsEl = document.getElementById('stats');
        if (statsEl && /£\s*[\d,]+(?:\.\d+)?/.test(statsEl.textContent || '')) {
          statsEl.childNodes.forEach(function (node) {
            if (node.nodeType === 3 && /£\s*[\d,]+(?:\.\d+)?/.test(node.textContent)) {
              node.textContent = node.textContent.replace(/£\s*[\d,]+(?:\.\d+)?/, moneyStr);
            }
          });
        }
      }
    } catch (_) {}
    try {
      var captionIds = ['paincaption','arousalcaption','tirednesscaption','stresscaption','traumacaption','controlcaption','allurecaption','druggedcaption'];
      captionIds.forEach(function (cid) {
        var el = document.getElementById(cid);
        if (el && typeof Wikifier !== 'undefined') {
          try {
            var tmp = document.createElement('span');
            new Wikifier(tmp, '<<' + cid + '>>');
            el.innerHTML = tmp.innerHTML;
          } catch (_) {}
        }
      });
    } catch (_) {}
    try {
      if (typeof window.Dynamic !== 'undefined' && window.Dynamic.render) window.Dynamic.render();
    } catch (_) {}
    try {
      if (typeof State !== 'undefined' && State.temporary) State.temporary.forcerender = true;
    } catch (_) {}
    try {
      $(document).trigger('AIStoryGen:sidebarRefreshed', [{ reason: reason || 'state', clock: clock || getCurrentGameClock() }]);
    } catch (_) {}
    return clock || getCurrentGameClock();
  }

  var _aiRuntimeEvents = RuntimeEventsModule.create();
  window.AIStoryGen.runtimeEvents = _aiRuntimeEvents;
  window.AIStoryGen.RuntimeEvents = _aiRuntimeEvents;

  var _aiRuntimeChangeObserver = RuntimeChangeObserverModule.create({
    runtimeEvents: _aiRuntimeEvents,
    getClock: getCurrentGameClock,
    refreshVisualState: _refreshGameVisualState,
    warn: function (message, error) {
      try { console.warn(message, error); } catch (_) {}
    },
    getStateValues: function () {
      var V = getV();
      var keys = [
        'arousal', 'stress', 'pain', 'trauma', 'tiredness', 'control',
        'seductionskill', 'money', 'hour', 'minute', 'days'
      ];
      var values = {};
      if (V) {
        keys.forEach(function (key) {
          if (Object.prototype.hasOwnProperty.call(V, key)) values[key] = _cloneForAiSnapshot(V[key]);
        });
      }
      return values;
    },
    getStatLimits: function () {
      return _getAiStatFieldLimits(loadCfg());
    },
    getSidebarSnapshot: function () {
      var sidebar = {};
      try {
        var snap = MobileCompat && typeof MobileCompat.getSidebarSnapshot === 'function'
          ? MobileCompat.getSidebarSnapshot()
          : (MobileCompatModule.getSidebarSnapshot ? MobileCompatModule.getSidebarSnapshot(document) : {});
        sidebar.desktopText = _cleanAIReportText(snap.desktopText || '', 800);
        sidebar.mobileText = _cleanAIReportText(snap.mobileText || '', 800);
        sidebar.hasDesktopStats = !!snap.hasDesktopStats;
        sidebar.hasMobileStats = !!snap.hasMobileStats;
        sidebar.hasUiBar = !!snap.hasUiBar;
      } catch (_) {}
      return sidebar;
    }
  });

  function _notifyAiRuntimeChange(reason, opts) {
    if (_aiRuntimeChangeObserver && typeof _aiRuntimeChangeObserver.notifyChange === 'function') {
      return _aiRuntimeChangeObserver.notifyChange(reason, opts || {});
    }
    return { clock: _refreshGameVisualState(reason) };
  }

  function _notifyAiTimeChange(minutes, opts) {
    if (_aiRuntimeChangeObserver && typeof _aiRuntimeChangeObserver.notifyTimeChange === 'function') {
      return _aiRuntimeChangeObserver.notifyTimeChange(minutes, opts || {});
    }
    return _notifyAiRuntimeChange((opts && opts.reason) || 'time', opts);
  }

  function _notifyAiStatsApplied(changed, transactionPlan, opts) {
    if (_aiRuntimeChangeObserver && typeof _aiRuntimeChangeObserver.notifyStatsApplied === 'function') {
      return _aiRuntimeChangeObserver.notifyStatsApplied(changed, transactionPlan, opts || {});
    }
    return _notifyAiRuntimeChange((opts && opts.reason) || 'stats', opts);
  }

  function _recordAiRuntimeCheckpoint(type, detail) {
    try {
      if (_aiRuntimeChangeObserver && typeof _aiRuntimeChangeObserver.recordCheckpoint === 'function') {
        return _aiRuntimeChangeObserver.recordCheckpoint(type, detail || {});
      }
    } catch (_) {}
    return null;
  }

  function _restoreGameSnapshot(snap) {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    if (!V || !snap) return;
    Object.keys(snap).forEach(function (key) {
      if (key === '__aiNpcRelations') return;
      V[key] = _cloneForAiSnapshot(snap[key]);
    });
    _restoreGameTimeRuntimeSnapshot(snap, V);
    _restoreAiNpcRelationSnapshot(snap.__aiNpcRelations);
    try { $('#ai-time-indicator').remove(); } catch (_) {}
    try {
      if (Object.prototype.hasOwnProperty.call(snap, 'aiStoryGenItems')) {
        _persistAiItemStore();
        _renderAiItemsInLog();
      }
    } catch (_) {}
    _refreshGameVisualState();
    console.log('[AIStoryGen] restored game snapshot for AI round');
  }

  function _restoreGameTimeRuntimeSnapshot(snap, V) {
    if (!snap || typeof snap !== 'object') return;
    try {
      if (typeof Time !== 'undefined' && Time) {
        if (Object.prototype.hasOwnProperty.call(snap, 'timeStamp') && Number.isFinite(Number(snap.timeStamp)) && typeof Time.set === 'function') {
          Time.set(Number(snap.timeStamp));
        } else if (Object.prototype.hasOwnProperty.call(snap, 'hour') && Object.prototype.hasOwnProperty.call(snap, 'minute') && typeof Time.setTime === 'function') {
          Time.setTime(Number(snap.hour), Number(snap.minute));
        }
      }
    } catch (_) {}
    try {
      if (V && Object.prototype.hasOwnProperty.call(snap, 'timeStamp') && Number.isFinite(Number(snap.timeStamp))) V.timeStamp = Number(snap.timeStamp);
      if (V && typeof Time !== 'undefined' && Time) {
        if (Number.isFinite(Number(Time.hour))) V.hour = Number(Time.hour);
        if (Number.isFinite(Number(Time.minute))) V.minute = Number(Time.minute);
        if (Number.isFinite(Number(Time.days))) V.days = Number(Time.days);
      } else if (V) {
        if (Object.prototype.hasOwnProperty.call(snap, 'hour') && Number.isFinite(Number(snap.hour))) V.hour = Number(snap.hour);
        if (Object.prototype.hasOwnProperty.call(snap, 'minute') && Number.isFinite(Number(snap.minute))) V.minute = Number(snap.minute);
        if (Object.prototype.hasOwnProperty.call(snap, 'days') && Number.isFinite(Number(snap.days))) V.days = Number(snap.days);
      }
    } catch (_) {}
  }

  function _captureAiLocationRuntimeState() {
    return {
      currentLocationLabel: _aiCurrentLocationLabel || '',
      currentLocationPassage: _aiCurrentLocationPassage || '',
      locationArrived: !!_aiLocationArrived,
      availableDestinations: _cloneForAiSnapshot(_aiAvailableDestinations || []),
      lastLocationDecision: _cloneForAiSnapshot(_aiLastLocationDecision || null),
      replaceTargetLabel: _aiReplaceTargetLabel || '',
      replaceTargetPassage: _aiReplaceTargetPassage || '',
      replaceOriginalLinkId: _aiReplaceOriginalLinkId || '',
      replaceOriginalEventMode: !!_aiReplaceOriginalEventMode,
      lastChoiceText: _lastChoiceText || ''
    };
  }

  function _restoreAiLocationRuntimeState(loc) {
    loc = loc || {};
    _aiCurrentLocationLabel = String(loc.currentLocationLabel || '');
    _aiCurrentLocationPassage = _normalizePassageName(loc.currentLocationPassage || '');
    _aiLocationArrived = !!loc.locationArrived;
    _aiAvailableDestinations = _cloneForAiSnapshot(loc.availableDestinations || []);
    _aiLastLocationDecision = _cloneForAiSnapshot(loc.lastLocationDecision || null);
    _aiReplaceTargetLabel = String(loc.replaceTargetLabel || '');
    _aiReplaceTargetPassage = _normalizePassageName(loc.replaceTargetPassage || '');
    _aiReplaceOriginalLinkId = String(loc.replaceOriginalLinkId || '');
    _aiReplaceOriginalEventMode = !!loc.replaceOriginalEventMode;
    _lastChoiceText = String(loc.lastChoiceText || '');
  }

  function _captureAIRuntimeSnapshot() {
    return {
      game: _captureGameSnapshot(),
      memory: _snapshotMemoryForSave(),
      pickupCandidates: _cloneForAiSnapshot(_aiPickupCandidates || {}),
      pendingItemUses: _cloneForAiSnapshot(_pendingAiItemUses || []),
      intimateScene: null,
      location: _captureAiLocationRuntimeState()
    };
  }

  function _restoreAIRuntimeSnapshot(snap, opts) {
    opts = opts || {};
    if (!snap) return;
    try { _restoreGameSnapshot(snap.game); } catch (_) {}
    try { _replaceMemoryFromSave(snap.memory || {}); } catch (_) {}
    try { _aiPickupCandidates = _cloneForAiSnapshot(snap.pickupCandidates || {}); } catch (_) {}
    try { _pendingAiItemUses = _cloneForAiSnapshot(snap.pendingItemUses || []); } catch (_) {}
    try { _restoreAiLocationRuntimeState(snap.location || {}); } catch (_) {}
    if (opts.syncMemory) {
      try { _syncMemoryToCurrentSave('transaction-rollback'); } catch (_) {}
    }
  }

  function _restoreAiRoundStackSnapshot(history, forward) {
    try {
      _aiRoundHistory.length = 0;
      (Array.isArray(history) ? history : []).forEach(function (entry) {
        var cloned = _cloneAiRoundEntryForSave(entry);
        if (cloned) _aiRoundHistory.push(cloned);
      });
      _aiForwardStack.length = 0;
      (Array.isArray(forward) ? forward : []).forEach(function (entry) {
        var cloned = _cloneAiRoundEntryForSave(entry);
        if (cloned) _aiForwardStack.push(cloned);
      });
    } catch (_) {}
  }

  function _captureAiLifecycleTransientState() {
    return {
      replaceActive: !!_aiReplaceActive,
      replaceRoundCount: Number(_aiReplaceRoundCount || 0),
      replaceTargetLabel: String(_aiReplaceTargetLabel || ''),
      replaceTargetPassage: String(_aiReplaceTargetPassage || ''),
      replaceOriginPassage: String(_aiReplaceOriginPassage || ''),
      replaceSessionHTML: String(_aiReplaceSessionHTML || ''),
      replaceOriginalLinkId: String(_aiReplaceOriginalLinkId || ''),
      replaceOriginalEventMode: !!_aiReplaceOriginalEventMode,
      resyncTarget: String(_aiResyncTarget || ''),
      resyncAIHTML: String(_aiResyncAIHTML || ''),
      navHistory: _cloneForAiSnapshot(_aiNavHistory || {}),
      roundHistory: _cloneAiRoundStackForSave(_aiRoundHistory),
      forwardStack: _cloneAiRoundStackForSave(_aiForwardStack),
      roundHistoryPrePushedForAdvance: !!_aiRoundHistoryPrePushedForAdvance,
      nativeHandoffArchive: _cloneForAiSnapshot(_aiNativeHandoffArchive || null),
      pendingSaveState: _normaliseAISavedScene(_pendingAISaveState),
      currentLocationLabel: String(_aiCurrentLocationLabel || ''),
      currentLocationPassage: String(_aiCurrentLocationPassage || ''),
      locationArrived: !!_aiLocationArrived,
      availableDestinations: _cloneForAiSnapshot(_aiAvailableDestinations || []),
      lastLocationDecision: _cloneForAiSnapshot(_aiLastLocationDecision || null),
      lastChoiceText: String(_lastChoiceText || ''),
      lastNarrativePrompt: String(_lastNarrativePrompt || ''),
      lastChoicesData: _cloneForAiSnapshot(_lastChoicesData || null),
      narrativeWrap: _aiNarrativeWrap
    };
  }

  function _restoreAiLifecycleTransientState(snap) {
    if (!snap || typeof snap !== 'object') return false;
    _releaseAutoChoicesBusy('restore lifecycle transient state');
    _aiReplaceActive = !!snap.replaceActive;
    _aiReplaceRoundCount = Number(snap.replaceRoundCount || 0);
    _aiReplaceTargetLabel = String(snap.replaceTargetLabel || '');
    _aiReplaceTargetPassage = _normalizePassageName(snap.replaceTargetPassage || '');
    _aiReplaceOriginPassage = String(snap.replaceOriginPassage || '');
    _aiReplaceSessionHTML = String(snap.replaceSessionHTML || '');
    _aiReplaceOriginalLinkId = String(snap.replaceOriginalLinkId || '');
    _aiReplaceOriginalEventMode = !!snap.replaceOriginalEventMode;
    _aiResyncTarget = String(snap.resyncTarget || '');
    _aiResyncAIHTML = String(snap.resyncAIHTML || '');
    _aiNavHistory = _cloneForAiSnapshot(snap.navHistory || {});
    _restoreAiRoundStackSnapshot(snap.roundHistory || [], snap.forwardStack || []);
    _aiRoundHistoryPrePushedForAdvance = !!snap.roundHistoryPrePushedForAdvance;
    _aiNativeHandoffArchive = _cloneForAiSnapshot(snap.nativeHandoffArchive || null);
    _pendingAISaveState = _normaliseAISavedScene(snap.pendingSaveState);
    _aiCurrentLocationLabel = String(snap.currentLocationLabel || '');
    _aiCurrentLocationPassage = _normalizePassageName(snap.currentLocationPassage || '');
    _aiLocationArrived = !!snap.locationArrived;
    _aiAvailableDestinations = _cloneForAiSnapshot(snap.availableDestinations || []);
    _aiLastLocationDecision = _cloneForAiSnapshot(snap.lastLocationDecision || null);
    _lastChoiceText = String(snap.lastChoiceText || '');
    _lastNarrativePrompt = String(snap.lastNarrativePrompt || '');
    _lastChoicesData = _cloneForAiSnapshot(snap.lastChoicesData || null);
    _aiNarrativeWrap = snap.narrativeWrap && snap.narrativeWrap.parentNode
      ? snap.narrativeWrap
      : ($('#passages .passage .ai-narrative-wrap').get(0) || null);
    return true;
  }

  function _resetAiLifecycleTransientState(reason) {
    _releaseAutoChoicesBusy(reason || 'reset lifecycle transient state');
    _aiReplaceActive = false;
    _aiReplaceRoundCount = 0;
    _aiReplaceTargetLabel = '';
    _aiReplaceTargetPassage = '';
    _aiReplaceOriginPassage = '';
    _aiReplaceSessionHTML = '';
    _aiReplaceOriginalLinkId = '';
    _aiReplaceOriginalEventMode = false;
    _aiResyncTarget = '';
    _aiResyncAIHTML = '';
    _aiNavHistory = {};
    _aiRoundHistory.length = 0;
    _aiForwardStack.length = 0;
    _aiRoundHistoryPrePushedForAdvance = false;
    _aiNativeHandoffArchive = null;
    _pendingAISaveState = null;
    _aiCurrentLocationLabel = '';
    _aiCurrentLocationPassage = '';
    _aiLocationArrived = false;
    _aiAvailableDestinations = [];
    _aiLastLocationDecision = null;
    _lastChoiceText = '';
    _lastNarrativePrompt = '';
    _lastChoicesData = null;
    _aiNarrativeWrap = null;
  }

  function _createAiRoundActionToken(opts) {
    opts = opts || {};
    return {
      runtimeSnapshot: _captureAIRuntimeSnapshot(),
      roundHistory: _cloneAiRoundStackForSave(_aiRoundHistory),
      forwardStack: _cloneAiRoundStackForSave(_aiForwardStack),
      choices: Array.isArray(opts.choices) ? _cloneForAiSnapshot(opts.choices) : _captureCurrentAiRoundChoices(),
      prepared: false,
      committed: false,
      rolledBack: false
    };
  }

  function _prepareAiRoundAction(token, opts) {
    opts = opts || {};
    if (!token || token.committed || token.rolledBack || token.prepared) return false;
    _aiRoundHistoryPrePushedForAdvance = _pushCurrentToAiRoundHistory({
      gameSnapshot: token.runtimeSnapshot && token.runtimeSnapshot.game,
      pickupCandidates: token.runtimeSnapshot && token.runtimeSnapshot.pickupCandidates,
      choices: token.choices
    });
    _aiForwardStack.length = 0;
    var timeCost = Math.max(0, Number(opts.timeCost || 0));
    if (timeCost > 0) advanceGameTime(timeCost);
    token.prepared = true;
    return true;
  }

  function _rollbackAiRoundAction(token, reason) {
    if (!token || token.committed || token.rolledBack) return false;
    _aiRoundHistoryPrePushedForAdvance = false;
    try { _restoreAIRuntimeSnapshot(token.runtimeSnapshot, { syncMemory: true }); } catch (_) {}
    _restoreAiRoundStackSnapshot(token.roundHistory, token.forwardStack);
    token.runtimeSnapshot = null;
    token.roundHistory = null;
    token.forwardStack = null;
    token.choices = null;
    token.rolledBack = true;
    try { console.log('[AIStoryGen] choice action rolled back: ' + (reason || 'unknown')); } catch (_) {}
    return true;
  }

  function _commitAiRoundAction(token) {
    if (!token || token.rolledBack || token.committed) return false;
    token.committed = true;
    _aiRoundHistoryPrePushedForAdvance = false;
    token.runtimeSnapshot = null;
    token.roundHistory = null;
    token.forwardStack = null;
    token.choices = null;
    return true;
  }

  var AILifecycleController = {
    schemaVersion: 1,
    captureTransientState: _captureAiLifecycleTransientState,
    restoreTransientState: _restoreAiLifecycleTransientState,
    resetTransientState: _resetAiLifecycleTransientState,
    createRoundAction: _createAiRoundActionToken,
    prepareRoundAction: _prepareAiRoundAction,
    rollbackRoundAction: _rollbackAiRoundAction,
    commitRoundAction: _commitAiRoundAction
  };
  window.AIStoryGen.lifecycleController = AILifecycleController;
  window.AIStoryGen.LifecycleController = AILifecycleController;

  function _cloneAiRoundEntryForSave(entry) {
    var cloned = RoundSnapshotModule.cloneEntry(entry, {
      allowedGameKeys: _aiSnapshotKeys
    });
    if (!cloned) return null;
    cloned.targetPassage = _normalizePassageName(cloned.targetPassage || '');
    cloned.currentLocationPassage = _normalizePassageName(cloned.currentLocationPassage || '');
    return cloned;
  }

  function _cloneAiRoundStackForSave(stack) {
    return RoundSnapshotModule.cloneStack(stack, {
      allowedGameKeys: _aiSnapshotKeys,
      maxEntries: 20,
      maxChars: 2000000
    }).map(function (entry) {
      entry.targetPassage = _normalizePassageName(entry.targetPassage || '');
      entry.currentLocationPassage = _normalizePassageName(entry.currentLocationPassage || '');
      return entry;
    });
  }

  function _normaliseAISavedScene(scene) {
    if (!scene || typeof scene !== 'object' || !scene.aiHTML || !scene.passage) return null;
    var clean = {};
    Object.keys(scene).forEach(function (key) {
      if (key === 'roundHistory' || key === 'forwardStack') return;
      clean[key] = _cloneForAiSnapshot(scene[key]);
    });
    clean.roundHistory = _cloneAiRoundStackForSave(scene.roundHistory || []);
    clean.forwardStack = _cloneAiRoundStackForSave(scene.forwardStack || []);
    clean.snapshotSchemaVersion = RoundSnapshotModule.schemaVersion;
    return clean;
  }

  function _restoreAiRoundStacksFromSaved(saved) {
    if (!saved || typeof saved !== 'object') return false;
    var history = Array.isArray(saved.roundHistory) ? saved.roundHistory : [];
    var forward = Array.isArray(saved.forwardStack) ? saved.forwardStack : [];
    _aiRoundHistory.length = 0;
    _aiForwardStack.length = 0;
    history.forEach(function (entry) {
      var cloned = _cloneAiRoundEntryForSave(entry);
      if (cloned) _aiRoundHistory.push(cloned);
    });
    forward.forEach(function (entry) {
      var cloned = _cloneAiRoundEntryForSave(entry);
      if (cloned) _aiForwardStack.push(cloned);
    });
    return !!(_aiRoundHistory.length || _aiForwardStack.length);
  }

  function _hydrateAiRoundHistoryFromSave() {
    if (_aiRoundHistory.length || _aiForwardStack.length) return false;
    try {
      var saved = _getAISaveStateFromCurrentVariables() || _pendingAISaveState;
      if (!saved) return false;
      return _restoreAiRoundStacksFromSaved(saved);
    } catch (_) {
      return false;
    }
  }

  function _captureAISaveStateForSave() {
    try {
      if (_isAISaveRestoreSuppressed()) return null;
      var passageName = (typeof State !== 'undefined' && State.passage) || _currentPassageName();
      var mode = '';
      var aiHTML = '';
      if (_aiReplaceActive) {
        mode = 'replace';
        var $replaceWrap = $('#passages .passage .ai-replaced-content');
        aiHTML = $replaceWrap.length ? $replaceWrap.html() : (_aiReplaceSessionHTML || '');
        passageName = _aiReplaceOriginPassage || passageName;
      } else {
        var $normalWrap = $('#passages .passage .ai-narrative-wrap');
        if ($normalWrap.length) {
          mode = 'normal';
          aiHTML = $normalWrap.html() || '';
        }
      }
      if (!mode || !aiHTML) return null;
      return {
        mode: mode,
        passage: passageName || '',
        aiHTML: aiHTML,
        targetLabel: _aiReplaceTargetLabel || '',
        targetPassage: _aiReplaceTargetPassage || '',
        originalLinkId: _aiReplaceOriginalLinkId || '',
        originalEventMode: !!_aiReplaceOriginalEventMode,
        roundCount: _aiReplaceRoundCount || 0,
        currentLocationLabel: _aiCurrentLocationLabel || '',
        currentLocationPassage: _aiCurrentLocationPassage || '',
        locationArrived: !!_aiLocationArrived,
        replaceSessionHTML: _aiReplaceSessionHTML || '',
        roundHistory: _cloneAiRoundStackForSave(_aiRoundHistory),
        forwardStack: _cloneAiRoundStackForSave(_aiForwardStack),
        savedAt: Date.now()
      };
    } catch (e) {
      try { console.warn('[AIStoryGen] capture AI save state failed', e); } catch (_) {}
      return null;
    }
  }

  function _writeAISaveStateToVariables(vars, navState) {
    if (!vars || typeof vars !== 'object') return;
    if (navState) vars.aiStoryGenNavState = _cloneForAiSnapshot(navState);
    else delete vars.aiStoryGenNavState;
    _patchAIStoryGenStateField(vars, 'scene', navState || null);
  }

  function _syncAISaveStateToCurrentSave() {
    if (_isAISaveRestoreSuppressed()) {
      _getUniqueCurrentMomentVariableObjects().forEach(function (vars) {
        _writeAISaveStateToVariables(vars, null);
      });
      return null;
    }
    var navState = _captureAISaveStateForSave();
    _getUniqueCurrentMomentVariableObjects().forEach(function (vars) {
      _writeAISaveStateToVariables(vars, navState);
    });
    return navState;
  }

  function _replaceAISaveStateFromSave(navState) {
    if (navState && typeof navState === 'object' && navState.aiHTML && navState.passage) {
      if (/^Prison\b/i.test(String(navState.passage || ''))) {
        _pendingAISaveState = null;
        return;
      }
      _pendingAISaveState = _normaliseAISavedScene(navState);
      setTimeout(function () {
        var currentPassage = (typeof State !== 'undefined' && State.passage) || _currentPassageName();
        if (_isNativeSexOrCombatPassage(currentPassage)) {
          _pendingAISaveState = null;
          return;
        }
        _restoreAISaveStateIfNeeded(currentPassage);
      }, 300);
    } else {
      _pendingAISaveState = null;
    }
  }

  var _aiPreSaveSyncRunning = false;
  var _aiPreSaveSyncLastAt = 0;
  var _aiPreSaveSyncLastState = null;
  var _aiPreSaveSyncLastDuration = 0;
  var _aiPreSaveSyncRunCount = 0;
  var _aiPreSaveSyncReuseCount = 0;

  function _syncAIStateBeforePossibleSave(reason) {
    var now = Date.now();
    if (_aiPreSaveSyncRunning || (_aiPreSaveSyncLastState && now - _aiPreSaveSyncLastAt < 500)) {
      _aiPreSaveSyncReuseCount += 1;
      return _aiPreSaveSyncLastState;
    }
    _aiPreSaveSyncRunning = true;
    var startedAt = now;
    try {
      _installAISaveRuntimeHooks();
      _bindMemoryToCurrentStateIfNeeded();
      _aiPreSaveSyncLastState = _syncAIStoryGenStateToCurrentSave(reason || 'pre-save');
      _syncAISaveTitleToCurrentState();
      _aiPreSaveSyncLastAt = Date.now();
      _aiPreSaveSyncLastDuration = _aiPreSaveSyncLastAt - startedAt;
      _aiPreSaveSyncRunCount += 1;
      return _aiPreSaveSyncLastState;
    } catch (e) {
      try { console.warn('[AIStoryGen] pre-save sync failed', e); } catch (_) {}
      return null;
    } finally {
      _aiPreSaveSyncRunning = false;
    }
  }

  window.AIStoryGen.getSaveSyncDiagnostics = function () {
    return {
      running: !!_aiPreSaveSyncRunning,
      lastAt: _aiPreSaveSyncLastAt,
      lastDurationMs: _aiPreSaveSyncLastDuration,
      runCount: _aiPreSaveSyncRunCount,
      reuseCount: _aiPreSaveSyncReuseCount,
      roundHistory: RoundSnapshotModule.auditStack(_aiRoundHistory, { maxChars: 2000000 }),
      forwardStack: RoundSnapshotModule.auditStack(_aiForwardStack, { maxChars: 2000000 })
    };
  };

  function _getAISaveStateFromCurrentVariables() {
    try {
      var nav = _readAuthoritativeAISceneFromVariables(_getStateVariables());
      if (nav) return nav;
    } catch (_) {}
    try {
      if (typeof State !== 'undefined' && State.active && State.active.variables) {
        var activeNav = _readAuthoritativeAISceneFromVariables(State.active.variables);
        if (activeNav) return activeNav;
      }
    } catch (_) {}
    return null;
  }

  function _restoreAISaveStateIfNeeded(passageName) {
    try {
      if (_isAISaveRestoreSuppressed()) {
        _pendingAISaveState = null;
        return false;
      }
      var saved = _getAISaveStateFromCurrentVariables() || _pendingAISaveState;
      if (!saved || !saved.aiHTML) return false;
      if (/^Prison\b/i.test(String(saved.passage || ''))) {
        _pendingAISaveState = null;
        _clearUnsafePrisonAiState();
        return false;
      }
      if (_isNativeSexOrCombatPassage(passageName)) {
        _pendingAISaveState = null;
        return false;
      }
      if (saved.passage && passageName && saved.passage !== passageName) {
        // A save-scoped overlay belongs to exactly one native passage. Restoring it
        // on a later page makes stale narration look current and corrupts AI back/forward.
        _pendingAISaveState = null;
        try { _writeAISaveStateToVariables(_getStateVariables(), null); } catch (_) {}
        try { console.warn('[AIStoryGen] skipped stale AI save state across passage mismatch saved="' + saved.passage + '" current="' + passageName + '"'); } catch (_) {}
        return false;
      }
      var $passage = $('#passages .passage');
      if (!$passage.length) return false;

      $passage.find('.ai-replaced-content, .ai-narrative-wrap').remove();
      var $existingOriginal = $passage.find('.ai-original-wrap');
      if ($existingOriginal.length) $existingOriginal.replaceWith($existingOriginal.contents());
      $('#passages .ai-choices, #passages .ai-choices-end').remove();

      var $overlayKeep = _detachNativeOverlayKeepers($passage);
      _hidePassageOriginalContent($passage);
      if ($overlayKeep.length) $passage.append($overlayKeep);

      if (saved.mode === 'normal') {
        _aiReplaceActive = false;
        _aiNarrativeWrap = document.createElement('div');
        _aiNarrativeWrap.className = 'ai-narrative-wrap';
        _aiNarrativeWrap.innerHTML = saved.aiHTML;
        $passage[0].appendChild(_aiNarrativeWrap);
      } else {
        _aiReplaceActive = true;
        _aiReplaceOriginPassage = saved.passage || passageName || '';
        _aiReplaceTargetLabel = saved.targetLabel || '';
        _aiReplaceTargetPassage = _normalizePassageName(saved.targetPassage || '');
        _aiReplaceOriginalLinkId = saved.originalLinkId || '';
        _aiReplaceOriginalEventMode = !!saved.originalEventMode;
        _aiReplaceRoundCount = Number(saved.roundCount || 0);
        if (saved.currentLocationPassage) {
          _setAiLocationState(saved.currentLocationPassage, saved.currentLocationLabel || '', 'restore saved AI location', { arrived: !!saved.locationArrived });
        } else if (saved.currentLocationLabel) {
          _setAiLocationLabelOnly(saved.currentLocationLabel, 'restore saved AI location label', { arrived: !!saved.locationArrived });
        } else {
          _clearAiLocationState('restore saved AI location empty');
        }
        _aiReplaceSessionHTML = saved.replaceSessionHTML || saved.aiHTML || '';
        var $aiWrap = $('<div class="ai-replaced-content"></div>').html(saved.aiHTML);
        $passage.append($aiWrap);
        _repairStaleEventModeUI($aiWrap);
        _refreshOriginalEventModeFromLink();
      }
      _restoreAiRoundStacksFromSaved(saved);

      _pendingAISaveState = null;
      setTimeout(function () { injectAILinkClones(); }, 50);
      autoInjectChoices(passageName || saved.passage || '');
      console.log('[AIStoryGen] restored AI save state for passage="' + (passageName || saved.passage || '') + '"');
      return true;
    } catch (e) {
      console.warn('[AIStoryGen] restore AI save state failed', e);
      return false;
    }
  }

  function _restoreAIIntimateSceneIfNeeded(passageName) {
    return false;
  }

  // -- Narrative cache: { location_hour_dangerLevel: { text, time } } --
  var _narrativeCache = {};

  function getCachedNarrative(key, cfg) {
    var ttl = (cfg.cacheTTLMinutes || 5) * 60 * 1000;
    var entry = _narrativeCache[key];
    if (entry && (Date.now() - entry.time) < ttl) {
      return entry.text;
    }
    delete _narrativeCache[key];
    return null;
  }

  function setCachedNarrative(key, text) {
    _narrativeCache[key] = { text: text, time: Date.now() };
    // Limit cache size
    var keys = Object.keys(_narrativeCache);
    while (keys.length > 30) { delete _narrativeCache[keys[0]]; keys.shift(); }
  }

  function restoreOriginalPassage(opts) {
    opts = opts || {};
    if (!_aiReplaceActive) return;
    var keepAI = opts.keepAIFunctionality === true;
    if (keepAI) _archiveAiRoundHistoryForNativeHandoff('restore original passage keep AI');
    var $passage = $('#passages .passage');
    if ($passage.length) {
      // Remove every AI overlay type before restoring the native passage.
      _clearAiOverlayResidue($passage, 'native');
      // Unwrap original content (restore visibility) — use replaceWith to preserve text nodes
      var $owRestore = $passage.find('.ai-original-wrap');
      if ($owRestore.length) $owRestore.replaceWith($owRestore.contents());
    }
    _aiReplaceActive = false;
    _aiReplaceOriginPassage = '';
    _aiReplaceOriginalLinkId = '';
    _aiReplaceOriginalEventMode = false;
    _aiReplaceSessionHTML = '';
    $('#passages .ai-choices, #passages .ai-choices-end').remove();
    _clearAISaveNavigationState('restore original passage', { preserveRoundHistory: keepAI });
    if (!keepAI) _suppressAutoChoices('restore original passage', 5000);
    // Re-inject fresh AI link clones with working handlers
    setTimeout(function () {
      injectAILinkClones();
      if (keepAI) autoInjectChoices(typeof State !== 'undefined' ? State.passage : '');
    }, 50);
  }
  window.AIStoryGen.restoreOriginalPassage = restoreOriginalPassage;

  function _triggerOriginalAiLink() {
    var id = String(_aiReplaceOriginalLinkId || '').trim();
    if (!id) return false;
    var el = null;
    try {
      el = $('[data-ai-origid]').filter(function () {
        return String($(this).attr('data-ai-origid') || '') === id && !$(this).hasClass('ai-injected-link');
      }).get(0) || null;
    } catch (_) {}
    if (!el) return false;
    try {
      console.log('[AIStoryGen] finishing AI by triggering original link: ' + id);
      el.click();
      return true;
    } catch (e) {
      console.warn('[AIStoryGen] original link trigger failed', e);
      return false;
    }
  }

  function _triggerOriginalLinkToPassage(targetPassage, reason) {
    var dest = _normalizePassageName(targetPassage || '');
    if (!dest) return false;
    var el = null;
    try {
      $('#passages .passage a[data-passage]').each(function () {
        if (el) return;
        var $a = $(this);
        if ($a.closest(OptionalAddonBridge.cloneCleanupSelector('.ai-narrative-section,.ai-choices,.ai-choices-end,.ai-injected-row,.ai-item-use-panel,.ai-memory-inline,.ai-pixel-panel,.ai-pixelgen-panel')).length) return;
        var passage = _normalizePassageName($a.attr('data-passage') || '');
        if (passage === dest) el = this;
      });
    } catch (_) {}
    if (!el) return false;
    try {
      console.log('[AIStoryGen] finishing AI by triggering native passage link: ' + dest + (reason ? ' (' + reason + ')' : ''));
      el.click();
      return true;
    } catch (e) {
      console.warn('[AIStoryGen] native passage link trigger failed', e);
      return false;
    }
  }

  function _canDirectPlayPassage(targetPassage) {
    var dest = _normalizePassageName(targetPassage || '');
    if (!dest || _isUnsafeDirectPassage(dest)) return false;
    try {
      var story = _getNativeStory();
      if (story && story.has && !story.has(dest)) return false;
    } catch (_) {}
    return true;
  }

  function _navigateToNativePassage(targetPassage, opts) {
    opts = opts || {};
    var dest = _normalizePassageName(targetPassage || '');
    if (!dest) {
      _recordAiNavigationAttempt('blocked', {
        source: opts.source || 'native-navigation',
        targetPassage: dest,
        reason: 'empty target'
      });
      return false;
    }
    var reason = opts.reason || 'AI native navigation';
    if (_isUnsafeDirectPassage(dest)) {
      _warnUnsafeDirectPassage(dest);
      _recordAiNavigationAttempt('blocked', {
        source: opts.source || 'native-navigation',
        targetPassage: dest,
        reason: 'unsafe direct passage'
      });
      return false;
    }
    if (opts.preferOriginalAiLink && _triggerOriginalAiLink()) {
      _recordAiNavigationAttempt('triggered', {
        source: opts.source || 'original-ai-link',
        targetPassage: dest,
        reason: reason,
        usedOriginalLink: true,
        ok: true
      });
      _sampleAiNavigationResult(dest, opts.source || 'original-ai-link');
      return true;
    }
    if (_triggerOriginalLinkToPassage(dest, reason)) {
      _recordAiNavigationAttempt('triggered', {
        source: opts.source || 'original-link',
        targetPassage: dest,
        reason: reason,
        usedOriginalLink: true,
        ok: true
      });
      _sampleAiNavigationResult(dest, opts.source || 'original-link');
      return true;
    }
    if (opts.allowDirect === false || !_canDirectPlayPassage(dest)) {
      _recordAiNavigationAttempt('blocked', {
        source: opts.source || 'native-navigation',
        targetPassage: dest,
        reason: opts.allowDirect === false ? 'direct play disabled' : 'cannot direct play passage'
      });
      return false;
    }
    var nativeEngine = _getNativeEngine();
    if (nativeEngine && nativeEngine.play) {
      _markAISaveRestoreSuppressed(opts.suppressMs || 2500);
      var escapedEventCleared = _clearEscapedNativeEventBeforeAiDirectNavigation(dest, reason);
      if (!escapedEventCleared) {
        _clearInvalidNativeEventQueueBeforeAiDirectNavigation(dest, reason, {
          force: opts.discardNativeEventQueue === true
        });
      }
      try { console.log('[AIStoryGen] native navigation via Engine.play: ' + dest + (reason ? ' (' + reason + ')' : '')); } catch (_) {}
      try {
        nativeEngine.play(dest);
        _recordAiNavigationAttempt('triggered', {
          source: opts.source || 'engine-play',
          targetPassage: dest,
          reason: reason,
          usedEnginePlay: true,
          ok: true
        });
        _sampleAiNavigationResult(dest, opts.source || 'engine-play');
      } catch (e) {
        _recordAiNavigationAttempt('failed', {
          source: opts.source || 'engine-play',
          targetPassage: dest,
          reason: reason,
          usedEnginePlay: true,
          ok: false,
          error: e && e.message || String(e)
        });
        throw e;
      }
      return true;
    }
    _recordAiNavigationAttempt('blocked', {
      source: opts.source || 'native-navigation',
      targetPassage: dest,
      reason: 'Engine.play unavailable'
    });
    return false;
  }

  function _isUnsafeDirectPassage(targetPassage) {
    var dest = String(targetPassage || '').trim();
    if (!dest) return false;
    if (/^(Moor|Bog)$/i.test(dest)) return true;
    // Eden's cabin interior passages are native event-chain pages. Direct
    // Engine.play from AI/manual arrival can bypass NPC/event setup and leave
    // the page at a "Continue" stub followed by native NPC detachment errors.
    if (/^(?:Forest Cabin|Eden Cabin)$/i.test(dest)) return true;
    // Prison passages are event-chain internals. They require original prison
    // variables to be initialised first, so direct AI/manual arrival can crash
    // widgets such as <<prison_end>> with an undefined $prison object.
    if (/^Prison\b/i.test(dest)) return true;
    return false;
  }

  function _safeManualArriveFallback(targetPassage) {
    var dest = String(targetPassage || '').trim();
    if (!/^(?:Forest Cabin|Eden Cabin)$/i.test(dest)) return '';
    try {
      var fallbackStory = _getNativeStory();
      if (!fallbackStory || _nativeStoryHas('Eden Clearing')) {
        return 'Eden Clearing';
      }
    } catch (_) {
      return 'Eden Clearing';
    }
    return '';
  }

  function _warnUnsafeDirectPassage(targetPassage) {
    var cfg = loadCfg();
    var label = _resolveLocationLabel(targetPassage) || targetPassage;
    _showAIUserMessage(cfg.language === 'zh'
      ? ('\u672a\u76f4\u63a5\u8df3\u8f6c\u5230\u300c' + label + '\u300d\uff1a\u8fd9\u4e2a\u5730\u70b9\u5c5e\u4e8e\u539f\u7248\u4e8b\u4ef6\u94fe\uff0c\u9700\u8981\u901a\u8fc7\u5f53\u524d\u9875\u9762\u7684\u539f\u7248\u5165\u53e3\u8fdb\u5165\uff0c\u907f\u514d\u7ed5\u8fc7\u524d\u7f6e\u6570\u636e\u5bfc\u81f4\u62a5\u9519\u3002')
      : ('Did not jump directly to "' + label + '": this passage belongs to a native event chain and must be entered through a native link to avoid missing setup data.'), true);
    return;
    _showAIUserMessage(cfg.language === 'zh'
      ? ('未直接跳转到「' + label + '」：这个地点会生成原版事件/NPC，需要通过当前页面的原版入口进入，避免侧边栏 NPC 脱离控制错误。')
      : ('Did not jump directly to "' + label + '": this location creates native events/NPCs and must be entered through a native link to avoid NPC state errors.'), true);
  }

  function _removeStaleMoorErrorDom() {
    try {
      $('#storyCaptionContent span.red, #story-caption span.red, #ui-bar span.red').filter(function () {
        return /Moor|流程中生成的NPC|脱离控制|Vrelnir/i.test($(this).text() || '');
      }).remove();
      $('.error-reporter-btn').each(function () {
        try {
          if (!window.Errors || !Errors.log || !Errors.log.length) $(this).hide();
        } catch (_) {}
      });
    } catch (_) {}
  }

  function _removeMalformedAIEventDom() {
    try {
      var badErrorRe = /Error evaluating = sigil|scene is not defined|Forest is not defined|current is not defined/i;
      var repaired = false;
      $('#passages .error-view, #passages .macro-error, #passages .error, #passages tw-error, #passages .red').filter(function () {
        return badErrorRe.test(String($(this).text() || ''));
      }).each(function () {
        repaired = true;
        $(this).remove();
      });
      $('#passages .ai-narrative-section, #passages .ai-story-choice-result, #passages .ai-generated-story').each(function () {
        var $section = $(this);
        var text = String($section.text() || '');
        if (!/\[(?:AI_EVENT|AI_META|LOC:)/i.test(text) && !badErrorRe.test(text)) return;
        var cleaned = _stripAIMetadataMarkers(text)
          .replace(/\b(?:summary|eventType|location|targetLocation|locationStatus|sceneFocus|visualAction|characters|presentCharacters|presentEntities|presentTargets|sexTargets|memoryTags|memoryImportance|itemsGained|itemsLost|statChanges)\s*=?\s*[^。\n]*(?=\s+(?:summary|eventType|location|targetLocation|locationStatus|sceneFocus|visualAction|characters|presentCharacters|presentEntities|presentTargets|sexTargets|memoryTags|memoryImportance|itemsGained|itemsLost|statChanges)\s*=|$)/gi, ' ')
          .replace(/\s+/g, ' ')
          .trim();
        if (cleaned && cleaned !== text) {
          var $keep = $section.children('.ai-narrative-toolbar, .ai-pickup-line, .ai-stats-line').detach();
          repaired = true;
          $section.text(cleaned);
          if ($keep.length) $section.append($keep);
        }
      });
      if (repaired) {
        _clearAiLocationState('repair malformed AI event UI');
      }
    } catch (_) {}
  }

  function _clearStaleMoorEventQueue(reason) {
    try {
      if (typeof State === 'undefined' || !State.variables) return false;
      var current = String(State.passage || '').trim();
      if (/^(Moor|Bog)$/i.test(current)) return false;
      var V = State.variables;
      var ev = V.event;
      if (!ev || !Array.isArray(ev.buffer)) return false;
      var before = ev.buffer.length;
      ev.buffer = ev.buffer.filter(function (entry) {
        var area = entry && entry.area;
        if (!Array.isArray(area)) return true;
        var joined = area.join('|');
        return !(/^Moor$/i.test(String(area[0] || '')) && /eventsmoorlow|beastNEWinit/i.test(joined));
      });
      if (ev.buffer.length === before) return false;
      _removeStaleMoorErrorDom();
      try { console.log('[AIStoryGen] cleared stale Moor event queue after AI direct navigation' + (reason ? ': ' + reason : '')); } catch (_) {}
      setTimeout(function () {
        _removeStaleMoorErrorDom();
        try {
          if (typeof UIBar !== 'undefined' && UIBar.update) UIBar.update();
          var eventCleanupEngine = _getNativeEngine();
          if (eventCleanupEngine && eventCleanupEngine.show) eventCleanupEngine.show();
        } catch (_) {}
        setTimeout(_removeStaleMoorErrorDom, 50);
      }, 0);
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] stale Moor event cleanup failed', e); } catch (_) {}
      return false;
    }
  }

  function _finishAiReplaceAndGo(targetPassage, opts) {
    opts = opts || {};
    var keepAI = opts.keepAIFunctionality === true;
    var dest = _normalizePassageName(targetPassage || _aiCurrentLocationPassage || _aiReplaceTargetPassage || '');
    if (!dest) {
      restoreOriginalPassage({ keepAIFunctionality: keepAI });
      return;
    }
    if (keepAI) _archiveAiRoundHistoryForNativeHandoff('finish AI replace to ' + dest);
    var $passage = $('#passages .passage');
    if ($passage.length) {
      _clearAiOverlayResidue($passage, 'native');
      var $ow = $passage.find('.ai-original-wrap');
      if ($ow.length) $ow.replaceWith($ow.contents());
    }
    _aiReplaceActive = false;
    _aiReplaceOriginPassage = '';
    _aiReplaceTargetLabel = '';
    _aiReplaceTargetPassage = '';
    _aiReplaceOriginalEventMode = false;
    _clearAiLocationState('finish AI replace');
    _aiReplaceSessionHTML = '';
    _prepareAINativeExit(opts.skipOriginal ? 'arrive/manual correction to native page' : 'finish AI replace to native page', opts);
    _clearAISaveNavigationState('finish AI replace to ' + dest, { preserveRoundHistory: keepAI || !!opts.preserveRoundHistory });
    var didNavigate = _navigateToNativePassage(dest, {
      preferOriginalAiLink: !opts.skipOriginal,
      reason: opts.skipOriginal ? 'arrive/manual correction' : 'finish AI replace',
      source: 'finish-ai-replace',
      discardNativeEventQueue: opts.discardNativeEventQueue === true
    });
    _aiReplaceOriginalLinkId = '';
    _aiReplaceOriginalEventMode = false;
    if (!didNavigate) {
      try { console.warn('[AIStoryGen] finish AI replace could not navigate to: ' + dest); } catch (_) {}
    }
  }

  function _getNativeEventNpcSlotCount(V) {
    try {
      var list = V && V.NPCList;
      if (!Array.isArray(list)) return 0;
      for (var i = list.length - 1; i >= 0; i--) {
        if (list[i] && list[i].type !== undefined) return i + 1;
      }
    } catch (_) {}
    return 0;
  }

  function _getNativeEventActiveNpcCount(V) {
    try {
      var nativeCount = Number(V && V.enemyno);
      if (Number.isFinite(nativeCount) && nativeCount >= 0) return Math.floor(nativeCount);
      var list = V && V.NPCList;
      if (!Array.isArray(list)) return 0;
      var active = 0;
      for (var i = 0; i < list.length; i++) {
        if (list[i] && list[i].type !== undefined && list[i].type !== null) active += 1;
      }
      return active;
    } catch (_) {
      return 0;
    }
  }

  function _isNativeMajorAreaPassage(passage) {
    try {
      var current = _normalizePassageName(passage || '');
      return !!(current && typeof setup !== 'undefined' && setup && Array.isArray(setup.majorAreas) && setup.majorAreas.indexOf(current) >= 0);
    } catch (_) {
      return false;
    }
  }

  function _getNativeEventBufferInvalidReason(V) {
    try {
      var ev = V && V.event;
      if (!ev || !Array.isArray(ev.buffer) || !ev.buffer.length) return '';
      var buffer = ev.buffer;
      var npcSlots = _getNativeEventNpcSlotCount(V);
      if (buffer.length > npcSlots) return 'buffer longer than NPC slots';
      var used = {};
      var maxSlot = -1;
      for (var i = 0; i < buffer.length; i++) {
        var entry = buffer[i] || {};
        var slot = Number(entry.slot);
        if (!Number.isFinite(slot) || Math.floor(slot) !== slot || slot < 0) return 'invalid slot';
        if (slot >= npcSlots) return 'slot outside NPC slots';
        if (used[slot]) return 'duplicate slot';
        used[slot] = true;
        if (slot > maxSlot) maxSlot = slot;
      }
      for (var j = 0; j <= maxSlot; j++) {
        if (!used[j]) return 'slot gap';
      }
    } catch (e) {
      return 'validator exception';
    }
    return '';
  }

  function _removeNativeNpcEventErrorDom() {
    try {
      var re = /生成的NPC发生异常脱离|NPC.*脱离|Vrelnir/i;
      $('#passages .error-view, #passages .macro-error, #passages .error, #passages tw-error, #passages .red, #ui-bar .error-view, #ui-bar .macro-error, #ui-bar .error, #ui-bar .red').filter(function () {
        return re.test(String($(this).text() || ''));
      }).remove();
    } catch (_) {}
  }

  function _clearInvalidNativeEventQueueBeforeAiDirectNavigation(targetPassage, reason, opts) {
    try {
      opts = opts || {};
      if (typeof State === 'undefined' || !State.variables) return false;
      var V = State.variables;
      var ev = V.event;
      if (!ev || !Array.isArray(ev.buffer) || !ev.buffer.length) return false;
      var invalidReason = _getNativeEventBufferInvalidReason(V);
      // Manual arrival deliberately abandons the native scene. Its queue may
      // still be structurally valid, but must not follow the player to a
      // different passage and detach scene-generated NPCs during cleanup.
      if (!invalidReason && opts.force !== true) return false;
      var fullyCleared = false;
      if (opts.force === true) {
        // A manual jump abandons the current native scene entirely. Clearing
        // only buffer leaves the event object's generated-NPC bookkeeping
        // alive, which can still fire the vanilla detached-NPC error later.
        fullyCleared = _clearNativeNpcEventState({
          clearNpcState: _getNativeEventActiveNpcCount(V) > 0,
          reason: invalidReason || 'AI direct navigation abandoned native event',
          currentPassage: (typeof State !== 'undefined' && State.passage) || '',
          targetPassage: _normalizePassageName(targetPassage || '')
        });
        try {
          if (V.event) delete V.event;
          if (State.active && State.active.variables) delete State.active.variables.event;
          fullyCleared = true;
        } catch (_) {
          try { ev.buffer = []; } catch (_) {}
        }
      } else {
        ev.buffer = [];
      }
      _removeNativeNpcEventErrorDom();
      try {
        console.warn('[AIStoryGen] cleared ' + (invalidReason || 'pending manual') + ' native event ' + (fullyCleared ? 'state' : 'buffer') + ' before AI direct navigation to ' + _normalizePassageName(targetPassage || '') + (reason ? ' (' + reason + ')' : ''));
      } catch (_) {}
      setTimeout(function () {
        _removeNativeNpcEventErrorDom();
        try {
          if (typeof UIBar !== 'undefined' && UIBar.update) UIBar.update();
          var staleMoorEngine = _getNativeEngine();
          if (staleMoorEngine && staleMoorEngine.show) staleMoorEngine.show();
        } catch (_) {}
        setTimeout(_removeNativeNpcEventErrorDom, 50);
      }, 0);
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] invalid native event buffer cleanup failed', e); } catch (_) {}
      return false;
    }
  }

  function _finishNormalAiAndGo(targetPassage, opts) {
    opts = opts || {};
    var keepAI = opts.keepAIFunctionality === true;
    var dest = _normalizePassageName(targetPassage || _aiCurrentLocationPassage || '');
    if (!dest) return false;
    if (keepAI) _archiveAiRoundHistoryForNativeHandoff('finish normal AI to ' + dest);
    var $passage = $('#passages .passage');
    if (_aiNarrativeWrap && _aiNarrativeWrap.parentNode) {
      _aiNarrativeWrap.parentNode.removeChild(_aiNarrativeWrap);
      _aiNarrativeWrap = null;
    }
    if ($passage.length) {
      _clearAiOverlayResidue($passage, 'native');
      var $ow = $passage.find('.ai-original-wrap');
      if ($ow.length) $ow.replaceWith($ow.contents());
    }
    _clearAiLocationState('finish normal AI');
    _prepareAINativeExit('finish normal AI to native page', opts);
    _clearAISaveNavigationState('finish normal AI to ' + dest, { preserveRoundHistory: keepAI || !!opts.preserveRoundHistory });
    return _navigateToNativePassage(dest, {
      reason: 'normal AI finish',
      source: 'finish-normal-ai',
      discardNativeEventQueue: opts.discardNativeEventQueue === true
    });
  }

  // -- AI round-level navigation: push/pop within a single AI session --

  function _captureCurrentAiRoundChoices() {
    try {
      // PanelManager may place the choice panel as a direct child of
      // #passages, outside .passage. Capture from the shared panel zone.
      var $panel = $('#passages .ai-choices').filter(function () {
        return $(this).find('.ai-choices-list').length > 0 && !$(this).find('.ai-choices-loading').length;
      }).last();
      if (!$panel.length || !_lastChoicesData || !Array.isArray(_lastChoicesData.choices)) return [];
      return _cloneForAiSnapshot(_lastChoicesData.choices);
    } catch (_) {
      return [];
    }
  }

  function _restoreAiRoundChoices(entry) {
    if (!entry || !Array.isArray(entry.choices) || !entry.choices.length) return false;
    var choices = _cloneForAiSnapshot(entry.choices);
    var cfg = loadCfg();
    var $container = $('<div class="ai-choices ai-choices-auto"></div>');
    if (_aiReplaceActive && _aiReplaceRoundCount > 0) {
      var roundInfo = cfg.language === 'zh'
        ? ('\u25c6 \u7b2c ' + _aiReplaceRoundCount + ' \u8f6e')
        : ('\u25c6 Round ' + _aiReplaceRoundCount);
      $container.append($('<div class="ai-round-info" style="text-align:center;color:#b4a078;font-size:0.85em;margin-bottom:0.3em;"></div>').text(roundInfo));
    }
    _placeAIChoicesContainer($container);
    renderChoices($container, choices, cfg);
    _scheduleAIPixelAssistRefresh('AI round choices restored', 300);
    return true;
  }

  function _captureCurrentAiRound(opts) {
    opts = opts || {};
    var gameSnapshot = opts.gameSnapshot
      ? RoundSnapshotModule.sanitizeGameSnapshot(opts.gameSnapshot, _aiSnapshotKeys)
      : _captureGameSnapshot();
    var pickupCandidates = opts.pickupCandidates ? _cloneForAiSnapshot(opts.pickupCandidates) : _cloneForAiSnapshot(_aiPickupCandidates || {});
    var roundChoices = Array.isArray(opts.choices) && opts.choices.length
      ? _cloneForAiSnapshot(opts.choices)
      : _captureCurrentAiRoundChoices();
    if (_aiReplaceActive) {
      var $aiWrap = $('#passages .passage .ai-replaced-content');
      if (!$aiWrap.length) return null;
      var html = $aiWrap.html();
      if (!html || !html.trim()) return null;
      return {
        aiHTML: html,
        roundCount: _aiReplaceRoundCount,
        mode: 'replace',
        originPassage: _aiReplaceOriginPassage || (typeof State !== 'undefined' ? State.passage : ''),
        targetLabel: _aiReplaceTargetLabel || '',
        targetPassage: _aiReplaceTargetPassage || '',
        originalLinkId: _aiReplaceOriginalLinkId || '',
        originalEventMode: !!_aiReplaceOriginalEventMode,
        currentLocationLabel: _aiCurrentLocationLabel || '',
        currentLocationPassage: _aiCurrentLocationPassage || '',
        locationArrived: !!_aiLocationArrived,
        choices: roundChoices,
        gameSnapshot: gameSnapshot,
        pickupCandidates: pickupCandidates
      };
    }
    var normalWrap = (_aiNarrativeWrap && _aiNarrativeWrap.parentNode) ? _aiNarrativeWrap : null;
    if (!normalWrap) {
      normalWrap = $('#passages .passage .ai-narrative-wrap').get(0) || null;
      if (normalWrap) _aiNarrativeWrap = normalWrap;
    }
    if (normalWrap && normalWrap.innerHTML && normalWrap.innerHTML.trim()) {
      return {
        aiHTML: normalWrap.innerHTML,
        roundCount: _aiReplaceRoundCount,
        mode: 'normal',
        originPassage: typeof State !== 'undefined' ? State.passage : '',
        currentLocationLabel: _aiCurrentLocationLabel || '',
        currentLocationPassage: _aiCurrentLocationPassage || '',
        locationArrived: !!_aiLocationArrived,
        choices: roundChoices,
        gameSnapshot: gameSnapshot,
        pickupCandidates: pickupCandidates
      };
    }
    return null;
  }

  function _restoreAiRoundEntry(entry) {
    if (!entry || !entry.aiHTML) return;
    var $passage = $('#passages .passage');
    if (!$passage.length) return;

    if (entry.mode === 'replace') {
      // A round can cross between normal and replace modes. Leave exactly one
      // active overlay behind, otherwise old narration remains visible after Back.
      _clearAiOverlayResidue($passage, 'replace');
      _aiReplaceActive = true;
      _aiReplaceOriginPassage = entry.originPassage || (typeof State !== 'undefined' ? State.passage : '');
      _aiReplaceTargetLabel = entry.targetLabel || '';
      _aiReplaceTargetPassage = _normalizePassageName(entry.targetPassage || '');
      _aiReplaceOriginalLinkId = entry.originalLinkId || '';
      _aiReplaceOriginalEventMode = !!entry.originalEventMode;
      if (entry.currentLocationPassage) {
        _setAiLocationState(entry.currentLocationPassage, entry.currentLocationLabel || '', 'restore AI round location', { arrived: !!entry.locationArrived });
      } else if (entry.currentLocationLabel) {
        _setAiLocationLabelOnly(entry.currentLocationLabel, 'restore AI round location', { arrived: !!entry.locationArrived });
      }
      var $aiWrap = $passage.find('.ai-replaced-content');
      if (!$aiWrap.length) {
        _hidePassageOriginalContent($passage);
        $aiWrap = $('<div class="ai-replaced-content"></div>');
        $passage.append($aiWrap);
      }
      $aiWrap.empty().html(entry.aiHTML);
      _updateReplaceSessionHTML();
    } else {
      _clearAiOverlayResidue($passage, 'normal');
      _aiReplaceActive = false;
      _aiReplaceOriginPassage = '';
      _aiReplaceTargetLabel = '';
      _aiReplaceTargetPassage = '';
      _aiReplaceOriginalLinkId = '';
      _aiReplaceOriginalEventMode = false;
      if (entry.currentLocationPassage) {
        _setAiLocationState(entry.currentLocationPassage, entry.currentLocationLabel || '', 'restore normal AI round location', { arrived: !!entry.locationArrived });
      } else if (entry.currentLocationLabel) {
        _setAiLocationLabelOnly(entry.currentLocationLabel, 'restore normal AI round location', { arrived: !!entry.locationArrived });
      }
      if (!_aiNarrativeWrap || !_aiNarrativeWrap.parentNode) {
        _aiNarrativeWrap = document.createElement('div');
        _aiNarrativeWrap.className = 'ai-narrative-wrap';
        var $overlayKeep = _detachNativeOverlayKeepers($passage);
        if (!$passage.find('.ai-original-wrap').length) _hidePassageOriginalContent($passage);
        if ($overlayKeep.length) $passage.append($overlayKeep);
        $passage[0].appendChild(_aiNarrativeWrap);
      }
      _aiNarrativeWrap.innerHTML = entry.aiHTML;
    }

    _aiReplaceRoundCount = entry.roundCount != null ? entry.roundCount : 0;
    _restoreGameSnapshot(entry.gameSnapshot);
    _replaceMemoryFromSave((entry.gameSnapshot && entry.gameSnapshot.aiStoryGenMemory) || {});
    _syncMemoryToCurrentSave('AI round restore');
    _aiPickupCandidates = _cloneForAiSnapshot(entry.pickupCandidates || {});
    $('#passages .ai-choices, #passages .ai-choices-end').remove();
    _releaseAutoChoicesBusy('restore AI round');
    if (_restoreAiRoundChoices(entry)) {
      return;
    }
    if (_aiReplaceActive) {
      autoInjectChoices(_aiReplaceOriginPassage, _aiReplaceTargetLabel, _aiReplaceTargetPassage);
    } else {
      autoInjectChoices(typeof State !== 'undefined' ? State.passage : '');
    }
  }

  function _hasAiNativeHandoffArchive() {
    return !!(_aiNativeHandoffArchive && _aiNativeHandoffArchive.savedAt && Date.now() - _aiNativeHandoffArchive.savedAt < 10 * 60 * 1000);
  }

  function _archiveAiRoundHistoryForNativeHandoff(reason) {
    try {
      var current = _captureCurrentAiRound();
      if (!current && !_aiRoundHistory.length && !_aiForwardStack.length) return false;
      _aiNativeHandoffArchive = {
        currentRound: _cloneAiRoundEntryForSave(current),
        roundHistory: _cloneAiRoundStackForSave(_aiRoundHistory),
        forwardStack: _cloneAiRoundStackForSave(_aiForwardStack),
        savedAt: Date.now(),
        reason: reason || 'native handoff'
      };
      try { console.log('[AIStoryGen] archived AI round history for native handoff: ' + (_aiNativeHandoffArchive.reason || '')); } catch (_) {}
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] archive AI native handoff failed', e); } catch (_) {}
      return false;
    }
  }

  function _restoreAiNativeHandoffForBackward() {
    try {
      if (!_hasAiNativeHandoffArchive()) return false;
      var saved = _aiNativeHandoffArchive;
      _restoreAiRoundStackSnapshot(saved.roundHistory || [], saved.forwardStack || []);
      _aiNativeHandoffArchive = null;
      if (saved.currentRound && saved.currentRound.aiHTML) {
        _restoreAiRoundEntry(saved.currentRound);
        _syncAISaveStateToCurrentSave();
        return true;
      }
      return _aiRoundHistory.length > 0;
    } catch (e) {
      try { console.warn('[AIStoryGen] restore AI native handoff failed', e); } catch (_) {}
      _aiNativeHandoffArchive = null;
      return false;
    }
  }

  // Save current AI overlay state to round history (called before each new AI round)
  function _pushCurrentToAiRoundHistory(opts) {
    var snap = _captureCurrentAiRound(opts);
    if (!snap) return false;
    var last = _aiRoundHistory.length ? _aiRoundHistory[_aiRoundHistory.length - 1] : null;
    if (last && last.mode === snap.mode && last.roundCount === snap.roundCount && last.aiHTML === snap.aiHTML) {
      return true;
    }
      _aiRoundHistory.push(snap);
    while (_aiRoundHistory.length > 20) _aiRoundHistory.shift();
    _syncAISaveStateToCurrentSave();
    console.log('[AIStoryGen] pushed AI round history, size=' + _aiRoundHistory.length + ', round=' + snap.roundCount);
    return true;
  }

  function _consumePrePushedAiRoundHistoryForAdvance() {
    if (!_aiRoundHistoryPrePushedForAdvance) return false;
    _aiRoundHistoryPrePushedForAdvance = false;
    try { console.log('[AIStoryGen] skipped duplicate AI round history push for current advance'); } catch (_) {}
    return true;
  }

  function _tryAiBackward() {
    _hydrateAiRoundHistoryFromSave();
    if (!_aiRoundHistory.length && !_aiReplaceActive && !(_aiNarrativeWrap && _aiNarrativeWrap.innerHTML && _aiNarrativeWrap.innerHTML.trim())) {
      if (_restoreAiNativeHandoffForBackward()) return true;
    }
    if (_aiRoundHistory.length > 0) {
      _aiBackward();
      return true;
    }
    if (_aiReplaceActive) {
      _releaseAutoChoicesBusy('blocked empty AI backward');
      autoInjectChoices(_aiReplaceOriginPassage || (typeof State !== 'undefined' ? State.passage : ''), _aiReplaceTargetLabel, _aiReplaceTargetPassage);
      _showAIUserMessage(loadCfg().language === 'zh' ? '已经是当前AI剧情的最早记录。请使用下方“到达/返回原版章节”离开AI剧情。' : 'This is the earliest AI story record. Use the bottom return/arrive button to leave AI story.', false);
      return true;
    }
    if (_aiNarrativeWrap && _aiNarrativeWrap.innerHTML.trim()) {
      _releaseAutoChoicesBusy('blocked empty normal AI backward');
      autoInjectChoices(typeof State !== 'undefined' ? State.passage : '');
      _showAIUserMessage(loadCfg().language === 'zh' ? '已经是当前AI剧情的最早记录。请使用下方“返回原版章节”离开AI剧情。' : 'This is the earliest AI story record. Use the bottom return button to leave AI story.', false);
      return true;
    }
    return false;
  }

  function _tryAiForward() {
    _hydrateAiRoundHistoryFromSave();
    if (_aiForwardStack.length > 0) {
      _aiForward();
      return true;
    }
    return false;
  }

  // Navigate backward within AI rounds. Returns true if handled.
  function _aiBackward() {
    if (_aiRoundHistory.length === 0) return false;

    var cur = _captureCurrentAiRound();
    if (cur) _aiForwardStack.push(cur);

    var prev = _aiRoundHistory.pop();
    _restoreAiRoundEntry(prev);
    _syncAISaveStateToCurrentSave();

    console.log('[AIStoryGen] AI backward to round ' + prev.roundCount + ', remaining history=' + _aiRoundHistory.length);
    return true;
  }

  // Navigate forward within AI rounds. Returns true if handled.
  function _aiForward() {
    if (_aiForwardStack.length === 0) return false;

    var cur = _captureCurrentAiRound();
    if (cur) _aiRoundHistory.push(cur);

    var next = _aiForwardStack.pop();
    _restoreAiRoundEntry(next);
    _syncAISaveStateToCurrentSave();

    console.log('[AIStoryGen] AI forward to round ' + next.roundCount + ', remaining forward=' + _aiForwardStack.length);
    return true;
  }

  // Clear AI round history (called when exiting AI mode)
  function _clearAiRoundHistory() {
    _aiRoundHistory.length = 0;
    _aiForwardStack.length = 0;
    _syncAISaveStateToCurrentSave();
  }

  // -- Passage-level AI state save/restore for cross-passage navigation --
  // Call this BEFORE SugarCube replaces the DOM (in :passageinit or Engine hook).
  function saveCurrentAINavState() {
    if (_isAISaveRestoreSuppressed()) return;
    if (!_aiReplaceActive || !_aiReplaceOriginPassage) return;
    try {
      var $aiWrap = $('#passages .passage .ai-replaced-content');
      var aiHTML = $aiWrap.length ? $aiWrap.html() : '';
      // Don't save if there's nothing to save
      if (!aiHTML) {
        console.log('[AIStoryGen] save AI nav state skipped — no AI content in DOM');
        return;
      }
      _aiNavHistory[_aiReplaceOriginPassage] = {
        aiHTML: aiHTML,
        targetLabel: _aiReplaceTargetLabel,
        targetPassage: _aiReplaceTargetPassage,
        originalLinkId: _aiReplaceOriginalLinkId,
        originalEventMode: _aiReplaceOriginalEventMode,
        roundCount: _aiReplaceRoundCount,
        savedAt: Date.now()
      };
      console.log('[AIStoryGen] saved AI nav state for passage="' + _aiReplaceOriginPassage + '" htmlLen=' + aiHTML.length);
    } catch (e) {
      console.warn('[AIStoryGen] save AI nav state failed', e);
    }
  }

  // Restore AI replace state from navigation history if available for current passage
  function restoreAINavStateIfNeeded(passageName) {
    try {
      if (_isAISaveRestoreSuppressed()) return false;
      var saved = _aiNavHistory[passageName];
      if (!saved) return false;
      // Don't restore stale entries (>5 min)
      if (Date.now() - saved.savedAt > 5 * 60 * 1000) {
        delete _aiNavHistory[passageName];
        return false;
      }

      console.log('[AIStoryGen] restoring AI nav state for passage="' + passageName + '"');

      var $passage = $('#passages .passage');
      if (!$passage.length) return false;

      // Clean up any leftover AI panels from previous passages.
      _clearAiOverlayResidue($passage, 'replace');
      var $owNav = $passage.find('.ai-original-wrap');
      if ($owNav.length) $owNav.replaceWith($owNav.contents());
      $('#passages .ai-choices').remove();

      // Hide original passage content (same pattern as handleLocationReplace)
      var $overlayKeep = _detachNativeOverlayKeepers($passage);
      _hidePassageOriginalContent($passage);
      if ($overlayKeep.length) $passage.append($overlayKeep);

      // Restore AI replace state variables
      _aiReplaceActive = true;
      _aiReplaceOriginPassage = passageName;
      _aiReplaceTargetLabel = saved.targetLabel;
      _aiReplaceTargetPassage = _normalizePassageName(saved.targetPassage);
      _aiReplaceOriginalLinkId = saved.originalLinkId || '';
      _aiReplaceOriginalEventMode = !!saved.originalEventMode;
      _aiReplaceRoundCount = saved.roundCount;
      _refreshOriginalEventModeFromLink();

      // Restore AI content
      var $aiWrap = $('<div class="ai-replaced-content"></div>');
      $aiWrap.html(saved.aiHTML);
      $passage.append($aiWrap);
      _repairStaleEventModeUI($aiWrap);

      // Auto-generate fresh AI choices for continued exploration
      if (!_aiReplaceOriginalEventMode) autoInjectChoices(passageName, saved.targetLabel, saved.targetPassage);

      // Clean up old entry (one-shot restore)
      delete _aiNavHistory[passageName];

      return true;
    } catch (e) {
      console.warn('[AIStoryGen] restore AI nav state failed', e);
      return false;
    }
  }

  function _isApiConfigured(cfg) {
    cfg = cfg || loadCfg();
    var localEndpoint = /^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?\//i.test(cfg.endpoint || '');
    return (!!(cfg.apiKey && String(cfg.apiKey).trim().length > 3)) || localEndpoint;
  }

  function _apiNotConfiguredText(cfg) {
    cfg = cfg || loadCfg();
    return cfg.language === 'zh'
      ? '请先在侧边栏「OPTIONS/设置 → 织境空间」中配置 API 密钥，才能使用 AI 功能。'
      : 'Configure your API Key in the sidebar OPTIONS overlay → Woven Realm before using AI features.';
  }

  function _makeApiWarnBlock(cfg, opts) {
    opts = opts || {};
    var $w = $('<div class="ai-api-warn ai-gen-error"></div>')
      .css({
        margin: opts.compact ? '0.4em 0' : '0.8em 0',
        padding: '0.6em 1em',
        border: '1px solid #c44',
        background: 'rgba(200, 40, 40, 0.2)',
        color: '#ff6666',
        textAlign: 'center',
        fontWeight: 'bold',
        lineHeight: '1.45',
      })
      .text(_apiNotConfiguredText(cfg));
    if (opts.bar) $w.addClass('ai-api-warn-bar');
    if (opts.userMsg) $w.addClass('ai-user-msg');
    return $w;
  }

  function _showAIUserMessage(msg, persistent) {
    $('#passages > .ai-user-msg').remove();
    var $m = _makeApiWarnBlock(loadCfg(), { userMsg: true }).text(msg);
    _mountAiPassageNotice($m, 'user-message', {
      zoneId: 'wovenrealm-passage-notices',
      mode: 'prepend',
      getRoot: function () { return $('#passages'); }
    });
    if (!persistent) {
      setTimeout(function () { $m.fadeOut(400, function () { $(this).remove(); }); }, 10000);
    }
  }

  function _clearAIUserMessage() {
    try { $('#passages > .ai-user-msg').remove(); } catch (e) {}
  }

  function _appendChoiceRetryButton($container, cfg, onRetry) {
    if (!$container || !$container.length || typeof onRetry !== 'function') return;
    $container.find('.ai-choices-retry-row').remove();
    var retryTxt = cfg.language === 'zh' ? '刷新选项' : 'Refresh choices';
    var reportFileTxt = cfg.language === 'zh' ? '报告到文件' : 'Report to file';
    var reportClipTxt = cfg.language === 'zh' ? '报告到剪贴板' : 'Report to clipboard';
    var reportIssueTxt = cfg.language === 'zh' ? '复制反馈模板' : 'Copy issue template';
    var $row = $('<div class="ai-choices-retry-row" style="margin-top:0.5em;"></div>');
    var $btn = $('<button class="ai-regen-btn"></button>').text(retryTxt);
    var $reportFileBtn = $('<button class="ai-regen-btn"></button>').css('margin-left', '0.5em').text(reportFileTxt);
    var $reportClipBtn = $('<button class="ai-regen-btn"></button>').css('margin-left', '0.5em').text(reportClipTxt);
    var $reportIssueBtn = $('<button class="ai-regen-btn"></button>').css('margin-left', '0.5em').text(reportIssueTxt);
    $btn.on('click', function () {
      $row.remove();
      onRetry();
    });
    $reportFileBtn.on('click', function () { exportAIErrorReportToFile(); });
    $reportClipBtn.on('click', function () { exportAIErrorReportToClipboard(); });
    $reportIssueBtn.on('click', function () { exportAIErrorIssueTemplateToClipboard(); });
    $row.append($btn).append($reportFileBtn).append($reportClipBtn).append($reportIssueBtn);
    $container.append($row);
  }

  function _getSexModeContextText() {
    var parts = [];
    try { parts.push(_extractCurrentAiStoryText()); } catch (e) {}
    try {
      var $ai = $('#passages .passage .ai-replaced-content, #passages .passage .ai-narrative-wrap, #passages .passage .ai-story-current, #passages .passage .ai-story-text').clone();
      $ai.find(OptionalAddonBridge.cloneCleanupSelector('script, style, input, textarea, select, button, a[data-passage], .ai-narrative-toolbar, .ai-memory-inline, .ai-item-use-panel, .ai-back-to-game, .ai-choices, .ai-choices-end, .ai-reload-scene-panel, .ai-pixel-panel, .ai-pixelgen-panel, [data-ai-pixel-panel]')).remove();
      parts.push($ai.text());
    } catch (e2) {}
    try {
      if (!_isGameMenuPassage((typeof State !== 'undefined' && State.passage) || '') && !_isShopOrUIPage()) {
        var $page = $('#passages .passage').clone();
        $page.find(OptionalAddonBridge.cloneCleanupSelector('script, style, input, textarea, select, button, a[data-passage], .link-internal, .macro-link, .ai-cfg, .ai-unified-settings, .ai-merged-settings, .apg-panel-wrap, #settingsOptions, #settingsDiv, #customOverlayContent, .ai-narrative-toolbar, .ai-memory-inline, .ai-item-use-panel, .ai-back-to-game, .ai-choices, .ai-choices-end, .ai-reload-scene-panel, .ai-pixel-panel, .ai-pixelgen-panel, [data-ai-pixel-panel]')).remove();
        parts.push($page.text());
      }
    } catch (e3) {}
    return parts.join('\n').replace(/\s+/g, ' ').slice(0, 6000);
  }

  function _shouldShowSexModeOption(extraText) {
    if (!_isAISexModeEnabled()) return false;
    return NativeTargetDetector.shouldShowOption({
      triggerMode: Number(loadCfg().sexModeTriggerMode || DEFAULT_CFG.sexModeTriggerMode) || DEFAULT_CFG.sexModeTriggerMode,
      combatActive: _isNativeCombatActive(),
      contextText: _getSexModeContextText()
    });
  }

  function _runNativeWikifier(setup) {
    if (!setup) return true;
    try {
      if (typeof Wikifier === 'undefined') return false;
      var tmp = document.createElement('span');
      new Wikifier(tmp, setup);
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] native Wikifier setup failed', e); } catch (e2) {}
      return false;
    }
  }

  function _clearNativeNpcEventState(decision) {
    var V = _getStateVariables();
    if (!V || !V.event) return false;
    var clearNpcState = !!(decision && decision.clearNpcState);
    if (clearNpcState && _runNativeWikifier('<<clearnpc>>')) {
      return true;
    }
    try {
      if (typeof EventSystem !== 'undefined' && EventSystem && typeof EventSystem.clear === 'function') {
        EventSystem.clear();
      } else {
        delete V.event;
      }
    } catch (_) {
      try { delete V.event; } catch (_) {}
    }
    if (clearNpcState) {
      try {
        V.enemyno = 0;
        V.enemynomax = 0;
        ['npc', 'npcnum', 'npcrow'].forEach(function (key) {
          if (Array.isArray(V[key])) V[key].splice(0);
        });
        if (Array.isArray(V.NPCList) && typeof setup !== 'undefined' && setup && setup.baseNPC) {
          for (var i = 0; i < V.NPCList.length; i++) {
            if (typeof clone === 'function') V.NPCList[i] = clone(setup.baseNPC);
            else V.NPCList[i] = Object.assign({}, setup.baseNPC);
          }
        }
      } catch (_) {}
    }
    return true;
  }

  function _formatNativeNpcName(name) {
    name = String(name || '').trim();
    if (/^[A-Za-z][A-Za-z0-9_-]*$/.test(name)) return name;
    return JSON.stringify(name);
  }

  function _nativeNpcSetup(npc, suffix) {
    npc = String(npc || '').trim();
    if (!npc) return '';
    return '<<npc ' + _formatNativeNpcName(npc) + (suffix || '') + '>>';
  }

  var NativeTargetDetector = NativeTargetDetectorModule.create({
    getContextText: _getSexModeContextText,
    getPassageName: _getNativeScenePassageName,
    getStructuredTargets: _getStructuredNativeSexTargets,
    isCombatActive: _isNativeCombatActive,
    buildNpcSetup: _nativeNpcSetup
  });
  window.AIStoryGen.nativeTargetDetector = NativeTargetDetector;
  window.AIStoryGen.NativeTargetDetector = NativeTargetDetector;

  var NativeEventGuard = NativeEventGuardModule.create({
    getCurrentPassage: function () {
      return (typeof State !== 'undefined' && State.passage) || '';
    },
    getEventBuffer: function () {
      var V = _getStateVariables();
      return V && V.event && Array.isArray(V.event.buffer) ? V.event.buffer : [];
    },
    getActiveNpcCount: function () {
      return _getNativeEventActiveNpcCount(_getStateVariables());
    },
    isReplaceActive: function () {
      return !!_aiReplaceActive;
    },
    isCombatActive: _isNativeCombatActive,
    clearEventQueue: function (decision) {
      var V = _getStateVariables();
      if (!V || !V.event) return false;
      _clearNativeNpcEventState(decision || {});
      try {
        if (typeof State !== 'undefined' && State.active && State.active.variables) {
          delete State.active.variables.event;
        }
      } catch (_) {}
      try { console.warn('[AIStoryGen] cleared stale native event queue', decision); } catch (_) {}
      return true;
    }
  });
  window.AIStoryGen.nativeEventGuard = NativeEventGuard;
  window.AIStoryGen.NativeEventGuard = NativeEventGuard;

  function _clearStaleNativeEventLoopForLink(link, reason) {
    try {
      if (!link || !NativeEventGuard || typeof NativeEventGuard.clearForOriginalLink !== 'function') return false;
      var V = _getStateVariables();
      if (!V || !V.event || !Array.isArray(V.event.buffer)) return false;
      return NativeEventGuard.clearForOriginalLink({
        currentPassage: (typeof State !== 'undefined' && State.passage) || '',
        targetPassage: link.getAttribute('data-passage') || '',
        linkText: (link.innerText || link.textContent || '').replace(/\s+/g, ' ').trim(),
        eventBuffer: V.event.buffer,
        replaceActive: !!_aiReplaceActive,
        combatActive: _isNativeCombatActive(),
        reason: reason || ''
      });
    } catch (e) {
      try { console.warn('[AIStoryGen] stale native event loop guard failed', e); } catch (_) {}
      return false;
    }
  }

  function _clearOrphanedNativeEventQueueAfterPassageDisplay(reason) {
    try {
      if (!NativeEventGuard || typeof NativeEventGuard.clearOrphanedQueue !== 'function') return false;
      var V = _getStateVariables();
      if (!V || !V.event || !Array.isArray(V.event.buffer) || !V.event.buffer.length) return false;
      var currentPassage = (typeof State !== 'undefined' && State.passage) || '';
      var activeNpcCount = _getNativeEventActiveNpcCount(V);
      var cleared = NativeEventGuard.clearOrphanedQueue({
        currentPassage: currentPassage,
        eventBuffer: V.event.buffer,
        activeNpcCount: activeNpcCount,
        replaceActive: !!_aiReplaceActive,
        combatActive: _isNativeCombatActive(),
        reason: reason || 'passagedisplay'
      });
      if (!cleared && typeof NativeEventGuard.clearEscapedActiveEvent === 'function') {
        cleared = NativeEventGuard.clearEscapedActiveEvent({
          currentPassage: currentPassage,
          currentIsMajorArea: _isNativeMajorAreaPassage(currentPassage),
          eventBuffer: V.event.buffer,
          activeNpcCount: activeNpcCount,
          replaceActive: !!_aiReplaceActive,
          combatActive: _isNativeCombatActive(),
          reason: reason || 'passagedisplay'
        });
      }
      if (!cleared) return false;
      _removeNativeNpcEventErrorDom();
      try { if (typeof UIBar !== 'undefined' && UIBar.update) UIBar.update(); } catch (_) {}
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] orphaned native event queue guard failed', e); } catch (_) {}
      return false;
    }
  }

  function _clearEscapedNativeEventBeforeAiDirectNavigation(targetPassage, reason) {
    try {
      if (!NativeEventGuard || typeof NativeEventGuard.clearEscapedActiveEvent !== 'function') return false;
      var V = _getStateVariables();
      if (!V || !V.event || !Array.isArray(V.event.buffer) || !V.event.buffer.length) return false;
      return NativeEventGuard.clearEscapedActiveEvent({
        currentPassage: _normalizePassageName(targetPassage || ''),
        currentIsMajorArea: _isNativeMajorAreaPassage(targetPassage),
        eventBuffer: V.event.buffer,
        activeNpcCount: _getNativeEventActiveNpcCount(V),
        replaceActive: false,
        combatActive: _isNativeCombatActive(),
        reason: reason || 'AI direct native navigation'
      });
    } catch (e) {
      try { console.warn('[AIStoryGen] escaped native event pre-navigation guard failed', e); } catch (_) {}
      return false;
    }
  }

  function _buildSingleNativeSexSetup(target) {
    if (!target) return '';
    if (target.npc) return '<<endcombat>><<set $sexstart to 1>>' + _nativeNpcSetup(target.npc, '') + '<<person1>>';
    return target.setup || '';
  }

  function _getNativeSexCandidateTemplates() {
    return NativeTargetDetector.getCandidateTemplates();
  }
  function _findNativeSexTemplateByName(name) {
    return NativeTargetDetector.findTemplateByName(name, { structured: true });
  }
  function _getStructuredNativeSexTargets() {
    var log = _getAiEventLog();
    if (!log || !log.length) return [];
    var event = log[log.length - 1] || {};
    if (!event || !event.summary) return [];
    if (event.createdAt && Date.now() - Number(event.createdAt) > 30 * 60 * 1000) return [];
    var names = _dedupeTextList(event.sexTargets && event.sexTargets.length
      ? event.sexTargets
      : _aiEventPresentTargets(event));
    if (!names.length) return [];
    var out = [];
    names.forEach(function (name) {
      var target = _findNativeSexTemplateByName(name);
      if (!target) return;
      for (var i = 0; i < out.length; i++) {
        if (out[i].label === target.label && out[i].passage === target.passage) return;
      }
      out.push(target);
    });
    return out;
  }

  function _getDirectNativeSexTargets(contextText) {
    return NativeTargetDetector.collectTargets(contextText);
  }
  function _getNativeScenePassageName() {
    try { return String((typeof State !== 'undefined' && State.passage) || '').trim(); } catch (_) {}
    return '';
  }

  function _summarizeNativeSexTarget(target) {
    if (!target) return null;
    return {
      label: String(target.label || target.npc || target.passage || '').trim(),
      npc: target.npc || '',
      passage: target.passage || '',
      manual: !!target.manual,
      custom: !!target.custom,
      structured: !!target.structured
    };
  }

  // Public Woven Realm no longer owns the legacy AI intimate scene engine.
  // The optional AIStoryGenIntimateAddon owns custom intimate scenes, visual
  // layers, action packs, native entry bridges, and settlement. These stubs
  // only preserve old public API call sites long enough to clean stale UI/state.
  function _isAIIntimateModePassage(name) {
    return false;
  }

  function _captureAIIntimateSceneForSave() {
    return null;
  }

  function _clearAIIntimateScene(reason) {
    OptionalAddonBridge.clearIntimateSceneDom();
    try { _persistAIIntimateScene(reason || 'public intimate cleanup'); } catch (_) {}
  }

  function _persistAIIntimateScene(reason) {
    try {
      function write(vars) {
        if (!vars || typeof vars !== 'object') return;
        delete vars.aiStoryGenIntimateScene;
        _patchAIStoryGenStateField(vars, 'intimateScene', null);
      }
      write(_getStateVariables());
      try { if (typeof State !== 'undefined' && State.active && State.active.variables) write(State.active.variables); } catch (_) {}
      try {
        if (typeof State !== 'undefined' && Array.isArray(State.history) && State.activeIndex != null && State.history[State.activeIndex] && State.history[State.activeIndex].variables) {
          write(State.history[State.activeIndex].variables);
        }
      } catch (_) {}
      try {
        if (typeof State !== 'undefined' && Array.isArray(State._history) && State.activeIndex != null && State._history[State.activeIndex] && State._history[State.activeIndex].variables) {
          write(State._history[State.activeIndex].variables);
        }
      } catch (_) {}
      _syncAIStoryGenStateToCurrentSave(reason || 'public-intimate-cleanup');
    } catch (e) {
      try { console.warn('[AIStoryGen] public intimate cleanup failed', e); } catch (_) {}
    }
  }

  function _getNativeSceneStatus(reason) {
    var sexModeEnabled = _isAISexModeEnabled();
    var passageName = _getNativeScenePassageName();
    var combatActive = _isNativeCombatActive();
    var nativeSexOrCombat = _isNativeSexOrCombatPassage(passageName);
    var targets = [];
    var shouldShow = false;
    try { targets = _getDirectNativeSexTargets().slice(0, 10); } catch (e) { targets = []; }
    try { shouldShow = sexModeEnabled && !combatActive && _shouldShowSexModeOption(); } catch (e2) { shouldShow = false; }
    var legacyUiStatus = OptionalAddonBridge.getLegacyUiStatus();
    return {
      schemaVersion: 3,
      reason: reason || '',
      aiSexModeEnabled: sexModeEnabled,
      passage: passageName,
      combatActive: combatActive,
      nativeSexOrCombatPassage: nativeSexOrCombat,
      shouldShowSexModeOption: shouldShow,
      sexTargets: targets.map(_summarizeNativeSexTarget).filter(Boolean),
      targetPickerOpen: legacyUiStatus.targetPickerOpen,
      sexModeButtons: legacyUiStatus.sexModeButtons,
      endCombatControls: $('#passages .ai-end-combat-wrap').length,
      customIntentInputs: $('#passages .ai-combat-custom').length,
      lastJump: _cloneForAiSnapshot(_lastNativeSceneJump || null)
    };
  }

  function _refreshNativeSceneControls(reason) {
    try {
      var status = _getNativeSceneStatus(reason || 'refresh');
      if (!status.aiSexModeEnabled) {
        _clearAISexModeUi();
        return _getNativeSceneStatus(reason || 'refresh disabled');
      }
      if (status.combatActive || status.nativeSexOrCombatPassage) {
        _callIntimateCombatRuntime('injectCustomIntentInputs', [], false);
      } else {
        _ensureSexModeEntryInExistingActions();
      }
      _dedupeSexModeButtons();
      try {
        if (window.AIStoryGen && window.AIStoryGen.PanelManager && typeof window.AIStoryGen.PanelManager.normalizeOrder === 'function') {
          window.AIStoryGen.PanelManager.normalizeOrder(reason || 'native scene controls');
        } else if (window.AIStoryGen && typeof window.AIStoryGen.normalizePanelOrder === 'function') {
          window.AIStoryGen.normalizePanelOrder();
        }
      } catch (_) {}
      return _getNativeSceneStatus(reason || 'refresh complete');
    } catch (e) {
      try { console.warn('[AIStoryGen] native scene control refresh failed', e); } catch (_) {}
      return _getNativeSceneStatus('refresh failed');
    }
  }

  function _clearSexTargetPicker() {
    return OptionalAddonBridge.clearTargetPicker();
  }

  function _hideAiPanelsForSettings() {
    try {
      _clearSexTargetPicker();
      $('#passages .ai-choices, #passages .ai-choices-end').attr('data-ai-hidden-settings', '1').hide();
    } catch (e) {}
  }

  function _restoreAiPanelsAfterSettings() {
    try {
      $('#passages .ai-choices[data-ai-hidden-settings], #passages .ai-choices-end[data-ai-hidden-settings]')
        .removeAttr('data-ai-hidden-settings')
        .show();
    } catch (e) {}
  }

  function _prepareNativeModeJump() {
    if (!_isAISexModeEnabled()) return;
    var $passage = $('#passages .passage');
    if ($passage.length) {
      $passage.find('.ai-replaced-content, .ai-narrative-wrap').remove();
      _aiNarrativeWrap = null;
      var $ow = $passage.find('.ai-original-wrap');
      if ($ow.length) $ow.replaceWith($ow.contents());
    }
    _aiReplaceActive = false;
    _aiReplaceOriginPassage = '';
    _aiReplaceSessionHTML = '';
    _pendingAISaveState = null;
    try { _writeAISaveStateToVariables(_getStateVariables(), null); } catch (_) {}
    try { if (typeof State !== 'undefined' && State.active && State.active.variables) _writeAISaveStateToVariables(State.active.variables, null); } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State.history) && State.activeIndex != null && State.history[State.activeIndex] && State.history[State.activeIndex].variables) {
        _writeAISaveStateToVariables(State.history[State.activeIndex].variables, null);
      }
    } catch (_) {}
    try {
      if (typeof State !== 'undefined' && Array.isArray(State._history) && State.activeIndex != null && State._history[State.activeIndex] && State._history[State.activeIndex].variables) {
        _writeAISaveStateToVariables(State._history[State.activeIndex].variables, null);
      }
    } catch (_) {}
    $('#passages .ai-choices, #passages .ai-choices-end').remove();
    _clearSexTargetPicker();
    _clearAiRoundHistory();
  }

  function _showNativeSexTargetPicker(targets, opts) {
    opts = opts || {};
    _clearSexTargetPicker();
    var mode = opts.mode === 'ai' ? 'ai' : 'native';
    var addon = _getIntimateAddonApi();
    if (addon && mode === 'ai' && typeof addon.enterCustom === 'function') {
      try { addon.enterCustom(targets || []); } catch (e0) { _showAIUserMessage('亲密扩展入口调用失败：' + (e0 && e0.message ? e0.message : e0), true); }
      return;
    }
    if (addon && mode === 'native' && typeof addon.enterNative === 'function') {
      try { addon.enterNative(targets || []); } catch (e1) { _showAIUserMessage('亲密扩展入口调用失败：' + (e1 && e1.message ? e1.message : e1), true); }
      return;
    }
    _clearAISexModeUi();
  }

  function _buildNativeSexSetupForTargets(targets) {
    targets = (targets || []).filter(Boolean).slice(0, 10);
    if (targets.length <= 1) return targets[0] ? (targets[0].setup || _buildSingleNativeSexSetup(targets[0])) : '';
    var chunks = ['<<endcombat>>', '<<set $sexstart to 1>>'];
    if (targets[0].preSetup) chunks.push(targets[0].preSetup);
    var personIndex = 1;
    for (var i = 0; i < targets.length && personIndex <= 10; i++) {
      if (!targets[i].npc) continue;
      chunks.push(_nativeNpcSetup(targets[i].npc, '') + '<<person' + personIndex + '>>');
      personIndex++;
    }
    if (personIndex === 1) return targets[0].setup;
    return chunks.join('');
  }

  function _buildNativeNamedGroupSexSetup(targets) {
    targets = (targets || []).filter(function (target) { return target && target.npc; }).slice(0, 10);
    if (targets.length <= 1) return targets[0] ? targets[0].setup : '';
    var chunks = ['<<endcombat>>'];
    if (targets[0].preSetup) chunks.push(targets[0].preSetup);
    chunks.push('<<clearnpc>>');
    chunks.push('<<set $sexstart to 1>>');
    for (var i = 0; i < targets.length; i++) {
      chunks.push(_nativeNpcSetup(targets[i].npc, ' -1'));
    }
    return chunks.join('');
  }

  var _lastNativeSceneJump = null;

  function _rememberNativeSceneJump(data) {
    _lastNativeSceneJump = Object.assign({ at: Date.now() }, data || {});
    return _lastNativeSceneJump;
  }

  function _preflightNativeSexTarget(target) {
    if (!target) return { ok: false, reason: 'missing target' };
    var passage = String(target.passage || '').trim();
    if (!passage) return { ok: false, reason: 'missing passage', label: target.label || target.npc || '' };
    if (!_nativeStoryHas(passage)) {
      return { ok: false, reason: 'passage not found', passage: passage, label: target.label || target.npc || passage };
    }
    return { ok: true, passage: passage, label: target.label || target.npc || passage };
  }

  function _jumpNativeSexTargets(targets) {
    if (!_isAISexModeEnabled()) {
      _clearAISexModeUi();
      return false;
    }
    targets = (targets || []).filter(Boolean).slice(0, 10);
    if (!targets.length) return false;
    if (targets.length === 1) return _jumpNativeSexTarget(targets[0]);
    var namedTargets = targets.filter(function (target) { return target && target.npc; }).slice(0, 10);
    if (namedTargets.length > 1) {
      var namedBase = Object.assign({}, namedTargets[0], {
        label: namedTargets.map(function (t) { return t.label; }).join('\u3001'),
        passage: 'Named NPC Gangbang',
        setup: _buildNativeNamedGroupSexSetup(namedTargets)
      });
      return _jumpNativeSexTarget(namedBase);
    }
    var base = Object.assign({}, targets[0], {
      label: targets.map(function (t) { return t.label; }).join('\u3001'),
      setup: _buildNativeSexSetupForTargets(targets)
    });
    return _jumpNativeSexTarget(base);
  }

  function _jumpNativeSexTarget(direct) {
    var cfg = loadCfg();
    if (!_isAISexModeEnabled(cfg)) {
      _clearAISexModeUi();
      return false;
    }
    var directEngine = _getNativeEngine();
    if (!direct || !direct.passage || !directEngine || !directEngine.play) return false;
    var preflight = _preflightNativeSexTarget(direct);
    if (!preflight.ok) {
      _rememberNativeSceneJump(Object.assign({ ok: false }, preflight));
      _showAIUserMessage(cfg.language === 'zh'
        ? ('\u6682\u65f6\u4e0d\u80fd\u8fdb\u5165\u300c' + (preflight.label || direct.label || direct.passage) + '\u300d\u7684\u539f\u7248\u573a\u666f\uff1a' + preflight.reason)
        : ('Cannot enter native scene for ' + (preflight.label || direct.label || direct.passage) + ': ' + preflight.reason), true);
      return false;
    }
    if (!_runNativeWikifier(direct.setup)) {
      _rememberNativeSceneJump({ ok: false, reason: 'setup failed', passage: direct.passage, label: direct.label || direct.passage });
      _showAIUserMessage(cfg.language === 'zh'
        ? ('\u672a\u80fd\u521d\u59cb\u5316\u4e0e\u300c' + direct.label + '\u300d\u7684\u539f\u7248\u573a\u666f\uff0c\u5df2\u4fdd\u7559\u5f53\u524dAI\u5267\u60c5\u9875\u9762\u3002')
        : ('Could not initialise the native scene with ' + direct.label + '. The current AI story page was kept.'), true);
      return false;
    }
    _prepareNativeModeJump();
    _rememberNativeSceneJump({ ok: true, reason: 'jump scheduled', passage: direct.passage, label: direct.label || direct.passage });
    setTimeout(function () {
      try {
        directEngine.play(direct.passage);
      } catch (e) {
        _rememberNativeSceneJump({ ok: false, reason: 'Engine.play failed', passage: direct.passage, label: direct.label || direct.passage });
        _showAIUserMessage(cfg.language === 'zh'
          ? ('\u5df2\u627e\u5230\u300c' + direct.label + '\u300d\u7684\u539f\u7248\u573a\u666f\uff0c\u4f46\u8df3\u8f6c\u5931\u8d25\u3002')
          : ('Found the native scene for ' + direct.label + ', but the jump failed.'), true);
      }
    }, 0);
    return true;
  }

  function _enterNativeSexMode() {
    var cfg = loadCfg();
    var addon = _getIntimateAddonApi();
    if (addon && typeof addon.enterNative === 'function') {
      try { addon.enterNative(); } catch (e0) { _showAIUserMessage((cfg.language === 'zh' ? '亲密扩展入口调用失败：' : 'Intimate addon entry failed: ') + (e0 && e0.message ? e0.message : e0), true); }
      return;
    }
    if (!_isAISexModeEnabled(cfg)) {
      _clearAISexModeUi();
      return;
    }
    var directTargets = _getDirectNativeSexTargets();
    _clearAIUserMessage();
    if (directTargets.length >= 1) {
      _showNativeSexTargetPicker(directTargets, { mode: 'native' });
      return;
    }
    _showAIUserMessage(cfg.language === 'zh'
      ? '\u5f53\u524d\u5267\u60c5\u6ca1\u6709\u660e\u786e\u5728\u573a\u4e14\u53ef\u8fdb\u5165\u8272\u8272\u6a21\u5f0f\u7684\u5bf9\u8c61\u3002'
      : 'The current story has no clearly present target for sex mode.', false);
  }

  function _enterAIIntimateMode() {
    var cfg = loadCfg();
    var addon = _getIntimateAddonApi();
    if (addon && typeof addon.enterCustom === 'function') {
      try { addon.enterCustom(); } catch (e0) { _showAIUserMessage((cfg.language === 'zh' ? '亲密扩展入口调用失败：' : 'Intimate addon entry failed: ') + (e0 && e0.message ? e0.message : e0), true); }
      return;
    }
    if (!_isAISexModeEnabled(cfg)) {
      _clearAISexModeUi();
      return;
    }
    var directTargets = _getDirectNativeSexTargets();
    _clearAIUserMessage();
    if (directTargets.length >= 1) {
      _showNativeSexTargetPicker(directTargets, { mode: 'ai' });
      return;
    }
    _showAIUserMessage(cfg.language === 'zh'
      ? '\u5f53\u524d\u5267\u60c5\u6ca1\u6709\u660e\u786e\u5728\u573a\u7684\u5bf9\u8c61\uff0c\u4e0d\u80fd\u5f00\u59cb\u8272\u8272\u6a21\u5f0f\u751f\u6210\u3002'
      : 'The current story has no clearly present target for AI free sex-mode generation.', false);
  }

  function _refreshApiWarnBar() {
    var cfg = loadCfg();
    $('#passages > .ai-api-warn-bar').remove();
    if (_isApiConfigured(cfg)) return;
    if (typeof State !== 'undefined' && State.passage && _isGameMenuPassage(State.passage)) return;
    _mountAiPassageNotice(_makeApiWarnBlock(cfg, { bar: true }), 'api-warn-bar', {
      zoneId: 'wovenrealm-passage-notices',
      mode: 'append',
      getRoot: function () { return $('#passages'); }
    });
  }

  function _preflightAI(cfg) {
    if (!_isApiConfigured(cfg)) {
      throw new AIError(AIErrorType.NOT_CONFIGURED, _apiNotConfiguredText(cfg));
    }
    if (!cfg.endpoint) {
      throw new AIError(AIErrorType.NOT_CONFIGURED,
        cfg.language === 'zh' ? '未配置 API 地址。' : 'API endpoint not set.');
    }
  }

  function _recoverFromFailedReplace(cfg, errMsg) {
    var $passage = $('#passages .passage');
    if ($passage.length) {
      _clearAiOverlayResidue($passage, 'native');
      var $ow = $passage.find('.ai-original-wrap');
      if ($ow.length) $ow.replaceWith($ow.contents());
    }
    _aiReplaceActive = false;
    _aiReplaceOriginPassage = '';
    _aiReplaceSessionHTML = '';
    _clearAiRoundHistory();
    $('#passages .ai-choices, #passages .ai-choices-end').remove();
    if (errMsg) _showAIUserMessage(errMsg);
    setTimeout(function () { injectAILinkClones(); }, 50);
  }

  function _selectNativeOverlayKeepers($scope) {
    var $root = ($scope && $scope.length) ? $scope : $('#passages .passage');
    if (!$root.length) return $();
    var $keepers = $root.find('#customOverlayContainer, #debugOverlay');
    var $looseOverlay = $root.find('#customOverlay').filter(function () {
      return !$(this).closest('#customOverlayContainer').length;
    });
    if ($root.is && $root.is('#customOverlayContainer, #debugOverlay')) $keepers = $keepers.add($root);
    if ($root.is && $root.is('#customOverlay') && !$root.closest('#customOverlayContainer').length) $looseOverlay = $looseOverlay.add($root);
    return $keepers.add($looseOverlay);
  }

  function _detachNativeOverlayKeepers($passage) {
    return _selectNativeOverlayKeepers($passage).detach();
  }

  function _hoistNativeOverlayKeepers(reason) {
    try {
      var $passage = $('#passages .passage');
      if (!$passage.length) return false;
      var moved = false;
      _selectNativeOverlayKeepers($passage).each(function () {
        var parent = this.parentNode;
        if (!parent || parent !== $passage[0] || $(this).closest('.ai-original-wrap').length) {
          $(this).detach().appendTo($passage);
          moved = true;
        }
      });
      if (moved) {
        try { console.log('[AIStoryGen] hoisted native overlay out of hidden AI original wrap' + (reason ? ': ' + reason : '')); } catch (_) {}
      }
      return moved;
    } catch (_) {
      return false;
    }
  }

  var _nativeOverlayHoistTimers = {};
  var _lastNativeOverlayTouchEndAt = 0;

  function _scheduleNativeOverlayHoist(reason, delay) {
    delay = Math.max(0, Number(delay || 0));
    var timerKey = String(delay);
    if (_nativeOverlayHoistTimers[timerKey]) clearTimeout(_nativeOverlayHoistTimers[timerKey]);
    _nativeOverlayHoistTimers[timerKey] = setTimeout(function () {
      delete _nativeOverlayHoistTimers[timerKey];
      _hoistNativeOverlayKeepers(reason);
    }, delay);
  }

  function _installNativeOverlayHoistHooks() {
    if (window.AIStoryGen && window.AIStoryGen._nativeOverlayHoistInstalled) return;
    if (window.AIStoryGen) window.AIStoryGen._nativeOverlayHoistInstalled = true;
    try {
      document.addEventListener('click', function () {
        if (Date.now() - _lastNativeOverlayTouchEndAt < 700) return;
        _scheduleNativeOverlayHoist('click', 0);
        _scheduleNativeOverlayHoist('click delayed', 80);
        _scheduleNativeOverlayHoist('click late', 250);
      }, true);
      document.addEventListener('touchend', function () {
        _lastNativeOverlayTouchEndAt = Date.now();
        _scheduleNativeOverlayHoist('touchend', 0);
        _scheduleNativeOverlayHoist('touchend delayed', 80);
        _scheduleNativeOverlayHoist('touchend late', 250);
      }, true);
    } catch (_) {}
    try {
      $(document).on(':passagedisplay.aiStoryGenOverlayHoist :passagerender.aiStoryGenOverlayHoist', function () {
        _scheduleNativeOverlayHoist('passage render', 0);
        _scheduleNativeOverlayHoist('passage render delayed', 150);
      });
    } catch (_) {}
    try {
      if (window.MutationObserver && document.body) {
        var obs = new MutationObserver(function (mutations) {
          for (var i = 0; i < mutations.length; i++) {
            var nodes = mutations[i].addedNodes || [];
            for (var j = 0; j < nodes.length; j++) {
              var node = nodes[j];
              if (!node || node.nodeType !== 1) continue;
              if ((node.id && /^(customOverlayContainer|customOverlay|debugOverlay)$/.test(node.id)) ||
                  (node.querySelector && node.querySelector('#customOverlayContainer,#customOverlay,#debugOverlay'))) {
                _scheduleNativeOverlayHoist('mutation', 0);
                _scheduleNativeOverlayHoist('mutation delayed', 80);
                return;
              }
            }
          }
        });
        obs.observe(document.body, { childList: true, subtree: true });
        window.AIStoryGen._nativeOverlayHoistObserver = obs;
      }
    } catch (_) {}
  }

  _installNativeOverlayHoistHooks();

  function _hidePassageOriginalContent($passage) {
    if (!$passage || !$passage.length) return;
    $passage.find('.ai-injected-row').remove();
    if ($passage.find('> .ai-original-wrap, .ai-original-wrap').length) return;
    var $overlayKeep = _detachNativeOverlayKeepers($passage);
    var wrapDiv = document.createElement('div');
    wrapDiv.className = 'ai-original-wrap';
    wrapDiv.style.display = 'none';
    var passageEl = $passage[0];
    while (passageEl.childNodes.length > 0) {
      wrapDiv.appendChild(passageEl.childNodes[0]);
    }
    passageEl.appendChild(wrapDiv);
    if ($overlayKeep.length) $passage.append($overlayKeep);
    _scheduleNativeOverlayHoist('hide original', 0);
  }

  function _hasActiveAIOverlay($passage) {
    if (!$passage || !$passage.length) $passage = $('#passages .passage');
    if (!$passage.length) return false;
    return $passage.find('.ai-replaced-content, .ai-narrative-wrap').length > 0
      || $passage.find('.ai-gen-loading').length > 0;
  }

  function _updateReplaceSessionHTML() {
    if (!_aiReplaceActive) {
      _aiReplaceSessionHTML = '';
      return;
    }
    var $aiWrap = $('#passages .passage .ai-replaced-content');
    if ($aiWrap.length) _aiReplaceSessionHTML = $aiWrap.html();
  }

  // There are two mutually-exclusive AI presentation modes. Centralising their
  // transition cleanup prevents stale DOM from a prior mode leaking into Back,
  // native handoff, passage restoration, or a failed request recovery.
  function _clearAiOverlayResidue($passage, nextMode) {
    var $root = ($passage && $passage.length) ? $passage : $('#passages .passage');
    if (!$root.length) return;
    var mode = String(nextMode || 'native').toLowerCase();
    if (mode !== 'normal') {
      $root.find('.ai-narrative-wrap').remove();
      _aiNarrativeWrap = null;
    }
    if (mode !== 'replace') {
      $root.find('.ai-replaced-content').remove();
      _aiReplaceSessionHTML = '';
    }
  }

  // Re-apply cached AI overlay when SugarCube rebuilds the same passage mid-session
  function _reapplyReplaceOverlay($passage) {
    if (!$passage || !$passage.length) $passage = $('#passages .passage');
    if (!$passage.length || !_aiReplaceActive || !_aiReplaceSessionHTML) return false;
    if ($passage.find('.ai-replaced-content').length) return false;

    _clearAiOverlayResidue($passage, 'replace');
    $passage.find('.ai-injected-row').remove();
    var $overlayKeep = _detachNativeOverlayKeepers($passage);
    if (!$passage.find('.ai-original-wrap').length) {
      var wrapDiv = document.createElement('div');
      wrapDiv.className = 'ai-original-wrap';
      wrapDiv.style.display = 'none';
      var passageEl = $passage[0];
      while (passageEl.childNodes.length > 0) {
        wrapDiv.appendChild(passageEl.childNodes[0]);
      }
      passageEl.appendChild(wrapDiv);
      if ($overlayKeep.length) $passage.append($overlayKeep);
    }
    _scheduleNativeOverlayHoist('reapply replace overlay', 0);
    $passage.append($('<div class="ai-replaced-content"></div>').html(_aiReplaceSessionHTML));
    console.log('[AIStoryGen] re-applied AI replace overlay after passage re-render');
    return true;
  }

  // Safety: unhide original content when wrap is hidden but no AI overlay is present (prevents blank page)
  function _ensurePassageContentVisible() {
    var $passage = $('#passages .passage');
    if (!$passage.length) return false;
    var $origWrap = $passage.find('.ai-original-wrap');
    if ($origWrap.length) {
      var hidden = $origWrap.filter(function () {
        return this.style.display === 'none' || $(this).css('display') === 'none';
      });
      if (hidden.length && _isNativeCombatFinishPassage()) {
        console.warn('[AIStoryGen] restoring native combat settlement controls');
        hidden.replaceWith(hidden.contents());
        _removeAIChoicePanels();
        $passage.find('.ai-injected-row, .ai-injected-link').remove();
        return true;
      }
      if (hidden.length && !_hasActiveAIOverlay($passage)) {
        console.warn('[AIStoryGen] recovering hidden original content (no active AI overlay)');
        hidden.replaceWith(hidden.contents());
        if (_aiReplaceActive) {
          _aiReplaceActive = false;
          _aiReplaceOriginPassage = '';
          _aiReplaceSessionHTML = '';
          _clearAiRoundHistory();
        }
        setTimeout(function () { injectAILinkClones(); }, 50);
        return true;
      }
    }
    // Stale replace flag: overlay lost after passage rebuild
    if (_aiReplaceActive && !_hasActiveAIOverlay($passage) && !$origWrap.length) {
      console.warn('[AIStoryGen] clearing stale AI replace state (overlay lost after passage rebuild)');
      _aiReplaceActive = false;
      _aiReplaceOriginPassage = '';
      _aiReplaceSessionHTML = '';
      _clearAiRoundHistory();
      setTimeout(function () { injectAILinkClones(); }, 50);
      return true;
    }
    return false;
  }

  // Back-compat alias
  function _ensureOriginalVisible() {
    _ensurePassageContentVisible();
  }

  function _removeAIChoicePanels() {
    $('#passages .ai-choices, #passages .ai-choices-end').remove();
  }

  function _removeAINativeExitPanels() {
    _abortCurrentAIRequest('native exit panel cleanup');
    _removeAIChoicePanels();
    $('#passages .ai-manual-choice-trigger, #passages .ai-manual-arrive-panel, #passages .ai-gen-loading').remove();
    $('#passages .apg-ai-assist, #passages [data-ai-pixel-panel="1"], #passages .aipixel-panel, #passages #aipixel-panel').remove();
  }

  function _prepareAINativeExit(reason, opts) {
    opts = opts || {};
    _removeAINativeExitPanels();
    if (_aiPixelAssistRefreshTimer) {
      clearTimeout(_aiPixelAssistRefreshTimer);
      _aiPixelAssistRefreshTimer = null;
    }
    _releaseAutoChoicesBusy(reason || 'native exit');
    if (opts.suppressAutoChoices !== false) {
      _suppressAutoChoices(reason || 'native exit', opts.suppressMs || 8000);
    }
  }

  var _aiPanelLayoutTimers = {};
  var _aiPanelLayoutLastAt = 0;
  var _aiPanelLayoutRunCount = 0;
  var _AI_PANEL_LAYOUT_STALE_MS = 500;
  var _AI_PANEL_MANAGED_SELECTOR = OptionalAddonBridge.managedPanelSelector();
  var _AI_PANEL_PIXEL_SELECTOR = '.apg-ai-assist';

  function _releaseAIStoryPanelLayoutLock(reason) {
    try {
      window._aiPanelLayoutMoving = false;
      window._apgAssistOrderMoving = false;
      window._aiPanelLayoutMovingAt = 0;
      window._aiPanelLayoutMoveToken = null;
      if (reason && window.console && console.debug) console.debug('[AIStoryGen] panel layout lock released: ' + reason);
    } catch (_) {}
  }

  function _placeAIChoicesContainer($container) {
    if (!_placeAIManagedPanel($container)) return false;
    _scheduleAIChoicePixelReposition(300);
    _scheduleAIChoicePixelReposition(900);
    return true;
  }

  function _placeAIManagedPanel($container) {
    var $passages = $('#passages');
    if (!$passages.length || !$container || !$container.length) return false;
    var node = $container[0];
    var $firstPixel = $passages.children(_AI_PANEL_PIXEL_SELECTOR).first();
    if ($firstPixel.length && node !== $firstPixel[0]) {
      if (node.nextSibling !== $firstPixel[0]) $firstPixel.before(node);
    } else {
      if ($passages[0].lastElementChild !== node) $passages.append(node);
    }
    _scheduleAIChoicePixelReposition(0);
    return true;
  }

  function _directPanelChildren(selector) {
    return $('#passages').children(selector).toArray();
  }

  function _dedupeDirectPanels(selector, keyFn) {
    var seen = {};
    var removed = 0;
    $(_directPanelChildren(selector).reverse()).each(function () {
      var key = keyFn ? keyFn(this) : selector;
      key = String(key || selector);
      if (seen[key]) {
        $(this).remove();
        removed++;
        return;
      }
      seen[key] = true;
    });
    return removed;
  }

  function _panelKindForNode(node) {
    var $node = $(node);
    if ($node.hasClass('ai-choices')) return 'choices';
    if ($node.hasClass('ai-choices-end')) return 'choices-end';
    if ($node.hasClass('ai-back-to-game')) return 'back-to-game';
    var legacyKind = OptionalAddonBridge.panelKindForNode(node);
    if (legacyKind) return legacyKind;
    if ($node.hasClass('ai-reload-scene-panel')) return 'reload-scene';
    if ($node.hasClass('ai-item-use-panel')) return 'item-use';
    if ($node.hasClass('ai-memory-inline')) return 'memory-inline';
    if ($node.hasClass('ai-gen-loading')) return 'loading';
    return 'managed';
  }

  function _dedupePixelPanels() {
    return _dedupeDirectPanels(_AI_PANEL_PIXEL_SELECTOR, function (node) {
      return 'pixel:' + ($(node).attr('data-apg-mode') || 'scene');
    });
  }

  function _dedupeManagedPanels() {
    return _dedupeDirectPanels(OptionalAddonBridge.managedDedupeSelector(), function (node) {
      return _panelKindForNode(node);
    });
  }

  function _scheduleAIChoicePixelReposition(delay) {
    return _aiPanelManagerEngine.scheduleLayout(delay);
  }

  var _autoChoicesEnsureTimer = null;
  var _lastAutoChoicesEnsureKey = '';

  function _getChoiceTriggerMode(cfg) {
    cfg = cfg || loadCfg();
    var mode = String(cfg.choiceTriggerMode || '').toLowerCase();
    if (!/^(auto|manual|off)$/.test(mode)) mode = Number(cfg.autoChoices || 0) > 0 ? 'auto' : 'off';
    return mode;
  }

  function _removeManualChoiceTrigger() {
    $('#passages .ai-manual-choice-trigger').remove();
  }

  function scheduleEnsureAutoChoices(reason, delay) {
    if (_isAutoChoicesSuppressed()) return;
    if (_autoChoicesEnsureTimer) clearTimeout(_autoChoicesEnsureTimer);
    _autoChoicesEnsureTimer = setTimeout(function () {
      _autoChoicesEnsureTimer = null;
      try {
        if (_isAutoChoicesSuppressed()) return;
        var cfg = loadCfg();
        if (_getChoiceTriggerMode(cfg) !== 'auto') return;
        if (_autoChoicesBusy) return;
        var name = (typeof State !== 'undefined' && State.passage) || '';
        if (!name || _isGameMenuPassage(name)) return;
        if (!_aiReplaceActive && _isNativeCombatFinishPassage(name)) {
          _removeAIChoicePanels();
          return;
        }
        var V_check = getV();
        if (V_check && safeRead(function(){return V_check.combat;},0)===1) return;
        if (_isShopOrUIPage()) return;
        if ($('#passages .ai-choices, #passages .ai-choices-end, #passages .ai-manual-choice-trigger, #passages .ai-gen-loading').length) return;
        var key = name + '|' + ($('#passages .passage').text() || '').replace(/\s+/g, ' ').slice(0, 160);
        if (_lastAutoChoicesEnsureKey === key) return;
        _lastAutoChoicesEnsureKey = key;
        console.log('[AIStoryGen] ensuring missing AI choices' + (reason ? ': ' + reason : ''));
        autoInjectChoices(name, '', '', { force: true });
      } catch (e) {
        console.warn('[AIStoryGen] ensure AI choices failed', e);
      }
    }, delay == null ? 600 : delay);
  }

  var _aiPixelAssistRefreshTimer = null;
  function _scheduleAIPixelAssistRefresh(reason, delay) {
    if (_isAutoChoicesSuppressed()) return;
    if (_aiPixelAssistRefreshTimer) clearTimeout(_aiPixelAssistRefreshTimer);
    _aiPixelAssistRefreshTimer = setTimeout(function () {
      _aiPixelAssistRefreshTimer = null;
      try {
        if (_isAutoChoicesSuppressed()) return;
        var pixel = window.AIPixelGen;
        if (!pixel || typeof pixel.injectAIStoryAssist !== 'function') return;
        if (typeof pixel.isEnabled === 'function' && !pixel.isEnabled()) return;
        pixel.injectAIStoryAssist();
      } catch (e) {
        try { console.warn('[AIStoryGen] pixel assist refresh failed' + (reason ? ' (' + reason + ')' : ''), e); } catch (_) {}
      }
    }, delay == null ? 250 : delay);
  }

  function _installAIChoiceOrderObserver() {
    return _aiPanelManagerEngine.installOrderObserver();
  }

  var PanelManager = PanelManagerModule.create({
    publicSchemaVersion: 5,
    minFlushInterval: 90,
    getPanelRoot: function () {
      return document.getElementById('passages');
    },
    hasPanelHost: function (rootEl) {
      return !!(rootEl && $('#passages').find('.passage').length);
    },
    isLayoutMoving: function () {
      return !!window._aiPanelLayoutMoving;
    },
    isLayoutStale: function () {
      var movingAt = Number(window._aiPanelLayoutMovingAt || 0) || 0;
      return !!(movingAt && Date.now() - movingAt >= _AI_PANEL_LAYOUT_STALE_MS);
    },
    acquireLayoutLock: function (token) {
      window._aiPanelLayoutMoving = true;
      window._apgAssistOrderMoving = true;
      window._aiPanelLayoutMovingAt = Date.now();
      window._aiPanelLayoutMoveToken = token;
    },
    releaseLayoutLock: function (reason, token) {
      if (!token || window._aiPanelLayoutMoveToken === token) _releaseAIStoryPanelLayoutLock(reason);
    },
    getPanels: function (kind) {
      return kind === 'pixel'
        ? _directPanelChildren(_AI_PANEL_PIXEL_SELECTOR)
        : _directPanelChildren(_AI_PANEL_MANAGED_SELECTOR);
    },
    dedupePanels: function (kind) {
      return kind === 'pixel' ? _dedupePixelPanels() : _dedupeManagedPanels();
    },
    getChildren: function () {
      return $('#passages').children().toArray();
    },
    appendPanelNode: function (rootEl, node) {
      if (!rootEl || !node) return false;
      $(rootEl).append(node);
      return true;
    },
    markZone: function (zoneId) {
      if (_aiMountController && typeof _aiMountController.mountZone === 'function') {
        _aiMountController.mountZone(zoneId, {
          mount: function () { return true; }
        });
      }
    },
    getObserverRoot: function () {
      return document.getElementById('passages') || document.body;
    },
    countPanels: function (kind) {
      return kind === 'pixel'
        ? _directPanelChildren(_AI_PANEL_PIXEL_SELECTOR).length
        : _directPanelChildren(_AI_PANEL_MANAGED_SELECTOR).length;
    },
    dedupePixelPanels: _dedupePixelPanels,
    removeChoicePanels: _removeAIChoicePanels,
    warn: function (message, err) {
      try { console.warn(message, err); } catch (_) {}
    }
  });
  var _aiPanelManagerEngine = PanelManager;
  window.AIStoryGen.panelManager = PanelManager;
  window.AIStoryGen.PanelManager = PanelManager;
  window.AIStoryGen.layoutPanels = function () { return PanelManager.layout(); };
  window.AIStoryGen.normalizePanelOrder = function () { return PanelManager.normalizeOrder(); };
  window.AIStoryGen.repositionChoicesAbovePixel = function () { return PanelManager.normalizeOrder(); };

  function autoInjectChoices(title, targetLabel, targetPassage, opts) {
    opts = opts || {};
    if (!opts.force && !_aiReplaceActive && _isAutoChoicesSuppressed()) return;
    if (opts.force && !_aiReplaceActive && _isAutoChoicesSuppressed()) return;
    if (_autoChoicesBusy) {
      if (!opts.force) return;
      _releaseAutoChoicesBusy('forced auto choices restart');
      try { restoreErrorReporter(); } catch (_) {}
    }
    var cfg = loadCfg();
    // In AI replace mode, always allow choice generation regardless of the normal page entry mode.
    if (!_aiReplaceActive && !opts.force && _getChoiceTriggerMode(cfg) !== 'auto') return;
    if (!_aiReplaceActive && !opts.force && _sessionAutoPaused) return; // 会话暂停中
    var name = title || (typeof State !== 'undefined' && State.passage) || '';
    if (!name) return;
    if (name.indexOf('AIStoryGen_') === 0) return;
    if (_isGameMenuPassage(name)) return;
    if (!_aiReplaceActive) _syncAiLocationToNativePassage(name, 'auto choices native page');
    if (!_aiReplaceActive && _isNativeCombatFinishPassage(name)) {
      _removeAIChoicePanels();
      return;
    }
    var V_forChoices = getV();
    if (V_forChoices && safeRead(function(){return V_forChoices.combat;},0)===1) {
      _removeAIChoicePanels();
      OptionalAddonBridge.clearStandalone();
      _dedupeSexModeButtons();
      return;
    }
    // Note: _isShopOrUIPage is NOT checked here — it's only used in injectAILinkClones.
    // DOM heuristics are too fragile for blocking AI options; passage name blacklist is the primary defense.

    // Clean up any leftover AI panels from previous passages
    _removeManualChoiceTrigger();
    _removeAIChoicePanels();

    // Safety: ensure original content is visible (not hidden from a previous round)
    _ensureOriginalVisible();

    if (!_isApiConfigured(cfg)) {
      var $containerNoKey = $('<div class="ai-choices ai-choices-auto"></div>');
      $containerNoKey.append(_makeApiWarnBlock(cfg));
      _placeAIChoicesContainer($containerNoKey);
      _scheduleAIPixelAssistRefresh('api warning choices', 300);
      _refreshApiWarnBar();
      return;
    }

    _autoChoicesBusy = true;
    // Timeout protection: auto-release lock after 30s
    if (_autoChoicesBusyTimer) clearTimeout(_autoChoicesBusyTimer);
    _autoChoicesBusyTimer = setTimeout(function () {
      if (_autoChoicesBusy) {
        console.warn('[AIStoryGen] _autoChoicesBusy lock released by timeout (30s)');
        _releaseAutoChoicesBusy('timeout');
      }
    }, 30000);
    suppressErrorReporter();
    var $passages = $('#passages');
    if (!$passages.length) { _releaseAutoChoicesBusy('missing passages'); return; }

    var $container = $('<div class="ai-choices ai-choices-auto"></div>');
    var loadingTxt = cfg.language === 'zh' ? 'AI 正在生成选项…' : 'AI generating choices…';
    var $loading = $('<div class="ai-choices-loading ai-gen-loading"></div>').text(loadingTxt);
    $container.append($loading);
    _placeAIChoicesContainer($container);
    var choiceContext = _captureAutoChoiceContext(name, targetLabel, targetPassage, $container.get(0));

    var choiceRequest = _createTimedAbortController(45000);
    _currentAbortController = choiceRequest.controller;
    generateChoices(cfg, '', choiceRequest.signal, targetLabel, targetPassage).then(function (choices) {
      choiceRequest.clear();
      if (_currentAbortController === choiceRequest.controller) _currentAbortController = null;
      if (!_isAutoChoiceContextCurrent(choiceContext)) {
        try { console.warn('[AIStoryGen] discard stale AI choices for passage: ' + choiceContext.passage); } catch (_) {}
        $container.remove();
        _releaseAutoChoicesBusy('stale auto choices discarded');
        restoreErrorReporter();
        return;
      }
      $loading.remove();

      // Q3: Show round progress indicator at top of choices panel
      if (_aiReplaceActive) {
        var roundInfo = cfg.language === 'zh'
          ? ('\u25C6 \u63A2\u7D22\u8F6E\u6B21 ' + _aiReplaceRoundCount)
          : ('\u25C6 Round ' + _aiReplaceRoundCount);
        var $roundInfo = $('<div class="ai-round-info" style="text-align:center;color:#b4a078;font-size:0.85em;margin-bottom:0.3em;"></div>').text(roundInfo);
        $container.append($roundInfo);
      }

      renderChoices($container, choices, cfg);
      _scheduleAIPixelAssistRefresh('auto choices rendered', 300);

      // Original passage content remains visible above AI choices.
      // Hiding only happens in advanceWithNarrative (once AI narrative replaces it).
      _ensureOriginalVisible();

      _releaseAutoChoicesBusy('auto choices complete');
      restoreErrorReporter();
    }).catch(function (err) {
      choiceRequest.clear();
      if (_currentAbortController === choiceRequest.controller) _currentAbortController = null;
      if (!_isAutoChoiceContextCurrent(choiceContext)) {
        $container.remove();
        _releaseAutoChoicesBusy('stale auto choices failed/discarded');
        restoreErrorReporter();
        return;
      }
      if (err && err.name === 'AbortError') {
        err = new Error(cfg.language === 'zh' ? '连接超时 (45秒)' : 'Request timed out (45s)');
      }
      $loading.removeClass('ai-gen-loading').addClass('ai-choices-error');
      $loading.text((cfg.language === 'zh' ? '选项生成失败: ' : 'Choice error: ') + (err && err.message ? err.message : err));
      _releaseAutoChoicesBusy('auto choices failed');
      restoreErrorReporter();
      _appendChoiceRetryButton($container, cfg, function () {
        $container.remove();
        autoInjectChoices(title, targetLabel, targetPassage);
      });
      _scheduleAIPixelAssistRefresh('auto choices failed', 300);
    });
  }

  function injectManualChoiceTrigger(title, targetLabel, targetPassage) {
    var cfg = loadCfg();
    if (_aiReplaceActive || _getChoiceTriggerMode(cfg) !== 'manual') {
      _removeManualChoiceTrigger();
      return;
    }
    if (_isAutoChoicesSuppressed() || _autoChoicesBusy || _sessionAutoPaused) return;
    var name = title || (typeof State !== 'undefined' && State.passage) || '';
    if (!name || name.indexOf('AIStoryGen_') === 0 || _isGameMenuPassage(name)) {
      _removeManualChoiceTrigger();
      return;
    }
    _syncAiLocationToNativePassage(name, 'manual choice native page');
    if (_isNativeCombatFinishPassage(name)) {
      _removeManualChoiceTrigger();
      _removeAIChoicePanels();
      return;
    }
    var V_forChoices = getV();
    if (V_forChoices && safeRead(function(){return V_forChoices.combat;},0)===1) {
      _removeManualChoiceTrigger();
      return;
    }
    if (_isShopOrUIPage()) {
      _removeManualChoiceTrigger();
      return;
    }
    if ($('#passages .ai-choices, #passages .ai-choices-end, #passages .ai-gen-loading').length) {
      _removeManualChoiceTrigger();
      return;
    }
    if ($('#passages .ai-manual-choice-trigger').length) return;
    var label = cfg.language === 'zh' ? '✨ 生成剧情' : '✨ Generate story';
    var $container = $('<div class="ai-manual-choice-trigger ai-choices-auto" style="margin-top:0.7em;"></div>');
    var $btn = $('<button type="button" class="ai-manual-choice-button" style="font:inherit;padding:0.35em 0.8em;border:1px solid #556;background:#202030;color:#f0d060;cursor:pointer;border-radius:2px;"></button>').text(label);
    _bindAiInteractionShield($container, 'manual-choice-trigger');
    $btn.on('click', function () {
      _removeManualChoiceTrigger();
      autoInjectChoices(name, targetLabel || '', targetPassage || '', { force: true, manual: true });
    });
    $container.append($btn);
    _placeAIChoicesContainer($container);
    _scheduleAIPixelAssistRefresh('manual choice trigger rendered', 300);
  }

  // Inject "AI版" clones below each game link in the passage
  function _forceRefreshChoicesFromToolbar(narrativeName) {
    _releaseAutoChoicesBusy('toolbar refresh');
    _lastAutoChoicesEnsureKey = '';
    try { restoreErrorReporter(); } catch (_) {}
    $('#passages .ai-choices, #passages .ai-choices-end').remove();
    var currentPassage = (typeof State !== 'undefined' && State.passage) || '';
    if (!_aiReplaceActive && _isNativeCombatFinishPassage(currentPassage)) {
      _ensureOriginalVisible();
      _showAIUserMessage(loadCfg().language === 'zh' ? '战斗结算页保留原版继续选项。' : 'Native continue option is preserved on combat settlement pages.', false);
      return;
    }
    var title = _aiReplaceActive ? (_aiReplaceOriginPassage || currentPassage) : currentPassage;
    var targetLabel = _aiReplaceActive ? (_aiReplaceTargetLabel || narrativeName || '') : '';
    var targetPassage = _aiReplaceActive ? (_aiReplaceTargetPassage || _aiCurrentLocationPassage || '') : '';
    _showAIUserMessage(loadCfg().language === 'zh' ? '正在刷新选项…' : 'Refreshing choices...', false);
    autoInjectChoices(title, targetLabel, targetPassage, { force: true });
  }

  function injectAILinkClones() {
    var cfg = loadCfg();
    if (_isAutoChoicesSuppressed()) {
      $('#passages .ai-injected-row, #passages .ai-injected-link').remove();
      return;
    }
    if (!cfg.aiReplaceLinks) return;
    if (!_isApiConfigured(cfg)) {
      $('#passages .ai-injected-row').remove();
      _refreshApiWarnBar();
      return;
    }

    // Skip menu/shop/UI pages by passage name first
    var curPassage = (typeof State !== 'undefined' && State.passage) || '';
    if (_isGameMenuPassage(curPassage)) {
      $('#passages .ai-injected-row').remove();
      return;
    }
    if (_isNativeCombatActive() || _isNativeSexOrCombatPassage(curPassage)) {
      $('#passages .ai-injected-row, #passages .ai-injected-link').remove();
      $('#passages .ai-choices, #passages .ai-choices-end').remove();
      return;
    }

    var $passage = $('#passages .passage');
    if (!$passage.length) return;
    // Skip shop/UI pages by DOM detection
    if (_isShopOrUIPage()) {
      $passage.find('.ai-injected-row').remove();
      $('#passages .ai-choices').remove();
      return;
    }
    $passage.find('.ai-injected-row').remove();

    $passage.find('a[data-passage]').each(function () {
      var $orig = $(this);
      // Skip links inside AI-generated content
      if ($orig.closest('.ai-narrative-section').length) return;
      // Skip links to game menu passages (Shift+4 Settings, Shift+5 Attitudes, etc.)
      var tp = $orig.attr('data-passage');
      if (_isGameMenuPassage(tp)) return;
      // Avoid double-injection — check if an AI row already follows
      if ($orig.next('.ai-injected-row').length) return;

      var linkText = $orig.clone().children().remove().end().text().trim();
      var targetPassage = $orig.attr('data-passage');
      if (!linkText || linkText.length < 2 || !targetPassage) return;
      if (_shouldSkipAIStoryLink($orig, targetPassage, linkText)) return;
      var origId = $orig.attr('data-ai-origid');
      if (!origId) {
        origId = 'ai-orig-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
        $orig.attr('data-ai-origid', origId);
      }
      var isEventAction = _isOriginalEventActionLink($orig, targetPassage, linkText);

      // Create a compact AI affordance below the original without duplicating
      // the destination text, so the vanilla game link remains easy to click.
      var $aiLink = $('<span class="ai-injected-link"></span>');
      $aiLink.text('   [剧情生成]')
        .attr('data-ai-target', targetPassage)
        .attr('data-ai-text', linkText)
        .attr('data-ai-origid', origId)
        .attr('data-ai-event', isEventAction ? '1' : '0')
        .attr('title', linkText + ' [剧情生成]')
        .data('ai-target', targetPassage)
        .data('ai-text', linkText)
        .data('ai-origid', origId)
        .data('ai-event', isEventAction ? '1' : '0');
      var $row = $('<span class="ai-injected-row"></span>').append($aiLink);
      $row.insertAfter($orig);
    });
    _refreshApiWarnBar();
  }

  // Capturing-phase click handler — runs before SugarCube link navigation
  document.addEventListener('click', function (e) {
    var target = e.target && e.target.closest ? e.target.closest('.ai-injected-link') : null;
    if (!target) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    var $t = $(target);
    var tp = $t.data('ai-target') || $t.attr('data-ai-target');
    var txt = $t.data('ai-text') || $t.attr('data-ai-text');
    var origId = $t.data('ai-origid') || $t.attr('data-ai-origid') || '';
    var eventMode = String($t.data('ai-event') || $t.attr('data-ai-event') || '') === '1';
    if (!tp || !txt) return;
    console.log('[AIStoryGen] [AI] link clicked →', tp, txt);
    var cfg = loadCfg();
    try {
      _preflightAI(cfg);
    } catch (preErr) {
      console.warn('[AIStoryGen] [AI] link preflight failed', preErr);
      _showAIUserMessage(preErr.message || String(preErr), true);
      return;
    }
    handleLocationReplace(tp, txt, origId, eventMode);
  }, true);
  window.AIStoryGen.injectAILinkClones = injectAILinkClones;

  document.addEventListener('click', function (e) {
    var link = e.target && e.target.closest ? e.target.closest('#passages a[data-passage]') : null;
    if (!link) return;
    if (link.closest && link.closest('.ai-injected-link, .ai-choices, .ai-replaced-content, .ai-narrative-wrap, .ai-back-to-game')) return;
    _clearStaleNativeEventLoopForLink(link, 'original link click');
    if (_aiReplaceActive) return;
    if (!_aiNarrativeWrap && !document.querySelector('#passages .ai-narrative-wrap')) return;
    _markAISaveRestoreSuppressed(5000);
    _clearAiRoundHistory();
    try {
      var V = _getStateVariables();
      if (V) {
        delete V.aiStoryGenNavState;
        V.aiStoryGenSuppressRestoreUntil = _suppressAISaveRestoreUntil;
      }
    } catch (_) {}
  }, true);

  // -- Suppress DoL NPC validation errors during AI activity --
  // (Kylar/Kylar-related NPCs may trigger false-positive errors when generated
  //  in passages with NPC limits, especially during prolonged AI exploration)
  function suppressErrorReporter() {
    // Hide the error overlay button
    var $errBtn = $('.error-reporter-btn');
    if ($errBtn.length) $errBtn.hide();
    // Hide sidebar red error text (e.g. "事件错误")
    $('#storyCaptionContent button .red').closest('button').hide();
    // Also hide any visible error overlay
    $('#errorOverlay').hide();
  }
  function restoreErrorReporter() {
    var $errBtn = $('.error-reporter-btn');
    if ($errBtn.length) $errBtn.show();
    $('#storyCaptionContent button .red').closest('button').show();
  }

  // -- SugarCube navigation hooks for AI state persistence --

  // :passageinit fires BEFORE the new passage DOM is built.
  // Save AI state for cross-passage restore, then clear round history.
  $(document).on(':passageinit', function (ev) {
    var initTitle = (ev && ev.passage && ev.passage.title) || '';
    _closeAiItemUseDialog();
    _cleanupStaleAIBlockingUI('passageinit');
    if (_rescueInvalidPrisonDirectState(initTitle, 'passageinit')) return;
    if (_aiReplaceActive) {
      var newTitle = initTitle;
      if (newTitle && newTitle !== _aiReplaceOriginPassage) {
        saveCurrentAINavState();
        _clearAiRoundHistory();
        console.log('[AIStoryGen] :passageinit saved AI state before navigating to "' + newTitle + '"');
      }
    }
  });

  // :passagedisplay fires AFTER the new passage is rendered in DOM.
  $(document).on(':passagedisplay', function (ev) {
    var title = (ev && ev.passage && ev.passage.title) || '';
    if (_rescueInvalidPrisonDirectState(title, 'passagedisplay')) {
      _ensurePassageContentVisible();
      return;
    }

    // Prevent blank page: hidden original wrap with no AI overlay
    _ensurePassageContentVisible();
    _cleanupStaleAIBlockingUI('passagedisplay');
    _cleanupInlineAiInventorySections();
    _removeMalformedAIEventDom();

    if (_restoreAIIntimateSceneIfNeeded(title)) {
      return;
    }

    // Try to restore AI replace state from navigation history (cross-passage forward)
    if (_restoreAISaveStateIfNeeded(title)) {
      _scheduleAiArriveButtonRepair('restore AI save state', 120);
      return;
    }

    // Try to restore AI replace state from navigation history (cross-passage forward)
    if (restoreAINavStateIfNeeded(title)) {
      _scheduleAiArriveButtonRepair('restore AI navigation state', 120);
      setTimeout(function () { injectAILinkClones(); }, 50);
      return;
    }

    // Handle resync: LOC tracking triggered a passage switch, re-overlay AI content
    if (_aiResyncTarget && title === _aiResyncTarget) {
      var $rpassage = $('#passages .passage');
      if ($rpassage.length && _aiResyncAIHTML) {
        _clearAiOverlayResidue($rpassage, 'replace');
        $rpassage.find('.ai-original-wrap').remove();
        var $roverlayKeep = _detachNativeOverlayKeepers($rpassage);
        // Use childNodes to capture text nodes too
        var wrapDiv = document.createElement('div');
        wrapDiv.className = 'ai-original-wrap';
        wrapDiv.style.display = 'none';
        while ($rpassage[0].childNodes.length > 0) {
          wrapDiv.appendChild($rpassage[0].childNodes[0]);
        }
        $rpassage[0].appendChild(wrapDiv);
        if ($roverlayKeep.length) $rpassage.append($roverlayKeep);
        var $rAiWrap = $('<div class="ai-replaced-content"></div>').html(_aiResyncAIHTML);
        $rpassage.append($rAiWrap);
        // Refresh destinations from new passage
        _collectDestinations($rpassage);
        console.log('[AIStoryGen] resync complete — AI overlay restored on passage: ' + title);
      }
      _aiResyncTarget = '';
      _aiResyncAIHTML = '';
      _scheduleAiArriveButtonRepair('resync restored AI overlay', 120);
      setTimeout(function () { injectAILinkClones(); }, 50);
      return;
    }

    // Same passage re-rendered while AI replace active — restore cached overlay
    if (_aiReplaceActive && _aiReplaceOriginPassage && title === _aiReplaceOriginPassage) {
      var $livePassage = $('#passages .passage');
      if ($livePassage.length && !$livePassage.find('.ai-replaced-content').length && _aiReplaceSessionHTML) {
        _reapplyReplaceOverlay($livePassage);
        _scheduleAiArriveButtonRepair('reapply replace overlay', 120);
        setTimeout(function () { injectAILinkClones(); }, 50);
        autoInjectChoices(title, _aiReplaceTargetLabel, _aiReplaceTargetPassage);
        return;
      }
    }

    if (_aiReplaceActive && _aiReplaceOriginPassage && title !== _aiReplaceOriginPassage) {
      _clearAiRoundHistory();
      _aiReplaceActive = false;
      _aiReplaceOriginPassage = '';
    }

    if (!_aiReplaceActive && _isAISaveRestoreSuppressed() && $('#passages .passage .ai-narrative-wrap, #passages .passage .ai-original-wrap').length) {
      _restoreOriginalFromNormalAIOverlay('native passage navigation');
    }

    // Reset AI narrative container and location tracking on passage change (normal mode)
    _aiNarrativeWrap = null;
    if (!_aiReplaceActive) {
      _clearAiLocationState('normal passage change');
    }

    var choiceTriggerMode = _getChoiceTriggerMode(loadCfg());
    if (choiceTriggerMode === 'auto') {
      autoInjectChoices(title);
    } else if (choiceTriggerMode === 'manual') {
      _removeAIChoicePanels();
      injectManualChoiceTrigger(title);
    } else {
      _removeManualChoiceTrigger();
      _removeAIChoicePanels();
    }
    setTimeout(function () {
      injectAILinkClones();
      ensureStandaloneSexModeButton();
      _refreshApiWarnBar();
      _scheduleAIChoicePixelReposition(0);
      if (_getChoiceTriggerMode(loadCfg()) === 'auto') {
        scheduleEnsureAutoChoices('passagedisplay follow-up', 900);
      } else if (_getChoiceTriggerMode(loadCfg()) === 'manual') {
        injectManualChoiceTrigger(title);
      }
    }, 50);
    _scheduleAIChoicePixelReposition(350);
    _scheduleAIChoicePixelReposition(1000);
    _scheduleAiArriveButtonRepair('passagedisplay final repair', 250);
    setTimeout(_installAIChoiceOrderObserver, 120);
  });

  // === NAVIGATION INTERCEPT (capturing-phase DOM click interception) ===
  // DoL's SugarCube has all API methods locked (non-configurable, non-writable):
  //   - State.activeIndex: getter-only, configurable:false
  //   - State.backward/forward/show: configurable:false, writable:false
  //   - SugarCube.Engine.backward/forward: configurable:false, writable:false
  // So we intercept clicks on #history-backward / #history-forward via capturing
  // phase — which fires BEFORE SugarCube's jQuery handlers on the target element.
  (function installNavHooks() {
    function aiNavActive() {
      return _aiRoundHistory.length > 0 ||
        _hasAiNativeHandoffArchive() ||
        _aiReplaceActive ||
        !!(_aiNarrativeWrap && _aiNarrativeWrap.innerHTML && _aiNarrativeWrap.innerHTML.trim());
    }
    function isBackwardBtn(el) {
      if (!el) return false;
      if (el.id === 'history-backward' || el.id === 'backwords') return true;
      if (el.closest && (el.closest('#history-backward') || el.closest('#backwords'))) return true;
      return false;
    }
    function isForwardBtn(el) {
      if (!el) return false;
      if (el.id === 'history-forward') return true;
      if (el.closest && el.closest('#history-forward')) return true;
      return false;
    }

    document.addEventListener('click', function navCapture(e) {
      var target = e.target;

      if (isBackwardBtn(target) || (target.parentElement && isBackwardBtn(target.parentElement))) {
        _releaseAutoChoicesBusy('history backward');
        if (_tryAiBackward()) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
        }
        return;
      }

      if (isForwardBtn(target) || (target.parentElement && isForwardBtn(target.parentElement))) {
        if (_tryAiForward()) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
        }
        return;
      }
    }, true);

    document.addEventListener('keydown', function aiNavKeyCapture(e) {
      if (!aiNavActive()) return;

      var key = e.key || '';
      var isBackKey = key === 'Backspace' || (key === 'ArrowLeft' && (e.altKey || e.metaKey));
      var isForwardKey = key === 'ArrowRight' && (e.altKey || e.metaKey);
      if (!isBackKey && !isForwardKey) return;

      var target = e.target;
      var tag = target && target.tagName ? target.tagName.toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || (target && target.isContentEditable)) return;

      if (isBackKey) {
        _releaseAutoChoicesBusy('keyboard history backward');
        if (_tryAiBackward()) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
        }
        return;
      }

      if (isForwardKey && _tryAiForward()) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
      }
    }, true);

    console.log('[AIStoryGen] AI navigation hooks installed (history buttons + keyboard)');
  })();

  // NOTE: DoL sidebar buttons (Social/Stats/Traits/...) use <<overlayReplace>>
  // which displays a fixed overlay (#customOverlayContainer) WITHOUT switching passage.
  // No special click monitoring is needed — just keep the overlay container outside
  // of the .ai-original-wrap (handled in handleLocationReplace).

  function _ensureAiItemStore() {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    if (!V) return null;
    if (!Array.isArray(V.aiStoryGenItems)) V.aiStoryGenItems = [];
    return V.aiStoryGenItems;
  }

  function _normaliseAiItemStoreArray(items) {
    var result = [];
    if (!Array.isArray(items)) return result;
    items.forEach(function (item) {
      var name = _normaliseAiItemName(item && item.name);
      if (_isLegacyConsumedAiItemName(name) || _isLegacyConsumedAiItemName(item && item.name)) return;
      if (_isBadAiItemName(name)) return;
      var inferredType = _classifyAiItem({ name: name });
      var resolvedType = inferredType !== 'other' ? inferredType : (item.type || item.category || inferredType);
      var metadata = ItemSchemaModule.inferItemMetadata
        ? ItemSchemaModule.inferItemMetadata({ name: name, type: resolvedType, description: item.description || item.source || '' })
        : { purpose: '', effect: '', consumable: false };
      var row = {
        id: String(item.id || ('aiitem_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7))),
        name: name,
        qty: Math.max(1, parseInt(item.qty, 10) || 1),
        ai: true,
        tag: item.tag || 'AI道具',
        type: resolvedType,
        description: _cleanAiItemSourceSummary(item.description || item.source || ''),
        purpose: String(item.purpose || metadata.purpose || ''),
        effect: String(item.effect || metadata.effect || ''),
        consumable: item.consumable == null ? !!metadata.consumable : !!item.consumable,
        passage: String(item.passage || ''),
        sourceLocation: String(item.sourceLocation || item.passage || ''),
        source: _normaliseAiItemSource(item.source),
        tags: Array.isArray(item.tags) ? item.tags.slice(0, 8) : [],
        usable: item.usable !== false,
        createdAt: item.createdAt || Date.now(),
        updatedAt: item.updatedAt || Date.now()
      };
      var existing = result.find(function (entry) { return entry && entry.name === name; });
      if (!existing) {
        result.push(row);
        return;
      }
      existing.qty = Math.max(1, parseInt(existing.qty, 10) || 1) + row.qty;
      existing.updatedAt = Math.max(Number(existing.updatedAt || 0), Number(row.updatedAt || 0)) || Date.now();
      if ((!existing.description || row.description.length > existing.description.length) && row.description) existing.description = row.description;
      if ((!existing.source || row.source.length > existing.source.length) && row.source) existing.source = row.source;
      if (row.type !== 'other') existing.type = row.type;
      if (!existing.purpose && row.purpose) existing.purpose = row.purpose;
      if (!existing.effect && row.effect) existing.effect = row.effect;
      if (row.consumable) existing.consumable = true;
      existing.tags = Array.from(new Set((existing.tags || []).concat(row.tags || []))).slice(0, 8);
    });
    if (result.length > 100) result.splice(0, result.length - 100);
    return result;
  }

  function _replaceAiItemStoreFromSave(items) {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    if (!V) return [];
    V.aiStoryGenItems = _normaliseAiItemStoreArray(items);
    return V.aiStoryGenItems;
  }

  function _syncAiItemsToCurrentMoment() {
    try {
      if (typeof State === 'undefined') return;
      var items = _cloneForAiSnapshot(_getAiItemStore());
      _getUniqueCurrentMomentVariableObjects().forEach(function (vars) {
        vars.aiStoryGenItems = _cloneForAiSnapshot(items);
        _patchAIStoryGenStateField(vars, 'items', items);
      });
    } catch (e) {
      try { console.warn('[AIStoryGen] sync AI items to current moment failed', e); } catch (_) {}
    }
  }

  function _persistAiItemStore() {
    _syncAiItemsToCurrentMoment();
  }

  var _pendingAiItemUses = [];
  var _lastAiItemsUsedForTurn = [];
  var _aiPickupCandidates = {};
  var _aiItemUseDialogState = null;
  var _aiLastTransientStateSignature = '';

  function _currentAITransientStateSignature() {
    var passage = _currentPassageName();
    var activeIndex = '';
    try {
      if (typeof State !== 'undefined' && State.activeIndex != null) activeIndex = String(State.activeIndex);
    } catch (_) {}
    return passage + '|' + activeIndex;
  }

  function _filterAiItemSelectionToCurrentInventory(list) {
    list = Array.isArray(list) ? list : [];
    var items = _getAiItemStore();
    var byId = {};
    var byName = {};
    items.forEach(function (item) {
      if (!item) return;
      if (item.id) byId[String(item.id)] = item;
      if (item.name) byName[String(item.name)] = item;
    });
    return list.filter(function (picked) {
      if (!picked) return false;
      var current = (picked.id && byId[String(picked.id)]) || (picked.name && byName[String(picked.name)]);
      if (!current) return false;
      var have = Math.max(1, parseInt(current.qty, 10) || 1);
      var qty = Math.max(1, parseInt(picked.qty, 10) || 1);
      picked.qty = Math.min(qty, have);
      return true;
    });
  }

  function _syncTransientAIItemRuntimeWithCurrentState(reason) {
    try {
      var sig = _currentAITransientStateSignature();
      var changed = sig && sig !== _aiLastTransientStateSignature;
      _pendingAiItemUses = _filterAiItemSelectionToCurrentInventory(_pendingAiItemUses);
      _lastAiItemsUsedForTurn = _filterAiItemSelectionToCurrentInventory(_lastAiItemsUsedForTurn);
      if (changed) {
        _aiPickupCandidates = {};
        _pendingAiItemUses = [];
        _lastAiItemsUsedForTurn = [];
        _closeAiItemUseDialog();
      }
      _aiLastTransientStateSignature = sig;
    } catch (e) {
      try { console.warn('[AIStoryGen] sync transient AI item runtime failed' + (reason ? ' (' + reason + ')' : ''), e); } catch (_) {}
    }
  }

  function _getAiItemStore() {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    if (!V || !Array.isArray(V.aiStoryGenItems)) return [];
    for (var i = V.aiStoryGenItems.length - 1; i >= 0; i--) {
      var entry = V.aiStoryGenItems[i];
      if (!entry || _isBadAiItemName(entry.name) || _isLegacyConsumedAiItemName(entry.name)) V.aiStoryGenItems.splice(i, 1);
      else {
        entry.source = _normaliseAiItemSource(entry.source);
        var metadata = ItemSchemaModule.inferItemMetadata
          ? ItemSchemaModule.inferItemMetadata(entry)
          : { purpose: '', effect: '', consumable: false };
        if (!entry.purpose) entry.purpose = String(metadata.purpose || '');
        if (!entry.effect) entry.effect = String(metadata.effect || '');
        if (entry.consumable == null) entry.consumable = !!metadata.consumable;
      }
    }
    return V.aiStoryGenItems;
  }

  function _normaliseAiItemName(name) {
    return ItemSchemaModule.normaliseAiItemName(name);
  }

  function _isLegacyConsumedAiItemName(name) {
    name = String(name || '').replace(/\s+/g, ' ').trim();
    if (!name) return false;
    return /(?:\(|\uff08)\s*(?:\u5df2\u4f7f\u7528|used|consumed)\s*(?:\)|\uff09)\s*$/i.test(name);
  }

  function _aiItemComparableName(name) {
    name = String(name || '').replace(/\s+/g, ' ').trim();
    name = name.replace(/^(?:itemsGained|items_gained|items)\s*[:=]\s*/i, '').trim();
    name = name.replace(/\s*[\(\uff08]\s*(?:gained|obtained|acquired|\u83b7\u5f97|\u5df2\u83b7\u5f97)\s*[\)\uff09]\s*$/i, '').trim();
    name = name.replace(/\s*(?:x|\u00d7|\*)\s*\d+\s*$/i, '').trim();
    var normalized = '';
    try { normalized = _normaliseAiItemName(name); } catch (_) { normalized = ''; }
    return String(normalized || name).toLowerCase().replace(/[\s_\-·・'"\u2018\u2019\u201c\u201d]/g, '').trim();
  }

  function _currentWornAiItemNameSet() {
    var set = {};
    try {
      var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
      var worn = V && V.worn;
      if (!worn || typeof worn !== 'object') return set;
      Object.keys(worn).forEach(function (slot) {
        var item = worn[slot];
        if (!item || typeof item !== 'object') return;
        [
          item.name,
          item.name_cap,
          item.displayName,
          item.display_name,
          item.label,
          item.cn_name,
          item.cnName
        ].forEach(function (value) {
          var key = _aiItemComparableName(value);
          if (key && key !== 'naked') set[key] = true;
        });
      });
    } catch (_) {}
    return set;
  }

  function _isCurrentWornAiItemName(name, wornSet) {
    var key = _aiItemComparableName(name);
    if (!key) return false;
    wornSet = wornSet || _currentWornAiItemNameSet();
    return !!wornSet[key];
  }

  function _filterAiRuntimeItems(items) {
    var wornSet = _currentWornAiItemNameSet();
    return (Array.isArray(items) ? items : []).filter(function (item) {
      var name = _normaliseAiItemName(item && item.name);
      if (_isBadAiItemName(name)) return false;
      if (_isCurrentWornAiItemName(name, wornSet) || _isCurrentWornAiItemName(item && item.name, wornSet)) return false;
      return true;
    });
  }

  function _normaliseAiItemSource(source) {
    source = String(source || '').replace(/\s+/g, ' ').trim();
    source = _removeAIEventBlocks(source);
    source = source.replace(/\[(?:ITEMS?|STATS|AI_ITEMS_USED|LOC|AI_META)[^\]]*\]/gi, '').replace(/\s+/g, ' ').trim();
    if (source.length > 130) {
      var firstSentence = source.split(/(?<=[。！？.!?])\s*/).filter(Boolean)[0] || source;
      source = firstSentence.length <= 130 ? firstSentence : source.slice(0, 130);
    }
    return source;
  }

  function _getAiItemRawSource(source) {
    source = String(source || '').replace(/\s+/g, ' ').trim();
    source = _removeAIEventBlocks(source);
    source = source.replace(/\[(?:ITEMS?|STATS|AI_ITEMS_USED|LOC|AI_META)[^\]]*\]/gi, '').replace(/\s+/g, ' ').trim();
    if (source.length > 4000) source = source.slice(0, 4000).trim();
    return source;
  }

  function _cleanAiItemSourceSummary(text) {
    text = String(text || '').replace(/\s+/g, ' ').trim();
    text = text.replace(/^["'“”‘’]+|["'“”‘’]+$/g, '').trim();
    text = text.replace(/^(?:摘要|来源|物品来源|AI摘要)\s*[:：]\s*/i, '').trim();
    text = _removeAIEventBlocks(text);
    text = text.replace(/\[(?:ITEMS?|STATS|AI_ITEMS_USED|LOC|AI_META)[^\]]*\]/gi, '').replace(/\s+/g, ' ').trim();
    if (text.length > 130) text = text.slice(0, 130).trim();
    return text;
  }

  function _summarizeAiItemSourceInBackground(sourceText, itemNames) {
    sourceText = String(sourceText || '').replace(/\s+/g, ' ').trim();
    itemNames = (itemNames || []).filter(Boolean);
    if (!sourceText || !itemNames.length) return;
    var cfg = loadCfg();
    if (!_isApiConfigured(cfg) || typeof callAI !== 'function') return;
    var prompt = cfg.language === 'zh'
      ? [
          '请把下面这段游戏剧情整理成“AI物品来源描述”，用于库存里显示。',
          '要求：',
          '- 中文输出，130字以内。',
          '- 只说明玩家如何获得这些物品，以及关键地点/对象。',
          '- 不要复述完整剧情，不要写心理描写、环境铺陈、长句。',
          '- 不要输出列表、标题、引号或括号标记。',
          '物品：' + itemNames.join('、'),
          '剧情：' + sourceText
        ].join('\n')
      : [
          'Summarise this game narrative into an inventory item source note.',
          'Rules: <=130 characters, one concise sentence, mention how the player obtained the item(s), no title, no list, no metadata.',
          'Items: ' + itemNames.join(', '),
          'Narrative: ' + sourceText
        ].join('\n');
    callAI(prompt, { highQuality: true, temperature: 0.2, max_tokens: 220 }).then(function (summary) {
      summary = _cleanAiItemSourceSummary(summary);
      if (!summary) return;
      var store = _ensureAiItemStore();
      if (!store) return;
      var changed = false;
      store.forEach(function (entry) {
        if (!entry || itemNames.indexOf(entry.name) === -1) return;
        entry.source = summary;
        entry.description = summary;
        entry.updatedAt = Date.now();
        changed = true;
      });
      if (changed) {
        _persistAiItemStore();
        _renderAiItemsInLog();
      }
    }).catch(function () {
      // Keep the local fallback summary if the backend is unavailable.
    });
  }

  function _ensureSexModeEntryInExistingActions() {
    try {
      _clearAISexModeUi();
    } catch (e) {
      try { console.warn('[AIStoryGen] ensure sex mode entry failed', e); } catch (_) {}
    }
  }

  function _isBadAiItemName(name) {
    return ItemSchemaModule.isBadAiItemName(name);
  }

  function _escapeAiHtml(text) {
    return String(text == null ? '' : text).replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch];
    });
  }

  function _parseAiItemToken(token) {
    return ItemSchemaModule.parseAiItemToken(token);
  }

  function _mergeAiItemListByName(items) {
    return ItemSchemaModule.mergeAiItemListByName(items);
  }

  function _recordAiItems(items, sourceText) {
    var store = _ensureAiItemStore();
    items = _filterAiRuntimeItems(_mergeAiItemListByName(items));
    if (!store || !items.length) return [];
    var cfg = loadCfg();
    var added = [];
    var summarizeNames = [];
    items.forEach(function (item) {
      var name = _normaliseAiItemName(item && item.name);
      var qty = Math.max(1, parseInt(item && item.qty, 10) || 1);
      if (_isBadAiItemName(name)) return;
      var existing = store.find(function (entry) { return entry && entry.name === name; });
      if (existing) {
        existing.qty = Math.max(1, parseInt(existing.qty, 10) || 1) + qty;
        existing.updatedAt = Date.now();
      } else {
        var itemType = _classifyAiItem({ name: name });
        var itemMetadata = ItemSchemaModule.inferItemMetadata
          ? ItemSchemaModule.inferItemMetadata({ name: name, type: itemType, description: sourceText })
          : { purpose: '', effect: '', consumable: false };
        store.push({
          id: 'aiitem_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7),
          name: name,
          qty: qty,
          ai: true,
          tag: cfg.language === 'zh' ? 'AI道具' : 'AI item',
          type: itemType,
          description: _cleanAiItemSourceSummary(sourceText),
          purpose: String(itemMetadata.purpose || ''),
          effect: String(itemMetadata.effect || ''),
          consumable: !!itemMetadata.consumable,
          passage: (typeof State !== 'undefined' && State.passage) || '',
          sourceLocation: (typeof State !== 'undefined' && State.passage) || '',
          source: _normaliseAiItemSource(sourceText),
          tags: [],
          usable: true,
          createdAt: Date.now(),
          updatedAt: Date.now()
        });
      }
      added.push({ name: name, qty: qty });
      if (summarizeNames.indexOf(name) === -1) summarizeNames.push(name);
    });
    if (store.length > 100) store.splice(0, store.length - 100);
    _persistAiItemStore();
    _renderAiItemsInLog();
    _summarizeAiItemSourceInBackground(sourceText, summarizeNames);
    return added;
  }

  function _expandAiItemTokens(token) {
    return ItemSchemaModule.expandAiItemTokens(token);
  }

  function _queueAiItemPickupCandidates(items, sourceText) {
    var cleaned = _filterAiRuntimeItems(_mergeAiItemListByName(items));
    if (!cleaned.length) return null;
    var id = 'aipick_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
    _aiPickupCandidates[id] = {
      id: id,
      items: cleaned,
      source: _getAiItemRawSource(sourceText),
      createdAt: Date.now()
    };
    return _aiPickupCandidates[id];
  }

  function _formatAiPickupItems(items) {
    var cleaned = _filterAiRuntimeItems(_mergeAiItemListByName(items || []));
    return cleaned.map(function (item) {
      return _escapeAiHtml(item.name) + (item.qty > 1 ? ' x' + item.qty : '');
    }).join('\u3001');
  }

  function _makeAiPickupLine(candidate) {
    if (!candidate || !candidate.items || !candidate.items.length) return '';
    candidate.items = _filterAiRuntimeItems(_mergeAiItemListByName(candidate.items));
    if (!candidate.items.length) return '';
    return [
      '<div class="ai-pickup-line" data-ai-pickup-id="' + _escapeAiHtml(candidate.id) + '">',
      '<span class="ai-items-line">[\u53ef\u62fe\u53d6AI\u9053\u5177] ' + _formatAiPickupItems(candidate.items) + '</span> ',
      '<button type="button" class="ai-pickup-btn" data-ai-pickup-action="take">\u6536\u5165AI\u5e93\u5b58</button>',
      '<button type="button" class="ai-pickup-btn" data-ai-pickup-action="skip">\u4e0d\u62ff</button>',
      '</div>'
    ].join('');
  }

  function _consumeAiItems(items) {
    var store = _ensureAiItemStore();
    if (!store || !items || !items.length) return [];
    var consumed = [];
    items.forEach(function (item) {
      var name = _normaliseAiItemName(item && item.name);
      var qty = Math.max(1, parseInt(item && item.qty, 10) || 1);
      if (_isBadAiItemName(name)) return;
      var existing = store.find(function (entry) { return entry && entry.name === name; });
      if (!existing) return;
      var have = Math.max(1, parseInt(existing.qty, 10) || 1);
      var used = Math.min(have, qty);
      existing.qty = have - used;
      existing.updatedAt = Date.now();
      consumed.push({ name: name, qty: used });
    });
    for (var i = store.length - 1; i >= 0; i--) {
      if (!store[i] || Math.max(0, parseInt(store[i].qty, 10) || 0) <= 0) store.splice(i, 1);
    }
    _persistAiItemStore();
    _renderAiItemsInLog();
    return consumed;
  }

  function _isAiItemConsumableByDefault(item) {
    var name = _normaliseAiItemName(item && item.name);
    if (!name) return false;
    if (item && item.consumable != null) return !!item.consumable;
    var type = String(item && (item.type || item.category) || _classifyAiItem({ name: name }));
    if (type === 'food') return true;
    return /(\u679c|\u91ce\u679c|\u6811\u8393|\u91ce\u8393|\u8393|\u6d46\u679c|\u6a31\u6843|\u82f9\u679c|\u68a8|\u8461\u8404|\u8336|\u9152|\u996e|\u836f|\u836f\u5242|\u836f\u7247|berry|berries|raspberry|fruit|drink|potion|medicine|pill)/i.test(name);
  }

  function _shouldConsumeSelectedAiItem(item, rawText, choiceText) {
    var name = _normaliseAiItemName(item && item.name);
    if (!name) return false;
    var text = _visibleAiItemUsageText(String(choiceText || '') + ' ' + String(rawText || ''));
    if (!text || !_isAiItemMentionedInVisibleText(text, { name: name })) return false;
    if (/(放回|收回|装回|归还|仍然完好|没有消耗|未消耗|保留完整|put (?:it )?back|return(?:ed)?|remain(?:s|ed)? intact|not consumed)/i.test(text)) return false;
    return /(吃(?:下|掉)?|喝(?:下|掉)?|吞(?:下|咽)?|咽下|嚼碎|服用|涂抹|点燃|烧掉|燃尽|撕碎|剪碎|砸碎|打碎|捻碎|碾碎|磨碎|撒(?:下|入|在)?|倒(?:入|出|掉)?|投入|丢弃|扔掉|送给|交给|递给|喂给|用完|耗尽|消耗|损坏|eat|drink|swallow|chew|apply|ignite|burn|tear|crush|grind|sprinkle|pour|discard|throw away|give (?:it )?to|use up|consume|break)/i.test(text);
  }

  function _visibleAiItemUsageText(raw) {
    var text = String(raw || '');
    try { text = _removeAIEventBlocks(text); } catch (_) {}
    return text
      .replace(/\[AI_ITEMS_USED:\s*([^\]]+)\]\s*/gi, '')
      .replace(/\[(?:ITEMS?|STATS|LOC|AI_META)[^\]]*\]/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function _isAiItemMentionedInVisibleText(raw, item) {
    var name = _normaliseAiItemName(item && item.name);
    if (!name) return true;
    var text = _visibleAiItemUsageText(raw);
    if (!text) return false;
    if (text.indexOf(name) >= 0) return true;
    if (/(\u8393|\u6d46\u679c|berry|berries|raspberry)/i.test(name)) {
      return /(\u8393|\u6d46\u679c|\u91ce\u679c|\u679c\u5b50|berry|berries|raspberry)/i.test(text);
    }
    return false;
  }

  function _appendMissingAiItemUsageLine(raw, selectedItems) {
    selectedItems = Array.isArray(selectedItems) ? selectedItems : [];
    var missing = selectedItems.filter(function (item) {
      return item && item.name && !_isAiItemMentionedInVisibleText(raw, item);
    });
    if (!missing.length) return raw;
    var visible = missing.map(function (item) {
      var qty = Math.max(1, parseInt(item.qty, 10) || 1);
      return _escapeAiHtml(item.name) + (qty > 1 ? ' x' + qty : '');
    }).join('\u3001');
    return String(raw || '').trim() + '<br><span class="ai-items-line">[AI\u9053\u5177\u4f7f\u7528] \u4f60\u4f7f\u7528\u4e86' + visible + '\u3002</span>';
  }

  function parseAndApplyAiItemUsage(text, transactionPlan) {
    var raw = String(text || '');
    var used = _getAiTransactionPlanItemsToConsume(transactionPlan, raw);
    var selectedForTurn = transactionPlan && transactionPlan.items
      ? _getAiTransactionPlanItems(transactionPlan, 'selectedUses')
      : _cloneForAiSnapshot(_lastAiItemsUsedForTurn || []);
    if (selectedForTurn.length) raw = _appendMissingAiItemUsageLine(raw, selectedForTurn);
    raw = raw.replace(/\[AI_ITEMS_USED:\s*([^\]]+)\]\s*/gi, function (_, body) {
      return '';
    });
    var consumed = _consumeAiItems(used);
    if (transactionPlan && transactionPlan.items) {
      transactionPlan.items.consumed = _formatRuntimeItemPlan(consumed);
      transactionPlan.items.consumeApplied = consumed.length > 0;
      if (used.length && !consumed.length) transactionPlan.items.consumeBlockedReason = 'no_matching_ai_inventory_item';
      else delete transactionPlan.items.consumeBlockedReason;
    }
    if (consumed.length) {
      var visible = consumed.map(function (item) {
        return _escapeAiHtml(item.name) + (item.qty > 1 ? ' x' + item.qty : '');
      }).join('\u3001');
      raw = raw.trim() + '<br><span class="ai-items-line ai-items-consumed-line"><strong>已消耗AI道具：</strong>' + visible + '</span>';
    }
    return raw;
  }

  function _formatAiItemListForPrompt(items) {
    items = Array.isArray(items) ? items : [];
    return items.map(function (item) {
      return String(item.name || '').trim() + ' x' + Math.max(1, parseInt(item.qty, 10) || 1);
    }).filter(Boolean).join('; ');
  }

  function _findAiItemStoreEntryForUse(item) {
    var store = _getAiItemStore();
    if (!store || !store.length || !item) return null;
    var id = String(item.id || '').trim();
    var name = _normaliseAiItemName(item.name || '');
    if (id) {
      for (var i = 0; i < store.length; i++) {
        if (store[i] && String(store[i].id || '') === id) return store[i];
      }
    }
    if (name) {
      for (var j = 0; j < store.length; j++) {
        if (store[j] && _normaliseAiItemName(store[j].name || '') === name) return store[j];
      }
    }
    return null;
  }

  function _cleanAiItemPromptDetail(text, limit) {
    text = String(text || '')
      .replace(/\[(?:AI_EVENT|\/AI_EVENT|ITEMS?|STATS|AI_ITEMS_USED|LOC|AI_META)[^\]]*\]/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    limit = Math.max(40, Math.min(240, parseInt(limit, 10) || 120));
    return text.length > limit ? text.slice(0, limit) + '...' : text;
  }

  function _inferAiItemUseHint(item) {
    var name = _normaliseAiItemName(item && item.name);
    var type = String(item && (item.type || item.category) || _classifyAiItem(item || {}));
    var purpose = _cleanAiItemPromptDetail(item && item.purpose || '', 100);
    var effect = _cleanAiItemPromptDetail(item && item.effect || '', 120);
    if (purpose || effect) {
      return [purpose, effect].filter(Boolean).join('；');
    }
    if (type === 'food') return '食用、饮用或作为临时补给，正文应体现味道、饱腹/解渴/恢复或不适等即时效果';
    if (type === 'key') return '用于开锁、开启、进入、确认权限或解决阻挡';
    if (type === 'tool') return '作为工具或随身物件参与当前动作，帮助移动、采集、修理、遮挡、防护或互动';
    if (type === 'clue') return '用于查看、比对、追踪线索或推动判断';
    if (type === 'accessory') return '作为佩戴物、信物、伪装、交易物或情绪/关系触发物参与剧情';
    if (/(\u8393|\u6d46\u679c|\u91ce\u679c|\u679c\u5b50|berry|berries|raspberry|fruit)/i.test(name)) {
      return '食用或作为食物补给，正文应体现味道、解渴/恢复、弄脏手指或留下残渣等具体效果';
    }
    return '根据物品名称和来源判断合理用途，让它改变玩家动作、互动方式、环境反馈或下一步结果';
  }

  function _buildAiItemEffectContext(items, cfg, actionText) {
    items = Array.isArray(items) ? items : [];
    var lines = [];
    items.forEach(function (picked) {
      if (!picked || !picked.name) return;
      var storeItem = _findAiItemStoreEntryForUse(picked) || {};
      var merged = Object.assign({}, storeItem, picked);
      var qty = Math.max(1, parseInt(picked.qty, 10) || 1);
      var type = String(merged.type || merged.category || _classifyAiItem(merged));
      var desc = _cleanAiItemPromptDetail(merged.description || merged.source || '', 130);
      var source = _cleanAiItemPromptDetail(merged.sourceLocation || merged.passage || '', 60);
      var purpose = _cleanAiItemPromptDetail(merged.purpose || '', 100);
      var effect = _cleanAiItemPromptDetail(merged.effect || '', 120);
      var parts = [
        '- name=' + String(picked.name || '').trim(),
        'qty=' + qty,
        'type=' + type,
        'categoryLabel=' + _aiItemCategoryLabel(type),
        'useHint=' + _inferAiItemUseHint(merged),
        'consumable=' + (merged.consumable ? 'yes' : 'no')
      ];
      if (purpose) parts.push('purpose=' + purpose);
      if (effect) parts.push('expectedEffect=' + effect);
      if (desc) parts.push('details=' + desc);
      if (source) parts.push('sourceLocation=' + source);
      lines.push(parts.join('; '));
    });
    if (!lines.length) return '';
    var action = _cleanAiItemPromptDetail(actionText || '', 100);
    var zh = !cfg || cfg.language === 'zh';
    return [
      '<item_effect_context>',
      action ? (zh ? '玩家本轮选择：' : 'Player action this turn: ') + action : '',
      lines.join('\n'),
      zh
        ? '这些是玩家确认要在本轮剧情中使用的物品详情。正文必须让物品影响行动过程或结果，而不是只在结尾标记里列出。'
        : 'These are the item details for this turn. The prose must let the items affect the action process or result, not merely list them in metadata.',
      '</item_effect_context>'
    ].filter(Boolean).join('\n');
  }

  function _takePendingAiItemUses() {
    var items = _pendingAiItemUses.slice();
    _pendingAiItemUses.length = 0;
    _lastAiItemsUsedForTurn = _cloneForAiSnapshot(items || []);
    return items;
  }

  function _buildAiItemUseBlock(items, cfg, actionText) {
    items = Array.isArray(items) ? items : [];
    if (!items.length) return '';
    var list = _formatAiItemListForPrompt(items);
    if (!list) return '';
    var effectContext = _buildAiItemEffectContext(items, cfg, actionText);
    if (cfg && cfg.language === 'zh') {
      return [
        '<ai_items_to_use>',
        list,
        '</ai_items_to_use>',
        effectContext,
        '\u73a9\u5bb6\u672c\u8f6e\u5df2\u786e\u8ba4\u4f7f\u7528\u4e0a\u9762\u7684AI\u9053\u5177\u3002\u4e0b\u4e00\u9875\u5267\u60c5\u5fc5\u987b\u8ba9\u6bcf\u4e2a\u5df2\u9009\u9053\u5177\u4ee5\u51c6\u786e\u540d\u79f0\u51fa\u73b0\u5728\u6b63\u6587\u91cc\uff0c\u5e76\u771f\u6b63\u53c2\u4e0e\u73a9\u5bb6\u884c\u52a8\u3002\u4e0d\u8981\u5ffd\u7565\uff0c\u4e0d\u8981\u53ea\u5728\u5143\u6570\u636e\u4e2d\u8bb0\u5f55\u3002',
        '\u5982\u679c\u9053\u5177\u6709 <item_effect_context> \u91cc\u7684 details/useHint\uff0c\u5fc5\u987b\u4f18\u5148\u6309\u8fd9\u4e9b\u4fe1\u606f\u5199\u5b83\u7684\u7528\u6cd5\u548c\u6548\u679c\u3002',
        '\u5982\u679c\u67d0\u4e2aAI\u9053\u5177\u5728\u5267\u60c5\u4e2d\u88ab\u6d88\u8017\u3001\u635f\u574f\u3001\u9001\u51fa\u6216\u4e22\u5931\uff0c\u5728 AI_EVENT \u91cc\u5199 itemsLost=\u9053\u5177\u540d x1; \u9053\u5177\u540d x2\u3002\u4e5f\u53ef\u517c\u5bb9\u9644\u52a0 [AI_ITEMS_USED: \u9053\u5177\u540d x1; \u9053\u5177\u540d x2]\u3002',
        '\u5982\u679c\u9053\u5177\u53ea\u662f\u5c55\u793a\u3001\u62ff\u51fa\u3001\u77ed\u6682\u4f7f\u7528\u540e\u6536\u56de\uff0citemsLost \u7559\u7a7a\uff0c\u7cfb\u7edf\u4f1a\u8ba9\u5b83\u56de\u5230AI\u5e93\u5b58\u3002'
      ].join('\n');
    }
    return [
      '<ai_items_to_use>',
      list,
      '</ai_items_to_use>',
      effectContext,
      'The player has confirmed using the AI items above this turn. The next story prose must mention every selected item by exact name and make it meaningfully participate in the action.',
      'If <item_effect_context> includes details/useHint, use that information first to decide how the item is used and what effect it has.',
      'If an item is consumed, broken, given away, or lost, write itemsLost=item name x1; item name x2 in AI_EVENT. You may also append [AI_ITEMS_USED: item name x1; item name x2] for compatibility.',
      'If the item is only shown, held, or briefly used and returned to the backpack, leave itemsLost empty.'
    ].join('\n');
  }

  function _getAiTransactionPlanRelationships(transactionPlan, rawText) {
    var schema = _getAiNpcRelationSchema();
    if (transactionPlan && Array.isArray(transactionPlan.relationships)) {
      return transactionPlan.relationships.map(function (change) {
        var npc = _resolveAiNpcKey(change && change.npc) || String(change && change.npc || '').trim();
        var field = String(change && change.field || '').toLowerCase();
        var spec = schema[field];
        var delta = parseInt(change && change.delta, 10) || 0;
        if (!npc || !spec || !delta) return null;
        return {
          npc: npc,
          label: String(change && change.label || _toChineseName(npc) || npc),
          field: spec.key,
          delta: delta
        };
      }).filter(Boolean);
    }
    return _collectAiNpcRelationshipChanges(rawText, _parseAIEventBlock(rawText));
  }

  function _markAiTransactionRelationship(transactionPlan, change, applied, reason, delta) {
    if (!transactionPlan || !Array.isArray(transactionPlan.relationships) || !change) return;
    for (var i = 0; i < transactionPlan.relationships.length; i++) {
      var rel = transactionPlan.relationships[i];
      if (!rel || rel._checked) continue;
      if (String(rel.npc || '') !== String(change.npc || '')) continue;
      if (String(rel.field || '') !== String(change.field || '')) continue;
      if ((parseInt(rel.delta, 10) || 0) !== (parseInt(change.delta, 10) || 0)) continue;
      rel.applied = !!applied;
      rel.appliedDelta = applied ? (parseInt(delta, 10) || 0) : 0;
      if (reason) rel.blockedReason = reason;
      else delete rel.blockedReason;
      rel._checked = true;
      break;
    }
  }

  function _finalizeAiTransactionRelationships(transactionPlan) {
    if (!transactionPlan || !Array.isArray(transactionPlan.relationships)) return;
    transactionPlan.relationshipsApplied = transactionPlan.relationships.some(function (rel) { return !!(rel && rel.applied); });
    transactionPlan.relationships.forEach(function (rel) {
      if (!rel || rel._checked) return;
      rel.applied = false;
      rel.appliedDelta = 0;
      rel.blockedReason = rel.blockedReason || 'not_applied';
    });
    transactionPlan.relationships.forEach(function (rel) {
      if (rel) delete rel._checked;
    });
  }

  function parseAndApplyNpcRelationships(text, transactionPlan) {
    var raw = String(text || '');
    var changes = _getAiTransactionPlanRelationships(transactionPlan, raw);
    if (transactionPlan && Array.isArray(transactionPlan.relationships)) {
      transactionPlan.relationshipsApplied = false;
    }
    if (!changes.length) return raw;
    var cfg = loadCfg();
    var relationLimits = _getAiNpcRelationFieldLimits(cfg);
    var root = _getAiNpcRoot();
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
    var schema = _getAiNpcRelationSchema();
    var applied = [];
    changes.forEach(function (change) {
      if (!change || !change.npc || !schema[change.field]) {
        _markAiTransactionRelationship(transactionPlan, change, false, 'invalid_relationship_change', 0);
        return;
      }
      var limit = Number(relationLimits[change.field] || 0);
      if (limit <= 0) {
        _markAiTransactionRelationship(transactionPlan, change, false, 'field_limit_disabled', 0);
        return;
      }
      var delta = Math.max(-limit, Math.min(limit, parseInt(change.delta, 10) || 0));
      if (!delta) {
        _markAiTransactionRelationship(transactionPlan, change, false, 'zero_delta', 0);
        return;
      }
      var targets = [];
      if (root && root[change.npc] && root[change.npc][change.field] !== undefined) targets.push(root[change.npc]);
      if (V && V[change.npc] && V[change.npc][change.field] !== undefined && targets.indexOf(V[change.npc]) < 0) targets.push(V[change.npc]);
      if (!targets.length) {
        _markAiTransactionRelationship(transactionPlan, change, false, 'npc_field_not_found', 0);
        return;
      }
      targets.forEach(function (npc) {
        var nextVal = (Number(npc[change.field]) || 0) + delta;
        npc[change.field] = Math.max(-1000, Math.min(1000, nextVal));
      });
      applied.push({
        label: change.label || _toChineseName(change.npc) || change.npc,
        field: change.field,
        delta: delta
      });
      _markAiTransactionRelationship(transactionPlan, change, true, '', delta);
    });
    _finalizeAiTransactionRelationships(transactionPlan);
    if (!applied.length) return raw;
    var visible = applied.map(function (change) {
      var spec = schema[change.field] || { label: change.field };
      var color = change.delta >= 0 ? '#8f8' : '#f88';
      return '<span style="color:' + color + ';font-size:0.85em;">' +
        _escapeAiHtml(change.label) + ' ' + _escapeAiHtml(spec.label) + ' ' +
        (change.delta >= 0 ? '+' : '') + change.delta + '</span>';
    }).join(' | ');
    try {
      _refreshGameVisualState('npc relation');
      setTimeout(function () { _refreshGameVisualState('npc relation delayed'); }, 50);
      setTimeout(function () { _refreshGameVisualState('npc relation delayed'); }, 250);
    } catch (_) {}
    return raw.trim() + '<br><span class="ai-stats-line ai-npc-rel-line">[ ' + visible + ' ]</span>';
  }

  function parseAndApplyAiItems(text, transactionPlan) {
    var raw = String(text || '');
    var items = transactionPlan && transactionPlan.items
      ? _getAiTransactionPlanItems(transactionPlan, 'gained')
      : _collectAiRuntimeItems(raw, _parseAIEventBlock(raw));
    raw = raw.replace(/\[ITEMS?:\s*([^\]]+)\]\s*/gi, function (_, body) {
      return '';
    });
    // Inventory candidates must be explicit. Do not infer items from free prose.
    var candidate = _queueAiItemPickupCandidates(items, raw);
    if (transactionPlan && transactionPlan.items) {
      transactionPlan.items.pickupQueued = !!candidate;
      transactionPlan.items.pickupCandidateId = candidate ? String(candidate.id || '') : '';
      transactionPlan.items.pickupItems = candidate ? _formatRuntimeItemPlan(candidate.items || []) : [];
    }
    if (candidate) raw = raw.trim() + '<br>' + _makeAiPickupLine(candidate);
    return raw;
  }

  function _renderAiItemsInLog() {
    try {
      _getAiItemStore();
      _cleanupInlineAiInventorySections();
    } catch (e) {
      console.warn('[AIStoryGen] cleanup AI items failed', e);
    }
  }

  function _cleanupInlineAiInventorySections() {
    $('.ai-log-items-section').remove();
    $('.ai-memory-inline').remove();
    $('a.ai-back-link').filter(function () {
      return /AI\s*记忆|AI\s*璁板繂|Memory/i.test(String($(this).text() || ''));
    }).remove();
  }

  function _classifyAiItem(item) {
    var name = String(item && item.name || '').trim();
    if (/(\u94a5\u5319|\u94a5|\u9501|key|lock)/i.test(name)) return 'key';
    if (/(\u6212\u6307|\u9879\u94fe|\u8033\u73af|\u624b\u956f|\u5fbd\u7ae0|\u53d1\u5939|\u9970\u54c1|ring|necklace|earring|bracelet|badge|clip)/i.test(name)) return 'accessory';
    if (/(\u5200|\u5251|\u68cd|\u5de5\u5177|\u9524|\u94f2|\u94c1\u9539|\u7ef3|\u53e3\u7434|\u4f1e|knife|tool|hammer|shovel|rope|harmonica|umbrella)/i.test(name)) return 'tool';
    if (/(\u98df|\u996d|\u7cd6|\u6c34|\u725b\u5976|\u9762\u5305|\u72d7\u7cae|\u9e21\u86cb|\u679c|\u91ce\u679c|\u6811\u8393|\u91ce\u8393|\u8393|\u6d46\u679c|food|water|milk|bread|candy|feed|egg|berry|berries|raspberry|fruit)/i.test(name)) return 'food';
    if (/(\u4fe1|\u7eb8|\u7b14\u8bb0|\u7167\u7247|\u5730\u56fe|\u7ebf\u7d22|\u65e5\u8bb0|\u540d\u7247|\u90ae\u7968|\u539f\u77f3|\u91d1\u5c5e\u7247|\u788e\u7247|\u77f3\u677f|\u8bc1\u636e|letter|note|photo|map|clue|journal|diary|card|stamp|gemstone fragment|metal fragment|evidence)/i.test(name)) return 'clue';
    return 'other';
  }

  function _aiItemCategoryLabel(key) {
    var map = {
      all: '\u5168\u90e8',
      key: '\u94a5\u5319',
      accessory: '\u9970\u54c1',
      tool: '\u5de5\u5177',
      food: '\u98df\u7269',
      clue: '\u7ebf\u7d22',
      other: '\u5176\u4ed6'
    };
    return map[key] || map.other;
  }

  function _discardAiItem(itemId) {
    var store = _ensureAiItemStore();
    if (!store || !itemId) return false;
    for (var i = store.length - 1; i >= 0; i--) {
      if (store[i] && store[i].id === itemId) {
        store.splice(i, 1);
        _persistAiItemStore();
        return true;
      }
    }
    return false;
  }

  function _buildAiInventoryOverlay($root, activeCategory) {
    var items = _getAiItemStore();
    $root.empty().addClass('ai-inventory-page');
    $root.append($('<h2></h2>').text('AI\u5e93\u5b58'));
    activeCategory = activeCategory || 'all';

    var categories = ['all', 'key', 'accessory', 'tool', 'food', 'clue', 'other'];
    var $cats = $('<div class="ai-inventory-cats"></div>');
    categories.forEach(function (cat) {
      var count = cat === 'all'
        ? items.length
        : items.filter(function (item) { return _classifyAiItem(item) === cat; }).length;
      var $cat = $('<button type="button" class="ai-inventory-cat"></button>')
        .toggleClass('active', cat === activeCategory)
        .attr('data-ai-inventory-cat', cat)
        .text(_aiItemCategoryLabel(cat) + (count ? ' ' + count : ''));
      $cat.on('click', function () { _buildAiInventoryOverlay($root, cat); });
      $cats.append($cat);
    });
    $root.append($cats);

    if (!items.length) {
      $root.append($('<div class="ai-log-items-empty"></div>').text('\u6682\u65e0AI\u9053\u5177'));
      return;
    }
    var shown = activeCategory === 'all'
      ? items.slice()
      : items.filter(function (item) { return _classifyAiItem(item) === activeCategory; });
    if (!shown.length) {
      $root.append($('<div class="ai-log-items-empty"></div>').text('\u8fd9\u4e00\u7c7b\u6682\u65e0AI\u9053\u5177'));
      return;
    }
    var $list = $('<div class="ai-inventory-list"></div>');
    shown.forEach(function (item) {
      var qty = Math.max(1, parseInt(item.qty, 10) || 1);
      var $row = $('<div class="ai-inventory-row"></div>');
      $row.append($('<span class="ai-log-item-tag"></span>').text('AI\u9053\u5177'));
      $row.append($('<span class="ai-inventory-cat-label"></span>').text(_aiItemCategoryLabel(_classifyAiItem(item))));
      $row.append($('<span class="ai-inventory-name"></span>').text(String(item.name || '').trim()));
      $row.append($('<span class="ai-inventory-qty"></span>').text('x' + qty));
      var $discard = $('<button type="button" class="ai-inventory-discard"></button>').text('\u4e22\u5f03');
      $discard.on('click', function () {
        if (!_discardAiItem(item.id)) return;
        _pendingAiItemUses = _pendingAiItemUses.filter(function (picked) { return picked && picked.id !== item.id; });
        _buildAiInventoryOverlay($root, activeCategory);
      });
      $row.append($discard);
      var metadata = [];
      if (item.purpose) metadata.push('用途：' + String(item.purpose));
      if (item.effect) metadata.push('预期：' + String(item.effect));
      metadata.push(item.consumable ? '默认会消耗' : '默认保留');
      $row.append($('<div class="ai-inventory-meta"></div>').text(metadata.join(' · ')));
      if (item.source) $row.append($('<div class="ai-log-item-source"></div>').text(String(item.source || '')));
      $list.append($row);
    });
    $root.append($list);
  }

  function _buildAiMemoryOverlay($root) {
    if (MemoryUI && typeof MemoryUI.buildOverlay === 'function') {
      return MemoryUI.buildOverlay($root);
    }
    $root.empty().addClass('ai-memory-page ai-cfg');
    $root.append($('<h2></h2>').text('AI记忆'));
    var $body = $('<div class="ai-memory-body"></div>');
    var $msg = $('<div class="ai-cfg-msg"></div>');
    renderMemoryEntries($body, $msg);
    $root.append($body).append($msg);
  }

  function injectAiInventoryLogTab() {
    _cleanupInlineAiInventorySections();
    setTimeout(_cleanupInlineAiInventorySections, 50);
    setTimeout(_cleanupInlineAiInventorySections, 250);
    var overlay = document.getElementById('customOverlay');
    var $tabBar = $('#overlayTabs');
    var $content = $('#customOverlayContent');
    if (!$tabBar.length || !$content.length) return;
    if (overlay && overlay.getAttribute('data-overlay') === 'options') return;
    var tabText = ($tabBar.text() || '') + ' ' + (overlay ? (overlay.getAttribute('data-overlay') || '') : '');
    if (!/(\u65e5\u5fd7|\u7b14\u8bb0|log|journal|note)/i.test(tabText)) return;
    var $closeBtn = $('#overlayTabs .customOverlayClose');
    function addLogTab(id, label, buildFn) {
      if ($('#' + id).length) return;
      var $btn = $('<button></button>').attr('id', id).text(label);
      $btn.on('click', function () {
        $('#overlayTabs button').removeClass('tab-selected');
        $btn.addClass('tab-selected');
        var $wrap = $('<div></div>');
        $content.empty().append($wrap);
        buildFn($wrap);
      });
      if ($closeBtn.length) $btn.insertBefore($closeBtn);
      else $tabBar.append($btn);
    }

    addLogTab('aiMemoryTab', 'AI记忆', function ($wrap) {
      _buildAiMemoryOverlay($wrap);
    });
    addLogTab('aiInventoryTab', 'AI\u5e93\u5b58', function ($wrap) {
      $wrap.addClass('ai-inventory-wrap');
      _buildAiInventoryOverlay($wrap);
    });
  }

  var _aiInventoryTabInjectionTimer = null;
  function scheduleAiInventoryTabInjection(delay) {
    if (_aiInventoryTabInjectionTimer) clearTimeout(_aiInventoryTabInjectionTimer);
    _aiInventoryTabInjectionTimer = setTimeout(function () {
      _aiInventoryTabInjectionTimer = null;
      injectAiInventoryLogTab();
    }, delay || 0);
  }

  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('.ai-pickup-btn') : null;
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();
    var line = btn.closest('.ai-pickup-line');
    var id = line ? line.getAttribute('data-ai-pickup-id') : '';
    if (line && line.getAttribute('data-ai-pickup-processed') === '1') return;
    if (line) line.setAttribute('data-ai-pickup-processed', '1');
    var candidate = id ? _aiPickupCandidates[id] : null;
    if (!candidate) {
      if (line) line.remove();
      return;
    }
    var action = btn.getAttribute('data-ai-pickup-action') || '';
    if (action === 'take') {
      var added = _recordAiItems(candidate.items, candidate.source);
      if (line) {
        if (added && added.length) {
          line.innerHTML = '<span class="ai-items-line">[AI\u9053\u5177\u5df2\u6536\u5165] ' + _formatAiPickupItems(added) + '</span>';
        } else {
          line.innerHTML = '<span class="ai-items-line">[AI\u9053\u5177] \u6ca1\u6709\u53ef\u6536\u5165\u7684\u6709\u6548AI\u9053\u5177</span>';
        }
      }
    } else {
      if (line) line.innerHTML = '<span class="ai-items-line">[AI\u9053\u5177] \u672a\u62fe\u53d6</span>';
    }
    delete _aiPickupCandidates[id];
  }, true);

  function _updateAiItemUseButtonLabel($btn, cfg) {
    if (!$btn || !$btn.length) return;
    var base = cfg && cfg.language === 'zh' ? '\u4f7f\u7528\u9053\u5177' : 'Use items';
    var count = Array.isArray(_pendingAiItemUses) ? _pendingAiItemUses.length : 0;
    $btn.text(count > 0 ? base + '（已选' + count + '）' : base);
  }

  function _closeAiItemUseDialog() {
    try { $(document).off('keydown.aiItemUseDialog'); } catch (_) {}
    try { $('.ai-item-use-backdrop').remove(); } catch (_) {}
    _aiItemUseDialogState = null;
  }

  function _hasActiveAIIntimateSceneState() {
    try {
      var saved = _readAuthoritativeAIIntimateSceneFromVariables(_getStateVariables());
      return !!(saved && saved.active);
    } catch (_) {
      return false;
    }
  }

  function _cleanupStaleAIBlockingUI(reason) {
    try {
      if (!_aiItemUseDialogState) $('.ai-item-use-backdrop').remove();
    } catch (_) {}
    try {
      var title = _getNativeScenePassageName();
      if (!_isAIIntimateModePassage(title) && !_hasActiveAIIntimateSceneState()) {
        OptionalAddonBridge.clearFixedIntimateActions();
      }
    } catch (_) {}
    try {
      if (reason && window.console && console.debug) console.debug('[AIStoryGen] stale blocking UI cleanup: ' + reason);
    } catch (_) {}
  }

  function _initialAiItemUseSelection() {
    var selected = {};
    (_pendingAiItemUses || []).forEach(function (item) {
      if (!item || !item.id) return;
      selected[String(item.id)] = {
        id: String(item.id || ''),
        name: String(item.name || ''),
        qty: Math.max(1, parseInt(item.qty, 10) || 1)
      };
    });
    return selected;
  }

  function _syncAiItemUseDialogSelection($dialog) {
    if (!_aiItemUseDialogState) return;
    $dialog.find('.ai-item-use-dialog-row').each(function () {
      var $row = $(this);
      var id = String($row.attr('data-ai-item-id') || '');
      if (!id) return;
      var max = Math.max(1, parseInt($row.attr('data-ai-item-max'), 10) || 1);
      var qty = Math.max(0, Math.min(max, parseInt($row.attr('data-ai-item-qty'), 10) || 0));
      if (qty <= 0) {
        delete _aiItemUseDialogState.selected[id];
        return;
      }
      _aiItemUseDialogState.selected[id] = {
        id: id,
        name: String($row.attr('data-ai-item-name') || ''),
        qty: qty
      };
    });
  }

  function _renderAiItemUseDialogBody($dialog, $button, cfg) {
    if (!_aiItemUseDialogState) return;
    var items = _getAiItemStore();
    var activeCategory = _aiItemUseDialogState.category || 'all';
    var categories = ['all', 'key', 'accessory', 'tool', 'food', 'clue', 'other'];
    var $body = $dialog.find('.ai-item-use-dialog-body').empty();

    var $cats = $('<div class="ai-inventory-cats ai-item-use-dialog-cats"></div>');
    categories.forEach(function (cat) {
      var count = cat === 'all'
        ? items.length
        : items.filter(function (item) { return _classifyAiItem(item) === cat; }).length;
      var $cat = $('<button type="button" class="ai-inventory-cat"></button>')
        .toggleClass('active', cat === activeCategory)
        .attr('data-ai-inventory-cat', cat)
        .text(_aiItemCategoryLabel(cat) + (count ? ' ' + count : ''));
      $cat.on('click', function () {
        _syncAiItemUseDialogSelection($dialog);
        _aiItemUseDialogState.category = cat;
        _renderAiItemUseDialogBody($dialog, $button, cfg);
      });
      $cats.append($cat);
    });
    $body.append($cats);

    if (!items.length) {
      $body.append($('<div class="ai-log-items-empty"></div>').text('\u6682\u65e0\u53ef\u7528AI\u9053\u5177'));
      return;
    }

    var shown = activeCategory === 'all'
      ? items.slice()
      : items.filter(function (item) { return _classifyAiItem(item) === activeCategory; });
    if (!shown.length) {
      $body.append($('<div class="ai-log-items-empty"></div>').text('\u8fd9\u4e00\u7c7b\u6682\u65e0AI\u9053\u5177'));
      return;
    }

    var $list = $('<div class="ai-inventory-list ai-item-use-dialog-list"></div>');
    shown.forEach(function (item) {
      var id = String(item.id || '');
      var name = String(item.name || '').trim();
      var maxQty = Math.max(1, parseInt(item.qty, 10) || 1);
      var selected = id && _aiItemUseDialogState.selected[id];
      var pickedQty = selected ? Math.max(1, Math.min(maxQty, parseInt(selected.qty, 10) || 1)) : 0;
      var $row = $('<div class="ai-inventory-row ai-item-use-dialog-row"></div>')
        .attr('data-ai-item-id', id)
        .attr('data-ai-item-name', name)
        .attr('data-ai-item-max', maxQty)
        .attr('data-ai-item-qty', pickedQty)
        .toggleClass('is-selected', pickedQty > 0);
      var $selectedBadge = $('<span class="ai-item-use-dialog-selected-badge"></span>').text('\u5df2\u7528');
      var $minus = $('<button type="button" class="ai-item-use-dialog-qty-btn" aria-label="\u51cf\u5c11\u4f7f\u7528\u6570\u91cf"></button>').text('-');
      var $plus = $('<button type="button" class="ai-item-use-dialog-qty-btn" aria-label="\u589e\u52a0\u4f7f\u7528\u6570\u91cf"></button>').text('+');
      var $qtyValue = $('<span class="ai-item-use-dialog-qty-value"></span>').text('x' + pickedQty);
      var $discard = $('<button type="button" class="ai-item-use-dialog-delete"></button>').text('\u5220\u9664');
      function refreshRowVisual() {
        var on = pickedQty > 0;
        $row.toggleClass('is-selected', on);
        $minus.prop('disabled', pickedQty <= 0);
        $plus.prop('disabled', pickedQty >= maxQty);
        $row.attr('data-ai-item-qty', pickedQty);
        $qtyValue.text('x' + pickedQty);
      }
      function setQty(nextQty) {
        pickedQty = Math.max(0, Math.min(maxQty, parseInt(nextQty, 10) || 0));
        refreshRowVisual();
        _syncAiItemUseDialogSelection($dialog);
      }
      $row.on('click', function (ev) {
        if ($(ev.target).closest('button,input,a,label').length) return;
        setQty(pickedQty > 0 ? 0 : 1);
      });
      $minus.on('click', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        setQty(pickedQty - 1);
      });
      $plus.on('click', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        setQty(pickedQty + 1);
      });
      $discard.on('click', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        if (!_discardAiItem(id)) return;
        delete _aiItemUseDialogState.selected[id];
        _pendingAiItemUses = _pendingAiItemUses.filter(function (picked) { return picked && picked.id !== id; });
        _updateAiItemUseButtonLabel($button, cfg);
        $dialog.find('.ai-item-use-dialog-msg').removeClass('err').addClass('ok').text('\u5df2\u5220\u9664\uff1a' + name);
        _renderAiItemUseDialogBody($dialog, $button, cfg);
      });
      refreshRowVisual();
      $row.append($('<span class="ai-item-use-dialog-pick"></span>').append($selectedBadge));
      $row.append($('<span class="ai-log-item-tag"></span>').text('AI\u9053\u5177'));
      $row.append($('<span class="ai-inventory-cat-label"></span>').text(_aiItemCategoryLabel(_classifyAiItem(item))));
      $row.append($('<span class="ai-inventory-name"></span>').text(name));
      $row.append($('<span class="ai-inventory-qty"></span>').text('持有 x' + maxQty));
      $row.append($('<div class="ai-item-use-dialog-qty-wrap"></div>').append($('<span></span>').text('\u4f7f\u7528')).append($minus).append($qtyValue).append($plus));
      $row.append($discard);
      var metadata = [];
      if (item.purpose) metadata.push('用途：' + String(item.purpose));
      if (item.effect) metadata.push('预期：' + String(item.effect));
      metadata.push(item.consumable ? '使用后默认消耗' : '使用后默认保留');
      $row.append($('<div class="ai-inventory-meta"></div>').text(metadata.join(' · ')));
      if (item.source) $row.append($('<div class="ai-log-item-source"></div>').text(String(item.source || '')));
      $list.append($row);
    });
    $body.append($list);
  }

  function _openAiItemUseDialog($button, cfg) {
    _closeAiItemUseDialog();
    cfg = cfg || loadCfg();
    _aiItemUseDialogState = {
      category: 'all',
      selected: _initialAiItemUseSelection()
    };
    var $backdrop = $('<div class="ai-item-use-backdrop" role="presentation"></div>');
    var $dialog = $('<div class="ai-item-use-dialog" role="dialog" aria-modal="true"></div>');
    var $title = $('<div class="ai-item-use-dialog-title"></div>').text(cfg.language === 'zh' ? '选择使用 AI 道具' : 'Choose AI items');
    var $close = $('<button type="button" class="ai-item-use-dialog-close" aria-label="Close"></button>').text('×');
    var $body = $('<div class="ai-item-use-dialog-body"></div>');
    var $msg = $('<div class="ai-cfg-msg ai-item-use-dialog-msg"></div>');
    var $actions = $('<div class="ai-item-use-dialog-actions"></div>');
    var $confirm = $('<button type="button" class="ai-choice-btn ai-item-use-dialog-confirm"></button>').text(cfg.language === 'zh' ? '确认使用' : 'Confirm');
    var $cancel = $('<button type="button" class="ai-choice-btn ai-item-use-dialog-cancel"></button>').text(cfg.language === 'zh' ? '取消' : 'Cancel');
    $dialog.append($('<div class="ai-item-use-dialog-head"></div>').append($title).append($close));
    $dialog.append($body).append($msg);
    $actions.append($confirm).append($cancel);
    $dialog.append($actions);
    $backdrop.append($dialog);
    _mountAiFloatingPanel($backdrop, 'ai-item-use-dialog', {
      className: 'ai-mobile-floating-panel ai-mobile-blocking-dialog',
      mode: 'append',
      shield: true
    });

    function closeOnly() {
      _closeAiItemUseDialog();
    }
    $close.on('click', closeOnly);
    $cancel.on('click', closeOnly);
    $backdrop.on('click', function (ev) {
      if (ev.target === $backdrop[0]) closeOnly();
    });
    $(document).on('keydown.aiItemUseDialog', function (ev) {
      if (ev.key === 'Escape') closeOnly();
    });
    $confirm.on('click', function () {
      _syncAiItemUseDialogSelection($dialog);
      var picked = Object.keys(_aiItemUseDialogState.selected).map(function (id) {
        return _aiItemUseDialogState.selected[id];
      }).filter(function (item) { return item && item.name; });
      _pendingAiItemUses = picked;
      _updateAiItemUseButtonLabel($button, cfg);
      if (picked.length) {
        _showAIUserMessage((cfg.language === 'zh' ? '已选择AI道具：' : 'Selected AI items: ') + _formatAiItemListForPrompt(picked), false);
      } else {
        _showAIUserMessage(cfg.language === 'zh' ? '本轮未选择AI道具。' : 'No AI items selected this turn.', false);
      }
      _closeAiItemUseDialog();
    });
    _renderAiItemUseDialogBody($dialog, $button, cfg);
    setTimeout(function () { try { $dialog.find('button, input').filter(':visible').first().focus(); } catch (_) {} }, 0);
  }

  function _parseAiMoneyAmount(raw, hadCurrency) {
    raw = String(raw || '').replace(/,/g, '').trim();
    if (!raw) return 0;
    var n = parseFloat(raw);
    if (!isFinite(n) || n <= 0) return 0;
    // DoL stores money as pence. Explicit pound signs are converted; plain
    // numeric story amounts are treated as the same unit used by [STATS: money].
    return hadCurrency ? Math.max(1, Math.round(n * 100)) : Math.max(1, Math.round(n));
  }

  function _parseChineseMoneyNumber(raw) {
    raw = String(raw || '').replace(/\s+/g, '').trim();
    if (!raw) return 0;
    var digits = {
      '\u96f6': 0, '\u3007': 0,
      '\u4e00': 1, '\u4e8c': 2, '\u4e24': 2,
      '\u4e09': 3, '\u56db': 4, '\u4e94': 5,
      '\u516d': 6, '\u4e03': 7, '\u516b': 8, '\u4e5d': 9
    };
    var smallUnits = { '\u5341': 10, '\u767e': 100, '\u5343': 1000 };
    var largeUnits = { '\u4e07': 10000, '\u842c': 10000, '\u4ebf': 100000000, '\u5104': 100000000 };
    var total = 0;
    var section = 0;
    var number = 0;
    for (var i = 0; i < raw.length; i++) {
      var ch = raw.charAt(i);
      if (Object.prototype.hasOwnProperty.call(digits, ch)) {
        number = digits[ch];
        continue;
      }
      if (Object.prototype.hasOwnProperty.call(smallUnits, ch)) {
        section += (number || 1) * smallUnits[ch];
        number = 0;
        continue;
      }
      if (Object.prototype.hasOwnProperty.call(largeUnits, ch)) {
        section += number;
        total += (section || 1) * largeUnits[ch];
        section = 0;
        number = 0;
        continue;
      }
      return 0;
    }
    return total + section + number;
  }

  function _inferExplicitMoneyDeltaFromNarrative(text) {
    var raw = _removeAIEventBlocks(String(text || ''))
      .replace(/\[STATS:\s*[^\]]+\]/gi, ' ')
      .replace(/\[(?:ITEMS?|AI_ITEMS_USED|LOC|AI_META)[^\]]*\]/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!raw) return 0;
    var isSpend = /(\u4e70|\u8d2d|\u4e70\u4e0b|\u8d2d\u4e70|\u652f\u4ed8|\u4ed8\u7ed9|\u4ed8\u4e86|\u82b1\u8d39|\u82b1\u4e86|\u552e\u4ef7|\u4ef7\u683c|\u8981\u4ef7|\u6210\u4ea4|\u6263\u9664|buy|bought|pay|paid|spend|spent|cost|price|purchase)/i.test(raw);
    var isGain = /(\u627e\u5230|\u53d1\u73b0|\u83b7\u5f97|\u5f97\u5230|\u8d5a|\u5356\u51fa|\u6536\u5230|\u6536\u5165|find|found|gain|gained|earn|earned|sell|sold|receive|received)/i.test(raw);
    if (!isSpend && !isGain) return 0;
    var amounts = [];
    var re = /([\u00a3\uffe1\u5143])?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)\s*(?:\u5143|\u4fbf\u58eb|pence|p)?/gi;
    var m;
    while ((m = re.exec(raw))) {
      var before = raw.slice(Math.max(0, m.index - 24), m.index);
      var after = raw.slice(re.lastIndex, Math.min(raw.length, re.lastIndex + 24));
      var windowText = before + m[0] + after;
      if (!/(\u94b1|\u91d1\u94b1|\u73b0\u91d1|\u4ef7|\u552e|\u4e70|\u8d2d|\u652f\u4ed8|\u4ed8|\u82b1|\u6263|\u5b9d\u77f3|\u82f1\u9551|\u9551|gem|\u00a3|\uffe1|\u5143|money|cash|price|cost|pay|paid|buy|bought|purchase)/i.test(windowText)) continue;
      var hadCurrency = !!m[1] || /(\u5143|\u4fbf\u58eb|pence|p)/i.test(m[0]);
      var amount = _parseAiMoneyAmount(m[2], /[\u00a3\uffe1]/.test(m[1] || '') || (/(\u5143)/.test(m[0]) ? false : false));
      if (amount) amounts.push(amount);
    }
    var cnRe = /([\u96f6\u3007\u4e00\u4e8c\u4e24\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e\u5343\u4e07\u842c\u4ebf\u5104]{1,16})\s*(?:\u82f1\u9551|\u9551|\u5143|\u4fbf\u58eb)?/g;
    while ((m = cnRe.exec(raw))) {
      before = raw.slice(Math.max(0, m.index - 24), m.index);
      after = raw.slice(cnRe.lastIndex, Math.min(raw.length, cnRe.lastIndex + 24));
      windowText = before + m[0] + after;
      if (!/(\u94b1|\u91d1\u94b1|\u73b0\u91d1|\u4ef7|\u552e|\u4e70|\u8d2d|\u652f\u4ed8|\u4ed8|\u82b1|\u6263|\u5b9d\u77f3|\u82f1\u9551|\u9551|gem|money|cash|price|cost|pay|paid|buy|bought|purchase)/i.test(windowText)) continue;
      amount = _parseChineseMoneyNumber(m[1]);
      if (amount) amounts.push(amount);
    }
    if (!amounts.length) return 0;
    var picked = Math.max.apply(Math, amounts);
    return isSpend ? -picked : picked;
  }

  function _resolveAiRuntimeStat(key) {
    return EventSchemaModule.resolveRuntimeStat(key);
  }

  function _getAiRuntimeStatLabel(key) {
    return EventSchemaModule.getRuntimeStatLabel(key);
  }

  function _getAiRuntimeStatLimit(key, defaultLimit) {
    return EventSchemaModule.getRuntimeStatLimit(key, defaultLimit);
  }

  function _formatAiRuntimeStatAllowlist() {
    return EventSchemaModule.formatRuntimeStatAllowlist();
  }

  function _formatAiRuntimeNonMoneyStatAllowlist() {
    return _formatAiRuntimeStatAllowlist()
      .split(/\s*,\s*/)
      .filter(function (key) { return String(key || '').toLowerCase() !== 'money'; })
      .join(', ');
  }

  var _aiStatSchema = StatSchemaModule.create({
    getDefaults: function () { return DEFAULT_CFG; },
    getRuntimeStatLimit: _getAiRuntimeStatLimit
  });
  window.AIStoryGen.statSchema = _aiStatSchema;

  function _getAiStatLimitFieldDefs() {
    return _aiStatSchema.getFieldDefs();
  }

  function _clampAiStatFieldLimit(value, fallback, max) {
    return _aiStatSchema.clampFieldLimit(value, fallback, max);
  }

  function _getAiStatFieldLimit(cfg, field) {
    return _aiStatSchema.getFieldLimit(cfg, field);
  }

  function _getAiStatFieldLimits(cfg) {
    return _aiStatSchema.getFieldLimits(cfg);
  }

  function _formatAiStatFieldLimitText(cfg) {
    return _aiStatSchema.formatFieldLimitText(cfg);
  }

  function _pushNormalisedAiStatPart(out, seen, part, explicitMoneyDelta) {
    return EventSchemaModule.pushNormalisedStatPart(out, seen, part, explicitMoneyDelta);
  }

  function _scaleAiRuntimeStatDeltaForNativeMeter(key, val) {
    var statSpec = _resolveAiRuntimeStat(key);
    var target = statSpec && statSpec.target;
    var abs = Math.abs(parseInt(val, 10) || 0);
    if (!abs || abs > 100) return val;
    var scale = 0;
    if (target === 'arousal') scale = 100;
    else if (target === 'stress') scale = val < 0 ? 80 : 40;
    else if (target === 'trauma') scale = 10;
    else if (target === 'tiredness') scale = val < 0 ? 20 : 15;
    return scale ? val * scale : val;
  }

  function _collectAiRuntimeStatChanges(rawText, eventData, includeNarrativeMoney) {
    var explicitMoneyDelta = _inferExplicitMoneyDeltaFromNarrative(rawText);
    var out = [];
    var seen = {};
    eventData = eventData || _parseAIEventBlock(rawText);
    var allowLegacyMoneyMarker = !!eventData.moneyChange;
    if (eventData.moneyChange) {
      _pushNormalisedAiStatPart(out, seen, 'money' + (String(eventData.moneyChange).charAt(0) === '-' ? '' : '+') + eventData.moneyChange, explicitMoneyDelta);
    }
    _parseListField(eventData.statChanges || eventData.stats || '').forEach(function (part) {
      _pushNormalisedAiStatPart(out, seen, part, explicitMoneyDelta);
    });
    _parseStatsChangesFromText(rawText).forEach(function (part) {
      if (/^\s*(?:money|\u91d1\u94b1|\u94b1)\s*[+-]/i.test(String(part || '')) && !allowLegacyMoneyMarker) return;
      _pushNormalisedAiStatPart(out, seen, part, explicitMoneyDelta);
    });
    return { parts: out, explicitMoneyDelta: explicitMoneyDelta };
  }

  var _aiTransactionPlanner = TransactionPlannerModule.create({
    loadCfg: loadCfg,
    clone: _cloneForAiSnapshot,
    parseAIEventBlock: _parseAIEventBlock,
    collectRuntimeStatChanges: _collectAiRuntimeStatChanges,
    collectRuntimeItems: _collectAiRuntimeItems,
    collectRuntimeLostItems: _collectAiRuntimeLostItems,
    getLastItemsUsedForTurn: function () { return _lastAiItemsUsedForTurn || []; },
    isItemConsumableByDefault: _isAiItemConsumableByDefault,
    shouldConsumeSelectedItem: _shouldConsumeSelectedAiItem,
    collectNpcRelationshipChanges: _collectAiNpcRelationshipChanges,
    normaliseEventStatus: _normaliseAiEventStatus,
    parseTimeFromChoice: parseTimeFromChoice,
    getLastChoiceText: function () { return _lastChoiceText || ''; },
    dedupeTextList: _dedupeTextList,
    normaliseItemName: _normaliseAiItemName,
    classifyItem: _classifyAiItem,
    parseListField: _parseListField,
    eventIndicatesArrival: _aiEventIndicatesArrival,
    getConsistencyDiagnostics: function () { return _lastConsistencyDiagnostics || []; },
    getConsistencyBlockedEffects: function () { return _lastConsistencyBlockedEffects || []; },
    getConsistencyBlockedEffectSummary: _getConsistencyBlockedEffectSummary,
    filterRuntimeItems: _filterAiRuntimeItems,
    mergeItemListByName: _mergeAiItemListByName
  });
  window.AIStoryGen.transactionPlanner = _aiTransactionPlanner;

  function _findPlannedMoneyDelta(statParts) {
    return _aiTransactionPlanner.findPlannedMoneyDelta(statParts);
  }

  function _formatRuntimeItemPlan(items) {
    return _aiTransactionPlanner.formatRuntimeItemPlan(items);
  }

  function _buildAiTransactionPlan(rawText, cfg, opts) {
    return _aiTransactionPlanner.buildPlan(rawText, cfg, opts);
  }

  function _getAiTransactionPlanItems(transactionPlan, field) {
    return _aiTransactionPlanner.getPlanItems(transactionPlan, field);
  }

  function _getAiTransactionPlanItemsToConsume(transactionPlan, rawText) {
    return _aiTransactionPlanner.getItemsToConsume(transactionPlan, rawText);
  }

  function _getAiTransactionPlanStats(transactionPlan, rawText) {
    return _aiTransactionPlanner.getPlanStats(transactionPlan, rawText);
  }

  // Parse [STATS: arousal+5, stress-10] from AI output and apply to game state
  function parseAndApplyStats(text, transactionPlan) {
    var runtimeStats = _getAiTransactionPlanStats(transactionPlan, text);
    var explicitMoneyDelta = runtimeStats.explicitMoneyDelta;
    var inferredMoney = 0;
    // Raw markers are implementation metadata. Only committed changes are
    // rendered back below, so blocked or unsupported values cannot leak into
    // the visible narrative.
    var cleanText = String(text || '').replace(/\[STATS:\s*[^\]]+\]\s*/gi, '').trim();
    if (!runtimeStats.parts.length && !inferredMoney) {
      if (transactionPlan && transactionPlan.stats) {
        transactionPlan.stats.applied = false;
        transactionPlan.stats.changed = [];
      }
      return cleanText;
    }
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    if (!V) {
      if (transactionPlan && transactionPlan.stats) {
        transactionPlan.stats.applied = false;
        transactionPlan.stats.blockedReason = 'missing_state_variables';
      }
      return cleanText;
    }
    var keyMap = {
      'arousal': 'arousal', 'stress': 'stress', 'pain': 'pain',
      'trauma': 'trauma', 'awareness': 'awareness', 'lewdity': 'lewdity',
      'fatigue': 'tiredness', 'purity': 'purity',
      'exhibitionism': 'exhibitionism', 'promiscuity': 'promiscuity',
      'deviancy': 'deviancy', 'masochism': 'masochism',
      'skulduggery': 'skulduggery', 'swimming': 'swimming',
      'athletics': 'athletics', 'tending': 'tending', 'seduction': 'seduction',
      'willpower': 'willpower', 'physique': 'physique', 'dancing': 'dancing',
      'housekeeping': 'housekeeping', 'science': 'science', 'english': 'english',
      'maths': 'maths', 'history': 'history', 'money': 'money',
      'beauty': 'beauty', 'charm': 'charm', 'lust': 'lust',
      'control': 'control', 'drunk': 'drunk', 'drugged': 'drugged',
      'hallucinogen': 'hallucinogen'
    };
    var cfg = loadCfg();
    var defaultLimit = Math.max(0, parseInt(cfg.statChangeLimit, 10) || 50);
    function clampDelta(key, val) {
      var statSpec = _resolveAiRuntimeStat(key);
      var statKey = statSpec && statSpec.key ? statSpec.key : key;
      var limit = statKey === 'money'
        ? Math.max(100000, defaultLimit * 200)
        : _getAiStatFieldLimit(cfg, statKey);
      if (limit <= 0) return 0;
      return Math.max(-limit, Math.min(limit, val));
    }
    var zhNames = { arousal: '兴奋', stress: '压力', pain: '疼痛', trauma: '创伤', awareness: '觉知', lewdity: '淫乱', tiredness: '疲劳', purity: '纯洁', exhibitionism: '暴露癖', promiscuity: '淫乱癖', deviancy: '变态癖', masochism: '受虐癖', skulduggery: '偷窃', swimming: '游泳', athletics: '运动', tending: '护理', seduction: '诱惑', willpower: '意志力', physique: '体质', dancing: '舞蹈', housekeeping: '家政', science: '科学', english: '英语', maths: '数学', history: '历史', money: '金钱', beauty: '美貌', charm: '魅力', lust: '性欲', control: '自控', drunk: '醉酒', drugged: '药物', hallucinogen: '致幻' };
    var parts = runtimeStats.parts.slice();
    if (inferredMoney) parts.push('money' + (inferredMoney >= 0 ? '+' : '') + inferredMoney);
    var changed = [];
    parts.forEach(function (part) {
      var m = part.match(/(\w+)\s*([+-]\d+)/);
      if (!m) return;
      var key = m[1].toLowerCase();
      var val = parseInt(m[2], 10);
      var statSpec = _resolveAiRuntimeStat(key);
      if (!statSpec) return;
      var mappedKey = statSpec.target;
      if (mappedKey === 'money' && explicitMoneyDelta && Math.sign(explicitMoneyDelta) === Math.sign(val) && Math.abs(explicitMoneyDelta) !== Math.abs(val)) {
        console.warn('[AIStoryGen] money marker adjusted to match narrative amount: marker=' + val + ', narrative=' + explicitMoneyDelta);
        val = explicitMoneyDelta;
      } else if (mappedKey !== 'money') {
        val = _scaleAiRuntimeStatDeltaForNativeMeter(mappedKey, val);
      }
      if (V[mappedKey] !== undefined) {
        var appliedVal = clampDelta(mappedKey, val);
        if (!appliedVal) return;
        var nextVal = (Number(V[mappedKey]) || 0) + appliedVal;
        V[mappedKey] = mappedKey === 'money'
          ? Math.max(0, nextVal)
          : Math.max(0, Math.min(20000, nextVal));
        changed.push(mappedKey + (appliedVal >= 0 ? '+' : '') + appliedVal);
      }
    });
    if (transactionPlan && transactionPlan.stats) {
      transactionPlan.stats.applied = changed.length > 0;
      transactionPlan.stats.changed = changed.slice();
      transactionPlan.stats.moneyDeltaApplied = _findPlannedMoneyDelta(changed);
      if (!changed.length) transactionPlan.stats.blockedReason = 'no_supported_or_nonzero_changes';
    }
    if (changed.length) {
      console.log('[AIStoryGen] stats applied:', changed.join(', '));
      // Build visible stats line like the original game
      var visible = changed.map(function (c) {
        var m = c.match(/(\w+)([+-]\d+)/);
        if (!m) return c;
        var label = _getAiRuntimeStatLabel(m[1]) || m[1];
        var isMoney = String(m[1] || '').toLowerCase() === 'money';
        var color = isMoney
          ? (m[2].charAt(0) === '+' ? '#8f8' : '#f88')
          : (m[2].charAt(0) === '+' ? '#f88' : '#8f8');
        return '<span style="color:' + color + ';font-size:0.85em;">' + label + ' ' + m[2] + '</span>';
      }).join(' | ');
      cleanText += '<br><span class="ai-stats-line">[ ' + visible + ' ]</span>';

      _notifyAiStatsApplied(changed, transactionPlan, { reason: 'stats', delays: [50, 250] });
    }
    return cleanText;
  }

  // Append AI narrative to passage — preserves game content above
  function _prepareAiNarrativeTextEffects(rawText, cfg, opts) {
    opts = opts || {};
    cfg = cfg || loadCfg();
    var transactionPlan = _buildAiTransactionPlan(rawText, cfg, opts);
    var cleanText = parseAndApplyStats(rawText, transactionPlan);
    cleanText = parseAndApplyNpcRelationships(cleanText, transactionPlan);
    cleanText = parseAndApplyAiItems(cleanText, transactionPlan);
    cleanText = parseAndApplyAiItemUsage(cleanText, transactionPlan);
    if (opts.postProcess !== false) cleanText = applyPostProcess(cleanText, cfg);
    if (cfg.language === 'zh') cleanText = _localizeNamesInText(cleanText);
    _lastAiTransactionPlan = _cloneForAiSnapshot(transactionPlan);
    return {
      ok: true,
      rawText: String(rawText || ''),
      cleanText: cleanText,
      metadataText: cleanText,
      transactionPlan: transactionPlan,
      consistencyDiagnostics: _cloneForAiSnapshot(_lastConsistencyDiagnostics || []),
      consistencyBlockedEffects: _cloneForAiSnapshot(_lastConsistencyBlockedEffects || []),
      consistencyBlockedEffectSummary: _getConsistencyBlockedEffectSummary(),
      reason: opts.reason || ''
    };
  }

  var _aiTransactionEngine = TransactionModule.create({
    publicSchemaVersion: 5,
    loadCfg: loadCfg,
    captureRuntimeSnapshot: _captureAIRuntimeSnapshot,
    restoreRuntimeSnapshot: _restoreAIRuntimeSnapshot,
    captureGameSnapshot: _captureGameSnapshot,
    restoreGameSnapshot: _restoreGameSnapshot,
    prepareNarrativeTextEffects: _prepareAiNarrativeTextEffects,
    getLastChoiceText: function () { return _lastChoiceText || ''; },
    parseLocationMarker: parseLocationMarker,
    inferLocationFromText: inferLocationFromText,
    getLastLocationDecision: function () { return _cloneForAiSnapshot(_aiLastLocationDecision || null); },
    eventSuppressesLocationFallback: _aiEventSuppressesLocationFallback,
    stripAIMetadataMarkers: _stripAIMetadataMarkers,
    recordAiEventMemory: _recordAiEventMemory,
    lastAiEventLocationStatus: _lastAiEventLocationStatus,
    markLocationInTransit: _markAiLocationInTransit,
    warn: function (message, err) {
      try { console.warn(message, err); } catch (_) {}
    }
  });
  var _aiTransactionAuditor = TransactionAuditModule.create({ limit: 30 });
  var _lastAiTransactionAudit = null;
  window.AIStoryGen.transactionAuditor = _aiTransactionAuditor;

  function _maybeShowAiChangeSummary(audit, cfg) {
    try {
      cfg = cfg || loadCfg();
      if (!Number(cfg.showChangeSummary || 0)) return null;
      if (!audit || !ChangeSummaryModule || typeof ChangeSummaryModule.summarizeAudit !== 'function') return null;
      var summary = ChangeSummaryModule.summarizeAudit(audit, { maxLines: 6 });
      if (!summary || !summary.text) return null;
      _showAIUserMessage(summary.text, false);
      return summary;
    } catch (e) {
      try { console.warn('[AIStoryGen] change summary failed', e); } catch (_) {}
      return null;
    }
  }
  window.AIStoryGen.summarizeLastChange = function () {
    return ChangeSummaryModule.summarizeAudit(_lastAiTransactionAudit, { maxLines: 6 });
  };

  function _applyAiNarrativeTransaction(rawText, cfg, opts) {
    var txResult = _aiTransactionEngine.applyNarrative(rawText, cfg, opts);
    if (txResult && txResult.transactionPlan) _lastAiTransactionPlan = _cloneForAiSnapshot(txResult.transactionPlan);
    return txResult;
  }

  function _commitAiNarrativeTransaction(rawText, cfg, opts) {
    opts = opts || {};
    var beforeAuditSnapshot = null;
    try { beforeAuditSnapshot = _captureAIRuntimeSnapshot(); } catch (_) {}
    var txResult = _aiTransactionEngine.commitNarrative(rawText, cfg, opts);
    if (txResult && txResult.transactionPlan && _aiTransactionAuditor) {
      try {
        var afterAuditSnapshot = null;
        try { afterAuditSnapshot = _captureAIRuntimeSnapshot(); } catch (_) {}
        var audit = _aiTransactionAuditor.record(txResult.transactionPlan, beforeAuditSnapshot, afterAuditSnapshot, {
          reason: opts.reason || '',
          source: opts.source || ''
        });
        txResult.transactionPlan.audit = audit ? {
          id: audit.id,
          ok: !!audit.ok,
          warningCount: audit.warnings ? audit.warnings.length : 0,
          warnings: audit.warnings || [],
          summary: audit.readable && audit.readable.zh || ''
        } : null;
        _lastAiTransactionAudit = _cloneForAiSnapshot(audit || null);
        _maybeShowAiChangeSummary(audit, cfg);
      } catch (auditError) {
        try { console.warn('[AIStoryGen] transaction audit failed', auditError); } catch (_) {}
      }
    }
    if (txResult && txResult.transactionPlan) _lastAiTransactionPlan = _cloneForAiSnapshot(txResult.transactionPlan);
    return txResult;
  }

  var AITransaction = {
    schemaVersion: 5,
    applyNarrative: function (rawText, cfg, opts) {
      return _applyAiNarrativeTransaction(rawText, cfg, opts);
    },
    commitNarrative: function (rawText, cfg, opts) {
      return _commitAiNarrativeTransaction(rawText, cfg, opts);
    },
    captureSnapshot: function () {
      return _captureGameSnapshot();
    },
    restoreSnapshot: function (snapshot) {
      _restoreGameSnapshot(snapshot);
    },
    captureRuntimeSnapshot: function () {
      return _captureAIRuntimeSnapshot();
    },
    restoreRuntimeSnapshot: function (snapshot, opts) {
      _restoreAIRuntimeSnapshot(snapshot, opts);
    }
  };
  window.AIStoryGen.transaction = AITransaction;
  window.AIStoryGen.AITransaction = AITransaction;

  function advanceWithNarrative(text) {
    var cfg = loadCfg();
    var currentPassageName = (typeof State !== 'undefined' && State.passage) || '';
    var preserveNativeCombatUI = !_aiReplaceActive && (_isNativeCombatActive() || _isNativeSexOrCombatPassage(currentPassageName));
    var txResult = _commitAiNarrativeTransaction(text, cfg, {
      reason: 'advance narrative',
      source: 'advance',
      recordMemory: true,
      applyLocation: true,
      memory: {
        name: '[AI]',
        reason: 'AI剧情事件',
        choiceText: _lastChoiceText || '',
        source: 'advance'
      }
    });
    var cleanText = txResult.cleanText;

    var locUpdated = !!txResult.locUpdated;
    if (_aiReplaceActive && locUpdated && _aiLocationArrived) {
      // Do NOT sync immediately - Engine.play() destroys the current DOM mid-render.
      // The sync will occur when user clicks the arrival button.
      console.log('[AIStoryGen] location arrived during replace mode, deferring sync');
    }
    // Append AI narrative — in replace mode, clear page for "page-turn" effect
    var $passage = $('#passages .passage');
    if ($passage.length) {
      var $section = $('<div class="ai-narrative-section"></div>');
      try { new Wikifier($section[0], cleanText); } catch (e) { $section.text(cleanText); }
      if (_aiReplaceActive) {
        _clearAiOverlayResidue($passage, 'replace');
        // Push current AI content to round history BEFORE replacing it, unless the click handler already did.
        if (!_consumePrePushedAiRoundHistoryForAdvance()) _pushCurrentToAiRoundHistory();
        // Clear forward stack (new round invalidates forward history)
        _aiForwardStack.length = 0;
        // Replace mode: only update the AI overlay, original content stays hidden underneath
        var $aiWrap = $passage.find('.ai-replaced-content');
        if ($aiWrap.length) {
          $aiWrap.empty().append($section);
        } else {
          $aiWrap = $('<div class="ai-replaced-content"></div>').append($section);
          $passage.append($aiWrap);
        }
        _appendNarrativeToolbar($section, _aiReplaceTargetLabel || _lastChoiceText, cleanText, _lastNarrativePrompt);
        _updateReplaceSessionHTML();
      } else {
        _clearAiOverlayResidue($passage, 'normal');
        // Normal mode: store reference to dedicated AI narrative container, clear old content first
        if (preserveNativeCombatUI) {
          var $staleHiddenOriginal = $passage.find('.ai-original-wrap');
          if ($staleHiddenOriginal.length) $staleHiddenOriginal.replaceWith($staleHiddenOriginal.contents());
        }
        if (!_aiNarrativeWrap || !_aiNarrativeWrap.parentNode) {
          _aiNarrativeWrap = document.createElement('div');
          _aiNarrativeWrap.className = 'ai-narrative-wrap';
          $passage.find('.ai-injected-row').remove();
          if (preserveNativeCombatUI) {
            // Combat/sex-combat pages contain live native controls. Never hide them
            // when a generic AI narrative is generated on top of the page.
            var $hiddenOriginal = $passage.find('.ai-original-wrap');
            if ($hiddenOriginal.length) $hiddenOriginal.replaceWith($hiddenOriginal.contents());
          } else {
            // Hide original passage content (game links are stale after AI advance)
            var $overlayKeep = _detachNativeOverlayKeepers($passage);
            _hidePassageOriginalContent($passage);
            if ($overlayKeep.length) $passage.append($overlayKeep);
          }
          $passage[0].appendChild(_aiNarrativeWrap);
        } else {
          if (!_consumePrePushedAiRoundHistoryForAdvance()) _pushCurrentToAiRoundHistory();
          _aiForwardStack.length = 0;
        }
        // Clear old narrative and append new
        _aiNarrativeWrap.innerHTML = '';
        _aiNarrativeWrap.appendChild($section[0]);
        _appendNarrativeToolbar($section, _lastChoiceText || (typeof State !== 'undefined' ? State.passage : ''), cleanText, _lastNarrativePrompt);
      }
      try { $section[0].scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (_) {}
    }
    _syncAISaveStateToCurrentSave();

    _autoChoicesBusy = false;
    $('#passages .ai-choices').remove();

    if (preserveNativeCombatUI) {
      try { NativeSceneBridge.ensureCombatControls('preserve native combat UI'); } catch (_) {}
      return;
    }

    if (_aiReplaceActive) {
      // Replace mode: auto-generate new choices.
      _aiReplaceRoundCount++;
      autoInjectChoices(typeof State !== 'undefined' ? State.passage : '');
    } else {
      // Normal mode: auto-generate new choices immediately (no "continue" button)
      autoInjectChoices(typeof State !== 'undefined' ? State.passage : '');
    }
  }

  /** In-place narrative refresh after regen (no new choice round). */
  function _renderNarrativeIntoSection($section, rawText, narrativeName, prompt) {
    var cfg = loadCfg();
    var txResult = _commitAiNarrativeTransaction(rawText, cfg, {
      reason: 'render narrative refresh',
      source: 'refresh',
      recordMemory: false,
      applyLocation: true
    });
    var cleanText = txResult.cleanText;
    $section.empty();
    try { new Wikifier($section[0], cleanText); } catch (e) { $section.text(cleanText); }
    _appendNarrativeToolbar($section, narrativeName, cleanText, prompt);
    if (_aiReplaceActive) _updateReplaceSessionHTML();
    _syncAISaveStateToCurrentSave();
    return cleanText;
  }

  async function _regenerateNarrativeSection($section, narrativeName, prompt) {
    var cfg = loadCfg();
    try {
      _preflightAI(cfg);
    } catch (e) {
      _showAIUserMessage(e.message || e, true);
      return;
    }
    if (!prompt) {
      _showAIUserMessage(cfg.language === 'zh' ? '无法重新生成：缺少原始指令' : 'Cannot regenerate: no prompt stored', true);
      return;
    }
    var $toolbar = $section.find('.ai-narrative-toolbar');
    var $regenBtn = $toolbar.find('.ai-regen-narrative-link');
    if ($regenBtn.prop('disabled')) return;
    $regenBtn.prop('disabled', true).css('opacity', '0.5');
    var loadTxt = cfg.language === 'zh' ? '重新生成中…' : 'Regenerating…';
    var $loading = $('<div class="ai-gen-loading" style="text-align:center;padding:0.5em 0;color:#b4a078;"></div>').text(loadTxt);
    $toolbar.before($loading);
    var regenSuffix = cfg.language === 'zh'
      ? '\n\n<instruction>请重新生成一版完全不同的叙事（与上一版有明显差异），仍遵守相同的状态与场景约束。不要重复上一版的句子。</instruction>'
      : '\n\n<instruction>Regenerate a clearly different version (distinct from the previous one), same state/scene constraints. Do not repeat prior sentences.</instruction>';
    try {
      var text = await callAI(prompt + regenSuffix, { storyStyle: true, structuredPrompt: true, purpose: 'story-regenerate' });
      $loading.remove();
      _renderNarrativeIntoSection($section, text, narrativeName, prompt);
    } catch (e) {
      $loading.remove();
      $regenBtn.prop('disabled', false).css('opacity', '1');
      _showAIUserMessage((cfg.language === 'zh' ? '重新生成失败: ' : 'Regen failed: ') + (e.message || e));
    }
  }

  /** Toolbar: regen + bookmark links below each AI narrative section */
  function _appendNarrativeToolbar($section, narrativeName, narrativeText, prompt) {
    if (prompt) _lastNarrativePrompt = prompt;
    $section.find('.ai-narrative-toolbar').remove();
    var cfg = loadCfg();
    var regenLabel = cfg.language === 'zh' ? '🔄 刷新剧情' : '🔄 Refresh story';
    var choicesLabel = cfg.language === 'zh' ? '🔁 刷新选项' : '🔁 Refresh choices';
    var bookmarkLabel = cfg.language === 'zh' ? '☆ 收藏剧情进长期记忆' : '☆ Bookmark';
    var $bar = $('<div class="ai-narrative-toolbar"></div>');
    var $regen = $('<a class="ai-regen-narrative-link" href="javascript:void(0)"></a>').text(regenLabel);
    var $choices = $('<a class="ai-refresh-choices-link" href="javascript:void(0)"></a>').text(choicesLabel);
    var $bookmark = $('<a class="ai-bookmark-link" href="javascript:void(0)"></a>').text(bookmarkLabel);
    var storedPrompt = prompt || _lastNarrativePrompt;
    var storedName = narrativeName;
    $regen.on('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      _regenerateNarrativeSection($section, storedName, storedPrompt);
    });
    $choices.on('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      _forceRefreshChoicesFromToolbar(storedName);
    });
    $bookmark.on('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var sameButton = this;
      var $clone = $section.clone();
      $clone.find('.ai-narrative-toolbar, .ai-gen-loading').remove();
      var curText = ($clone.text() || narrativeText || '').trim();
      addLongTermMemory(storedName, curText);
      $(sameButton).text(cfg.language === 'zh' ? '★ 已收藏进长期记忆' : '★ Saved').css('color', '#c0a060');
      setTimeout(function () { $(sameButton).text(bookmarkLabel).css('color', '#b4a078'); }, 2000);
    });
    $bar.append($regen).append($choices).append($bookmark);
    $section.append($bar);
  }

  window.AIStoryGen.autoInjectChoices = autoInjectChoices;
  window.AIStoryGen.advanceWithNarrative = advanceWithNarrative;

  // Handle intercepted game link → replace passage with AI-generated location narrative
  async function handleLocationReplace(targetPassage, linkText, originalLinkId, originalEventMode) {
    targetPassage = _normalizePassageName(targetPassage);
    var cfg = loadCfg();
    if (!cfg.aiReplaceLinks) return;
    if (_aiReplaceActive) return;

    try {
      _preflightAI(cfg);
    } catch (preErr) {
      console.warn('[AIStoryGen] location replace preflight failed', preErr);
      _showAIUserMessage(preErr.message || preErr, true);
      _refreshApiWarnBar();
      return;
    }

    var $passage = $('#passages .passage');
    if (!$passage.length) return;

    // Entering a native-link replace session must not retain a normal AI overlay.
    _clearAiOverlayResidue($passage, 'replace');

    // Hide original passage content (wrap in hidden div — never leaves DOM)
    _hidePassageOriginalContent($passage);
    _aiReplaceActive = true;
    _aiReplaceRoundCount = 0;  // reset round counter
    _aiReplaceTargetLabel = linkText;
    _aiReplaceTargetPassage = targetPassage;
    _aiReplaceOriginalLinkId = String(originalLinkId || '');
    _aiReplaceOriginalEventMode = !!originalEventMode;
    _aiReplaceOriginPassage = (typeof State !== 'undefined' && State.passage) || '';

    // Reset LOC tracking for this session
    _aiAvailableDestinations = [];
    _setAiLocationState(targetPassage, cleanLabel(linkText), 'start AI replace target', { arrived: false });

    // Capture available destinations from passage links (cleaned labels)
    _collectDestinations($passage);

    // Create AI content wrapper and show loading inside it
    var $aiWrap = $('<div class="ai-replaced-content"></div>');
    var loadingTxt = cfg.language === 'zh'
      ? 'AI 正在生成【' + linkText + '】的剧情…'
      : 'AI generating [' + linkText + ']...';
    var $loading = $('<div class="ai-gen-loading" style="text-align:center;padding:2em 0;">' + loadingTxt + '</div>');
    $aiWrap.append($loading);
    $passage.append($aiWrap);
    _updateReplaceSessionHTML();
    $('#passages .ai-choices').remove();

    // Build prompt: tell AI to generate narrative about this specific location
    var state = buildState(cfg);
    var scene = buildScene();
    var cacheKey = (scene.physicalLocationPassage || scene.location || '') + '_' + (scene.sceneFocusPassage || '') + '_' + (scene.hour || '') + '_' + (scene.dangerLevel || '');

    var sceneBlock = buildScenePromptText(scene);
    var atmosphereHint = scene.dangerLevel === 'dangerous'
      ? (cfg.language === 'zh' ? '当前为危险区域——气氛应紧张不安、潜伏威胁。' : 'This is a dangerous area — tense, threatening atmosphere.')
      : scene.dangerLevel === 'wilderness'
      ? (cfg.language === 'zh' ? '当前为野外——自然环境、未知与暴露感。' : 'This is wilderness — nature, unknowns, exposure.')
      : scene.dangerLevel === 'night'
      ? (cfg.language === 'zh' ? '当前为深夜——昏暗不安、隐秘行为。' : 'This is night — dim, uneasy, clandestine.')
      : scene.dangerLevel === 'safe'
      ? (cfg.language === 'zh' ? '当前为安全区域——日常、放松的基调。' : 'This is a safe area — everyday, relaxed tone.')
      : '';
    var locationPromptQuery = [
      linkText,
      targetPassage,
      _getCurrentNativePageText(1400),
      buildScenePromptText(scene)
    ].join(' ');
    var stateLines = [
      _buildPromptStateBlock(state, locationPromptQuery, 'travel'),
      _buildNarrativeDataPolicyBlock(cfg)
    ].join('\n');
    var promptText = cfg.language === 'zh'
      ? [
          stateLines,
          buildRecentBlock({ query: locationPromptQuery }),
          buildCurrentAiStoryBlock(),
          buildNativeContextAuthorityBlock(),
          buildKnownNpcNamesBlock(locationPromptQuery),
          '<scene>',
          sceneBlock,
          '</scene>',
          '<instruction>',
          _aiReplaceOriginalEventMode
            ? '玩家刚刚选择了原版动作【' + linkText + '】（action passage: ' + targetPassage + '）。'
            : '玩家刚刚选择了前往【' + linkText + '】（target passage: ' + targetPassage + '）。',
          _aiReplaceOriginalEventMode ? '这是原版机制动作的叙事前奏。只描写玩家开始准备该动作，并停在动作真正结算之前；不得写成已经脱衣、睡着、付款、获得物品、改变关系或完成动作。下一步将由原版链接执行真实状态变化。location 必须保持当前物理地点，targetLocation=current，locationStatus=current；动作位置只写入 sceneFocus。' : '',
          _aiReplaceOriginalEventMode
            ? '请生成一段简短动作前奏（1-2个短段），用第二人称现在时，不生成后续选择。'
            : '请为到达该目的地的过程生成一段叙事（2-3个短段），用第二人称现在时，符合游戏风格。',
          _aiReplaceOriginalEventMode
            ? '★ 叙事重点：只写当前房间内可见的准备动作；不要写离开、行走或已经到达新地点。'
            : '★ 叙事重点：描述玩家"正在前往"目标地点的过渡过程——离开、行走、到达。不要在原地无休止地描写环境。',
          '<state> 只用于避免机制矛盾；正文只描写当前画面可见后果和明确在场 NPC 的反应，不复述数值、余额、任务清单或角色卡。',
          atmosphereHint ? atmosphereHint : '',
          '可以引入途中的随机遭遇或环境描写，但不要破坏第四面墙。',
          buildKnownPlacesBlock({ required: [{ raw: targetPassage, label: linkText }] }),
          _aiReplaceOriginalEventMode ? '' : buildLocationResponseFormatBlock(targetPassage),
          _aiReplaceOriginalEventMode ? '' : PromptBuilderModule.buildLocationMarkerRule('zh'),
          buildAIEventResponseFormatBlock(),
          '注意：不要在叙事结尾生成"继续前往"等链接或选项，系统会自动添加。',
          '</instruction>',
        ].join('\n')
      : [
          stateLines,
          buildRecentBlock({ query: locationPromptQuery }),
          buildCurrentAiStoryBlock(),
          buildNativeContextAuthorityBlock(),
          buildKnownNpcNamesBlock(locationPromptQuery),
          '<scene>',
          sceneBlock,
          '</scene>',
          '<instruction>',
          _aiReplaceOriginalEventMode
            ? 'The player selected the native action [' + linkText + '] (action passage: ' + targetPassage + ').'
            : 'The player chose to go to [' + linkText + '] (target passage: ' + targetPassage + ').',
          _aiReplaceOriginalEventMode ? 'This is a narrative lead-in for a native mechanic action. Describe only the visible preparation and stop before the action is mechanically completed. Do not say the player has undressed, fallen asleep, paid, gained an item, changed a relationship, or completed the action. The native link performs the real state change next. Keep location at the current physical passage, targetLocation=current, and locationStatus=current; put an in-room position only in sceneFocus.' : '',
          _aiReplaceOriginalEventMode
            ? 'Generate a short action lead-in (1-2 short paragraphs), second-person present tense, with no follow-up choices.'
            : 'Generate a transition narrative of ARRIVING at this destination (2-3 paragraphs), second-person present tense, game style.',
          _aiReplaceOriginalEventMode
            ? '★ Focus: visible preparation inside the current room only. Do not narrate travel or arrival at a new location.'
            : '★ Focus: describe the player "on the way" to the destination — leaving, walking, arriving. Do NOT spin endless location description.',
          '<state> only prevents mechanical contradictions. Narrate visible current-scene consequences and reactions by explicitly present NPCs; do not recite exact stats, balances, quest lists, or character sheets.',
          atmosphereHint ? atmosphereHint : '',
          'Include encounters or environmental details along the way. No meta commentary.',
          buildKnownPlacesBlock({ required: [{ raw: targetPassage, label: linkText }] }),
          _aiReplaceOriginalEventMode ? '' : buildLocationResponseFormatBlock(targetPassage),
          _aiReplaceOriginalEventMode ? '' : PromptBuilderModule.buildLocationMarkerRule('en'),
          buildAIEventResponseFormatBlock(),
          'Note: Do NOT generate "Continue to..." links or choices at the end — the system adds navigation automatically.',
          '</instruction>',
        ].join('\n');

    _lastNarrativePrompt = promptText;

    // Check narrative cache for same location+time
    if (!_aiReplaceOriginalEventMode && cfg.cacheEnabled && cfg.cacheEnabled > 0) {
      var cached = getCachedNarrative(cacheKey, cfg);
      if (cached) {
        $aiWrap.empty();
        var $cachedSection = $('<div class="ai-narrative-section"></div>');
        try { new Wikifier($cachedSection[0], cached); } catch (e) { $cachedSection.text(cached); }
        $aiWrap.append($cachedSection);
        _appendNarrativeToolbar($cachedSection, linkText, cached, promptText);
        if (_aiReplaceOriginalEventMode) {
        var $navWrap2 = $('<div class="ai-nav-wrap" style="text-align:center;margin-top:1.5em;padding:0.5em 0;"></div>');
        var navLabel2 = cfg.language === 'zh' ? '→ 继续原剧情' : '→ Continue story';
        var $navLink2 = $('<a class="ai-continue-link" style="font-size:1.1em;font-weight:bold;" href="javascript:void(0)">' + navLabel2 + '</a>');
        $navLink2.on('click', function (e) {
          e.preventDefault();
          _finishAiReplaceAndGo(targetPassage);
        });
        $navWrap2.append($navLink2);
        $aiWrap.append($navWrap2);
        }
        _updateReplaceSessionHTML();
        if (!_aiReplaceOriginalEventMode) autoInjectChoices(typeof State !== 'undefined' ? State.passage : '', linkText, targetPassage);
        return;
      }
    }

    try {
      suppressErrorReporter();
      _autoChoicesBusy = true;  // block concurrent autoInjectChoices from :passagedisplay
      var text = await callAI(promptText, { storyStyle: true, structuredPrompt: true, purpose: _aiReplaceOriginalEventMode ? 'story-native-action-leadin' : 'story-travel' });
      var rawNarrativeText = String(text || '');
      var txResult = _applyAiNarrativeTransaction(text, cfg, { reason: 'location replace first narrative', postProcess: false });
      var cleanText = txResult.cleanText;

      // Parse LOC marker and sync if AI has arrived at a known location
      parseLocationMarker(cleanText);
      cleanText = _stripAIMetadataMarkers(cleanText);
      // NOTE: Do NOT call syncOriginalPassageToCurrentLocation() here on first generation.
      // Engine.play() during handleLocationReplace causes the passage to switch mid-render,
      // destroying the AI overlay DOM. The sync will happen naturally when the player clicks
      // "到达".

      // Re-query live passage — DOM may have been rebuilt during the API call
      $passage = $('#passages .passage');
      if (!$passage.length) return;

      $aiWrap = $passage.find('.ai-replaced-content');
      if (!$aiWrap.length && _aiReplaceActive) {
        _hidePassageOriginalContent($passage);
        $aiWrap = $('<div class="ai-replaced-content"></div>');
        $passage.append($aiWrap);
      } else if (!$aiWrap.length) {
        _ensurePassageContentVisible();
        return;
      }

      // Replace loading with AI content inside the overlay wrapper
      $aiWrap.empty();
      var $section = $('<div class="ai-narrative-section"></div>');
      try { new Wikifier($section[0], cleanText); } catch (e) { $section.text(cleanText); }
      $aiWrap.append($section);
      _appendNarrativeToolbar($section, linkText, cleanText, promptText);

      // If the AI has not arrived yet, provide a direct native fallback link.
      // Once arrived, the generated AI choices panel supplies the "到达" button.
      if (_aiReplaceOriginalEventMode) {
        // Always append a guaranteed navigation link to the actual target passage
        // This ensures the player can always progress to the destination, regardless
        // of what the AI generated. Without this, players get stuck in endless AI loops.
        var $navWrap = $('<div class="ai-nav-wrap" style="text-align:center;margin-top:1.5em;padding:0.5em 0;"></div>');
        var navLabel = cfg.language === 'zh' ? '→ 继续原剧情' : '→ Continue story';
        var $navLink = $('<a class="ai-continue-link" style="font-size:1.1em;font-weight:bold;" href="javascript:void(0)">' + navLabel + '</a>');
        $navLink.on('click', function (e) {
          e.preventDefault();
          _finishAiReplaceAndGo(targetPassage);
        });
        $navWrap.append($navLink);
        $aiWrap.append($navWrap);
        try { $section[0].scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (_) {}
      }

      _updateReplaceSessionHTML();

      // Auto-generate AI choices for this location content
      _autoChoicesBusy = false;  // release lock before choices generation
      if (!_aiReplaceOriginalEventMode) autoInjectChoices(typeof State !== 'undefined' ? State.passage : '', linkText, targetPassage);

      // Push AI-generated narrative to memory buffer for continuity
      _recordAiEventMemory(rawNarrativeText, cleanText, {
        name: '[AI]' + linkText,
        reason: 'AI地点剧情',
        choiceText: linkText,
        location: targetPassage,
        originalEventMode: _aiReplaceOriginalEventMode,
        source: 'locationReplace'
      }, cfg);
      // Cache this narrative for same-location return visits
      if (!_aiReplaceOriginalEventMode && cfg.cacheEnabled && cfg.cacheEnabled > 0) {
        setCachedNarrative(cacheKey, cleanText);
      }
      restoreErrorReporter();
    } catch (e) {
      restoreErrorReporter();
      _autoChoicesBusy = false;
      console.error('[AIStoryGen] location replace error', e);
      var errMsg = (cfg.language === 'zh' ? 'AI 生成失败: ' : 'AI error: ') + (e && e.message ? e.message : e);
      _recoverFromFailedReplace(cfg, errMsg);
    }
  }
  window.AIStoryGen.handleLocationReplace = handleLocationReplace;

  // ---------- 3. 状态序列化 ----------
  function pick(obj, keys) {
    const o = {};
    if (!obj) return o;
    keys.forEach(function (k) { if (obj[k] !== undefined) o[k] = obj[k]; });
    return o;
  }

  function summarizeWorn(worn) {
    if (!worn) return 'naked';
    const slots = ['upper', 'lower', 'under_lower', 'under_upper', 'feet', 'head', 'neck', 'hands', 'legs', 'face', 'over_upper', 'over_lower'];
    const parts = [];
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      const item = worn[slot];
      if (item && item.name && item.name !== 'naked' && item.name !== 'none') {
        parts.push(slot + ':' + item.name);
      }
    }
    return parts.length ? parts.join(', ') : 'naked';
  }

  var _aiChineseNameMap = {
    Robin: '罗宾',
    Whitney: '惠特尼',
    Kylar: '凯拉尔',
    Sydney: '悉尼',
    Avery: '艾弗里',
    Eden: '伊甸',
    Alex: '亚历克斯',
    Bailey: '贝利',
    Harper: '哈珀',
    Leighton: '莱顿',
    Landry: '兰德里',
    Morgan: '摩根',
    Jordan: '约旦',
    Remy: '雷米',
    Charlie: '查理',
    River: '瑞弗',
    Doren: '多伦',
    Gwylan: '格威兰',
    Quinn: '奎因',
    Mason: '梅森',
    Niki: '尼基',
    Sam: '萨姆',
    Briar: '布赖尔',
    BlackWolf: '黑狼',
    Black_Wolf: '黑狼',
    GreatHawk: '大鹰',
    Great_Hawk: '大鹰',
    Wraith: '幽灵'
  };

  function _cloneNameMap(map) {
    var out = {};
    Object.keys(map || {}).forEach(function (key) { out[key] = map[key]; });
    return out;
  }

  function _hasChineseText(text) {
    return /[\u4e00-\u9fff]/.test(String(text || ''));
  }

  function _pickChineseNpcNameFromValue(value) {
    if (!value) return '';
    var candidates = [];
    function addCandidate(v) {
      if (v == null) return;
      if (Array.isArray(v)) {
        for (var i = 0; i < v.length; i++) addCandidate(v[i]);
        return;
      }
      if (typeof v === 'object') {
        ['zh', 'cn', 'name', 'title', 'displayname', 'fullDescription', 'description'].forEach(function (k) {
          if (v[k] != null) addCandidate(v[k]);
        });
        return;
      }
      var s = cleanLabel(String(v || '')).trim();
      if (s && _hasChineseText(s)) candidates.push(s);
    }
    addCandidate(value.displayname_lan);
    addCandidate(value.displayname);
    addCandidate(value.title);
    addCandidate(value.fullDescription);
    addCandidate(value.description);
    addCandidate(value.name);
    candidates.sort(function (a, b) { return a.length - b.length; });
    return candidates[0] || '';
  }

  function _getRuntimeChineseNameMap() {
    var map = _cloneNameMap(_aiChineseNameMap);
    try {
      var detector = (window.AIStoryGen && window.AIStoryGen.NativeTargetDetectorModule) || window.AIStoryGenNativeTargetDetectorModule;
      var labels = detector && typeof detector.getKnownNpcLabels === 'function' ? detector.getKnownNpcLabels() : null;
      Object.keys(labels || {}).forEach(function (key) {
        var zh = labels[key];
        if (zh && _hasChineseText(zh)) {
          map[key] = zh;
          map[key.replace(/\s+/g, '')] = zh;
        }
      });
    } catch (_) {}
    try {
      var list = _getAiNpcNameList();
      var root = _getAiNpcRoot();
      var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
      for (var i = 0; i < list.length; i++) {
        var key = String(list[i] || '').trim();
        if (!key) continue;
        var npc = (V.NPCName && V.NPCName[i]) || (root && root[key]) || (V && V[key]) || null;
        var zh = _pickChineseNpcNameFromValue(npc);
        if (zh) {
          map[key] = zh;
          map[key.replace(/\s+/g, '')] = zh;
        }
      }
    } catch (_) {}
    return map;
  }

  function _canonicalizeChineseNpcNameVariants(text, map) {
    text = String(text || '');
    map = map || _getRuntimeChineseNameMap();
    var jordan = map.Jordan || map.JordanTemple || '';
    if (jordan === '约旦') text = text.replace(/乔丹/g, '约旦');
    if (map.Alex === '艾利克斯') text = text.replace(/亚历克斯/g, '艾利克斯');
    if (map.Sydney === '悉尼') text = text.replace(/西德尼/g, '悉尼');
    if (map.Avery === '艾弗利') text = text.replace(/艾弗里/g, '艾弗利');
    if (map.GreatHawk === '巨鹰' || map.Great_Hawk === '巨鹰') text = text.replace(/大鹰/g, '巨鹰');
    return text;
  }

  function _toChineseName(name) {
    name = String(name || '').trim();
    if (!name) return '';
    var map = _getRuntimeChineseNameMap();
    return map[name] || map[name.replace(/\s+/g, '')] || name;
  }

  function _localizeNamesInText(text) {
    text = String(text || '');
    var map = _getRuntimeChineseNameMap();
    Object.keys(map).forEach(function (key) {
      var zh = map[key];
      text = text.replace(new RegExp('\\b' + key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'g'), zh);
    });
    text = _canonicalizeChineseNpcNameVariants(text, map);
    text = _localizeStatTermsInText(text);
    text = _localizeCommonEnglishInChineseText(text);
    return text;
  }

  function _localizeCommonEnglishInChineseText(text) {
    text = String(text || '');
    var phraseMap = [
      ['miko outfit', '\u5deb\u5973\u670d'],
      ['wooden sandals', '\u6728\u5c50'],
      ['paper umbrella', '\u6cb9\u7eb8\u4f1e']
    ];
    phraseMap.forEach(function (pair) {
      text = text.replace(new RegExp('\\b' + pair[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'gi'), pair[1]);
    });
    var map = {
      warmth: '\u6e29\u70ed',
      warm: '\u6e29\u6696',
      cold: '\u51b0\u51b7',
      heat: '\u70ed\u610f',
      arousal: '\u6027\u594b',
      awareness: '\u89c9\u77e5',
      stress: '\u538b\u529b',
      pain: '\u75bc\u75db',
      trauma: '\u521b\u4f24',
      control: '\u81ea\u63a7',
      lust: '\u6b32\u671b',
      fatigue: '\u75b2\u52b3',
      tiredness: '\u75b2\u52b3',
      drugged: '\u836f\u6548',
      drunk: '\u9189\u610f',
      beauty: '\u7f8e\u8c8c',
      charm: '\u9b45\u529b',
      money: '\u91d1\u94b1',
      zori: '\u6728\u5c50',
      miko: '\u5deb\u5973',
      outfit: '\u670d\u88c5',
      jacket: '\u5939\u514b',
      boots: '\u9774\u5b50'
    };
    Object.keys(map).forEach(function (key) {
      text = text.replace(new RegExp('\\b' + key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'gi'), map[key]);
    });
    return text;
  }

  function _localizeStatTermsInText(text) {
    text = String(text || '');
    var map = {
      arousal: '兴奋',
      awareness: '觉知',
      stress: '压力',
      pain: '疼痛',
      trauma: '创伤',
      control: '自控',
      lust: '欲望',
      lewdity: '淫乱度',
      lewdness: '淫乱度',
      fatigue: '疲劳',
      tiredness: '疲劳',
      drugged: '药效',
      drunk: '醉意',
      hallucinogen: '致幻感',
      beauty: '美貌',
      charm: '魅力',
      money: '金钱'
    };
    Object.keys(map).forEach(function (key) {
      text = text.replace(new RegExp('\\b' + key + '\\b', 'gi'), map[key]);
    });
    return text;
  }

  function _aiNum(value, fallback) {
    var n = Number(value);
    return isFinite(n) ? n : (fallback || 0);
  }

  function _aiStatusEntry(value, max, label) {
    value = _aiNum(value, 0);
    max = _aiNum(max, 0);
    return {
      value: value,
      max: max || undefined,
      label: label,
      text: label + (max > 0 ? ' (' + value + '/' + max + ')' : ' (' + value + ')')
    };
  }

  function _aiTierLabel(value, max, labels) {
    value = _aiNum(value, 0);
    max = _aiNum(max, 0);
    if (max <= 0) return labels[0] || '';
    if (value >= max) return labels[6];
    if (value >= max * 4 / 5) return labels[5];
    if (value >= max * 3 / 5) return labels[4];
    if (value >= max * 2 / 5) return labels[3];
    if (value >= max / 5) return labels[2];
    if (value >= 1) return labels[1];
    return labels[0];
  }

  function _aiTraumaLabel(value, max) {
    return _aiTierLabel(value, max || 5000, ['\u5065\u5eb7', '\u4e0d\u5b89', '\u7d27\u5f20', '\u56f0\u6270', '\u4e0d\u7a33\u5b9a', '\u5907\u53d7\u6298\u78e8', '\u9ebb\u6728']);
  }

  function _aiStressLabel(value, max) {
    return _aiTierLabel(value, max || 10000, ['\u5e73\u9759', '\u5b89\u7a33', '\u51b7\u9759', '\u7d27\u7ef7', '\u5403\u529b', '\u75db\u82e6', '\u538b\u5012\u6027\u5d29\u6e83']);
  }

  function _aiArousalLabel(value, max) {
    return _aiTierLabel(value, max || 10000, ['\u51b7\u6de1', '\u88ab\u523a\u6fc0', '\u6027\u594b', '\u6b32\u671b\u4e0a\u5347', '\u96be\u4ee5\u5e73\u9759', '\u70ed\u610f\u7ffb\u6d8c', '\u56e0\u6027\u594b\u53d1\u6296']);
  }

  function _aiControlLabel(value, max, possessed) {
    if (possessed) {
      return _aiTierLabel(value, max || 1000, ['\u65e0\u529b', '\u88ab\u64cd\u7eb5', '\u9ebb\u6728', '\u7a7a\u6d1e', '\u6323\u624e', '\u63a5\u8fd1\u638c\u63a7', '\u638c\u63a7']);
    }
    return _aiTierLabel(value, max || 1000, ['\u5931\u63a7', '\u60ca\u6050', '\u6050\u60e7', '\u7126\u8651', '\u62c5\u5fe7', '\u4e0d\u5b89', '\u81ea\u4fe1']);
  }

  function _aiFatigueLabel(value, max) {
    return _aiTierLabel(value, max || 2000, ['\u7cbe\u529b\u5145\u6c9b', '\u6e05\u9192', '\u8b66\u89c9', '\u7565\u611f\u75b2\u60eb', '\u75b2\u60eb', '\u6781\u5ea6\u75b2\u52b3', '\u7b4b\u75b2\u529b\u5c3d']);
  }

  function _aiHungerLabel(value) {
    value = _aiNum(value, 0);
    if (value >= 2000) return '\u6328\u997f';
    if (value >= 1600) return '\u9965\u80a0\u8f98\u8f98';
    if (value >= 1200) return '\u5f88\u997f';
    if (value >= 800) return '\u9965\u997f';
    if (value >= 400) return '\u5fae\u997f';
    if (value >= 1) return '\u6ee1\u8db3';
    return '\u9971\u8179';
  }

  function _aiPainLabel(value) {
    value = _aiNum(value, 0);
    if (value >= 100) return '\u5d29\u6e83\u5927\u54ed';
    if (value >= 80) return '\u54ed\u6ce3\u55da\u54bd';
    if (value >= 60) return '\u54ed\u6ce3';
    if (value >= 40) return '\u6cea\u6c34\u6d41\u4e0b';
    if (value >= 20) return '\u773c\u7736\u542b\u6cea';
    if (value >= 1) return '\u96be\u53d7';
    return '\u65e0\u788d';
  }

  function _aiGenericLevel(value, max) {
    return _aiTierLabel(value, max || 1000, ['\u65e0', '\u5f88\u4f4e', '\u8f83\u4f4e', '\u4e2d\u7b49', '\u8f83\u9ad8', '\u5f88\u9ad8', '\u6781\u9ad8']);
  }

  function _aiRelationLevel(value) {
    value = _aiNum(value, 0);
    if (value >= 60) return '\u975e\u5e38\u9ad8';
    if (value >= 30) return '\u8f83\u9ad8';
    if (value >= 0) return '\u4e2d\u6027';
    if (value >= -30) return '\u8f83\u4f4e';
    return '\u5f88\u4f4e';
  }

  function _aiSkillGrade(value) {
    value = _aiNum(value, 0);
    if (value >= 1000) return 'S';
    if (value >= 800) return 'A';
    if (value >= 600) return 'B';
    if (value >= 400) return 'C';
    if (value >= 200) return 'D';
    if (value >= 1) return 'F';
    return '\u65e0';
  }

  function _aiDetailedSkillGrade(value) {
    value = _aiNum(value, 0);
    if (value >= 1000) return 'S';
    if (value >= 900) return 'A+';
    if (value >= 800) return 'A';
    if (value >= 700) return 'B+';
    if (value >= 600) return 'B';
    if (value >= 500) return 'C+';
    if (value >= 400) return 'C';
    if (value >= 300) return 'D+';
    if (value >= 200) return 'D';
    if (value >= 100) return 'F+';
    if (value >= 1) return 'F';
    return '\u65e0';
  }

  function _aiSchoolGrade(value) {
    value = _aiNum(value, -1);
    if (value >= 4) return 'A*';
    if (value >= 3) return 'A';
    if (value >= 2) return 'B';
    if (value >= 1) return 'C';
    if (value >= 0) return 'D';
    return 'F';
  }

  function _aiGetSetupRoot() {
    try { if (typeof setup !== 'undefined' && setup) return setup; } catch (_) {}
    try { if (window.SugarCube && window.SugarCube.setup) return window.SugarCube.setup; } catch (_) {}
    try { if (window.setup) return window.setup; } catch (_) {}
    return null;
  }

  function _aiGetTimeRoot() {
    try { if (typeof Time !== 'undefined' && Time) return Time; } catch (_) {}
    try { if (window.Time) return window.Time; } catch (_) {}
    return null;
  }

  function _aiGetWeatherName(V) {
    return safeRead(function () {
      if (typeof Weather !== 'undefined' && Weather && Weather.name) return Weather.name;
      if (window.Weather && window.Weather.name) return window.Weather.name;
      return V && V.weatherObj && V.weatherObj.name;
    }, 'unknown');
  }

  function _aiBuildWorldState(V) {
    var T = _aiGetTimeRoot();
    return {
      time: {
        hour: safeRead(function () { return T && T.hour; }, V.hour),
        minute: safeRead(function () { return T && T.minute; }, V.minute),
        weekDay: safeRead(function () { return T && (T.weekDayName || T.weekDay); }, V.weekday),
        monthDay: safeRead(function () { return T && T.monthDay; }, V.day),
        month: safeRead(function () { return T && T.monthName; }, ''),
        year: safeRead(function () { return T && T.year; }, ''),
        dayState: safeRead(function () { return T && T.dayState; }, ''),
        season: safeRead(function () { return T && T.season; }, ''),
        gameDays: safeRead(function () { return T && T.days; }, V.days)
      },
      school: {
        term: !!safeRead(function () { return T && T.schoolTerm; }, false),
        schoolDay: !!safeRead(function () { return T && T.schoolDay; }, false),
        schoolTime: !!safeRead(function () { return T && T.schoolTime; }, false)
      },
      moonPhase: safeRead(function () { return T && T.currentMoonPhase && T.currentMoonPhase.description; }, ''),
      weather: _aiGetWeatherName(V),
      location: {
        area: safeRead(function () { return V.area; }, 'unknown'),
        location: safeRead(function () { return V.location; }, 'unknown'),
        outside: !!safeRead(function () { return V.outside; }, false),
        passage: _currentPassageName()
      }
    };
  }

  function _aiBuildStatusDetail(V) {
    var possessed = !!safeRead(function () { return V.possessed; }, false);
    var arousalMax = _aiNum(V.arousalmax, 10000);
    var stressMax = _aiNum(V.stressmax, 10000);
    var traumaMax = _aiNum(V.traumamax, 5000);
    var controlMax = _aiNum(V.controlmax, 1000);
    var tiredMax = _aiNum((V.C && V.C.tiredness && V.C.tiredness.max), 2000);
    return {
      arousal: _aiStatusEntry(V.arousal, arousalMax, _aiArousalLabel(V.arousal, arousalMax)),
      stress: _aiStatusEntry(V.stress, stressMax, _aiStressLabel(V.stress, stressMax)),
      trauma: _aiStatusEntry(V.trauma, traumaMax, _aiTraumaLabel(V.trauma, traumaMax)),
      control: _aiStatusEntry(V.control, controlMax, _aiControlLabel(V.control, controlMax, possessed)),
      pain: _aiStatusEntry(V.pain, 100, _aiPainLabel(V.pain)),
      tiredness: _aiStatusEntry(V.tiredness, tiredMax, _aiFatigueLabel(V.tiredness, tiredMax)),
      hunger: _aiStatusEntry(V.hunger, 2000, _aiHungerLabel(V.hunger)),
      awareness: _aiStatusEntry(V.awareness, V.awarenessmax || 1000, _aiGenericLevel(V.awareness, V.awarenessmax || 1000)),
      lewdness: _aiStatusEntry(V.lewdity, 100, _aiGenericLevel(V.lewdity, 100)),
      effects: {
        drunk: _aiNum(V.drunk, 0),
        drugged: _aiNum(V.drugged, 0),
        hallucinogen: _aiNum(V.hallucinogen, 0),
        dissociation: _aiNum(V.dissociation, 0),
        trance: _aiNum(V.trance, 0),
        possessed: possessed,
        nightmares: _aiNum(V.nightmares, 0),
        anxiety: _aiNum(V.anxiety, 0),
        flashbacks: _aiNum(V.flashbacks, 0),
        panicAttacks: _aiNum(V.panicattacks, 0),
        hallucinations: _aiNum(V.hallucinations, 0)
      }
    };
  }

  function _aiSkillValue(value, detailed) {
    value = _aiNum(value, 0);
    return { value: value, grade: detailed ? _aiDetailedSkillGrade(value) : _aiSkillGrade(value) };
  }

  function _aiBuildSkillSummary(V) {
    return {
      general: {
        skulduggery: _aiSkillValue(V.skulduggery, true),
        dancing: _aiSkillValue(V.danceskill, true),
        swimming: _aiSkillValue(V.swimmingskill, true),
        athletics: _aiSkillValue(V.athletics, true),
        tending: _aiSkillValue(V.tending, true),
        housekeeping: _aiSkillValue(V.housekeeping, true)
      },
      sex: {
        seduction: _aiSkillValue(V.seductionskill, false),
        oral: _aiSkillValue(V.oralskill, false),
        vaginal: _aiSkillValue(V.vaginalskill, false),
        anal: _aiSkillValue(V.analskill, false),
        hand: _aiSkillValue(V.handskill, false),
        feet: _aiSkillValue(V.feetskill, false),
        penile: _aiSkillValue(V.penileskill, false),
        chest: _aiSkillValue(V.chestskill, false),
        thigh: _aiSkillValue(V.thighskill, false),
        bottom: _aiSkillValue(V.bottomskill, false)
      },
      school: {
        science: { score: _aiNum(V.science, 0), grade: _aiSchoolGrade(V.sciencetrait) },
        maths: { score: _aiNum(V.maths, 0), grade: _aiSchoolGrade(V.mathstrait) },
        english: { score: _aiNum(V.english, 0), grade: _aiSchoolGrade(V.englishtrait) },
        history: { score: _aiNum(V.history, 0), grade: _aiSchoolGrade(V.historytrait) },
        detention: _aiNum(V.detention, 0)
      }
    };
  }

  function _aiBuildNpcExtra(V, name) {
    var extra = {};
    switch (name) {
      case 'Robin':
        extra.timer = safeRead(function () { return V.robin && V.robin.timer; }, null);
        extra.hurtReason = safeRead(function () { return V.robin && V.robin.hurtReason; }, null);
        extra.moneyModifier = safeRead(function () { return V.robin && V.robin.moneyModifier; }, null);
        break;
      case 'Whitney':
        extra.gang = safeRead(function () { return V.whitney && V.whitney.gang; }, null);
        break;
      case 'Sydney': {
        var st = _aiGetSetupRoot();
        var idx = st && st.NPCNameList ? st.NPCNameList.indexOf('Sydney') : -1;
        extra.purity = idx >= 0 ? safeRead(function () { return V.NPCName && V.NPCName[idx] && V.NPCName[idx].purity; }, null) : null;
        extra.corruption = idx >= 0 ? safeRead(function () { return V.NPCName && V.NPCName[idx] && V.NPCName[idx].corruption; }, null) : null;
        break;
      }
      case 'Kylar':
        extra.raped = safeRead(function () { return V.kylar && V.kylar.raped; }, null);
        extra.riddle = safeRead(function () { return V.kylar && V.kylar.riddle; }, null);
        extra.fameStage = safeRead(function () { return V.kylar && V.kylar.fameStage; }, null);
        break;
      case 'Eden':
        extra.freedom = safeRead(function () { return V.edenfreedom; }, null);
        extra.days = safeRead(function () { return V.edendays; }, null);
        break;
      case 'Avery':
        extra.mansion = safeRead(function () { return V.avery_mansion != null; }, false);
        extra.mansionSchedule = safeRead(function () { return V.avery_mansion && V.avery_mansion.schedule; }, null);
        break;
      case 'Alex':
        extra.farmStage = safeRead(function () { return V.farm_stage; }, null);
        break;
      case 'Gwylan':
        extra.progress = safeRead(function () { return V.gwylan && V.gwylan.progress; }, null);
        break;
    }
    Object.keys(extra).forEach(function (key) {
      if (extra[key] == null || extra[key] === '') delete extra[key];
    });
    return extra;
  }

  function _aiEscapeRegExp(text) {
    return String(text || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function _aiBuildNamedNpcPromptEntry(V, name, npc, loveInterests) {
    npc = npc || {};
    var zhName = _toChineseName(name);
    var entry = {
      name: zhName,
      key: name,
      title: _localizeNamesInText(npc.title || zhName),
      gender: npc.gender || '',
      state: npc.state || '',
      isLoveInterest: !!(loveInterests && loveInterests.indexOf(name) !== -1),
      relationship: {
        love: _aiRelationObject(npc.love),
        lust: _aiRelationObject(npc.lust),
        dom: _aiRelationObject(npc.dom),
        rage: _aiRelationObject(npc.rage),
        trust: _aiRelationObject(npc.trust)
      }
    };
    var extra = _aiBuildNpcExtra(V, name);
    if (Object.keys(extra).length) entry.extra = extra;
    return entry;
  }

  function _aiCollectPresentNpcDetails(V, npcDetails, npcNameList) {
    var present = [];
    var seen = {};
    var text = '';
    try {
      var passageEl = document && document.querySelector && document.querySelector('#passages .passage');
      if (passageEl) text = String(passageEl.textContent || '');
    } catch (_) {}
    var localizedText = _localizeNamesInText(text);
    var rawText = String(text || '');

    function push(entry, source, evidence) {
      if (!entry || !entry.key || seen[entry.key]) return;
      seen[entry.key] = true;
      var copy = JSON.parse(JSON.stringify(entry));
      copy.presentSource = source || 'unknown';
      if (evidence) copy.presentEvidence = evidence;
      present.push(copy);
    }

    var byKey = {};
    (npcDetails || []).forEach(function (entry) {
      if (entry && entry.key) byKey[entry.key] = entry;
    });

    // Native named NPC rows are the strongest signal that an NPC is currently involved.
    try {
      var npcRows = Array.isArray(V.npcrow) ? V.npcrow : [];
      var npcKeys = Array.isArray(V.npc) ? V.npc : [];
      for (var ri = 0; ri < npcRows.length; ri++) {
        var rowKey = npcKeys[ri];
        if (rowKey && byKey[rowKey]) push(byKey[rowKey], 'native_npcrow', rowKey);
      }
    } catch (_) {}

    // Page text is the next best signal for named scene interaction.
    for (var i = 0; i < (npcDetails || []).length && present.length < 8; i++) {
      var npc = npcDetails[i];
      if (!npc || !npc.key || seen[npc.key]) continue;
      var candidates = [npc.name, npc.title, npc.key];
      var matched = '';
      for (var ci = 0; ci < candidates.length; ci++) {
        var cand = String(candidates[ci] || '').trim();
        if (!cand) continue;
        if (_hasChineseText(cand) && cand.length >= 2 && localizedText.indexOf(cand) >= 0) {
          matched = cand;
          break;
        }
        if (/^[A-Za-z][A-Za-z\s'-]{1,40}$/.test(cand)) {
          var re = new RegExp('(^|[^A-Za-z])' + _aiEscapeRegExp(cand) + '([^A-Za-z]|$)', 'i');
          if (re.test(rawText)) {
            matched = cand;
            break;
          }
        }
      }
      if (matched) push(npc, 'page_text', matched);
    }

    return present.slice(0, 8);
  }

  function _aiNativeEncounterNpcContext(V) {
    V = V || {};
    var out = {
      trusted: false,
      source: 'none',
      activeCount: 0,
      names: [],
      details: []
    };
    var npcList = Array.isArray(V.NPCList) ? V.NPCList : [];
    if (!npcList.length) return out;

    var nativeCount = Number(V.enemyno);
    var hasNativeCount = Number.isFinite(nativeCount) && nativeCount >= 0;
    var combatActive = _aiNum(V.combat, 0) === 1;
    var currentPassage = _normalizePassageName(_currentPassageName()).toLowerCase();
    var eventBufferMatches = false;
    try {
      var eventBuffer = V.event && Array.isArray(V.event.buffer) ? V.event.buffer : [];
      eventBufferMatches = eventBuffer.some(function (entry) {
        var area = entry && Array.isArray(entry.area) ? _normalizePassageName(entry.area[0] || '').toLowerCase() : '';
        return !!(area && currentPassage && (area === currentPassage || area.indexOf(currentPassage + ' ') === 0 || currentPassage.indexOf(area + ' ') === 0));
      });
    } catch (_) {}

    if (hasNativeCount) {
      out.trusted = nativeCount > 0;
      out.source = nativeCount > 0 ? 'native_enemyno' : 'native_enemyno_zero';
      out.activeCount = Math.max(0, Math.floor(nativeCount));
    } else if (combatActive) {
      out.trusted = true;
      out.source = 'native_combat';
      out.activeCount = _getNativeEventActiveNpcCount(V);
    } else if (eventBufferMatches) {
      out.trusted = true;
      out.source = 'matching_native_event';
      out.activeCount = _getNativeEventActiveNpcCount(V);
    }

    if (!out.trusted || out.activeCount <= 0) return out;
    var slotLimit = Math.min(npcList.length, out.activeCount, 6);
    for (var i = 0; i < slotLimit; i++) {
      var npc = npcList[i];
      if (!npc || (npc.active != null && npc.active !== 'active')) continue;
      if (npc.type == null && !npc.fullDescription && !npc.description) continue;
      var name = _localizeNamesInText(npc.fullDescription || npc.description || ('NPC#' + i));
      out.names.push(name);
      out.details.push({
        slot: i,
        name: name,
        type: npc.type || 'human',
        role: npc.role || '',
        gender: npc.gender || '',
        stance: npc.stance || '',
        trust: _aiRelationObject(npc.trust),
        lust: _aiRelationObject(npc.lust),
        love: _aiRelationObject(npc.love),
        dom: _aiRelationObject(npc.dom)
      });
    }
    return out;
  }

  function _aiRelationObject(value) {
    value = _aiNum(value, 0);
    return { value: value, level: _aiRelationLevel(value) };
  }

  function _aiMoneyPence(value) {
    value = Number(value || 0);
    if (!isFinite(value)) return 0;
    return Math.round(value);
  }

  function _aiFormatMoneyPence(value) {
    var pence = _aiMoneyPence(value);
    var sign = pence < 0 ? '-' : '';
    var abs = Math.abs(pence);
    var pounds = Math.floor(abs / 100);
    var pennies = String(abs % 100);
    while (pennies.length < 2) pennies = '0' + pennies;
    return sign + '\u00a3' + pounds.toLocaleString('en-GB') + '.' + pennies;
  }

  function _aiMoneyStateValue(value) {
    var pence = _aiMoneyPence(value);
    return {
      display: _aiFormatMoneyPence(pence),
      internalPence: pence
    };
  }

  function _aiBuildActiveQuests(V) {
    var T = _aiGetTimeRoot();
    var urgent = [];
    var active = [];
    function push(list, name, description, deadline) {
      list.push({ name: name, description: description, deadline: deadline || null });
    }
    var rentMoney = _aiNum(V.rentmoney, 0);
    if (rentMoney > 0) {
      var rentTime = _aiNum(V.renttime, 7);
      push(rentTime <= 1 ? urgent : active, 'Bailey rent', 'Rent due: ' + _aiFormatMoneyPence(rentMoney) + ', days left: ' + rentTime, rentTime <= 0 ? 'overdue' : (rentTime <= 1 ? 'today/tomorrow' : rentTime + ' days'));
    }
    if (_aiNum(V.community_service, 0) >= 1) push(urgent, 'Community service', 'Report to the police station on Barb Street.', 'today');
    var weekDay = _aiNum(safeRead(function () { return T && T.weekDay; }, 0), 0);
    if ((safeRead(function () { return V.harper_appointments && V.harper_appointments.enabled; }, false) || _aiNum(V.schoolPsych, 0) === 1) && weekDay === 6 && !safeRead(function () { return V.daily && V.daily.harperVisit; }, 0)) {
      push(urgent, 'Harper appointment', 'Doctor Harper appointment at the hospital.', 'today');
    }
    if (_aiNum(V.edenfreedom, 0) > 0) push(active, 'Eden return', 'Return to Eden cabin, days left: ' + _aiNum(V.edendays, 0), _aiNum(V.edendays, 0) <= 1 ? 'urgent' : _aiNum(V.edendays, 0) + ' days');
    var showType = safeRead(function () { return V.brothelshowdata && V.brothelshowdata.type; }, 'none');
    if (showType !== 'none' && safeRead(function () { return V.brothelshowdata && V.brothelshowdata.intro; }, false) && weekDay === 6) {
      push(urgent, 'Brothel show', 'Scheduled brothel show: ' + showType, 'today');
    }
    if (_aiNum(V.averydate, 0) === 1 && weekDay === 7) push(urgent, 'Avery date', 'Date with Avery tonight.', 'today 20:00');
    if (safeRead(function () { return T && T.schoolDay; }, false)) {
      var attended = safeRead(function () { return Object.keys((V.daily && V.daily.school && V.daily.school.attended) || {}); }, []);
      if (attended.length < 5) push(_aiNum(safeRead(function () { return T && T.hour; }, 0), 0) >= 13 ? urgent : active, 'School', (5 - attended.length) + ' lesson(s) remaining today.', 'before 15:00');
    }
    var templeRank = safeRead(function () { return V.temple_rank; }, '');
    if (templeRank && templeRank !== 'prospective') push(active, 'Temple duties', 'Temple rank: ' + templeRank + '. Check temple tasks.', null);
    if (_aiNum(V.farm_stage, 0) >= 1 && _aiNum(V.farm_attack_timer, 0) > 0) {
      push(active, 'Farm defense', 'Farm attack in ' + _aiNum(V.farm_attack_timer, 0) + ' day(s).', _aiNum(V.farm_attack_timer, 0) + ' days');
    }
    return { urgent: urgent, active: active };
  }

  function _aiBuildCurrentSceneSummary() {
    var out = {
      passageName: _currentPassageName(),
      tags: [],
      availableChoices: [],
      isInCombat: false,
      isSafePassage: false
    };
    try {
      var V = getSafeV() || {};
      out.isInCombat = _aiNum(V.combat, 0) === 1;
      var st = _aiGetSetupRoot();
      var major = st && Array.isArray(st.majorAreas) ? st.majorAreas : [];
      out.isSafePassage = major.indexOf(out.passageName) !== -1;
      if (window.SugarCube && window.SugarCube.Story && out.passageName) {
        var p = window.SugarCube.Story.get(out.passageName);
        out.tags = p && p.tags ? p.tags.slice(0, 12) : [];
      }
      var links = [];
      var passageEl = document.querySelector('#passages .passage');
      if (passageEl) {
        var nodes = passageEl.querySelectorAll('a[data-passage], .link-internal[data-passage]');
        for (var i = 0; i < nodes.length && links.length < 12; i++) {
          var txt = cleanLabel(nodes[i].textContent || '');
          var target = nodes[i].getAttribute('data-passage') || '';
          if (txt && target && !_isGameMenuPassage(target) && !/AIStoryGen_/.test(target)) {
            links.push({ text: txt, passage: target });
          }
        }
      }
      out.availableChoices = links;
    } catch (_) {}
    return out;
  }

  function buildState(cfg) {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
    var tier = cfg.tier || 2;

    var state = {
      world: _aiBuildWorldState(V),
      player: {
        gender: V.player ? (V.player.gender_appearance || V.player.gender) : V.gender,
        body: V.player ? V.player.bodysize : undefined,
        pronoun: V.pronoun,
      },
      stats: {
        arousal: V.arousal,
        awareness: V.awareness,
        lewdness: V.lewdity,
        stress: V.stress,
        pain: V.pain,
        trauma: V.trauma,
      },
      statusDetail: _aiBuildStatusDetail(V),
      worn_summary: summarizeWorn(V.worn),
      money: _aiMoneyStateValue(V.money),
    };
    var extraLongHairState = _aiExtraLongHair.getStoryState();
    if (extraLongHairState) state.player.hairAppearance = extraLongHairState;

    if (tier >= 2) {
      // -- Named NPC overview (persistent relationships, all met NPCs) --
      var _setup = (typeof setup !== 'undefined') ? window.setup : (window.SugarCube && window.SugarCube.setup) || null;
      var _C = (typeof C !== 'undefined' && C) ? C : (window.C || null);
      var npcNameList = (_setup && _setup.NPCNameList) ? _setup.NPCNameList : [];
      var loveInterests = (_setup && _setup.loveInterestNpc) ? _setup.loveInterestNpc : [];
      var npcs = [];
      var npcDetails = [];
      for (var ni = 0; ni < npcNameList.length; ni++) {
        var name = npcNameList[ni];
        var npc = (_C && _C.npc && _C.npc[name]) || (V.NPCName && V.NPCName[ni]) || V[name];
        if (!npc || !npc.init) continue;
        var entry = _aiBuildNamedNpcPromptEntry(V, name, npc, loveInterests);
        entry.love = npc.love || 0;
        entry.lust = npc.lust || 0;
        entry.dom = npc.dom || 0;
        if (npc.trust != null) entry.trust = npc.trust;
        if (npc.rage != null) entry.rage = npc.rage;
        npcs.push(entry);
        npcDetails.push({
          name: entry.name,
          key: name,
          title: entry.title,
          gender: npc.gender || '',
          state: npc.state || '',
          isLoveInterest: !!entry.isLoveInterest,
          relationship: entry.relationship,
          extra: entry.extra || {}
        });
      }
      if (npcs.length) state.npcs = npcs;
      if (npcDetails.length) state.npcDetails = npcDetails;
      // -- Native encounter slots, only when backed by an active native count/event --
      var nativeEncounterNpcs = _aiNativeEncounterNpcContext(V);
      if (nativeEncounterNpcs.names.length) state.nearbyNpcs = nativeEncounterNpcs.names;
      if (nativeEncounterNpcs.details.length) state.nearbyNpcDetails = nativeEncounterNpcs.details;
      state.nearbyNpcAuthority = nativeEncounterNpcs.source;
      var presentNpcDetails = _aiCollectPresentNpcDetails(V, npcDetails, npcNameList);
      if (presentNpcDetails.length) state.presentNpcDetails = presentNpcDetails;
      if (V.pregnancy && (V.pregnancy.type || (V.pregnancy.fetus && V.pregnancy.fetus.length))) {
        state.pregnancy = pick(V.pregnancy, ['type', 'duration', 'fetus']);
      }
      if (V.transformations) {
        var tf = {};
        Object.keys(V.transformations).forEach(function (k) {
          var v = V.transformations[k];
          if (v && (v.level || v.value)) tf[k] = v.level || v.value;
        });
        if (Object.keys(tf).length) state.transformations = tf;
      }
      // -- Skills (all general/sex/school/thresholds/sensitivity) --
      state.skills = {
        general: {
          skulduggery: V.skulduggery || 0,
          dancing: V.danceskill || 0,
          swimming: V.swimmingskill || 0,
          athletics: V.athletics || 0,
          tending: V.tending || 0,
          housekeeping: V.housekeeping || 0,
        },
        sex: {
          seduction: V.seductionskill || 0,
          oral: V.oralskill || 0,
          vaginal: V.vaginalskill || 0,
          anal: V.analskill || 0,
          hand: V.handskill || 0,
          feet: V.feetskill || 0,
          penile: V.penileskill || 0,
          chest: V.chestskill || 0,
          thigh: V.thighskill || 0,
          bottom: V.bottomskill || 0,
        },
        school: {
          science: { score: V.science || 0, grade: V.sciencetrait || 0 },
          maths:   { score: V.maths || 0,   grade: V.mathstrait || 0 },
          english: { score: V.english || 0, grade: V.englishtrait || 0 },
          history: { score: V.history || 0, grade: V.historytrait || 0 },
          detention: V.detention || 0,
        },
        thresholds: {
          exhibitionism: V.exhibitionism || 0,
          promiscuity: V.promiscuity || 0,
          deviancy: V.deviancy || 0,
        },
        sensitivity: {
          mouth: V.mouthsensitivity || 1,
          breast: V.breastsensitivity || 1,
          bottom: V.bottomsensitivity || 1,
          genital: V.genitalsensitivity || 1,
        },
      };
      state.skillSummary = _aiBuildSkillSummary(V);
      // -- Fame (12 categories) --
      if (V.fame) {
        var fameObj = {};
        var fameKeys = ['sex','prostitution','rape','bestiality','exhibitionism','pregnancy','impreg','scrap','good','business','social','model'];
        for (var fi = 0; fi < fameKeys.length; fi++) {
          if (V.fame[fameKeys[fi]]) fameObj[fameKeys[fi]] = V.fame[fameKeys[fi]];
        }
        if (Object.keys(fameObj).length) state.fame = fameObj;
      }
      // -- Quest reminders --
      var quests = {};
      if (V.rentmoney > 0) quests.rent = { amount: _aiFormatMoneyPence(V.rentmoney), daysLeft: V.renttime };
      if (V.community_service >= 1) quests.communityService = true;
      if (V.edenfreedom > 0) quests.edenFreedom = { progress: V.edenfreedom, daysLeft: V.edendays };
      if (Object.keys(quests).length) state.quests = quests;
      state.activeQuests = _aiBuildActiveQuests(V);
      state.sceneContext = _aiBuildCurrentSceneSummary();
    }

    if (tier >= 3) {
      state.worn_full = V.worn;
      // -- Crime record --
      if (V.crime) {
        var crimeTypes = ['assault','coercion','destruction','exposure','obstruction','prostitution','resisting','thievery','petty','trespassing'];
        var crimeObj = {};
        var totalCrime = 0;
        for (var ci = 0; ci < crimeTypes.length; ci++) {
          var ct = crimeTypes[ci];
          if (V.crime[ct]) {
            crimeObj[ct] = V.crime[ct].current || 0;
            totalCrime += V.crime[ct].current || 0;
          }
        }
        if (totalCrime > 0) state.crime = { total: totalCrime, types: crimeObj };
      }
      // -- School reputation --
      if (V.delinquency || V.cool) {
        state.schoolRep = { delinquency: V.delinquency || 0, coolness: V.cool || 0 };
      }
      // -- Orphanage status --
      if (V.orphan_hope || V.orphan_reb) {
        state.orphanage = { hope: V.orphan_hope || 0, rebellion: V.orphan_reb || 0 };
      }
      // -- World corruption --
      if (V.world_corruption_soft || V.world_corruption_hard) {
        state.worldCorruption = { soft: V.world_corruption_soft || 0, hard: V.world_corruption_hard || 0 };
      }
      // -- Inventory summary (lightweight) --
      var inv = {};
      if (V.spraymax > 0) inv.pepperSpray = { charges: V.spray || 0, max: V.spraymax };
      if (V.sewingKit >= 1) inv.sewingKit = true;
      if (V.condoms != null) inv.condoms = V.condoms;
      if (V.vaginalchastity >= 1) inv.chastityVaginal = true;
      if (V.analchastity >= 1) inv.chastityAnal = true;
      if (V.penilechastity >= 1) inv.chastityPenile = true;
      if (V.police_access_card >= 1) inv.policeCard = true;
      var toyCount = 0;
      if (V.player && V.player.inventory && V.player.inventory.sextoys) {
        for (var tn in V.player.inventory.sextoys) {
          if (Array.isArray(V.player.inventory.sextoys[tn])) toyCount += V.player.inventory.sextoys[tn].length;
        }
      }
      if (toyCount > 0) inv.sexToys = toyCount;
      if (Array.isArray(V.aiStoryGenItems) && V.aiStoryGenItems.length) {
        inv.aiItems = V.aiStoryGenItems.slice(-20).map(function (item) {
          return {
            name: item.name,
            qty: item.qty || 1,
            tag: item.tag || 'AI道具'
          };
        });
      }
      if (Object.keys(inv).length) state.inventory = inv;
    }

    return state;
  }

  function _migrateMatchedSceneEvent(event, currentStoryText, physicalRaw, physicalLabel, authoritativeNames) {
    if (!event || !currentStoryText) return { event: event, matchSource: 'none' };
    var hadFingerprint = !!String(event.narrativeFingerprint || '').trim();
    if (!hadFingerprint) event.narrativeFingerprint = _fingerprintAiSceneNarrative(currentStoryText);

    var focusPassage = _normalizePassageName(event.sceneFocusPassage || '');
    var targetCandidate = _normalizePassageName(event.targetLocation || '');
    if (/^(?:current|same|unknown)$/i.test(targetCandidate)) targetCandidate = '';
    var locationCandidate = focusPassage || targetCandidate || _normalizePassageName(event.location || '');
    var locationCommon = locationCandidate ? (_findCommonLocationByRaw(locationCandidate) || _findCommonLocation(locationCandidate)) : null;
    if (locationCommon && locationCommon.narrativeArrival === false) {
      focusPassage = _normalizePassageName(locationCommon.raw || locationCandidate);
      event.location = _canonicalizeAiLocationStateTarget(locationCommon.containerRaw || physicalRaw, '').raw || physicalRaw;
      event.targetLocation = 'current';
      event.locationStatus = 'current';
      event.sceneFocusPassage = focusPassage;
      if (!event.sceneFocus) event.sceneFocus = _resolveLocationDisplay(focusPassage, locationCommon.label || '') || locationCommon.label || focusPassage;
    } else {
      event.location = _normaliseAIEventLocationValue(event.location || physicalRaw) || physicalRaw;
      var normalizedTarget = _normaliseAIEventLocationValue(event.targetLocation || '');
      event.targetLocation = normalizedTarget || 'current';
      if (event.targetLocation === event.location || event.targetLocation === physicalRaw) {
        event.targetLocation = 'current';
        if (_normaliseAiEventStatus(event.locationStatus) === 'arrived') event.locationStatus = 'current';
      }
    }

    var presence = _sanitizeAiPresenceLists(event.presentCharacters || event.characters || [], event.presentEntities || [], authoritativeNames || []);
    event.presentCharacters = presence.characters;
    event.characters = presence.characters.slice();
    event.presentEntities = presence.entities;
    var allowed = {};
    presence.characters.concat(presence.entities).forEach(function (name) { allowed[_normaliseNpcLookupText(name)] = true; });
    event.sexTargets = _dedupeTextList(_parseListField(event.sexTargets || '')).filter(function (name) {
      return !!allowed[_normaliseNpcLookupText(name)];
    });
    if (!event.visualAction) event.visualAction = _visualActionFromNarrative(currentStoryText);
    if (!event.environmentDescription) {
      event.environmentDescription = _environmentDescriptionFromNarrative(currentStoryText, physicalLabel || physicalRaw, event.sceneFocus || '');
    }
    event.schemaVersion = Math.max(4, parseInt(event.schemaVersion, 10) || 0);
    return { event: event, matchSource: hadFingerprint ? 'fingerprint' : 'legacy_text_backfilled' };
  }

  function buildScene() {
    var V = (typeof State !== 'undefined' && State.variables) ? State.variables : {};
    var T = (typeof Time !== 'undefined' && Time) ? Time : null;
    var nativePassage = (typeof State !== 'undefined' && State.passage) ? _normalizePassageName(State.passage) : '';
    var graphPassage = _currentGraphPassage();
    var physicalRaw = graphPassage || nativePassage;
    var physicalCanonical = _canonicalizeAiLocationStateTarget(physicalRaw, '');
    physicalRaw = physicalCanonical.raw || physicalRaw;
    var physicalLabel = _resolveLocationDisplay(physicalRaw, physicalCanonical.label || '') || physicalRaw;
    var focusRaw = '';
    var focusLabel = '';
    var focusSource = 'none';
    var environmentDescription = '';
    var environmentDescriptionSource = 'none';
    var continuityAction = '';
    var actionSource = 'none';
    var continuityCharacters = [];
    var continuityEntities = [];
    var presenceSource = 'none';
    var currentAiStoryText = _extractCurrentAiStoryText();
    var matchedSceneEvent = null;
    var rejectedSceneEvent = null;
    var sceneEventMatchSource = 'none';
    var nativeEncounterNpcs = _aiNativeEncounterNpcContext(V);
    if (currentAiStoryText && Array.isArray(V.aiStoryGenEventLog) && V.aiStoryGenEventLog.length) {
      var latestSceneEvent = V.aiStoryGenEventLog[V.aiStoryGenEventLog.length - 1] || {};
      var latestPassage = _normalizePassageName(latestSceneEvent.passage || '');
      if ((!latestPassage || latestPassage === nativePassage || _aiReplaceActive) && _aiSceneEventMatchesCurrentStory(latestSceneEvent, currentAiStoryText)) {
        var migratedSceneEvent = _migrateMatchedSceneEvent(latestSceneEvent, currentAiStoryText, physicalRaw, physicalLabel, nativeEncounterNpcs.names);
        matchedSceneEvent = migratedSceneEvent.event;
        sceneEventMatchSource = migratedSceneEvent.matchSource;
        continuityCharacters = _dedupeTextList(latestSceneEvent.presentCharacters || latestSceneEvent.characters || []).slice(0, 8);
        continuityEntities = _dedupeTextList(latestSceneEvent.presentEntities || []).slice(0, 8);
        presenceSource = 'validated_ai_event';
        if (latestSceneEvent.sceneFocus) {
          focusLabel = String(latestSceneEvent.sceneFocus).replace(/\s+/g, ' ').trim().slice(0, 80);
          focusSource = 'validated_ai_event';
        }
        if (latestSceneEvent.environmentDescription) {
          environmentDescription = String(latestSceneEvent.environmentDescription).replace(/\s+/g, ' ').trim().slice(0, 220);
          environmentDescriptionSource = 'validated_ai_event';
        }
        if (latestSceneEvent.visualAction) {
          continuityAction = String(latestSceneEvent.visualAction).replace(/\s+/g, ' ').trim().slice(0, 180);
          actionSource = 'validated_ai_event';
        }
      } else {
        rejectedSceneEvent = latestSceneEvent;
      }
    }
    if (currentAiStoryText && !matchedSceneEvent) {
      var inferredCurrentPresence = _inferPresentTargetsFromEventText(currentAiStoryText);
      var sanitizedCurrentPresence = _sanitizeAiPresenceLists(inferredCurrentPresence.characters || [], inferredCurrentPresence.entities || [], nativeEncounterNpcs.names);
      continuityCharacters = sanitizedCurrentPresence.characters.slice(0, 8);
      continuityEntities = sanitizedCurrentPresence.entities.slice(0, 8);
      continuityAction = _visualActionFromNarrative(currentAiStoryText);
      environmentDescription = _environmentDescriptionFromNarrative(currentAiStoryText, physicalLabel, focusLabel);
      presenceSource = continuityCharacters.length || continuityEntities.length ? 'current_ai_story_inference' : 'none';
      actionSource = continuityAction ? 'current_ai_story_inference' : 'none';
      environmentDescriptionSource = environmentDescription ? 'current_ai_story_inference' : 'none';
    }
    if (_aiReplaceTargetPassage) {
      var focusCommon = _findCommonLocationByRaw(_aiReplaceTargetPassage) || _findCommonLocation(_aiReplaceTargetPassage);
      if (focusCommon && focusCommon.narrativeArrival === false) {
        focusRaw = _normalizePassageName(focusCommon.raw || _aiReplaceTargetPassage);
        if (!focusLabel) {
          focusLabel = _resolveLocationDisplay(focusRaw, focusCommon.label || _aiReplaceTargetLabel || '') || focusRaw;
          focusSource = 'location_controller_focus';
        }
      }
    }
    if (currentAiStoryText && !continuityAction) {
      continuityAction = _visualActionFromNarrative(currentAiStoryText);
      actionSource = continuityAction ? 'current_ai_story_fallback' : actionSource;
    }
    if (!environmentDescription) {
      environmentDescription = _environmentDescriptionFromNarrative(currentAiStoryText, physicalLabel, focusLabel);
      environmentDescriptionSource = environmentDescription ? (currentAiStoryText ? 'current_ai_story_fallback' : 'physical_location_fallback') : 'none';
    }
    var scene = {
      schemaVersion: 4,
      authority: 'native_physical_location_plus_validated_current_ai_continuity',
      location: V.location,
      area: V.area || 'unknown',
      nativePassage: nativePassage,
      gameLocation: V.location || '',
      physicalLocationPassage: physicalRaw,
      physicalLocationLabel: physicalLabel,
      physicalLocationSource: graphPassage ? 'location_controller' : 'native_passage',
      environmentDescription: environmentDescription,
      environmentDescriptionSource: environmentDescriptionSource,
      sceneFocusPassage: focusRaw,
      sceneFocus: focusLabel,
      sceneFocusSource: focusSource,
      visualAction: continuityAction,
      visualActionSource: actionSource,
      continuityCharacters: continuityCharacters,
      continuityEntities: continuityEntities,
      continuityPresenceSource: presenceSource,
      currentAiStoryPresent: !!currentAiStoryText,
      currentAiStoryFingerprint: _fingerprintAiSceneNarrative(currentAiStoryText),
      sceneEventId: matchedSceneEvent && matchedSceneEvent.id || '',
      sceneEventMatched: !!matchedSceneEvent,
      sceneEventMatchSource: sceneEventMatchSource,
      sceneEventFingerprint: matchedSceneEvent && matchedSceneEvent.narrativeFingerprint || '',
      rejectedSceneEventId: rejectedSceneEvent && rejectedSceneEvent.id || '',
      locationStatus: _aiReplaceOriginalEventMode ? 'current' : (_aiLocationArrived ? 'arrived' : (_aiReplaceActive ? 'inTransit' : 'current')),
      day: V.day,
      weekday: V.weekday,
      hour: V.hour,
      minute: V.minute,
      nativeNearby: nativeEncounterNpcs.names.length ? nativeEncounterNpcs.names.join(', ') : '',
      nativeNearbyList: nativeEncounterNpcs.names.slice(0, 6),
      nativeNearbySource: nativeEncounterNpcs.source,
    };
    scene.nearby = scene.nativeNearby || 'noneReported';
    // School schedule
    if (T) {
      if (T.schoolTerm) scene.schoolActive = true;
      if (T.schoolDay) scene.schoolDay = true;
      if (T.currentMoonPhase && T.currentMoonPhase.description) scene.moonPhase = T.currentMoonPhase.description;
    }
    // Danger/safety categorization
    var hour = V.hour != null ? Number(V.hour) : 12;
    var loc = (V.location || '').toLowerCase();
    var dangerLevel = 'neutral';
    if (loc.indexOf('alley') !== -1 || loc.indexOf('industrial') !== -1 || loc.indexOf('moor') !== -1 ||
        loc.indexOf('brothel') !== -1 || loc.indexOf('compound') !== -1 || loc.indexOf('docks') !== -1) {
      dangerLevel = 'dangerous';
    } else if (loc.indexOf('forest') !== -1 || loc.indexOf('farm') !== -1 ||
               loc.indexOf('beach') !== -1 || loc.indexOf('sea') !== -1) {
      dangerLevel = 'wilderness';
    } else if (hour < 6 || hour >= 21) {
      dangerLevel = 'night';
    } else if (loc.indexOf('school') !== -1 || loc.indexOf('orphanage') !== -1 ||
               loc.indexOf('library') !== -1 || loc.indexOf('temple') !== -1) {
      dangerLevel = 'safe';
    }
    scene.dangerLevel = dangerLevel;
    return scene;
  }
  window.AIStoryGen.buildScene = buildScene;

  function buildScenePromptPayload(scene) {
    scene = scene || {};
    var promptScene = {
      schemaVersion: scene.schemaVersion || 4,
      authority: scene.authority || 'native_physical_location_plus_validated_current_ai_continuity',
      physicalLocation: {
        nativePassage: scene.nativePassage || 'unknown',
        gameLocation: scene.gameLocation || scene.location || 'unknown',
        passage: scene.physicalLocationPassage || scene.nativePassage || 'unknown',
        label: scene.physicalLocationLabel || scene.physicalLocationPassage || scene.location || 'unknown',
        source: scene.physicalLocationSource || 'native_passage',
        status: scene.locationStatus || 'current',
        area: scene.area || 'unknown',
        environmentDescription: scene.environmentDescription || '',
        environmentDescriptionSource: scene.environmentDescriptionSource || 'none'
      },
      continuity: {
        activeAiStory: !!scene.currentAiStoryPresent,
        eventValidated: !!scene.sceneEventMatched,
        eventMatchSource: scene.sceneEventMatchSource || 'none',
        sceneFocus: scene.sceneFocus || '',
        sceneFocusPassage: scene.sceneFocusPassage || '',
        sceneFocusSource: scene.sceneFocusSource || 'none',
        visualAction: scene.visualAction || '',
        visualActionSource: scene.visualActionSource || 'none',
        presentCharacters: Array.isArray(scene.continuityCharacters) ? scene.continuityCharacters.slice(0, 8) : [],
        presentEntities: Array.isArray(scene.continuityEntities) ? scene.continuityEntities.slice(0, 8) : [],
        presenceSource: scene.continuityPresenceSource || 'none'
      },
      nativeEncounter: {
        actors: Array.isArray(scene.nativeNearbyList) ? scene.nativeNearbyList.slice(0, 6) : [],
        source: scene.nativeNearbySource || 'none'
      },
      time: {
        day: scene.day == null ? null : scene.day,
        weekday: scene.weekday == null ? null : scene.weekday,
        hour: scene.hour == null ? null : scene.hour,
        minute: scene.minute == null ? null : scene.minute,
        schoolActive: !!scene.schoolActive,
        schoolDay: !!scene.schoolDay,
        moonPhase: scene.moonPhase || ''
      },
      atmosphere: scene.dangerLevel || 'neutral'
    };
    return promptScene;
  }

  function buildScenePromptText(scene) {
    return JSON.stringify(buildScenePromptPayload(scene), null, 2);
  }

  window.AIStoryGen.sceneContract = {
    schemaVersion: 4,
    buildPromptPayload: buildScenePromptPayload,
    formatPrompt: buildScenePromptText,
    nativeEncounterFromState: _aiNativeEncounterNpcContext
  };

  function getGameLinks() {
    var links = [];
    var $passage = $('#passages .passage');
    if (!$passage.length) return links;
    $passage.find('a[data-passage]').each(function () {
      if ($(this).closest('.ai-narrative-section').length) return;
      var text = $(this).clone().children().remove().end().text().trim();
      if (!text || text.length < 2) return;
      var target = $(this).attr('data-passage');
      if (!target) return;
      if (_isGameMenuPassage(target)) return;
      links.push(text);
    });
    return links.slice(0, 10);
  }

  function _storyPromptCleanText(value, maxLen) {
    var text = String(value || '').replace(/\s+/g, ' ').trim();
    var out = '';
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      if (c >= 0xD800 && c <= 0xDBFF) {
        var n = i + 1 < text.length ? text.charCodeAt(i + 1) : 0;
        if (n >= 0xDC00 && n <= 0xDFFF) {
          out += text.charAt(i) + text.charAt(i + 1);
          i++;
        }
      } else if (c < 0xDC00 || c > 0xDFFF) {
        out += text.charAt(i);
      }
    }
    if (maxLen && out.length > maxLen) out = out.slice(0, maxLen).trim();
    return out;
  }

  function _loadPixelCfgForStoryPrompt() {
    try {
      var raw = localStorage.getItem('aiPixelGen_cfg');
      if (!raw) return {};
      var cfg = JSON.parse(raw);
      return cfg && typeof cfg === 'object' ? cfg : {};
    } catch (e) {
      return {};
    }
  }

  function _parseCustomNpcAppearanceNotes(text) {
    var rows = [];
    String(text || '').split(/\r?\n/).forEach(function (line) {
      line = _storyPromptCleanText(line, 900);
      if (!line) return;
      var m = line.match(/^([^:：=]{1,80})\s*[:：=]\s*(.+)$/);
      if (!m) return;
      var name = _storyPromptCleanText(m[1], 60);
      var desc = _storyPromptCleanText(m[2], 220);
      if (name && desc) rows.push({ name: name, desc: desc });
    });
    return rows;
  }

  function buildCharacterAppearanceSettingsBlock(query) {
    var pixelCfg = _loadPixelCfgForStoryPrompt();
    var entries = [];
    var seen = {};
    var queryText = _storyPromptCleanText(query || '', 5000).toLowerCase();
    function isRelevantName(name) {
      if (!queryText) return false;
      var raw = String(name || '').trim();
      var localized = '';
      try { localized = _localizeNamesInText(raw); } catch (_) {}
      return (raw && queryText.indexOf(raw.toLowerCase()) >= 0) ||
        (localized && queryText.indexOf(String(localized).toLowerCase()) >= 0);
    }
    var npcAppearances = pixelCfg && pixelCfg.npcAppearances && typeof pixelCfg.npcAppearances === 'object'
      ? pixelCfg.npcAppearances
      : {};

    Object.keys(npcAppearances).sort().forEach(function (name) {
      var cleanName = _storyPromptCleanText(name, 60);
      var desc = _storyPromptCleanText(npcAppearances[name], 220);
      if (!cleanName || !desc || seen[cleanName] || !isRelevantName(cleanName)) return;
      seen[cleanName] = 1;
      entries.push(cleanName + ': ' + desc);
    });

    _parseCustomNpcAppearanceNotes(pixelCfg.customNpcAppearances).forEach(function (row) {
      if (!row.name || !row.desc || seen[row.name] || !isRelevantName(row.name)) return;
      seen[row.name] = 1;
      entries.push(row.name + ': ' + row.desc);
    });

    if (!entries.length) return '';
    var intro = '\u4ee5\u4e0b\u662f\u73a9\u5bb6\u5728 NPC\u5f62\u8c61\u8bbe\u7f6e \u4e2d\u5199\u5165\u7684\u89d2\u8272\u5916\u89c2/\u7279\u70b9\u8bbe\u5b9a\u3002\u82e5\u5267\u60c5\u51fa\u73b0\u540c\u540d\u89d2\u8272\uff0c\u5e94\u4f18\u5148\u4fdd\u6301\u8fd9\u4e9b\u8bbe\u5b9a\uff1b\u4e0d\u8981\u56e0\u4e3a\u8fd9\u91cc\u5217\u51fa\u67d0\u89d2\u8272\u5c31\u628aTA\u5f3a\u884c\u52a0\u5165\u5f53\u524d\u573a\u666f\u3002';
    return '<character_appearance_settings role="player_custom_supplement_not_current_presence">\n' + intro + '\n' + entries.slice(0, 18).join('\n') + '\n</character_appearance_settings>';
  }

  function buildRecentBlock(opts) {
    opts = opts || {};
    var includeStoryMemory = opts.includeStoryMemory !== false;
    var blocks = [];
    var cfg = loadCfg();
    var query = _storyPromptCleanText(opts.query || '', 5000);
    var profile = _storyPromptCleanText(cfg.playerStoryProfile || '', 1200);
    if (profile) {
      blocks.push('<player_story_profile role="player_custom_supplement_not_native_state">\n' + profile + '\n</player_story_profile>');
    }
    var appearanceBlock = buildCharacterAppearanceSettingsBlock(query);
    if (appearanceBlock) {
      blocks.push(appearanceBlock);
    }
    if (!includeStoryMemory) {
      return blocks.length ? blocks.join('\n\n') + '\n\n' : '';
    }
    // Recent story memory (last N events)
    var recentCount = Math.max(0, Math.min(20, Number(cfg.recentMax || 0)));
    if (recentBuf.length && recentCount > 0) {
      var recentLimit = Math.max(200, Math.min(900, Number(cfg.recentLimit || 600)));
      var recentRows = recentBuf.slice(-recentCount);
      var lines = recentRows.map(function (r, i) {
        return '[' + (i + 1) + '] (passage: ' + _storyPromptCleanText(r.name, 100) + ') ' + _storyPromptCleanText(r.text, recentLimit);
      }).join('\n');
      blocks.push('<recent_story role="continuity_events_not_current_presence">\n' + lines + '\n</recent_story>');
    }
    // Long-term memory (player-bookmarked events)
    if (longTermMem.length) {
      var selectedLongTerm = PromptBuilderModule.selectRelevantMemories(
        longTermMem.map(function (entry) { return _normalizeImportantMemoryEntry(entry); }),
        query,
        { maxEntries: 6, maxChars: 3200, entryChars: 600 }
      );
      var ltm = selectedLongTerm.map(function (r, i) {
        var label = r.name.indexOf('[LTSummary]') === 0 ? 'summary' : r.name;
        var tag = r.tag ? '; tag: ' + r.tag : '';
        var lock = r.locked ? '; locked' : '';
        return '[' + (i + 1) + '] (' + label + tag + lock + ') ' + r.text;
      }).join('\n');
      if (ltm) {
        blocks.push('<long_term_memory role="retrieved_continuity_only_not_current_presence">\n仅列出与当前场景或行动最相关的长期记忆；不得把其中人物、地点或物品当作当前在场事实。\n' + ltm + '\n</long_term_memory>');
      }
    }
    return blocks.length ? blocks.join('\n\n') + '\n\n' : '';
  }

  function _buildPromptStateBlock(state, query, mode) {
    var compact = PromptBuilderModule.compactStateForPrompt(state || {}, {
      query: query || '',
      mode: mode || 'narrative'
    });
    return [
      '<state role="mechanical_constraints_only_do_not_restate">',
      JSON.stringify(compact, null, 2),
      '</state>'
    ].join('\n');
  }

  function _buildNarrativeDataPolicyBlock(cfg) {
    return PromptBuilderModule.buildNarrativeDataPolicyBlock((cfg && cfg.language) || 'zh') + '\n\n';
  }

  function _extractCurrentAiStoryText() {
    var $root = $();
    if (_aiReplaceActive) {
      $root = $('#passages .passage .ai-replaced-content');
    } else if (_aiNarrativeWrap && _aiNarrativeWrap.parentNode && document.documentElement.contains(_aiNarrativeWrap)) {
      $root = $(_aiNarrativeWrap);
    }
    if (!$root.length) return '';
    var $clone = $root.clone();
    $clone.find('script, style, button, input, select, .ai-narrative-toolbar, .ai-gen-loading, .ai-choices, .ai-memory-inline, .ai-back-to-game, .ai-nav-wrap').remove();
    return ($clone.text() || '').replace(/\s+/g, ' ').trim();
  }

  function buildCurrentAiStoryBlock() {
    var cfg = loadCfg();
    var text = _extractCurrentAiStoryText();
    if (!text) return '';
    var limit = Math.max(200, cfg.recentLimit || 600);
    if (text.length > limit) text = text.slice(0, limit) + '...';
    return '<current_ai_story>\n' + text + '\n</current_ai_story>\n\n';
  }

  // ---------- 4. Prompt 构造 ----------
  function _getCurrentNativePageText(maxLen) {
    try {
      var $passage = $('#passages .passage');
      if (!$passage.length) return '';
      var $clone = $passage.clone();
      $clone.find(OptionalAddonBridge.cloneCleanupSelector('script, style, input, textarea, select, button, .ai-cfg, .ai-unified-settings, .ai-merged-settings, .apg-panel-wrap, #settingsOptions, #settingsDiv, #customOverlayContent, .ai-narrative-toolbar, .ai-memory-inline, .ai-item-use-panel, .ai-back-to-game, .ai-choices, .ai-choices-end, .ai-reload-scene-panel, .ai-pixel-panel, .ai-pixelgen-panel, [data-ai-pixel-panel]')).remove();
      var text = ($clone.text() || '').replace(/\s+/g, ' ').trim();
      maxLen = maxLen || 1800;
      return text.length > maxLen ? text.slice(0, maxLen).trim() : text;
    } catch (_) {
      return '';
    }
  }

  function buildWorldContextBlock(state, scene, cfg) {
    try {
      if (!WorldContext || typeof WorldContext.formatPromptBlock !== 'function') return '';
      return WorldContext.formatPromptBlock({
        state: state || buildState(cfg || loadCfg()),
        scene: scene || buildScene(),
        cfg: cfg || loadCfg(),
        pageText: _getCurrentNativePageText(1800)
      }) + '\n\n';
    } catch (e) {
      try { console.warn('[AIStoryGen] failed to build world context', e); } catch (_) {}
      return '';
    }
  }

  function buildNativeContextAuthorityBlock() {
    return [
      '<context_authority>',
      'Authoritative game sources: <state>, <scene>, <world_context>, <current_map>, and <known_places> are read from the native game state.',
      'Do not overwrite or contradict native game facts: player body, clothing, stats, money, location, native inventory, quests, relationship values, active NPCs, or reachable map links.',
      'Use compact status labels, relevant skill summaries, presentNpcDetails relationship levels, and scene context only as constraints; never expose them as a character sheet or mechanics checklist.',
      'Use <world_context> for page type, school/time interpretation, map adjacency, visible native facts, visible links, and canonical NPC names. If it conflicts with memory, follow <world_context>.',
      'Treat <world_context>.visibleFacts as hard current-page facts. Do not contradict visible character presence, current actions, or indoor/outdoor location stated there.',
      'Within <scene>, physicalLocation.passage is the map/place anchor. continuity.sceneFocus is only the current in-room position or visual focus and must never be treated as a destination or copied into AI_EVENT.targetLocation.',
      'Within an active AI story, continuity.visualAction is the latest validated drawable action/posture. Preserve it as immediate continuity unless the selected action or new narration visibly changes it.',
      'AI_EVENT locationStatus=current preserves the existing physical location; only inTransit means the route is still underway.',
      'Within an active AI story only, continuity.presentCharacters and continuity.presentEntities may preserve immediate presence continuity. Check continuity.presenceSource: validated_ai_event is strongest, current_ai_story_inference is a fallback, and neither may override contradictory native visible facts.',
      'nativeEncounter.actors is present only when native encounter state has authoritative active-slot evidence. It is not a named-character source and must not be combined with memory to invent identities.',
      'Player-authored supplements (<player_story_profile> and <character_appearance_settings>) may guide tone, recurring preferences, or appearance details only when they do not conflict with native game state.',
      'Memory blocks (<recent_story>, <current_ai_story>, and <long_term_memory>) provide continuity. They are not proof that a character, creature, object, or place is currently present.',
      'Treat only <scene>, nearbyNpcs in <state>, the current AI story, and the selected player action as evidence for what is currently on screen.',
      'Use [AI_EVENT] as the structured story summary channel. Do not store UI text, sidebar text, menu labels, buttons, or raw passage descriptions as story facts.',
      '</context_authority>'
    ].join('\n') + '\n\n';
  }

  var STORY_STYLE_PRESETS = {
    none: '',
    custom: '',
    minimal: '极简文风：模仿海明威的写作手法，仅使用名词和动词，不使用比喻与抒情手法。',
    epic: '史诗文风：以极尽史诗的笔触书写故事的壮丽与辉煌。故事表面上应该是充满张力的，每个个体的抗争与矛盾都应该以最细致饱满的手法去描写，可参考托尔斯泰《战争与文明》，乔伊斯《尤利西斯》。',
    cult: 'cult文风：以最微小单元的腐化着眼描写，重点凸显社会的恶面，刻画一片恶之花盛放的土地。主角往往带有癫狂感和堕落感，可参考cult电影《女人的烦恼》、《菠萝酯》、《粉红色的火烈鸟》、《发条橙》。',
  };

  function _buildStoryStyleDirective(cfg) {
    cfg = cfg || loadCfg();
    var presetKey = String(cfg.storyStylePreset || 'none');
    var preset = STORY_STYLE_PRESETS[presetKey] || '';
    var custom = presetKey === 'custom'
      ? String(cfg.storyStylePrompt || '').replace(/\s+/g, ' ').trim()
      : '';
    var styleText = (custom || preset).slice(0, 1200);
    if (!styleText) return '';
    return [
      '<style_directive>',
      '文风设定：' + styleText,
      '该设定只影响叙事语言、节奏和氛围，不得覆盖 <state>、<scene>、当前地点、NPC在场状态、物品、数值变化、[STATS]、[ITEMS]、[AI_META]、[AI_EVENT] 等游戏事实和输出格式。',
      '如果文风设定与游戏事实或格式规则冲突，以游戏事实和格式规则为准。',
      '</style_directive>',
      '',
    ].join('\n');
  }

  function _applyStoryStyleDirectiveToPrompt(instruction, cfg) {
    var prompt = String(instruction || '');
    if (prompt.indexOf('<style_directive>') !== -1) return prompt;
    var block = _buildStoryStyleDirective(cfg);
    if (!block) return prompt;
    var idx = prompt.indexOf('<instruction>');
    if (idx >= 0) return prompt.slice(0, idx) + block + prompt.slice(idx);
    return block + prompt;
  }

  var STYLE_EN = [
    'You are an in-game narrator for the Twine adult text-adventure',
    '"Degrees of Lewdity".',
    'Your job is to "fill in" and "enrich" the game — add scene details,',
    'random encounters, atmospheric touches. You are NOT an independent writer;',
    'you are an extension of the game. Write in the SAME style as the base game:',
    '- Second person, present tense ("You feel...", "You see...").',
    '- British English spelling.',
    '- Concise, sensory-driven prose. 1-3 short paragraphs, like a random encounter.',
    '- Do NOT speak to the player out-of-character. No meta commentary.',
    '- Do NOT invent NPCs not present in <state>. Use given names exactly.',
    '- Match the player\'s gender / body / clothing as given in <state>.',
    '- Respect the player\'s current arousal/awareness/stress level.',
    '- <state> is a mechanical constraint, not prose material. Never recite exact stats, account balances, quest counters, or "state data" unless the selected action directly requires an exact transaction amount.',
    '- Do not invent what off-screen NPCs are currently doing. Memory preserves continuity but does not prove presence.',
    '- Read <recent_story> as the immediate prior narration. Maintain',
    '  continuity but do NOT repeat. Move forward naturally.',
    '- Read <long_term_memory> for the character\'s long-term history and',
    '  recurring themes. Respect character development across sessions.',
    '- Read <player_story_profile> as player-authored story preferences, tone, recurring traits, and desired plot direction. Weave it in subtly when relevant.',
    '- Read <character_appearance_settings> as player-authored appearance and trait notes. If a named character appears, preserve those details. Do not introduce characters solely because they are listed there.',
    '- You MUST be aware of the player\'s current location (<scene>).',
    '  Narratives must stay grounded in that location. Only introduce a small event when it follows causally from the selected action or visible native page.',
    '- State changes are optional and empty by default. Only when the narrated action has a direct, mechanically meaningful impact on the player\'s physical or',
    '  mental state, append a stats line: [STATS: arousal+500, stress-1600, pain+3]. Keep every delta proportional to the action duration and intensity.',
    '  Brief routine actions (about 1-5 minutes), walking, looking around, washing the face, changing clothes, breathing, or merely feeling refreshed/relaxed normally cause no stat change. Reduce tiredness only after meaningful rest or sleep; never turn descriptive mood words into mechanics by themselves.',
    '  Money is not inferred from keywords. If the player gains or loses money, the prose must clearly state the exact player-facing amount and reason, and AI_EVENT moneyChange must contain the matching signed pence amount. Example: £2000.00 rent => moneyChange=-200000; £1.00 => -100. Do not guess challenge rewards or costs.',
    '  If the player gains a concrete non-money item, append [ITEMS: item name x1; item name x2].',
    '  If writing Chinese narration, ITEMS names must also be Chinese short names. Do not output English item names.',
    '  ITEMS must contain only short concrete item names, never feelings, moods, scene states, scenery, doors, rooms, or full sentences. Examples: "狗粮 x1; 清水 x1"; not "feeling of freedom" or "the door is open".',
    '  Use native DoL-sized deltas: arousal/stress usually hundreds to thousands; tiredness usually tens to hundreds; trauma usually tens, or hundreds to 1000 for severe story events; pain/control/skills/traits stay small. Player-configured limits are ceilings, not target values. Use only allowed non-money stat keys from the AI runtime stat schema: ' + _formatAiRuntimeNonMoneyStatAllowlist() + '. money uses pence; moneyChange+100 = £1.00.',
    '',
    'Output in-game narration text only, plus required system markers: [STATS], [ITEMS], [AI_META], and [AI_EVENT] when requested.',
    'No preface, no markdown headers, no "Sure, here is...". Do not output any JSON outside allowed metadata blocks.',
  ].join('\n');

  var STYLE_ZH = [
    '- \u628a <character_appearance_settings> \u89c6\u4e3a\u73a9\u5bb6\u5199\u5165\u7684\u89d2\u8272\u5916\u89c2/\u7279\u70b9\u8bbe\u5b9a\uff1b\u540c\u540d\u89d2\u8272\u51fa\u73b0\u65f6\u5fc5\u987b\u4fdd\u6301\u4e00\u81f4\uff0c\u4f46\u4e0d\u8981\u56e0\u6b64\u65b0\u589e\u4e0d\u5728\u573a\u89d2\u8272\u3002',
    '你是 Twine 文字 AVG《Degrees of Lewdity》的内置叙事者。',
    '你的任务是"补全"和"丰富"游戏剧情：补充场景描写、生成随机遭遇、增添氛围细节。',
    '你不是独立编剧，而是游戏的延伸。保持原作风格：',
    '- 第二人称、现在时（"你感到……"、"你看到……"）。',
    '- 简洁、注重感官描写。输出 1-3 个短段，像随机遭遇一样自然。',
    '- 不要打破第四面墙、不要元注释、不要解释。',
    '- 不得编造 <state> 中未出现的 NPC，使用给定名字。',
    '- 所有人名必须使用中文名；不要输出 Robin、Whitney、Sydney、Kylar 等英文内部名。',
    '- 中文正文里不要直接写 arousal/stress/pain/trauma/control/lust 等英文内部变量名；如需描述状态，请写“兴奋/压力/疼痛/创伤/自控/欲望”等自然中文。',
    '- 严格匹配 <state> 中玩家的性别 / 体型 / 着装。',
    '- 尊重玩家当前的兴奋 / 觉醒 / 压力数值。',
    '- <state> 是机制约束，不是正文素材。不要复述精确属性、账户余额、任务计数、角色卡或“状态数据”；只有玩家本轮行动明确涉及交易时才使用必要的精确金额。',
    '- 不得编造离场 NPC 此刻正在做什么。记忆只维持连续性，不证明人物当前在场。',
    '- 把 <recent_story> 视为紧邻当前的剧情，保持连贯但不要重复。',
    '- 把 <long_term_memory> 中记录的人物过往关键记忆融入叙事背景，',
    '  尊重角色成长线和跨会话的角色发展。',
    '- 你必须了解玩家当前所在的地点 (<scene>)，',
    '  叙事和选项必须基于该地点展开；只有本轮行动或当前可见原版页面能自然引出时，才加入小事件。',
    '- 状态变化默认留空。只有剧情对玩家身心状态产生直接且有机制意义的影响时，才在末尾附加一行：',
    '  [STATS: arousal+500, stress-1600, pain+3]。变化幅度必须与行动时长和强度相称。约1-5分钟的普通行动、走动、观察、洗脸、换衣、呼吸或只是感觉清醒/放松，通常不产生数值变化；只有真正休息或睡眠才降低疲劳。不要把气氛词、感受词自动换算成数值。压力/兴奋这类 DoL 大数值属性通常用数百到数千；疲劳通常用几十到数百；创伤普通惊吓用几十，严重剧情事件才用数百到1000；疼痛/自控/技能/特质仍用小数值。玩家设置的细分区间是上限，不是推荐变化值。仅使用非金钱 AI 运行时属性白名单：' + _formatAiRuntimeNonMoneyStatAllowlist() + '。',
    '- 金钱变化不能靠“找到/发现/获得/进入挑战/奖励”等关键词推断。只有正文明确写出玩家可见的具体金额和原因时，才在 AI_EVENT 的 moneyChange 中写匹配的 signed pence，例如 £2000.00 房租 => moneyChange=-200000，£1.00 => -100；金额不明确或只是猜测奖励/花费时必须留空。',
    '',
    '只输出游戏内叙事正文，以及系统要求的 [STATS]、[ITEMS]、[AI_META]、[AI_EVENT] 标记块。不要前言、不要 Markdown 标题、不要"好的，以下是……"。',
  ].join('\n');

  function buildSystem(cfg) {
    var style = cfg.language === 'zh' ? STYLE_ZH : STYLE_EN;
    var extra = (cfg.systemPromptExtra || '').trim();
    var parts = [];
    if (extra) parts.push(extra);
    if (cfg.jailbreak && cfg.jailbreak.trim()) parts.push(cfg.jailbreak.trim());
    parts.push(style);
    parts.push([
      'Context priority rules:',
      '1. Native game state in <state>, <scene>, <current_map>, and <known_places> is authoritative.',
      '2. <world_context> is authoritative derived context for page type, school/time phase, map adjacency, visible native links, and canonical NPC names.',
      '3. Player profile, appearance notes, recent story, and long-term memory are supplements only; they must not override native game state or <world_context>.',
      '4. Memory is continuity, not current presence. Do not treat old names, places, or objects as currently present unless the current scene/action confirms them.',
      '5. Use AI_EVENT summaries for durable story facts; never convert UI text, menu text, sidebars, or raw passage descriptions into memory facts.'
    ].join('\n'));
    if (cfg.language === 'zh') {
      parts.push('When the user prompt requests [AI_META]{...}[/AI_META] or [AI_EVENT]...[/AI_EVENT], append those metadata blocks exactly. They are allowed metadata, not forbidden JSON. Do not output any other JSON.');
    }
    return parts.join('\n\n').trim();
  }

  function buildChoiceSystem(cfg) {
    cfg = cfg || loadCfg();
    var zh = cfg.language === 'zh';
    var rules = zh ? [
      '你为《Degrees of Lewdity》生成玩家下一步可执行选项。',
      '当前原版页面、当前场景、当前 AI 正文末态和明确在场人物是最高权威；记忆不能证明人物当前在场。',
      '选项必须推进当前状态，禁止重复当前正文已经完成的动作。',
      '没有对应原版可执行入口时，不得提供会直接改写穿着装备、正式睡眠/醒来、战斗、交易、消耗物品或任务结算的选项；可以写准备、查看、接近或尝试。',
      '只返回调用方要求的 JSON 数组，不得输出正文、解释、Markdown、HTML、[STATS]、[AI_META] 或 [AI_EVENT]。'
    ] : [
      'Generate executable next-step player choices for Degrees of Lewdity.',
      'The current native page, current scene, final state of the current AI story, and explicitly present characters are authoritative; memory does not prove presence.',
      'Every choice must advance the current state and must not repeat an action already completed in the current story.',
      'Without a corresponding executable native entry, do not offer choices that directly rewrite worn equipment, formal sleep/wake state, combat, transactions, item consumption, or quest settlement; offer preparation, checking, approaching, or attempting instead.',
      'Return only the JSON array requested by the caller. No prose, explanation, Markdown, HTML, [STATS], [AI_META], or [AI_EVENT].'
    ];
    var extra = String(cfg.systemPromptExtra || '').trim().slice(0, 1200);
    var jailbreak = String(cfg.jailbreak || '').trim().slice(0, 1200);
    return [extra, jailbreak, rules.join('\n')].filter(Boolean).join('\n\n');
  }

  function buildUser(cfg, instruction) {
    var state = buildState(cfg);
    var scene = buildScene();
    var promptQuery = [
      instruction || '',
      _getCurrentNativePageText(1400),
      _extractCurrentAiStoryText(),
      buildScenePromptText(scene)
    ].join(' ');
    return [
      _buildPromptStateBlock(state, promptQuery, 'narrative'),
      '',
      buildWorldContextBlock(state, scene, cfg),
      buildRecentBlock({ query: promptQuery }),
      buildCurrentAiStoryBlock(),
      buildNativeContextAuthorityBlock(),
      buildKnownNpcNamesBlock(promptQuery),
      _buildNarrativeDataPolicyBlock(cfg),
      '<scene>',
      buildScenePromptText(scene),
      '</scene>',
      '',
      '<instruction>',
      instruction || (cfg.language === 'zh' ? '继续描写当前场景。' : 'Continue describing the current scene.'),
      '</instruction>',
    ].join('\n');
  }

  // ---------- 5. DeepSeek 调用 ----------

  function _recordLastApiError(err, cfg, selected) {
    try {
      var aiErr = classifyError(err, (cfg && cfg.language) || 'zh');
      window.AIStoryGen.lastApiError = {
        at: new Date().toISOString(),
        type: aiErr.type || 'unknown',
        message: String(aiErr.message || err && err.message || err || '').slice(0, 500),
        detail: String(aiErr.detail || '').slice(0, 500),
        statusCode: aiErr.statusCode || err && (err.statusCode || err.status) || 0,
        provider: cfg && cfg.apiProvider || '',
        endpoint: selected && selected.endpoint || cfg && cfg.endpoint || '',
        model: selected && selected.model || cfg && cfg.model || ''
      };
    } catch (_) {}
  }

  /**
   * Low-level AI fetch: shared by callAI, generateChoices, and combat narrator.
   * @param {Array} messages - [{role, content}]
   * @param {Object} opts - { temperature, max_tokens, signal }
   * @returns {Promise<string>} response text content
   */
  async function _fetchAI(messages, opts) {
    var cfg = loadCfg();
    opts = opts || {};
    var providerRequestOptions = {};
    try { providerRequestOptions = ProviderPresetsModule.getNetworkProbeOptions(cfg, { href: location && location.href, origin: location && location.origin }); } catch (_) {}
    var selected = ApiClientModule.buildChatBody(cfg, Object.assign({}, opts, {
      messages: messages,
      providerCapabilities: providerRequestOptions.capabilities || null
    }), DEFAULT_CFG);
    var endpoint = selected.endpoint;
    var requestId = null;
    try {
      requestId = RequestLog.begin({
        provider: cfg.apiProvider || '',
        endpoint: endpoint,
        model: selected.model || cfg.model || '',
        highQuality: !!selected.useHighQuality,
        temperature: selected.body && selected.body.temperature,
        maxTokens: selected.body && selected.body.max_tokens,
        messages: messages,
        purpose: opts.purpose || ''
      });
    } catch (_) {}
    var localEndpoint = ApiClientModule.isLocalEndpoint(endpoint);
    if (!cfg.apiKey && !localEndpoint) {
      var keyErr = new AIError(AIErrorType.NOT_CONFIGURED,
        cfg.language === 'zh'
          ? '未设置 API 密钥。请先在侧边栏「OPTIONS/设置 → 织境空间」中配置。'
          : 'API Key not set. Configure in Woven Realm settings first.');
      _recordLastApiError(keyErr, cfg, selected);
      try { RequestLog.finishError(requestId, keyErr); } catch (_) {}
      throw keyErr;
    }
    var body = selected.body;
    var headers = ApiClientModule.buildHeaders(cfg.apiKey, providerRequestOptions.extraHeaders || {});
    var responseParseOptions = selected.providerCapabilities || providerRequestOptions.capabilities || {};
    function makeFetchOpts(requestBody) {
      var fo = {
        method: 'POST',
        headers: headers,
        body: ApiClientModule.safeJsonStringify ? ApiClientModule.safeJsonStringify(requestBody) : JSON.stringify(requestBody),
      };
      if (opts && opts.signal) fo.signal = opts.signal;
      return fo;
    }
    async function postOnce(requestBody) {
      var fetcher = ApiClientModule.safeFetch || fetch;
      var resp = await fetcher(endpoint, makeFetchOpts(requestBody));
      if (!resp.ok) {
        var t = await resp.text().catch(function () { return ''; });
        throw classifyError(ApiClientModule.buildHttpError(resp.status, t), cfg.language);
      }
      var raw = await resp.text();
      var j = ApiClientModule.parseJsonMaybe(raw);
      if (!j) {
        throw new AIError(AIErrorType.UNKNOWN,
          cfg.language === 'zh' ? 'API 返回了非 JSON 响应。' : 'API returned a non-JSON response.',
          String(raw || '').slice(0, 300));
      }
      var out = ApiClientModule.extractResponseText(j, responseParseOptions);
      if (!out) {
        throw new AIError(AIErrorType.UNKNOWN, ApiClientModule.emptyResponseMessage(j, cfg.language, responseParseOptions), ApiClientModule.emptyResponseDetail(j, 200, responseParseOptions));
      }
      return {
        text: out.trim(),
        finishReason: ApiClientModule.extractFinishReason(j, responseParseOptions),
        responseModel: j && j.model || '',
        usage: j && j.usage || null
      };
    }
    try {
      try {
        var firstResult = await postOnce(body);
        try { window.AIStoryGen.lastApiError = null; } catch (_) {}
        try {
          RequestLog.finishSuccess(requestId, {
            outputChars: String(firstResult.text || '').length,
            finishReason: firstResult.finishReason,
            responseModel: firstResult.responseModel,
            usage: firstResult.usage
          });
        } catch (_) {}
        return firstResult.text;
      } catch (emptyErr) {
        if (!(emptyErr instanceof AIError) || emptyErr.type !== AIErrorType.UNKNOWN || opts.noEmptyRetry || (opts.signal && opts.signal.aborted)) {
          throw emptyErr;
        }
        var retryBody = Object.assign({}, body);
        retryBody.max_tokens = Math.max(Number(body.max_tokens || 0) * 2, Number(body.max_tokens || 0) + 300, 700);
        retryBody.temperature = Math.max(0.2, Math.min(Number(body.temperature || 0.7), 0.8));
        try {
          RequestLog.noteAttempt(requestId, {
            type: 'empty_retry',
            reason: String(emptyErr.message || ''),
            maxTokens: retryBody.max_tokens,
            temperature: retryBody.temperature
          });
        } catch (_) {}
        console.warn('[AIStoryGen] empty AI response, retrying once with max_tokens=' + retryBody.max_tokens);
        var retryResult = await postOnce(retryBody);
        try { window.AIStoryGen.lastApiError = null; } catch (_) {}
        try {
          RequestLog.finishSuccess(requestId, {
            outputChars: String(retryResult.text || '').length,
            finishReason: retryResult.finishReason,
            responseModel: retryResult.responseModel,
            usage: retryResult.usage
          });
        } catch (_) {}
        return retryResult.text;
      }
    } catch (e) {
      var classified = classifyError(e, cfg.language);
      _recordLastApiError(classified, cfg, selected);
      try { RequestLog.finishError(requestId, classified); } catch (_) {}
      throw classified;
    }
  }

  function _looksLikeAbortSignal(value) {
    return !!(value && (typeof value.aborted === 'boolean' || typeof value.addEventListener === 'function'));
  }

  async function callAI(instruction, signalOrOpts, extraOpts) {
    var cfg = loadCfg();
    var opts = {};
    var signal = null;
    if (_looksLikeAbortSignal(signalOrOpts)) {
      signal = signalOrOpts;
      opts = Object.assign({}, extraOpts || {});
    } else {
      opts = Object.assign({}, signalOrOpts || {}, extraOpts || {});
      signal = opts.signal || null;
    }
    if (opts.storyStyle) {
      instruction = _applyStoryStyleDirectiveToPrompt(instruction, cfg);
    }
    var userContent = opts.structuredPrompt
      ? String(instruction || '')
      : buildUser(cfg, instruction);
    var messages = [
      { role: 'system', content: buildSystem(cfg) },
      { role: 'user', content: userContent },
    ];
    var fetchOpts = Object.assign({ temperature: cfg.temperature, max_tokens: cfg.max_tokens, signal: signal, purpose: 'story' }, opts);
    delete fetchOpts.storyStyle;
    delete fetchOpts.structuredPrompt;
    return _fetchAI(messages, fetchOpts);
  }
  window.AIStoryGen.callAI = callAI;

  // ---------- 6. 配置表单构建（共享函数） ----------
  var CONFIG_FIELDS = [
    { section: '连接' },
    { k: 'apiProvider', label: '接口服务商预设', type: 'select', options: ProviderPresetsModule.getSelectOptions(), help: '选择常见 OpenAI 兼容服务商后，会自动填入普通接口、高质量接口和推荐模型。选择“自定义 / 手动填写”时不会自动改动地址或模型。预设只负责填写配置，具体可用模型仍以服务商当前模型列表为准。' },
    { k: 'apiKey',     label: 'API 密钥',       type: 'password', help: '用于调用兼容 OpenAI 格式的接口。密钥只保存在本地浏览器/当前环境，不会写进剧情文本。留空时 AI 剧情和选项不会请求接口。' },
    { k: 'endpoint',   label: '接口地址',        type: 'text', help: 'AI 服务的 chat completions 地址。DeepSeek 默认是 https://api.deepseek.com/v1/chat/completions；其他兼容 OpenAI 的服务也可以填写对应地址。' },
    { k: 'model',      label: '模型',            type: 'text', help: '接口要调用的模型名称，必须是该服务支持的模型。模型越强通常越稳定，但速度和费用也可能更高。' },
    { k: 'language',   label: '语言 (en / zh)',  type: 'text', help: 'AI 输出语言。中文请填 zh，英文请填 en。这个设置会影响叙事、选项、错误提示和部分 prompt 结构。' },

    { section: '模块' },
    { k: 'aiPixelEnabled', label: '启用 AI 绘图', type: 'bool', help: '开启后显示绘图配置页、剧情旁生图入口和战斗姿势图入口。关闭后隐藏所有 AI 绘图相关窗口和按钮，但保留已有绘图设置与缓存，之后可随时重新开启。' },

    { section: '剧情生成' },
    { k: 'choiceTriggerMode', label: '剧情生成入口模式', type: 'select', options: [
      { value: 'auto', label: '自动：普通剧情页自动生成分支' },
      { value: 'manual', label: '手动：只显示生成剧情按钮' },
      { value: 'off', label: '关闭：不显示普通页剧情入口' }
    ], help: '控制普通原版剧情页底部的 AI 分支入口。自动会像以前一样直接生成选项；手动只显示“生成剧情”按钮，点击后才请求 API；关闭则不显示普通页 AI 分支入口。原版链接后面的“剧情生成”按钮仍由“地点链接剧情生成”单独控制。' },
    { k: 'aiReplaceLinks', label: '地点链接剧情生成', type: 'bool', help: '开启后原版地点链接后会出现“剧情生成”按钮。点击后会用 AI 过渡剧情接管该地点移动过程。' },
    { k: 'uiLayoutMode', label: 'AI界面宽度模式', type: 'select', options: [
      { value: 'auto', label: '自动：按设备选择' },
      { value: 'desktop', label: '原版宽度：桌面/宽屏' },
      { value: 'tablet', label: '平板紧凑：中等宽度' },
      { value: 'mobile', label: '手机紧凑：限制横向溢出' }
    ], help: '控制 AI 剧情面板、AI 选项和时间编辑器的宽度。自动模式下，手机和窄屏会使用紧凑布局，避免出现横向拖动和周围空白；桌面会尽量保持原版宽度。' },
    { k: 'aiChoiceMode', label: '剧情后续选项模式', type: 'bool', help: '关闭时为快速模式：选项主要根据当前状态和场景生成。开启后为剧情后续模式：选项会优先承接上一段 AI 剧情结尾，更连贯，但 prompt 更长、消耗略高。' },
    { k: 'temperature', label: '随机度', type: 'range', min: 0, max: 2, step: 0.1, help: '控制 AI 发散程度。低数值更稳定、更贴近提示；高数值更有变化，但更容易跑偏。推荐 0.7 到 1.0。' },
    { k: 'max_tokens', label: '最大输出长度', type: 'range', min: 100, max: 2000, step: 50, help: '限制单次 AI 回复长度。数值越高，剧情可写得越长，但速度更慢、消耗更多，也更可能产生冗余文本。' },
    { k: 'tier', label: '状态详细度', type: 'range', min: 1, max: 3, step: 1, help: '控制发送给 AI 的游戏状态详细程度。1 较精简；2 包含常用状态、NPC、孕等；3 更完整但 prompt 更长。' },
    { k: 'showChangeSummary', label: '显示本轮数值变化提示', type: 'bool', help: '开启后，每次 AI 剧情事务提交成功后，会在页面顶部短暂显示本轮实际变化，例如时间、压力、疲劳、金钱、AI 道具、NPC关系、地点和记忆。默认关闭，不影响游戏数据。' },
    { k: 'statChangeLimit', label: '人物数值变化区间', type: 'range', min: 0, max: 200, step: 5, help: '限制 AI 一次剧情能改动的玩家状态数值，防止模型误改过大。它是没有细分设置时使用的总兜底上限，不会和下方细分区间叠加。0 表示禁止 AI 改玩家状态。金钱有单独放宽，但仍不能低于 0。' },
    { label: '细分人物数值变化区间', type: 'statLimits', help: '分别微调疼痛、性奋、疲劳、压力、创伤、自控、诱惑每项一次最多变化多少。细分项优先于上方“人物数值变化区间”：例如总区间为 100，但疼痛细分为 20，则疼痛一次最多按 20 处理；没有细分项时才回退到总区间。0 表示禁止该状态由 AI 改动。' },
    { k: 'npcRelationChangeChance', label: 'NPC关系变化几率', type: 'range', min: 0, max: 100, step: 5, help: '控制 AI 剧情是否把 NPC 关系/状态变化真正写入游戏。0 表示禁止 NPC 关系变化，100 表示只要 AI 明确写出就允许。建议 20 到 50，避免每段剧情都涨关系。' },
    { k: 'npcRelationChangeLimit', label: 'NPC关系变化区间', type: 'range', min: 0, max: 10, step: 1, help: '限制单个 NPC 单项关系数值一次最多变化多少。0 表示禁止 NPC 关系变化；数值越大，love、trust、lust、rage、dom 等变化越明显。' },
    { k: 'sexModeTriggerMode', label: '\u8272\u8272\u5bbd\u5bb9\u5ea6', type: 'select', options: [
      { value: 1, label: '\u4e25\u683c\uff1a\u4eb2\u5bc6\u5267\u60c5\u65f6\u51fa\u73b0' },
      { value: 2, label: '\u5bbd\u677e\uff1a\u573a\u666f\u91cc\u6709\u89d2\u8272\u5c31\u51fa\u73b0' }
    ], help: '\u63a7\u5236\u300c\u8fdb\u5165\u8272\u8272\u6a21\u5f0f\u300d\u6309\u94ae\u4f55\u65f6\u51fa\u73b0\u3002\u4e25\u683c\uff1a\u53ea\u6709\u5f53\u524d\u5267\u60c5\u660e\u786e\u51fa\u73b0\u9760\u8fd1\u3001\u89e6\u78b0\u3001\u4eb2\u543b\u3001\u66a7\u6627\u7b49\u4eb2\u5bc6\u4e92\u52a8\u65f6\u624d\u51fa\u73b0\u3002\u5bbd\u677e\uff1a\u5f53\u524d\u573a\u666f\u91cc\u53ea\u8981\u6709\u53ef\u8bc6\u522b\u7684\u5728\u573a\u89d2\u8272\u3001\u89e6\u624b\u6216\u52a8\u7269\u5bf9\u8c61\uff0c\u5c31\u663e\u793a\u5165\u53e3\u3002' },
    { k: 'aiIntimateDynamicActions', label: 'AI 生成色色动作选项', type: 'bool', help: '开启后，独立 AI 色色模式会让 AI 根据当前姿势和上一轮剧情生成下一页各部位动作。模型漏写或格式异常时会自动回到内置固定动作池。关闭后始终使用固定动作池。' },

    { section: '记忆' },
    { k: 'recentMax', label: '短期记忆条数', type: 'range', min: 0, max: 20, step: 1, help: '每次生成时发送给 AI 的近期剧情条数，也是未压缩短期记录的上限。0 表示关闭短期记忆。短期记忆跟随当前游戏存档，不会跨存档共享。' },
    { k: 'recentLimit', label: '单条记忆字数上限', type: 'range', min: 200, max: 900, step: 50, help: '每条短期记忆最多保留多少字。实际运行范围为 200 到 900 字；较低可减少消耗，较高可保留更多上下文。' },
    { k: 'summarizeTrigger', label: '记忆压缩触发条数', type: 'range', min: 0, max: 30, step: 1, help: '短期记忆达到多少条时，把最早记录合并成一条滚动摘要。该值高于“短期记忆条数”时会自动按短期上限处理；0 表示关闭自动压缩，超出部分会整理进长期记忆。' },
    { k: 'longTermMax', label: '长期记忆容量', type: 'range', min: 0, max: 300, step: 10, help: '限制长期记忆最多保存多少条。达到上限后，系统会把最旧的未锁定条目合并进一条“长期归档”，不会直接丢弃剧情信息。0 表示无限制；默认 120 条。' },

    { section: '高质量后台' },
    { k: 'highQualityMode', label: '高质量模式', type: 'bool', help: '开启后，长期记忆压缩、短期记忆整理、长期记忆精炼、AI道具来源整理会使用下面的高质量接口和模型。普通剧情、选项和战斗叙事仍使用普通模型。' },
    { k: 'highQualityEndpoint', label: '高质量接口地址', type: 'text', help: '高质量任务使用的 chat completions 地址。默认仍为 DeepSeek 官方接口；如果你的高质量模型在另一个兼容 OpenAI 的服务上，可以单独填写这里。' },
    { k: 'highQualityModel', label: '高质量模型', type: 'text', help: '高质量任务使用的模型名。默认 deepseek-v4-pro，适合记忆压缩和剧情整理这种更需要稳定归纳的后台任务。' },

    { section: '战斗叙事' },
    { k: 'enableCombat', label: '战斗 AI 叙事', type: 'bool', help: '开启后战斗中会根据当前战斗状态生成 AI 叙事。关闭后不影响普通剧情生成。' },

    { section: '缓存与高级' },
    { k: 'cacheEnabled', label: '叙事缓存', type: 'bool', help: '开启后短时间内同地点、同氛围的叙事可复用缓存，减少等待和 API 消耗。调试剧情时可关闭。' },
    { k: 'cacheTTLMinutes', label: '缓存有效期(分钟)', type: 'range', min: 0, max: 60, step: 1, help: '叙事缓存保留多久。0 表示几乎不复用缓存；数值越高，重复地点越容易看到同一段缓存剧情。' },

    { section: '光脚附加效果' },
    { k: 'barefootBuffEnabled', label: '启用光脚附加效果', type: 'bool', tab: 'extras', help: '开启后，角色真正光脚时可以获得下方选中的原版正面鞋类判定。角色外观、脚部装备、库存和存档仍保持光脚；穿上真实鞋子时自动暂停，优先使用实际鞋类效果。默认关闭。' },
    { k: 'barefootBuffRugged', label: '崎岖地形鞋底', type: 'bool', tab: 'extras', help: '光脚时按原版 rugged 鞋类效果判定。可在森林、荒野、农场等崎岖地形提供原版体能/运动技能收益，并参与部分雪地、泥地和森林事件的防滑、防陷或难度修正。不会提供鞋子的遮蔽、保暖或外观。' },
    { k: 'barefootBuffSwim', label: '游泳脚蹼效果', type: 'bool', tab: 'extras', help: '光脚时按原版 swim 鞋类效果判定，获得原版脚蹼对游泳技能的收益。只提供该类型判定，不会凭空生成脚蹼物品，也不会改变角色外观。' },

    { section: '超长头发外观', tab: 'extras' },
    { k: 'extraLongHairStyle', label: '超长头发类型', type: 'select', tab: 'extras', options: [
      { value: 'off', label: '使用原版长度' },
      { value: 'pooled', label: '铺散脚边' },
      { value: 'trailing', label: '身后拖曳' },
      { value: 'cascade', label: '超长发瀑' },
      { value: 'serpentine', label: '蜿蜒拖尾' },
      { value: 'fan', label: '扇形铺展' },
      { value: 'endless', label: '无尽长发' }
    ], help: '为原版“长发拖地”增加六种更长外观。只有原版头发长度达到最大值 1000 时才生效，并会写入 AI 剧情状态和生图人物外观。新增发尾纸娃娃覆盖层会沿用当前发色；不会改写原版头发长度、理发流程或原版 hairlengthstage。' },

    { section: '提示词' },
    { k: 'playerStoryProfile', label: '玩家剧情特点 / 长期偏好', type: 'textarea', rows: 6, tab: 'prompt', help: '玩家手动写的长期剧情偏好，例如希望强化的主题、角色关系、叙事方向。生成剧情时会作为背景参考。' },
    { k: 'storyStylePreset', label: '文风设定', type: 'select', tab: 'prompt', options: [
      { value: 'none', label: '不使用预设' },
      { value: 'custom', label: '使用自定义文风' },
      { value: 'minimal', label: '极简文风' },
      { value: 'epic', label: '史诗文风' },
      { value: 'cult', label: 'cult文风' }
    ], help: '选择预设后，下方会显示对应文风提示词；选择“使用自定义文风”后，才可以在下方输入自己的风格。需要点击底部“保存”后生效。' },
    { k: 'storyStylePrompt', label: '文风提示词', type: 'textarea', rows: 7, tab: 'prompt', help: '这里显示当前文风的完整提示词。选择预设时为只读预览；选择“使用自定义文风”时可以编辑。文风只影响语言、节奏和氛围，不应改变地点、NPC、物品、数值、AI_META 或 AI_EVENT 等游戏事实。' },
    { k: 'longTermRefinePrompt', label: '长期记忆精炼提示词', type: 'textarea', rows: 14, tab: 'prompt', help: '点击 AI记忆 页里的“精炼记忆”时使用。可使用 {{memory}} 作为长期记忆原文占位符；不写占位符时会自动把原文接在提示词后面。' },
    { k: 'jailbreak', label: '破甲词 / 自定义提示前缀', type: 'textarea', tab: 'prompt', help: '追加到用户提示前部的自定义内容。会明显影响 AI 行为，建议只写确实需要长期生效的约束。' },
    { k: 'systemPromptExtra', label: '额外的叙事风格指令', type: 'textarea', tab: 'prompt', help: '追加到系统提示词。适合写文风、叙事节奏、禁止事项、偏好的剧情结构等长期规则。' },
    { k: 'combatPromptTemplate', label: '战斗叙事提示词模板', type: 'textarea', rows: 10, tab: 'prompt', help: '战斗 AI 叙事使用的模板。留空时使用内置模板。高级选项，模板写错可能导致战斗叙事不稳定。' },
    { k: 'postProcessPattern', label: '输出过滤正则', type: 'text', tab: 'prompt', help: '用正则处理 AI 输出中的固定废话或格式问题。高级选项，写错正则会被忽略。示例：/好的[\\s\\S]*?：/g' },
    { k: 'postProcessReplacement', label: '正则替换文本', type: 'text', tab: 'prompt', help: '与“输出过滤正则”配合使用。留空表示删除匹配内容；填写文字则把匹配内容替换为该文字。' },
  ];

  var _aiConfigSchema = ConfigSchemaModule.create({
    getFields: function () { return CONFIG_FIELDS; },
    isAdultContentUnlocked: _isAdultContentUnlocked,
    getDefaults: function () { return DEFAULT_CFG; }
  });
  window.AIStoryGen.configSchema = _aiConfigSchema;

  function getConfigSchema() {
    return _aiConfigSchema.getConfigSchema();
  }

  function _defaultConfigValue(field, cfg) {
    return _aiConfigSchema.defaultConfigValue(field, cfg);
  }

  function _coerceConfigFieldValue(field, input) {
    return _aiConfigSchema.coerceFieldValue(field, input);
  }

  function _configFieldsForTab(tab) {
    return _aiConfigSchema.fieldsForTab(tab);
  }
  window.AIStoryGen.getConfigSchema = getConfigSchema;

  function _ensureConfigLayoutStyles() {
    if (typeof document === 'undefined') return;
    if (document.getElementById('ai-config-layout-runtime-style')) return;
    var css = '';
    try {
      if (MobileCompatModule && typeof MobileCompatModule.getConfigLayoutStyleText === 'function') {
        css = MobileCompatModule.getConfigLayoutStyleText();
      }
    } catch (_) {}
    if (!css) {
      css = '.ai-merged-settings{box-sizing:border-box;max-width:100%;}.ai-cfg-form{display:grid;grid-template-columns:minmax(11em,15em) minmax(0,1fr);gap:.48em .9em;margin-bottom:.9em;}@media(max-width:900px){.ai-cfg-form{grid-template-columns:minmax(0,1fr);}.ai-cfg-row{display:grid;grid-template-columns:minmax(0,1fr);gap:.25em;}}';
    }
    var style = document.createElement('style');
    style.id = 'ai-config-layout-runtime-style';
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }

  /**
   * Build the AI config form into $container (a jQuery object).
   * Used by both the standalone <<aiconfig>> macro and the Settings tab.
   * @param {$} $container  jQuery element to append form into
   * @param {boolean} isSettingsTab  whether we're rendering inside the Settings tab
   */
  function buildConfigForm($container, isSettingsTab, tabName) {
    _ensureConfigLayoutStyles();
    var cfg = loadCfg();
    var activeConfigTab = String(tabName || 'story');
    var isDiagnosticTab = activeConfigTab === 'diagnostic';
    var visibleFields = isDiagnosticTab ? [] : _configFieldsForTab(activeConfigTab);
    var wrapperClass = isSettingsTab ? 'ai-cfg ai-cfg-settings' : 'ai-cfg';
    var $root = $('<div></div>').addClass(wrapperClass);

    if (isDiagnosticTab && !_isApiConfigured(cfg)) {
      $root.append(_makeApiWarnBlock(cfg, { compact: true }));
    }

    var $form = $('<div class="ai-cfg-form"></div>');
    var inputs = {};

    visibleFields.forEach(function (f) {
      if (f.section) {
        $form.append($('<div class="ai-cfg-section"></div>').text(f.section));
        return;
      }
      var $row = $('<div class="ai-cfg-row"></div>');
      var $label = $('<label></label>').text(f.label);
      if (f.help) {
        var $help = $('<span class="ai-cfg-help" tabindex="0">(?)</span>')
          .attr('title', f.help)
          .attr('data-help', f.help)
          .attr('aria-label', f.label + ' 说明');
        $label.append(' ').append($help);
      }
      $row.append($label);
      var $inp;
      if (f.type === 'statLimits' || f.type === 'relationLimits') {
        var isStatLimits = f.type === 'statLimits';
        var defs = isStatLimits ? _getAiStatLimitFieldDefs() : _getAiNpcRelationLimitFieldDefs();
        var $details = $('<details class="ai-cfg-details"></details>').addClass(isStatLimits ? 'ai-stat-limit-details' : 'ai-relation-limit-details');
        if (isStatLimits) $details.prop('open', true);
        var $summary = $('<summary></summary>').text(f.label || (isStatLimits ? '细分状态变化区间' : '细分人物数值变化区间'));
        $details.append($summary);
        if (f.help) $details.append($('<div class="ai-cfg-details-help"></div>').text(f.help));
        var $grid = $('<div></div>').addClass(isStatLimits ? 'ai-stat-limit-grid' : 'ai-relation-limit-grid');
        defs.forEach(function (def) {
          var val = _defaultConfigValue({ k: def.key }, cfg);
          var max = isStatLimits ? (def.max || 5000) : 10;
          var step = isStatLimits ? (def.step || 1) : 1;
          var $item = $('<label></label>').addClass(isStatLimits ? 'ai-stat-limit-item' : 'ai-relation-limit-item');
          var $name = $('<span></span>').addClass(isStatLimits ? 'ai-stat-limit-name' : 'ai-relation-limit-name').text(def.label);
          var $range = $('<input type="range">')
            .attr('min', 0)
            .attr('max', max)
            .attr('step', step)
            .val(val);
          var $num = $('<input type="number">')
            .addClass(isStatLimits ? 'ai-stat-limit-number' : 'ai-relation-limit-number')
            .attr('min', 0)
            .attr('max', max)
            .attr('step', step)
            .val(val);
          function syncLimit(value) {
            var next = isStatLimits
              ? _clampAiStatFieldLimit(value, def.fallback || 0, max)
              : _clampAiNpcRelationLimit(value, 0);
            $range.val(next);
            $num.val(next);
          }
          $range.on('input change', function () { syncLimit($(this).val()); });
          $num.on('input change', function () { syncLimit($(this).val()); });
          $item.append($name).append($range).append($num);
          $grid.append($item);
          inputs[def.key] = $range;
        });
        $details.append($grid);
        $form.append($details);
        return;
      } else if (f.type === 'textarea') {
        $inp = $('<textarea></textarea>').attr('rows', f.rows || 4).val(_defaultConfigValue(f, cfg));
      } else if (f.type === 'select') {
        $inp = $('<select></select>');
        (f.options || []).forEach(function (opt) {
          $inp.append($('<option></option>').attr('value', opt.value).text(opt.label));
        });
        $inp.val(String(_defaultConfigValue(f, cfg)));
      } else if (f.type === 'bool') {
        var checked = Number(_defaultConfigValue(f, cfg) || 0) ? true : false;
        var $wrap = $('<label class="ai-cfg-check"></label>');
        $inp = $('<input type="checkbox">').prop('checked', checked);
        $wrap.append($inp).append($('<span></span>').text(checked ? '开启' : '关闭'));
        $inp.on('change', function () {
          $wrap.find('span').text($(this).prop('checked') ? '开启' : '关闭');
        });
        $row.append($wrap);
        inputs[f.k] = $inp;
        $form.append($row);
        return;
      } else if (f.type === 'range') {
        var val = _defaultConfigValue(f, cfg);
        $inp = $('<input type="range">')
          .attr('min', f.min)
          .attr('max', f.max)
          .attr('step', f.step || 1)
          .val(val);
        var $rangeWrap = $('<div class="ai-cfg-range"></div>');
        var $value = $('<span class="ai-cfg-range-value"></span>').text(val);
        $inp.on('input change', function () {
          $value.text($(this).val());
        });
        $rangeWrap.append($inp).append($value);
        $row.append($rangeWrap);
        inputs[f.k] = $inp;
        $form.append($row);
        return;
      } else {
        $inp = $('<input>').attr('type', f.type).val(_defaultConfigValue(f, cfg));
        if (f.step) $inp.attr('step', f.step);
      }
      $row.append($inp);
      inputs[f.k] = $inp;
      $form.append($row);
    });

    function syncStoryStylePromptUi() {
      if (!inputs.storyStylePreset || !inputs.storyStylePrompt) return;
      var mode = String(inputs.storyStylePreset.val() || 'none');
      var $prompt = inputs.storyStylePrompt;
      if (mode === 'custom') {
        $prompt.prop('readonly', false).prop('disabled', false).css('opacity', '1');
        return;
      }
      var preview = STORY_STYLE_PRESETS[mode] || '';
      $prompt.val(preview);
      $prompt.prop('readonly', true).prop('disabled', false).css('opacity', preview ? '0.85' : '0.55');
    }
    if (inputs.storyStylePreset && inputs.storyStylePrompt) {
      inputs.storyStylePreset.on('change', syncStoryStylePromptUi);
      syncStoryStylePromptUi();
    }

    function syncBarefootBuffOptionUi() {
      if (!inputs.barefootBuffEnabled) return;
      var enabled = !!inputs.barefootBuffEnabled.prop('checked');
      ['barefootBuffRugged', 'barefootBuffSwim'].forEach(function (key) {
        if (!inputs[key]) return;
        inputs[key].prop('disabled', !enabled);
        try { inputs[key].closest('.ai-cfg-check').css('opacity', enabled ? '1' : '0.55'); } catch (_) {}
      });
    }
    if (inputs.barefootBuffEnabled) {
      inputs.barefootBuffEnabled.on('change', syncBarefootBuffOptionUi);
      syncBarefootBuffOptionUi();
    }

    var $btnSave = $('<button type="button" class="ai-cfg-btn ai-cfg-btn-primary ai-cfg-save-strong">保存设置</button>');
    var $btnTest = $('<button class="ai-cfg-btn">测试连接</button>');
    var $btnReset = $('<button class="ai-cfg-btn">恢复默认</button>');
    var $btnReportFile = $('<button class="ai-cfg-btn">导出错误报告到文件</button>');
    var $btnReportClip = $('<button class="ai-cfg-btn">导出错误报告到剪贴板</button>');
    var $btnReportIssue = $('<button class="ai-cfg-btn">复制反馈模板</button>');
    var $btnPixelDiag = $('<button class="ai-cfg-btn">复制生图诊断</button>');
    var $btnClearModCache = $('<button class="ai-cfg-btn">清理织境空间旧缓存</button>');
    var $health = $('<div class="ai-provider-health"></div>');
    var $reportSummary = $('<div class="ai-error-report-summary-panel"></div>');
    var $msg = $('<div class="ai-cfg-msg"></div>');
    var $barefootStatus = activeConfigTab === 'extras'
      ? $('<div class="ai-barefoot-buff-status" aria-live="polite"></div>')
      : null;
    var $extraLongHairStatus = activeConfigTab === 'extras'
      ? $('<div class="ai-extra-long-hair-status" aria-live="polite"></div>')
      : null;
    var $probeActions = $('<div class="ai-provider-probe-actions"></div>');

    function renderBarefootBuffStatus(reason) {
      if (!$barefootStatus) return;
      var diagnostics = null;
      try {
        if (_aiBarefootBuffs && typeof _aiBarefootBuffs.refresh === 'function') {
          diagnostics = _aiBarefootBuffs.refresh(reason || 'settings status');
        }
      } catch (_) {}
      diagnostics = diagnostics || {};
      var lines = [];
      if (!diagnostics.enabled) {
        lines.push('当前状态：光脚附加效果未启用。');
      } else if (!diagnostics.barefoot) {
        lines.push('当前状态：角色已穿鞋，附加效果暂停，使用实际鞋类效果。');
      } else if (diagnostics.activeLabels && diagnostics.activeLabels.length) {
        lines.push('当前状态：角色光脚；已生效：' + diagnostics.activeLabels.join('、') + '。');
      } else {
        lines.push('当前状态：角色光脚，但没有选择要附加的鞋类效果。');
      }
      lines.push('这些效果只参与原版鞋类类型判定；外观、脚部装备、库存和存档仍保持光脚。');
      if (diagnostics.lastPatchError) lines.push('运行时接入失败：' + diagnostics.lastPatchError);
      $barefootStatus
        .toggleClass('active', !!(diagnostics.barefoot && diagnostics.activeLabels && diagnostics.activeLabels.length))
        .toggleClass('error', !!diagnostics.lastPatchError)
        .text(lines.join(' '));
    }

    function renderExtraLongHairStatus() {
      if (!$extraLongHairStatus) return;
      var diagnostics = {};
      try {
        diagnostics = _aiExtraLongHair.getDiagnostics() || {};
      } catch (_) {}
      var text = '';
      if (!diagnostics.selected) {
        text = '当前状态：使用原版头发长度。';
      } else if (diagnostics.pendingNativeMax) {
        text = '当前状态：已选择“' + (diagnostics.label || '超长头发') + '”，但原版头发长度为 '
          + Number(diagnostics.nativeHairLength || 0) + '；达到最大长度 1000 后自动生效。';
      } else {
        text = '当前状态：超长外观“' + (diagnostics.label || '') + '”已生效。剧情、生图和纸娃娃发尾覆盖层会使用该类型。';
      }
      if (diagnostics.selected && !diagnostics.rendererInstalled) text += ' 纸娃娃覆盖层正在等待原版渲染器加载。';
      if (diagnostics.lastRendererError) text += ' 渲染接入失败：' + diagnostics.lastRendererError;
      $extraLongHairStatus
        .toggleClass('active', !!diagnostics.active)
        .text(text);
    }

    function applyProviderPresetToInputs(providerId, showMessage) {
      if (!inputs.apiProvider) return;
      var preset = ProviderPresetsModule.getPreset(providerId);
      if (!preset || preset.id === 'custom') {
        if (showMessage) $msg.removeClass('err').addClass('ok').text('已切换为自定义接口，请手动填写地址和模型。');
        return;
      }
      if (inputs.endpoint) inputs.endpoint.val(preset.endpoint);
      if (inputs.model) inputs.model.val(preset.model);
      if (inputs.highQualityEndpoint) inputs.highQualityEndpoint.val(preset.highQualityEndpoint || preset.endpoint);
      if (inputs.highQualityModel) inputs.highQualityModel.val(preset.highQualityModel || preset.model);
      if (showMessage) {
        $msg.removeClass('err').addClass('ok').text('已套用预设：' + preset.label + '。请确认模型在你的账号可用后保存。');
      }
    }
    if (inputs.apiProvider) {
      inputs.apiProvider.on('change', function () {
        applyProviderPresetToInputs($(this).val(), true);
      });
    }

    function collectFormCfg() {
      var next = Object.assign({}, loadCfg());
      visibleFields.forEach(function (f) {
        if (f.section) return;
        if (f.type === 'statLimits') {
          _getAiStatLimitFieldDefs().forEach(function (def) {
            next[def.key] = _coerceConfigFieldValue({ type: 'range', k: def.key }, inputs[def.key]);
          });
          return;
        }
        if (f.type === 'relationLimits') {
          _getAiNpcRelationLimitFieldDefs().forEach(function (def) {
            next[def.key] = _coerceConfigFieldValue({ type: 'range', k: def.key }, inputs[def.key]);
          });
          return;
        }
        next[f.k] = _coerceConfigFieldValue(f, inputs[f.k]);
      });
      if (next.storyStylePreset !== 'custom') {
        next.storyStylePrompt = '';
      }
      try { next = ProviderPresetsModule.normalizeConfigProvider(next); } catch (_) {}
      return next;
    }

    function endpointFormatLabel(endpoint) {
      endpoint = String(endpoint || '').trim();
      if (!endpoint) return { level: 'err', text: '未填写' };
      if (/\/chat\/completions\/?$/i.test(endpoint)) return { level: 'ok', text: '完整 chat/completions 地址' };
      if (/\/responses\/?$/i.test(endpoint)) return { level: 'warn', text: 'Responses 地址，当前会原样调用' };
      if (/\/models\/?$/i.test(endpoint)) return { level: 'warn', text: '模型列表地址；实际聊天会改为 chat/completions' };
      if (/\/v\d+(?:beta)?(?:\/openai)?\/?$/i.test(endpoint)) return { level: 'ok', text: 'Base URL，可自动补全 chat/completions' };
      return { level: 'warn', text: '自定义地址，将按 base URL 补全' };
    }

    function appendHealthRow($box, label, text, level) {
      var $row = $('<div class="ai-provider-health-row"></div>');
      $row.addClass('ai-provider-health-' + (level || 'info'));
      $row.append($('<span class="ai-provider-health-label"></span>').text(label));
      $row.append($('<span class="ai-provider-health-value"></span>').text(text || ''));
      $box.append($row);
    }

    function appendRequestLog($box) {
      var recent = [];
      try { recent = RequestLog.getRecent(5) || []; } catch (_) { recent = []; }
      var $log = $('<div class="ai-request-log"></div>');
      var $titleRow = $('<div class="ai-request-log-title-row"></div>');
      $titleRow.append($('<div class="ai-request-log-title"></div>').text('最近请求记录'));
      var $copyApi = $('<button type="button" class="ai-cfg-btn ai-request-log-copy">复制 API 诊断片段</button>');
      $copyApi.on('click', function () {
        window.AIStoryGen.copyApiDiagnosticSnippetToClipboard().then(function () {
          $msg.removeClass('err').addClass('ok').text('API 诊断片段已复制。');
        }, function (e) {
          $msg.removeClass('ok').addClass('err').text('API 诊断片段复制失败：' + String(e && e.message || e).slice(0, 120));
        });
      });
      $titleRow.append($copyApi);
      $log.append($titleRow);
      if (!recent.length) {
        $log.append($('<div class="ai-request-log-empty"></div>').text('暂无请求记录'));
        $box.append($log);
        return;
      }
      recent.forEach(function (entry) {
        var ok = entry.status === 'success';
        var pending = entry.status === 'pending';
        var label = '[' + (ok ? '成功' : (pending ? '进行中' : '失败')) + '] ';
        if (entry.purpose) label += '【' + entry.purpose + '】';
        label += (entry.provider || '自定义') + ' / ' + (entry.model || '未填写模型');
        var detail = [];
        if (entry.durationMs != null) detail.push(entry.durationMs + 'ms');
        if (entry.inputChars != null) detail.push('输入 ' + entry.inputChars + ' 字');
        if (entry.outputChars != null) detail.push('输出 ' + entry.outputChars + ' 字');
        if (entry.retryCount) detail.push('重试 ' + entry.retryCount + ' 次');
        if (entry.finishReason) detail.push('finish=' + entry.finishReason);
        if (entry.error && entry.error.type) detail.push(entry.error.type + (entry.error.statusCode ? ' HTTP ' + entry.error.statusCode : ''));
        var $item = $('<div class="ai-request-log-item"></div>').addClass(ok ? 'ok' : (pending ? 'warn' : 'err'));
        $item.append($('<div class="ai-request-log-main"></div>').text(label));
        $item.append($('<div class="ai-request-log-detail"></div>').text(detail.join('；') || (entry.endpoint || '')));
        $log.append($item);
      });
      $box.append($log);
    }

    function buildApiCompatSummary(probeResult, chatProbe, cfg) {
      probeResult = probeResult || {};
      chatProbe = chatProbe || null;
      cfg = cfg || collectFormCfg();
      var lines = [];
      var severity = 'ok';
      var providerAdvice = null;
      function add(level, text) {
        if (!text) return;
        lines.push(String(text));
        if (level === 'error') severity = 'error';
        else if (level === 'warning' && severity !== 'error') severity = 'warning';
      }
      var endpoint = String(cfg.endpoint || '').trim();
      var model = String(cfg.model || '').trim();
      var normalizedEndpoint = '';
      var localEndpoint = false;
      try { normalizedEndpoint = ApiClientModule.normalizeChatEndpoint(endpoint); } catch (_) { normalizedEndpoint = endpoint; }
      try { localEndpoint = ApiClientModule.isLocalEndpoint(normalizedEndpoint || endpoint); } catch (_) {}
      if (!endpoint) add('error', '接口地址为空，无法测试。');
      if (!model) add('error', '模型名为空，无法测试。');
      if (!localEndpoint && !String(cfg.apiKey || '').trim()) add('error', 'API Key 为空，非本地接口通常会认证失败。');
      var modelProbe = probeResult.modelProbe || null;
      if (probeResult.status === 'model_not_found' || (modelProbe && modelProbe.modelCount && !modelProbe.modelFound)) {
        add('error', '模型列表可访问，但没有找到当前模型：' + model + ((modelProbe && modelProbe.candidates && modelProbe.candidates.length) ? '。候选：' + modelProbe.candidates.slice(0, 4).join('，') : '。'));
      } else if (modelProbe && modelProbe.modelFound) {
        add('ok', '模型列表可访问，当前模型名存在。');
      } else if (probeResult.status === 'models_unavailable' || (modelProbe && modelProbe.skipped)) {
        add('warning', '模型列表不可用或已跳过，已继续测试聊天接口。');
      } else if (probeResult.status && probeResult.status !== 'ok') {
        add('warning', '模型列表探测结果：' + (probeResult.message || probeResult.status));
      }
      if (chatProbe) {
        if (chatProbe.ok) {
          add('ok', '聊天接口可用，并返回了可读取文本。');
        } else if (chatProbe.emptyReason) {
          add('warning', '聊天接口 HTTP 成功，但没有可读取文本：' + chatProbe.emptyReason);
        } else {
          add('error', '聊天接口失败：' + (chatProbe.message || chatProbe.errorType || '未知错误'));
          try {
            var compatCaps = ProviderPresetsModule.getConfigCapabilities(cfg);
            if (compatCaps && compatCaps.common404Hint && /(?:404|model|not found|模型|找不到)/i.test(String(chatProbe.message || chatProbe.errorType || ''))) {
              add('warning', '服务商 404 排查：' + compatCaps.common404Hint);
            }
          } catch (_) {}
        }
      } else {
        add('warning', '尚未完成聊天接口测试。');
      }
      try {
        providerAdvice = ProviderPresetsModule.buildProviderAdvice(cfg, probeResult, chatProbe);
        (providerAdvice.lines || []).forEach(function (line) {
          add(providerAdvice.severity === 'error' ? 'error' : 'warning', line);
        });
      } catch (_) {}
      return {
        schemaVersion: 1,
        ok: severity === 'ok',
        severity: severity,
        endpoint: normalizedEndpoint,
        model: model,
        lines: lines.slice(0, 8),
        modelFound: !!(modelProbe && modelProbe.modelFound),
        candidates: providerAdvice && providerAdvice.modelSuggestions && providerAdvice.modelSuggestions.length
          ? providerAdvice.modelSuggestions.slice(0, 8)
          : (modelProbe && modelProbe.candidates ? modelProbe.candidates.slice(0, 8) : []),
        providerAdvice: providerAdvice,
        chatOk: !!(chatProbe && chatProbe.ok)
      };
    }

    function renderProviderHealth() {
      if (!$health || !$health.length) return;
      var cfg = collectFormCfg();
      var diag = {};
      var caps = {};
      try { diag = ProviderPresetsModule.getDiagnostic(cfg); } catch (_) { diag = {}; }
      try { caps = ProviderPresetsModule.getConfigCapabilities(cfg); } catch (_) { caps = {}; }
      var advice = diag && diag.advice ? diag.advice : null;
      var selected = diag.selectedLabel || cfg.apiProvider || '未知';
      var inferred = diag.inferredLabel || '';
      var endpointInfo = endpointFormatLabel(cfg.endpoint);
      var normalizedEndpoint = '';
      try { normalizedEndpoint = ApiClientModule.normalizeChatEndpoint(cfg.endpoint || ''); } catch (_) {}
      var localEndpoint = false;
      try { localEndpoint = ApiClientModule.isLocalEndpoint(normalizedEndpoint || cfg.endpoint); } catch (_) {}
      var hasKey = !!String(cfg.apiKey || '').trim();
      var probe = window.AIStoryGen.lastProviderProbe && window.AIStoryGen.lastProviderProbe.modelProbe;
      var compat = window.AIStoryGen.lastProviderProbe && window.AIStoryGen.lastProviderProbe.compatSummary;
      var probeMatchesCurrent = probe && String(probe.requestedModel || '') === String(cfg.model || '').trim();
      var lastErr = window.AIStoryGen.lastApiError || null;
      $health.empty();
      $health.append($('<div class="ai-provider-health-title"></div>').text('接口配置体检'));
      appendHealthRow($health, '服务商', selected + (inferred && inferred !== selected ? '（地址像：' + inferred + '）' : ''), inferred && inferred !== selected ? 'warn' : 'ok');
      appendHealthRow($health, 'API Key', localEndpoint ? (hasKey ? '本地接口，已填写 Key' : '本地接口，可不填 Key') : (hasKey ? '已填写' : '未填写'), (!localEndpoint && !hasKey) ? 'err' : 'ok');
      appendHealthRow($health, '端点格式', endpointInfo.text + (normalizedEndpoint ? ' → ' + normalizedEndpoint : ''), endpointInfo.level);
      appendHealthRow($health, '模型', cfg.model ? cfg.model : '未填写', cfg.model ? 'ok' : 'err');
      appendHealthRow($health, '模型列表', (function () {
        if (!probe) return '未测试';
        if (!probeMatchesCurrent) return '上次测试的是：' + (probe.requestedModel || '未知模型');
        if (probe.skipped) return '已跳过：' + (probe.reason || '服务商能力设置');
        if (probe.modelFound) return '已确认存在（共 ' + (probe.modelCount || 0) + ' 个模型）';
        if (probe.modelCount) return '未找到当前模型；候选 ' + (probe.candidates || []).slice(0, 3).join('，');
        return '已测试，但没有读到模型列表';
      })(), !probe ? 'warn' : (!probeMatchesCurrent ? 'warn' : (probe.modelFound || probe.skipped ? 'ok' : 'err')));
      appendHealthRow($health, '服务能力', '/models: ' + String(caps.supportsModelsEndpoint || 'unknown') + '；temperature: ' + (caps.supportsTemperature ? '支持' : '未知/不支持') + '；thinking: ' + (caps.supportsThinkingDisable ? '可禁用' : '无特殊处理'), 'info');
      if (caps.apiShape || caps.endpointStyle) {
        appendHealthRow($health, '接口形态', [caps.apiShape || '', caps.endpointStyle || ''].filter(Boolean).join(' / '), 'info');
      }
      if (caps.recommendedBaseEndpoint) {
        appendHealthRow($health, '推荐端点', caps.recommendedBaseEndpoint, 'info');
      }
      if (caps.modelNameHint) {
        appendHealthRow($health, '模型名规则', caps.modelNameHint, 'info');
      }
      if (caps.common404Hint) {
        appendHealthRow($health, '404 排查', caps.common404Hint, 'info');
      }
      if (advice && advice.endpointSuggestion) {
        appendHealthRow($health, '推荐修正端点', advice.endpointSuggestion, advice.severity === 'error' ? 'err' : 'warn');
      }
      if (advice && advice.modelSuggestions && advice.modelSuggestions.length) {
        appendHealthRow($health, '推荐模型', advice.modelSuggestions.slice(0, 4).join('，'), advice.severity === 'error' ? 'err' : 'warn');
      }
      if (diag.warnings && diag.warnings.length) {
        appendHealthRow($health, '注意', diag.warnings.slice(0, 2).join('；'), 'warn');
      }
      if (compat && String(compat.model || '') === String(cfg.model || '').trim()) {
        appendHealthRow($health, '兼容性结论', (compat.lines || []).slice(0, 3).join('；') || (compat.ok ? '可用' : '需要检查'), compat.severity === 'error' ? 'err' : (compat.severity === 'warning' ? 'warn' : 'ok'));
      } else {
        appendHealthRow($health, '兼容性结论', '未完成测试连接', 'warn');
      }
      appendHealthRow($health, '最近错误', lastErr ? ((lastErr.type || 'unknown') + ': ' + String(lastErr.message || '').slice(0, 180)) : '无', lastErr ? 'err' : 'ok');
      appendRequestLog($health);
    }

    function _buildCurrentErrorReportPreview() {
      var baseDebug = null;
      try {
        baseDebug = (window.AIStoryGen && typeof window.AIStoryGen.dumpDebugState === 'function')
          ? window.AIStoryGen.dumpDebugState()
          : {
            controllerSchemas: _getAiControllerDebugState(),
            settingsInjection: _getAiSettingsInjectionDebugState(),
            runtimeStats: _getAiRuntimeStatsDebugState()
          };
      } catch (e) {
        baseDebug = {
          previewError: String(e && e.message || e),
          controllerSchemas: _getAiControllerDebugState(),
          settingsInjection: _getAiSettingsInjectionDebugState(),
          runtimeStats: _getAiRuntimeStatsDebugState()
        };
      }
      return _buildAIErrorReport(baseDebug, { available: false, reason: 'preview not exported' });
    }

    function renderErrorReportSummaryPreview() {
      if (!$reportSummary || !$reportSummary.length) return;
      $reportSummary.empty();
      var summary = null;
      try {
        var report = _buildCurrentErrorReportPreview();
        summary = report && report.diagnosticSummary;
      } catch (e) {
        summary = {
          severity: 'warning',
          headline: '错误报告摘要暂时无法生成。',
          lines: ['[注意] ' + String(e && e.message || e).slice(0, 180)],
          actionLines: ['1. 先保存设置并重新打开设置页，再尝试导出错误报告。']
        };
      }
      var severity = String(summary && summary.severity || 'info').toLowerCase();
      if (!/^(ok|info|warning|error)$/.test(severity)) severity = 'info';
      $reportSummary
        .removeClass('ok info warning error')
        .addClass(severity);
      $reportSummary.append($('<div class="ai-error-report-summary-title"></div>').text('问题反馈 / 错误报告'));
      $reportSummary.append($('<div class="ai-error-report-summary-headline"></div>').text((summary && summary.headline) || '错误报告摘要暂无可用信息。'));
      var lines = (summary && Array.isArray(summary.lines) ? summary.lines.slice(1, 5) : []);
      if (lines.length) {
        var $lines = $('<ul class="ai-error-report-summary-lines"></ul>');
        lines.forEach(function (line) {
          $lines.append($('<li></li>').text(line));
        });
        $reportSummary.append($lines);
      }
      var actions = summary && Array.isArray(summary.actionLines) ? summary.actionLines.slice(0, 6) : [];
      if (actions.length) {
        var $actions = $('<ol class="ai-error-report-summary-actions"></ol>');
        actions.forEach(function (line) {
          $actions.append($('<li></li>').text(String(line || '').replace(/^\d+\.\s*/, '')));
        });
        $reportSummary.append($('<div class="ai-error-report-summary-subtitle"></div>').text('建议操作'));
        $reportSummary.append($actions);
      } else {
        $reportSummary.append($('<div class="ai-error-report-summary-empty"></div>').text('目前没有需要优先处理的建议操作。'));
      }
      $reportSummary.append($('<div class="ai-error-report-summary-note"></div>').text('导出的报告包含当前剧情内容和诊断摘要，不包含 API Key、完整存档或 localStorage 内容。'));
      if (_aiMountController && typeof _aiMountController.mountZone === 'function') {
        _aiMountController.mountZone('wovenrealm-error-report-settings', {
          mount: function () { return !!($reportSummary && $reportSummary.length); }
        });
      }
    }

    function formatModelProbeMessage(result) {
      result = result || {};
      var probe = result.modelProbe || {};
      var parts = [];
      if (result.message) parts.push(result.message);
      if (probe.modelCount) parts.push('模型列表共 ' + probe.modelCount + ' 个');
      if (probe.modelFound) parts.push('当前模型已匹配');
      if (probe.candidates && probe.candidates.length) {
        parts.push('可选候选：' + probe.candidates.slice(0, 6).join('，'));
      }
      if (result.compatSummary && result.compatSummary.providerAdvice && result.compatSummary.providerAdvice.lines && result.compatSummary.providerAdvice.lines.length) {
        parts.push('建议：' + result.compatSummary.providerAdvice.lines.slice(0, 2).join('；'));
      }
      return parts.join('；');
    }

    function clearModelProbeActions() {
      $probeActions.empty().hide();
    }

    function applyModelCandidate(candidate) {
      candidate = String(candidate || '').trim();
      if (!candidate || !inputs.model) return;
      var before = String(inputs.model.val() || '').trim();
      inputs.model.val(candidate);
      if (inputs.highQualityModel) {
        var hq = String(inputs.highQualityModel.val() || '').trim();
        if (!hq || hq === before) inputs.highQualityModel.val(candidate);
      }
      var next = collectFormCfg();
      saveCfg(next);
      $(document).trigger('AIStoryGen:configSaved', [next]);
      _refreshApiWarnBar();
      $msg.removeClass('err').addClass('ok').text('已使用候选模型并保存：' + candidate + '。可以再次点击“测试连接”确认。');
      clearModelProbeActions();
      renderProviderHealth();
    }

    function applyEndpointSuggestion(endpoint) {
      endpoint = String(endpoint || '').trim();
      if (!endpoint || !inputs.endpoint) return;
      var before = String(inputs.endpoint.val() || '').trim();
      inputs.endpoint.val(endpoint);
      if (inputs.highQualityEndpoint) {
        var hq = String(inputs.highQualityEndpoint.val() || '').trim();
        if (!hq || hq === before) inputs.highQualityEndpoint.val(endpoint);
      }
      var next = collectFormCfg();
      saveCfg(next);
      $(document).trigger('AIStoryGen:configSaved', [next]);
      _refreshApiWarnBar();
      $msg.removeClass('err').addClass('ok').text('已使用推荐端点并保存：' + endpoint + '。可以再次点击“测试连接”确认。');
      clearModelProbeActions();
      renderProviderHealth();
    }

    function renderModelProbeActions(result) {
      clearModelProbeActions();
      var probe = result && result.modelProbe;
      var advice = result && result.compatSummary && result.compatSummary.providerAdvice ? result.compatSummary.providerAdvice : null;
      if (!advice) {
        try { advice = ProviderPresetsModule.buildProviderAdvice(collectFormCfg(), result || {}, result && result.chatProbe); } catch (_) { advice = null; }
      }
      var candidates = [];
      if (probe && Array.isArray(probe.candidates)) candidates = candidates.concat(probe.candidates);
      if (advice && Array.isArray(advice.modelSuggestions)) candidates = candidates.concat(advice.modelSuggestions);
      candidates = candidates.filter(function (candidate, index) {
        candidate = String(candidate || '').trim();
        return candidate && candidates.map(function (x) { return String(x || '').trim(); }).indexOf(candidate) === index;
      }).slice(0, 8);
      var endpointSuggestion = advice && advice.endpointSuggestion ? String(advice.endpointSuggestion || '').trim() : '';
      if (!candidates.length && !endpointSuggestion) return;
      $probeActions.append($('<span class="ai-provider-probe-label"></span>').text('建议修正：'));
      if (endpointSuggestion) {
        var $epBtn = $('<button type="button" class="ai-cfg-btn ai-provider-endpoint-candidate"></button>');
        $epBtn.text('使用推荐端点');
        $epBtn.attr('title', endpointSuggestion);
        $epBtn.on('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          applyEndpointSuggestion(endpointSuggestion);
        });
        $probeActions.append($epBtn);
      }
      candidates.forEach(function (candidate) {
        var $btn = $('<button type="button" class="ai-cfg-btn ai-provider-model-candidate"></button>');
        $btn.text('使用 ' + candidate);
        $btn.on('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          applyModelCandidate(candidate);
        });
        $probeActions.append($btn);
      });
      $probeActions.show();
    }

    $btnSave.on('click', function () {
      var next = collectFormCfg();
      saveCfg(next);
      _applyUILayoutMode('config saved');
      $(document).trigger('AIStoryGen:configSaved', [next]);
      renderBarefootBuffStatus('config saved');
      renderExtraLongHairStatus();
      $msg.removeClass('err').addClass('ok').text('已保存。');
      _clearSexTargetPicker();
      if (!_isAISexModeEnabled(next)) _clearAISexModeUi();
      else {
        try { NativeSceneBridge.refreshControls('config saved'); } catch (_) {}
      }
      _refreshApiWarnBar();
      if (_isApiConfigured(next)) {
        $('#passages > .ai-user-msg, #passages > .ai-api-warn-bar').remove();
      }
      clearModelProbeActions();
      if (isDiagnosticTab) {
        renderProviderHealth();
        renderErrorReportSummaryPreview();
      }
    });

    $btnTest.on('click', function () {
      $msg.removeClass('err ok').text('正在诊断网络…');
      clearModelProbeActions();
      renderProviderHealth();
      var cfg = collectFormCfg();
      var providerProbeOptions = {};
      try { providerProbeOptions = ProviderPresetsModule.getNetworkProbeOptions(cfg, { href: location && location.href, origin: location && location.origin }); } catch (_) {}
      checkNetwork(cfg.endpoint, cfg.apiKey, function (result) {
        try { result.compatSummary = buildApiCompatSummary(result, null, cfg); } catch (_) {}
        try { window.AIStoryGen.lastProviderProbe = result; } catch (_) {}
        renderProviderHealth();
        renderErrorReportSummaryPreview();
        if (result.status === 'model_not_found') {
          $msg.removeClass('ok').addClass('err').text('网络诊断: ' + formatModelProbeMessage(result));
          renderModelProbeActions(result);
          return;
        }
        if (result.status === 'ok' || result.status === 'models_unavailable') {
          $msg.removeClass('err ok').text(result.status === 'models_unavailable' ? '模型列表接口不可用，正在直接测试聊天接口…' : (formatModelProbeMessage(result) || '网络正常') + '，正在测试 API 调用…');
          var originalCfg = loadCfg();
          saveCfg(cfg);
          callAI('Reply with the single word: OK').then(function (txt) {
            saveCfg(originalCfg);
            result.chatProbe = {
              ok: true,
              textFound: !!txt,
              textPreview: String(txt || '').slice(0, 120)
            };
            try { result.compatSummary = buildApiCompatSummary(result, result.chatProbe, cfg); } catch (_) {}
            try { window.AIStoryGen.lastProviderProbe = result; } catch (_) {}
            renderProviderHealth();
            renderErrorReportSummaryPreview();
            $msg.removeClass('err').addClass('ok').text((((result.compatSummary && result.compatSummary.lines && result.compatSummary.lines.join('；')) || formatModelProbeMessage(result) || '全部正常') + '；聊天接口正常 → ' + txt.slice(0, 60)).slice(0, 500));
          }).catch(function (e) {
            saveCfg(originalCfg);
            var aiErr = classifyError(e, cfg.language);
            result.chatProbe = {
              ok: false,
              errorType: aiErr.type || '',
              statusCode: aiErr.statusCode || 0,
              message: aiErr.message || String(e && e.message || e)
            };
            try { result.compatSummary = buildApiCompatSummary(result, result.chatProbe, cfg); } catch (_) {}
            try { window.AIStoryGen.lastProviderProbe = result; } catch (_) {}
            renderProviderHealth();
            renderErrorReportSummaryPreview();
            renderModelProbeActions(result);
            var compatMessage = (result.compatSummary && result.compatSummary.lines && result.compatSummary.lines.join('；')) || aiErr.message;
            $msg.removeClass('ok').addClass('err').text(('网络可达但 API 调用失败: ' + compatMessage).slice(0, 650));
          });
        } else {
          $msg.removeClass('ok').addClass('err').text('网络诊断: ' + result.message);
          renderModelProbeActions(result);
        }
      }, cfg.model, providerProbeOptions);
    });

    $btnReset.on('click', function () {
      if (!confirm('确定重置所有“织境空间”设置为默认值？')) return;
      saveCfg(Object.assign({}, DEFAULT_CFG));
      $(document).trigger('AIStoryGen:configSaved', [loadCfg()]);
      _clearSexTargetPicker();
      $msg.removeClass('err').addClass('ok').text('已重置。刷新页面查看默认设置。');
      if (isDiagnosticTab) {
        renderProviderHealth();
        renderErrorReportSummaryPreview();
      }
    });

    $btnReportFile.on('click', function () {
      $msg.removeClass('err ok').text('正在生成错误报告…');
      exportAIErrorReportToFile().then(function () {
        renderErrorReportSummaryPreview();
        $msg.removeClass('err').addClass('ok').text('错误报告已生成。手机端请查看浏览器下载/Download 文件夹，或复制页面中的报告文本。');
      }, function (e) {
        renderErrorReportSummaryPreview();
        $msg.removeClass('ok').addClass('err').text('错误报告生成失败：' + String(e && e.message || e).slice(0, 120));
      });
    });

    $btnReportClip.on('click', function () {
      $msg.removeClass('err ok').text('正在复制错误报告到剪贴板…');
      exportAIErrorReportToClipboard().then(function () {
        renderErrorReportSummaryPreview();
        $msg.removeClass('err').addClass('ok').text('错误报告已准备好。若手机剪贴板为空，请复制页面中的报告文本。');
      }, function (e) {
        renderErrorReportSummaryPreview();
        $msg.removeClass('ok').addClass('err').text('错误报告复制失败：' + String(e && e.message || e).slice(0, 120));
      });
    });

    $btnReportIssue.on('click', function () {
      $msg.removeClass('err ok').text('正在生成反馈模板…');
      exportAIErrorIssueTemplateToClipboard().then(function () {
        renderErrorReportSummaryPreview();
        $msg.removeClass('err').addClass('ok').text('反馈模板已准备好。若手机剪贴板为空，请复制页面中的模板文本。');
      }, function (e) {
        renderErrorReportSummaryPreview();
        $msg.removeClass('ok').addClass('err').text('反馈模板生成失败：' + String(e && e.message || e).slice(0, 120));
      });
    });

    $btnPixelDiag.on('click', function () {
      var api = window.AIPixelGen;
      if (!api || typeof api.copyCurrentImagePromptDiagnosticToClipboard !== 'function') {
        $msg.removeClass('ok').addClass('err').text('生图诊断不可用：绘图模块尚未加载。');
        return;
      }
      $msg.removeClass('err ok').text('正在复制生图诊断…');
      api.copyCurrentImagePromptDiagnosticToClipboard('scene').then(function () {
        renderErrorReportSummaryPreview();
        $msg.removeClass('err').addClass('ok').text('生图诊断已复制。');
      }, function (e) {
        var text = e && e.diagnosticText ? e.diagnosticText : '';
        if (text) {
          _showAITextCopyFallback('生图诊断文本', '复制失败，请长按下方文本手动复制。', text, e && e.message || e);
          $msg.removeClass('ok').addClass('err').text('剪贴板不可用，请手动复制生图诊断文本。');
        } else {
          $msg.removeClass('ok').addClass('err').text('生图诊断生成失败：' + String(e && e.message || e).slice(0, 120));
        }
      });
    });

    $btnClearModCache.on('click', function () {
      if (!confirm('确定清理 ModLoader 中织境空间相关缓存？这不会删除存档、API 设置或其他 Mod。清理后请刷新页面，或重新加载最新版 zip。')) return;
      $msg.removeClass('err ok').text('正在清理织境空间旧缓存...');
      _clearAiModLoaderCache({ force: true, reason: 'manual settings button' }).then(function (result) {
        var removed = result && result.removed ? result.removed : [];
        renderErrorReportSummaryPreview();
        if (result && result.ok) {
          $msg.removeClass('err').addClass('ok').text(removed.length
            ? ('已清理旧缓存：' + removed.join(', ') + '。请刷新页面或重新加载最新版 zip。')
            : '没有发现需要清理的织境空间缓存。');
        } else {
          $msg.removeClass('ok').addClass('err').text('清理缓存失败：' + String(result && result.reason || 'unknown').slice(0, 120));
        }
      }, function (e) {
        renderErrorReportSummaryPreview();
        $msg.removeClass('ok').addClass('err').text('清理缓存失败：' + String(e && e.message || e).slice(0, 120));
      });
    });

    var $actions = $('<div class="ai-cfg-actions"></div>');
    $actions.append($btnSave).append($btnReset);
    if (isDiagnosticTab) $actions.append($btnTest);

    var $diagnostics = $('<div class="ai-cfg-diagnostics"></div>');
    var $reportBlock = $('<div class="ai-cfg-debug-block ai-cfg-report-block"></div>');
    var $reportActions = $('<div class="ai-cfg-debug-actions"></div>');
    $reportActions.append($btnReportFile).append($btnReportClip).append($btnReportIssue).append($btnPixelDiag).append($btnClearModCache);
    $reportBlock
      .append($reportSummary)
      .append($reportActions);
    var $healthBlock = $('<div class="ai-cfg-debug-block ai-cfg-health-block"></div>');
    $healthBlock.append($health).append($probeActions);
    $diagnostics.append($reportBlock).append($healthBlock);
    try {
      var intimateAddon = window.AIStoryGenIntimateAddon;
      if (intimateAddon && typeof intimateAddon.renderDiagnosticSummary === 'function') {
        var addonDiagHost = document.createElement('div');
        addonDiagHost.className = 'ai-cfg-debug-block ai-cfg-intimate-addon-block';
        intimateAddon.renderDiagnosticSummary(addonDiagHost, { embedded: true });
        $diagnostics.append(addonDiagHost);
      }
    } catch (addonDiagErr) {
      try { console.warn('[AIStoryGen] intimate addon diagnostic render failed', addonDiagErr); } catch (_) {}
    }

    if ($form.children().length) $root.append($form);
    if ($barefootStatus) {
      renderBarefootBuffStatus('settings opened');
      $root.append($barefootStatus);
    }
    if ($extraLongHairStatus) {
      renderExtraLongHairStatus();
      $root.append($extraLongHairStatus);
    }
    $root.append($actions).append($msg);
    if (isDiagnosticTab) $root.append($diagnostics);
    ['apiProvider', 'endpoint', 'model', 'highQualityEndpoint', 'highQualityModel', 'apiKey'].forEach(function (key) {
      if (inputs[key]) inputs[key].on('change keyup input', renderProviderHealth);
    });
    if (isDiagnosticTab) {
      renderProviderHealth();
      renderErrorReportSummaryPreview();
    }
    if (activeConfigTab === 'story') {
      var $version = $('<div class="ai-cfg-version"></div>').text('织境空间 v' + (window.AIStoryGen.VERSION || 'unknown'));
      $root.append($version);
    }

    // ── AI Memory viewer (always visible) ──


    $container.empty().append($root);
  }

  function buildPromptConfigForm($container, isSettingsTab) {
    return buildConfigForm($container, isSettingsTab, 'prompt');
  }

  function buildExtrasConfigForm($container, isSettingsTab) {
    return buildConfigForm($container, isSettingsTab, 'extras');
  }

  function buildDiagnosticConfigForm($container, isSettingsTab) {
    return buildConfigForm($container, isSettingsTab, 'diagnostic');
  }

  function _isAIPixelEnabledCfg(cfg) {
    if (AI_PIXEL_TEMP_DISABLED) return false;
    return Number((cfg || loadCfg()).aiPixelEnabled == null ? DEFAULT_CFG.aiPixelEnabled : (cfg || loadCfg()).aiPixelEnabled) !== 0;
  }

  const ConfigUI = ConfigUIModule.create({
    $: window.jQuery || window.$,
    loadCfg: loadCfg,
    isPixelEnabled: _isAIPixelEnabledCfg,
    renderStoryConfig: buildConfigForm,
    renderExtrasConfig: buildExtrasConfigForm,
    renderPromptConfig: buildPromptConfigForm,
    renderDiagnosticConfig: buildDiagnosticConfigForm,
    getPixelGen: function () { return window.AIPixelGen || null; }
  });
  window.AIStoryGen.ConfigUI = ConfigUI;

  function buildUnifiedConfigForm($container, isSettingsTab, defaultTab) {
    return ConfigUI.renderUnifiedConfigForm($container, isSettingsTab, defaultTab);
  }

  /** Render short-term and long-term memory entries into $container. */
  function renderMemoryEntries($container, $msg) {
    return MemoryUI.renderMemoryEntries($container, $msg);
  }

  /** Send all recentBuf entries to AI for summarization, replace buffer with result */
  async function compressMemory($container, $msg) {
    return MemoryUI.compressMemory($container, $msg);
  }

  window.AIStoryGen.buildStoryConfigForm = buildConfigForm;
  window.AIStoryGen.buildExtrasConfigForm = buildExtrasConfigForm;
  window.AIStoryGen.buildPromptConfigForm = buildPromptConfigForm;
  window.AIStoryGen.buildConfigForm = buildUnifiedConfigForm;

  // ---------- 7. Settings 页标签注入 ----------
  var aiTabActive = false;
  var _aiMountController = MountControllerModule.create({
    getDomState: function (scope) {
      if (scope === 'overlay') {
        var overlay = document.getElementById('customOverlay');
        return {
          hasCustomOverlay: !!overlay,
          overlayCandidate: overlay ? _isOptionsOverlayCandidate(overlay) : null,
          hasOverlayTabs: !!document.getElementById('overlayTabs'),
          hasOverlayContent: !!document.getElementById('customOverlayContent'),
          hasNativeOptionsTab: MountControllerModule.hasNativeTab ? MountControllerModule.hasNativeTab('overlay', document) : _hasNativeOptionsSettingsTab(),
          hasOptionsTab: !!document.getElementById('aiOptionsTab'),
          hasFallbackEntry: !!document.getElementById('aiOptionsFallbackEntry'),
          hasFallbackPanel: !!document.getElementById('aiOptionsFallbackPanel'),
          fallbackPanelHasForm: $('#aiOptionsFallbackPanel .ai-unified-settings').length > 0
        };
      }
      return {
        hasSettingsOptions: !!document.getElementById('settingsOptions'),
        hasSettingsDiv: !!document.getElementById('settingsDiv'),
        hasNativeSettingsTab: MountControllerModule.hasNativeTab ? MountControllerModule.hasNativeTab('main', document) : !!document.getElementById('aiStoryGenSettingsNativeTab'),
        hasSettingsTab: !!document.getElementById('aiSettingsTab'),
        hasFallbackEntry: !!document.getElementById('aiSettingsFallbackEntry'),
        hasFallbackPanel: !!document.getElementById('aiSettingsFallbackPanel'),
        fallbackPanelHasForm: $('#aiSettingsFallbackPanel .ai-unified-settings').length > 0
      };
    }
  });
  window.AIStoryGen.mountController = _aiMountController;
  var _aiSettingsInjectionDiagnostics = _aiMountController.getDiagnostics();

  if (_aiMountController && typeof _aiMountController.registerZone === 'function') {
    _aiMountController.registerZone('wovenrealm-settings-tab', {
      zone: 'Settings',
      scope: 'main',
      kind: 'settings-tab',
      label: '织境空间',
      priority: 80,
      selector: '#aiStoryGenSettingsNativeTab, #aiSettingsTab',
      targetSelector: '#settingsOptions'
    });
    _aiMountController.registerZone('wovenrealm-options-tab', {
      zone: 'OptionsOverlay',
      scope: 'overlay',
      kind: 'options-tab',
      label: '织境空间',
      priority: 80,
      selector: '#aiStoryGenOptionsNativeTab, #aiOptionsTab',
      targetSelector: '#overlayTabs, #customOverlayContent'
    });
    _aiMountController.registerZone('wovenrealm-error-report-settings', {
      zone: 'Settings',
      scope: 'main',
      kind: 'error-report',
      label: '错误报告',
      priority: 50,
      selector: '.ai-error-report-summary-panel, .ai-cfg-report-block',
      targetSelector: '.ai-unified-settings, #settingsDiv, #customOverlayContent'
    });
    _aiMountController.registerZone('wovenrealm-story-panels', {
      zone: 'AfterLinks',
      scope: 'main',
      kind: 'story-panel',
      label: 'AI 剧情面板',
      priority: 40,
      selector: '.ai-choices, .ai-choices-end, .ai-manual-choice-trigger, .ai-back-to-game, .ai-item-use-panel, .ai-memory-inline',
      targetSelector: '#passages'
    });
    _aiMountController.registerZone('wovenrealm-pixel-panel', {
      zone: 'AfterLinks',
      scope: 'main',
      kind: 'pixel-panel',
      label: 'AI 生图面板',
      priority: 30,
      selector: '.apg-ai-assist, [data-ai-pixel-panel="1"], .aipixel-panel, #aipixel-panel',
      targetSelector: '#passages'
    });
    _aiMountController.registerZone('wovenrealm-mobile-stats-refresh', {
      zone: 'MobileStats',
      scope: 'main',
      kind: 'runtime-refresh',
      label: '移动端状态刷新',
      priority: 20,
      selector: '#mobileStats, #stats',
      targetSelector: '#mobileStats, #stats'
    });
    _aiMountController.registerZone('wovenrealm-passage-notices', {
      zone: 'AfterLinks',
      scope: 'main',
      kind: 'passage-notice',
      label: '页面提示',
      priority: 25,
      selector: '.ai-user-msg, .ai-api-warn-bar',
      targetSelector: '#passages'
    });
    _aiMountController.registerZone('wovenrealm-runtime-notices', {
      zone: 'RuntimeOverlay',
      scope: 'main',
      kind: 'runtime-notice',
      label: '运行时提示',
      priority: 10,
      selector: '#ai-time-indicator',
      targetSelector: 'body'
    });
  }

  function _recordAiSettingsInjection(scope, status, reason) {
    if (_aiMountController && typeof _aiMountController.record === 'function') {
      _aiMountController.record(scope, status, reason);
      _aiSettingsInjectionDiagnostics = _aiMountController.getDiagnostics();
      return;
    }
    scope = scope === 'overlay' ? 'overlay' : 'main';
    _aiSettingsInjectionDiagnostics[scope] = {
      status: String(status || ''),
      reason: String(reason || '').slice(0, 160),
      at: Date.now()
    };
  }

  function _planAiSettingsMount(scope, opts) {
    if (_aiMountController && typeof _aiMountController.plan === 'function') {
      var mountPlan = _aiMountController.plan(scope, opts || {});
      _aiSettingsInjectionDiagnostics = _aiMountController.getDiagnostics();
      return mountPlan;
    }
    return { action: 'tab', status: 'tab-inserted', reason: scope === 'overlay' ? 'native overlay tab bar' : 'native Settings tab container' };
  }

  function _executeAiSettingsMountPlan(scope, mountPlan, handlers) {
    if (MountControllerModule && typeof MountControllerModule.executeMountPlan === 'function') {
      var ok = MountControllerModule.executeMountPlan(scope, _aiMountController, mountPlan, handlers || {});
      if (_aiMountController && typeof _aiMountController.getDiagnostics === 'function') {
        _aiSettingsInjectionDiagnostics = _aiMountController.getDiagnostics();
      }
      return ok;
    }
    if (mountPlan && mountPlan.action === 'ready') return true;
    if (mountPlan && mountPlan.action === 'fallback' && handlers && typeof handlers.onFallback === 'function') return !!handlers.onFallback(mountPlan, scope);
    if (mountPlan && mountPlan.action === 'skip' && handlers && typeof handlers.onSkip === 'function') return !!handlers.onSkip(mountPlan, scope);
    if (handlers && typeof handlers.onTab === 'function') return !!handlers.onTab(mountPlan, scope);
    return false;
  }

  function _hasNativeOptionsSettingsTab() {
    return MountControllerModule.hasNativeTab
      ? MountControllerModule.hasNativeTab('overlay', document)
      : !!document.getElementById('aiStoryGenOptionsNativeTab');
  }

  function _getSettingsPassageRoot() {
    return $('#passages .passage').last();
  }

  function _renderUnifiedSettingsInto($target) {
    if (!$target || !$target.length) return false;
    if (MountControllerModule && typeof MountControllerModule.renderSettingsPanel === 'function') {
      return MountControllerModule.renderSettingsPanel('main', {
        $: $,
        $target: $target,
        render: function ($grid) { buildUnifiedConfigForm($grid, true); }
      }, {
        status: 'settings-rendered',
        reason: 'unified settings render'
      });
    }
    var $wrap = $('<div class="solidBorderContainer settings-container"><div class="settingsGrid"></div></div>');
    $target.empty().append($wrap);
    buildUnifiedConfigForm($wrap.find('.settingsGrid'), true);
    return true;
  }

  function _ensureAISettingsFallbackEntry(reason) {
    return MountControllerModule.ensureFallbackEntry('main', {
      $: $,
      canMount: function () {
        var title = (typeof State !== 'undefined' && State.passage) || '';
        return title === 'Settings';
      },
      getTarget: _getSettingsPassageRoot,
      setActive: function () { aiTabActive = true; },
      hidePanels: _hideAiPanelsForSettings,
      render: _renderUnifiedSettingsInto,
      record: _recordAiSettingsInjection
    }, reason);
  }

  function injectAISettingsTab(active) {
    if ($('#aiStoryGenSettingsNativeTab').length) {
      _recordAiSettingsInjection('main', 'ready', 'native Settings widget tab already mounted');
      return true;
    }
    var mountPlan = _planAiSettingsMount('main');
    return _executeAiSettingsMountPlan('main', mountPlan, {
      zoneId: 'wovenrealm-settings-tab',
      onReady: function () { return true; },
      onFallback: function (plan) {
        _ensureAISettingsFallbackEntry(plan.reason);
        return false;
      },
      onTab: function (plan) {
        var $settingsOptions = $('#settingsOptions');
        var $container = $('#settingsOptions .containerStart');
        if (!$container.length) $container = $settingsOptions;
        if (!$container.length) {
          _ensureAISettingsFallbackEntry('missing #settingsOptions container');
          _recordAiSettingsInjection('main', 'fallback', 'missing #settingsOptions container');
          return false;
        }
        if ($('#aiSettingsTab').length) return true;
        return MountControllerModule.insertTab('main', {
            $: $,
            getContainer: function () { return $container; },
            record: _recordAiSettingsInjection,
            onClick: function ($tab) {
              aiTabActive = true;
              _hideAiPanelsForSettings();

              $('#settingsOptions .containerStart > div, #settingsOptions > div')
                .removeClass('gold buttonStartSelected')
                .addClass('buttonStart');
              $tab.addClass('gold buttonStartSelected').removeClass('buttonStart');

              var $settingsDiv = $('#settingsDiv');
              if ($settingsDiv.length) {
                _renderUnifiedSettingsInto($settingsDiv);
              } else {
                _ensureAISettingsFallbackEntry('missing #settingsDiv');
                _renderUnifiedSettingsInto($('#aiSettingsFallbackPanel'));
              }
              _recordAiSettingsInjection('main', 'opened', $settingsDiv.length ? 'settingsDiv' : 'fallback panel');
            }
          }, {
            id: 'aiSettingsTab',
            label: '织境空间',
            active: !!active,
            status: plan.status || 'tab-inserted',
            reason: plan.reason || 'native Settings tab container'
          });
      }
    });
  }

  function setupSettingsObservers() {
    var passagesEl = document.getElementById('passages');
    if (!passagesEl) return;
    _disconnectAISettingsObserver();

    window._aiSettingsPassageObserver = new MutationObserver(function () {
      var title = (typeof State !== 'undefined' && State.passage) || '';
      if (title !== 'Settings') {
        _disconnectAISettingsObserver();
        return;
      }
      var optsEl = document.getElementById('settingsOptions');
      if (!optsEl) {
        _ensureAISettingsFallbackEntry('observer missing #settingsOptions');
        return;
      }
      if (!$('#aiStoryGenSettingsNativeTab, #aiSettingsTab').length) injectAISettingsTab(aiTabActive);
      if (aiTabActive && !$('#settingsDiv .ai-unified-settings, #aiSettingsFallbackPanel .ai-unified-settings').length) {
        aiTabActive = false;
      }
      if (aiTabActive && $('#settingsDiv .ai-unified-settings, #aiSettingsFallbackPanel .ai-unified-settings').length) {
        $('#aiSettingsTab').removeClass('buttonStart').addClass('gold buttonStartSelected');
      }
    });
    window._aiSettingsPassageObserver.observe(passagesEl, { childList: true, subtree: true });
  }

  function _disconnectAISettingsObserver() {
    if (!window._aiSettingsPassageObserver) return false;
    window._aiSettingsPassageObserver.disconnect();
    window._aiSettingsPassageObserver = null;
    return true;
  }

  function scheduleAISettingsTabInjection(active) {
    _aiMountController.schedule('main', {
      reason: 'settings tab retry',
      attempts: 20,
      retryDelay: 150,
      immediate: true,
      extra: { active: !!active },
      attempt: function () { return injectAISettingsTab(active); },
      onExhausted: function () { _ensureAISettingsFallbackEntry('settings injection retries exhausted'); }
    });
  }

  // Hook into Settings passage (use :passagedisplay — fires AFTER DOM is ready)
  $(document).on(':passagedisplay', function (ev) {
    var title = (ev && ev.passage && ev.passage.title) || (typeof State !== 'undefined' && State.passage) || '';
    if (title !== 'Settings') {
      _disconnectAISettingsObserver();
      _restoreAiPanelsAfterSettings();
      return;
    }

    aiTabActive = false;
    setTimeout(function () {
      var currentTitle = (typeof State !== 'undefined' && State.passage) || '';
      if (currentTitle !== 'Settings') return;
      setupSettingsObservers();
      scheduleAISettingsTabInjection(false);
    }, 150);
  });

  // --- 7b. Options Overlay 标签注入（侧边栏 Options 按钮打开的浮层） ---
  var optionsTabActive = false;

  function _getOptionsOverlayContentTarget() {
    var $content = $('#customOverlayContent');
    if ($content.length) return $content.first();
    $content = $('#customOverlay .customOverlayContent, #customOverlay .overlayContent, #customOverlay .overlay-content, #customOverlay [data-overlay-content]').first();
    return $content;
  }

  function _isOptionsOverlayCandidate(overlay) {
    if (!overlay) return false;
    if (overlay.classList && overlay.classList.contains('hidden')) return false;
    var dataOverlay = String(overlay.getAttribute('data-overlay') || '').trim().toLowerCase();
    if (/^(options|settings)$/.test(dataOverlay)) return true;
    if (dataOverlay && !/^(options|settings)$/.test(dataOverlay)) return false;

    var text = '';
    try {
      text = [
        $('#customOverlayTitle').text() || '',
        $('#overlayTabs').text() || '',
        overlay.getAttribute('aria-label') || '',
        overlay.getAttribute('data-title') || ''
      ].join(' ');
    } catch (_) {
      text = '';
    }
    return /(options|settings|game settings|选项|设置|游戏设置)/i.test(text);
  }

  function injectOptionsTab() {
    var overlay = document.getElementById('customOverlay');
    if (_hasNativeOptionsSettingsTab()) {
      _recordAiSettingsInjection('overlay', 'ready', 'native Options widget tab already mounted');
      return true;
    }
    var mountPlan = _planAiSettingsMount('overlay');
    return _executeAiSettingsMountPlan('overlay', mountPlan, {
      zoneId: 'wovenrealm-options-tab',
      onReady: function () { return true; },
      onSkip: function () { return false; },
      onFallback: function (plan) {
        injectOptionsFallbackEntry(plan.reason);
        return false;
      },
      onTab: function (plan) {
        if (overlay && !_isOptionsOverlayCandidate(overlay)) return false;
        var $tabBar = $('#overlayTabs');
        if (!$tabBar.length) {
          injectOptionsFallbackEntry('missing #overlayTabs');
          _recordAiSettingsInjection('overlay', 'fallback', 'missing #overlayTabs');
          return false;
        }
        if (_hasNativeOptionsSettingsTab() || $('#aiOptionsTab').length) return true;
        return MountControllerModule.insertTab('overlay', {
            $: $,
            getContainer: function () { return $tabBar; },
            getBefore: function () { return $('#overlayTabs .customOverlayClose'); },
            record: _recordAiSettingsInjection,
            onClick: function ($btn) {
              optionsTabActive = true;
              _hideAiPanelsForSettings();

              $('#overlayTabs button').removeClass('tab-selected');
              $btn.addClass('tab-selected');

              var $content = _getOptionsOverlayContentTarget();
              if (!$content.length) {
                _recordAiSettingsInjection('overlay', 'failed', 'missing overlay content');
                return;
              }
              var $wrap = $('<div class="settingsGrid"></div>');
              $content.empty().append($wrap);
              buildUnifiedConfigForm($wrap, true);
              _recordAiSettingsInjection('overlay', 'opened', 'overlay tab');
            }
          }, {
            id: 'aiOptionsTab',
            label: '织境空间',
            status: plan.status || 'tab-inserted',
            reason: plan.reason || 'native overlay tab bar'
          });
      }
    });
  }

  function injectOptionsFallbackEntry(reason) {
    var overlay = document.getElementById('customOverlay');
    if (overlay && !_isOptionsOverlayCandidate(overlay)) return false;
    return MountControllerModule.ensureFallbackEntry('overlay', {
      $: $,
      getTarget: _getOptionsOverlayContentTarget,
      setActive: function () { optionsTabActive = true; },
      hidePanels: _hideAiPanelsForSettings,
      clearNativeSelection: function () { $('#overlayTabs button').removeClass('tab-selected'); },
      render: _renderUnifiedSettingsInto,
      record: _recordAiSettingsInjection
    }, reason);
  }

  function scheduleOptionsTabInjection(delay, attempts) {
    _aiMountController.schedule('overlay', {
      reason: 'options tab retry',
      delay: delay || 0,
      attempts: attempts == null ? 8 : attempts,
      retryDelay: 150,
      attempt: function () { return injectOptionsTab(); }
    });
  }

  function scheduleOptionsTabInjectionIfOpen(delay, attempts) {
    setTimeout(function () {
      var overlay = document.getElementById('customOverlay');
      if (!document.getElementById('overlayTabs')) {
        injectOptionsFallbackEntry('schedule missing #overlayTabs');
        return;
      }
      if (overlay && !_isOptionsOverlayCandidate(overlay)) return;
      scheduleOptionsTabInjection(0, attempts);
    }, delay || 0);
  }

  function setupOptionsOverlayObserver() {
    var overlay = document.getElementById('customOverlay');
    if (!overlay) {
      window._aiOptionsObservedOverlay = null;
      return;
    }
    if (window._aiOptionsObservedOverlay === overlay
      && window._aiOptionsAttrObserver
      && window._aiOptionsClassObserver) return;
    if (window._aiOptionsAttrObserver) window._aiOptionsAttrObserver.disconnect();
    if (window._aiOptionsClassObserver) window._aiOptionsClassObserver.disconnect();
    if (window._aiOptionsContentObserver) window._aiOptionsContentObserver.disconnect();
    window._aiOptionsObservedOverlay = overlay;

    // Watch data-overlay attribute — changes when a different overlay type opens
    var attrObserver = window._aiOptionsAttrObserver = new MutationObserver(function (mutations) {
      for (var i = 0; i < mutations.length; i++) {
        var m = mutations[i];
        if (m.type === 'attributes' && m.attributeName === 'data-overlay') {
          if (_isOptionsOverlayCandidate(overlay)) {
            optionsTabActive = false;
            // Delay: SugarCube widgets need time to render tabs
            scheduleOptionsTabInjection(250, 10);
          }
        }
      }
    });
    attrObserver.observe(overlay, { attributes: true, attributeFilter: ['data-overlay'] });

    // Watch class changes — overlay becomes visible when "hidden" class is removed
    var classObserver = window._aiOptionsClassObserver = new MutationObserver(function (mutations) {
      for (var i = 0; i < mutations.length; i++) {
        if (mutations[i].type === 'attributes' && mutations[i].attributeName === 'class') {
          if (overlay.classList.contains('hidden')) {
            optionsTabActive = false;
            _restoreAiPanelsAfterSettings();
            _clearSexTargetPicker();
          }
          if (_isOptionsOverlayCandidate(overlay)) {
            scheduleOptionsTabInjection(300, 10);
          }
        }
      }
    });
    classObserver.observe(overlay, { attributes: true, attributeFilter: ['class'] });

    // Watch #customOverlayContent — when native tabs replace its content,
    // deactivate our tab highlight if our form is no longer there.
    var contentEl = document.getElementById('customOverlayContent');
    if (contentEl) {
      var contentObserver = window._aiOptionsContentObserver = new MutationObserver(function () {
        scheduleOptionsTabInjectionIfOpen(50, 4);
        if (optionsTabActive && !$('#customOverlayContent .ai-unified-settings, #aiOptionsFallbackPanel .ai-unified-settings').length) {
          optionsTabActive = false;
          $('#aiOptionsTab').removeClass('tab-selected');
        }
      });
      contentObserver.observe(contentEl, { childList: true });
    }
  }

  // Kick off overlay observer after the DOM settles
  var _aiGlobalDomMaintenanceIgnoreUntil = 0;
  var _aiGlobalDomMaintenanceStats = {
    observerBatches: 0,
    ownedMutationSkips: 0,
    cooldownSkips: 0,
    scheduleRequests: 0,
    runs: 0
  };
  var _AI_GLOBAL_DOM_OWNED_SELECTOR = [
    '.ai-replaced-content',
    '.ai-narrative-wrap',
    '.ai-choices',
    '.ai-choices-end',
    '.ai-manual-choice-trigger',
    '.ai-inventory-wrap',
    '.ai-unified-settings',
    '.ai-injected-row',
    '.ai-gen-loading',
    '.ai-api-warn-bar',
    '.ai-user-message',
    '.ai-time-indicator',
    '.apg-ai-assist',
    '.apg-pixel-placeholder',
    '.apg-pixel-result',
    '.apg-pixel-controls',
    '.apg-pixel-spinner'
  ].join(', ');

  function _isAiOwnedGlobalDomNode(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.matches && node.matches(_AI_GLOBAL_DOM_OWNED_SELECTOR)) return true;
    return !!(node.closest && node.closest(_AI_GLOBAL_DOM_OWNED_SELECTOR));
  }

  function _isAiOwnedGlobalDomMutation(mutation) {
    var target = mutation && mutation.target;
    if (target && target.closest && target.closest(_AI_GLOBAL_DOM_OWNED_SELECTOR)) return true;
    var added = mutation && mutation.addedNodes || [];
    var removed = mutation && mutation.removedNodes || [];
    if (!added.length && !removed.length) return false;
    for (var i = 0; i < added.length; i++) {
      if (!_isAiOwnedGlobalDomNode(added[i])) return false;
    }
    for (var j = 0; j < removed.length; j++) {
      if (!_isAiOwnedGlobalDomNode(removed[j])) return false;
    }
    return true;
  }

  function _scheduleAiGlobalDomMaintenance() {
    _aiGlobalDomMaintenanceStats.scheduleRequests += 1;
    if (window._aiGlobalDomMaintenanceTimer) clearTimeout(window._aiGlobalDomMaintenanceTimer);
    window._aiGlobalDomMaintenanceTimer = setTimeout(function () {
      window._aiGlobalDomMaintenanceTimer = null;
      _aiGlobalDomMaintenanceStats.runs += 1;
      _aiGlobalDomMaintenanceIgnoreUntil = Date.now() + 250;
      _cleanupInlineAiInventorySections();
      if (document.getElementById('customOverlay')) setupOptionsOverlayObserver();
      scheduleOptionsTabInjectionIfOpen(50, 4);
      scheduleAiInventoryTabInjection(80);
      _scheduleAIChoicePixelReposition(80);
      scheduleEnsureAutoChoices('global observer', 1200);
    }, 100);
  }

  setTimeout(function () {
    _applyUILayoutMode('startup');
    try { $(window).off('resize.aiUILayoutMode orientationchange.aiUILayoutMode'); } catch (_) {}
    try { $(window).on('resize.aiUILayoutMode orientationchange.aiUILayoutMode', function () { _applyUILayoutMode('viewport change'); }); } catch (_) {}
    setupOptionsOverlayObserver();
    scheduleOptionsTabInjectionIfOpen(50, 6);
    scheduleAiInventoryTabInjection(800);
    // Retry in case the overlay element isn't in the DOM yet
    setTimeout(function () {
      if (!document.getElementById('customOverlay')) return;
      if (!window._aiOptionsObserverReady) {
        window._aiOptionsObserverReady = true;
        setupOptionsOverlayObserver();
        scheduleOptionsTabInjectionIfOpen(50, 6);
        scheduleAiInventoryTabInjection(50);
      }
    }, 2000);
  }, 500);

  setTimeout(function () {
    _installAIChoiceOrderObserver();
    if (window._aiOptionsGlobalObserver) window._aiOptionsGlobalObserver.disconnect();
    window._aiOptionsGlobalObserver = new MutationObserver(function (mutations) {
      _aiGlobalDomMaintenanceStats.observerBatches += 1;
      if (Date.now() < _aiGlobalDomMaintenanceIgnoreUntil) {
        _aiGlobalDomMaintenanceStats.cooldownSkips += 1;
        return;
      }
      var ownedOnly = true;
      for (var i = 0; i < mutations.length; i++) {
        if (!_isAiOwnedGlobalDomMutation(mutations[i])) {
          ownedOnly = false;
          break;
        }
      }
      if (ownedOnly) {
        _aiGlobalDomMaintenanceStats.ownedMutationSkips += 1;
        return;
      }
      _scheduleAiGlobalDomMaintenance();
    });
    if (document.body) {
      window._aiOptionsGlobalObserver.observe(document.body, { childList: true, subtree: true });
    }
  }, 500);

  setTimeout(function () {
    scheduleEnsureAutoChoices('startup', 800);
  }, 1200);

  // ---------- 7c. AI 选项生成 ----------

  function _isWolfCaveNativePageText(text) {
    return /Wolf Cave|wolf cave|\u72fc\u6d1e|\u5c0f\u72fc\u7fa4|\u6d1e\u53e3|\u5c0f\u6eaa|\u6eaa\u6c34|cave mouth|creek|stream/i.test(String(text || ''));
  }

  function _nativePageGroundingProfile(nativePageText, cfg) {
    var text = String(nativePageText || '');
    var zh = !cfg || cfg.language === 'zh';
    if (/\u4f60\u5728\u68ee\u6797\u6df1\u5904|\u6df1\u5165\u68ee\u6797|\u641c\u7d22\u8fd9\u7247\u533a\u57df|\u5f80\u57ce\u91cc\u8d70|You are deep in the forest|deep in the forest/i.test(text)) {
      return {
        key: 'forest',
        forbid: /(\u5c0f\u6eaa|\u6eaa\u8fb9|\u6eaa\u6d41|\u6d1e\u53e3|\u6d1e\u7a74\u6df1\u5904|\u72fc\u5d3d|\u72fc\u5d3d\u4eec|\u5c0f\u72fc\u8eab\u8fb9|\u5e72\u8349\u5806|\u83dc\u5730|\u79cd\u690d\u5703|\u8611\u83c7\u6876|\u95e8\u5eca|\u6cc9\u6c34|creek|stream|cave mouth|inside the cave|wolf cubs?|pups?|straw pile|garden beds?|mushroom buckets?|porch|spring)/i,
        fallbacks: zh ? [
          '\u6cbf\u7740\u6811\u5e72\u95f4\u7684\u9634\u5f71\u5feb\u901f\u524d\u8fdb (0:05)',
          '\u653e\u6162\u811a\u6b65\uff0c\u7559\u610f\u6811\u6797\u6df1\u5904\u7684\u58f0\u54cd (0:10)',
          '\u8e72\u4e0b\u68c0\u67e5\u5730\u9762\u7684\u811a\u5370\u548c\u88ab\u7ffb\u52a8\u7684\u6ce5\u571f (0:10)',
          '\u5728\u9644\u8fd1\u7684\u704c\u6728\u548c\u843d\u53f6\u95f4\u8c28\u614e\u641c\u7d22 (0:30)',
          '\u8fa8\u8ba4\u6765\u65f6\u7684\u65b9\u5411\uff0c\u51b3\u5b9a\u63a5\u4e0b\u6765\u53bb\u54ea\u91cc (0:05)'
        ] : [
          'Move quickly between the shadowed tree trunks (0:05)',
          'Slow down and listen to the sounds deeper in the forest (0:10)',
          'Crouch and check the footprints and disturbed earth (0:10)',
          'Search carefully through the nearby brush and fallen leaves (0:30)',
          'Work out the direction you came from and choose where to go next (0:05)'
        ]
      };
    }
    if (_isWolfCaveNativePageText(text)) {
      return {
        key: 'wolf_cave',
        forbid: /(Eden|\u4f0a\u7538|\u5c0f\u5c4b|\u95e8\u5eca|\u6cc9\u6c34|\u83dc\u5730|\u83dc\u56ed|\u79cd\u690d\u5703|\u5e84\u7a3c|\u4f5c\u7269|\u8611\u83c7\u6876|garden beds?|vegetable|crop|crops|mushroom buckets?|porch|spring)/i,
        fallbacks: zh ? [
          '\u5728\u5c0f\u6eaa\u8fb9\u5750\u4e0b\uff0c\u542c\u6d41\u6c34\u548c\u6d1e\u53e3\u5916\u7684\u52a8\u9759 (0:10)',
          '\u89c2\u5bdf\u5c0f\u72fc\u7fa4\u671b\u5411\u6811\u6797\u7684\u65b9\u5411 (0:10)',
          '\u68c0\u67e5\u6d1e\u53e3\u9644\u8fd1\u7684\u811a\u5370\u548c\u6ce5\u571f\u75d5\u8ff9 (0:10)',
          '\u8d70\u5230\u6d1e\u7a74\u8fb9\u7f18\uff0c\u67e5\u770b\u72fc\u7a9d\u91cc\u662f\u5426\u7559\u4e0b\u4ec0\u4e48\u7269\u54c1 (0:15)',
          '\u6cbf\u7740\u7a7a\u5730\u8fb9\u7f18\u5de1\u89c6\uff0c\u786e\u8ba4\u5468\u56f4\u662f\u5426\u5b89\u5168 (0:15)'
        ] : [
          'Sit beside the creek and listen to the water and the cave mouth (0:10)',
          'Watch the wolf cubs stare anxiously toward the forest (0:10)',
          'Check the footprints and disturbed earth near the cave entrance (0:10)',
          'Step to the cave edge and look for anything left in the wolf den (0:15)',
          'Circle the clearing edge and make sure the area is safe (0:15)'
        ]
      };
    }
    if (/\u4f0a\u7538\u5c0f\u5c4b\u5916\u7684\u7a7a\u5730|\u4f0a\u7538\u7684\u5e84\u7a3c|\u8611\u83c7\u6876|\u5c0f\u5c4b\u540e\u9762|Eden Clearing|Eden cabin/i.test(text)) {
      return {
        key: 'eden_clearing',
        forbid: /(\u72fc\u6d1e|\u5c0f\u72fc|\u72fc\u5d3d|\u6d1e\u53e3|\u6d1e\u7a74\u6df1\u5904|wolf cave|wolf cubs?|cave mouth|inside the cave|manor|laboratory|\u5b85\u90b8|\u5b9e\u9a8c\u5ba4)/i,
        fallbacks: zh ? [
          '\u8d70\u5230\u79cd\u690d\u5703\u8fb9\uff0c\u68c0\u67e5\u4f5c\u7269\u7684\u72b6\u51b5 (0:10)',
          '\u5728\u95e8\u5eca\u4e0b\u5750\u4e00\u4f1a\uff0c\u8ba9\u7d27\u7ef7\u7684\u8eab\u4f53\u653e\u677e (0:15)',
          '\u53bb\u5c0f\u5c4b\u540e\u7684\u6cc9\u6c34\u8fb9\u6d17\u6d17\u624b\u548c\u8138 (0:10)',
          '\u68c0\u67e5\u8611\u83c7\u6876\u9644\u8fd1\u662f\u5426\u8fd8\u6709\u53ef\u7528\u7684\u8611\u83c7 (0:15)',
          '\u6cbf\u7740\u7a7a\u5730\u8fb9\u7f18\u770b\u770b\u6811\u6797\u91cc\u7684\u52a8\u9759 (0:10)'
        ] : [
          'Step to the garden bed and check the crops (0:10)',
          'Sit beneath the porch and let your body relax (0:15)',
          'Go to the spring behind the cabin and wash your hands and face (0:10)',
          'Check near the mushroom buckets for anything useful (0:15)',
          'Walk the clearing edge and listen to the forest (0:10)'
        ]
      };
    }
    return null;
  }

  function _choiceContradictsCurrentNativePage(choiceText, nativePageText) {
    var choice = String(choiceText || '');
    if (!choice) return false;
    var profile = _nativePageGroundingProfile(nativePageText);
    return !!(profile && profile.forbid && profile.forbid.test(choice));
  }

  function _nativePageGroundedFallbackChoices(nativePageText, cfg) {
    var profile = _nativePageGroundingProfile(nativePageText, cfg);
    return profile && Array.isArray(profile.fallbacks) ? profile.fallbacks : [];
  }

  function _groundGeneratedChoicesToNativePage(choices, nativePageText, cfg) {
    choices = Array.isArray(choices) ? choices : [];
    if (!_nativePageGroundingProfile(nativePageText, cfg)) return choices;
    var grounded = [];
    var seen = {};
    function addChoice(choice) {
      choice = String(choice || '').replace(/\s+/g, ' ').trim();
      if (!choice || seen[choice]) return;
      if (_choiceContradictsCurrentNativePage(choice, nativePageText)) return;
      seen[choice] = true;
      grounded.push(choice);
    }
    choices.forEach(addChoice);
    _nativePageGroundedFallbackChoices(nativePageText, cfg).forEach(addChoice);
    return grounded.slice(0, 5);
  }

  async function generateChoices(cfg, hint, signal, targetLabel, targetPassage) {
    var state = buildState(cfg);
    var currentAiStoryBlock = buildCurrentAiStoryBlock();
    var nativePageText = _getCurrentNativePageText(1400);
    var nativePageBlock = nativePageText
      ? '<current_native_page role="authoritative_visible_original_game_page">\n' + nativePageText + '\n</current_native_page>\n\n'
      : '';
    var includeStoryMemoryForChoices = !!(_aiReplaceActive || currentAiStoryBlock);
    var scene = buildScene();
    var choiceQuery = [
      nativePageText,
      _extractCurrentAiStoryText(),
      hint || '',
      targetLabel || '',
      targetPassage || '',
      buildScenePromptText(scene)
    ].join(' ');
    var recentBlock = buildRecentBlock({
      includeStoryMemory: includeStoryMemoryForChoices,
      query: choiceQuery
    }) + currentAiStoryBlock + nativePageBlock + buildNativeContextAuthorityBlock();
    var worldContextBlock = buildWorldContextBlock(state, scene, cfg);
    var sceneBlock = buildScenePromptText(scene);
    var dangerHint = scene.dangerLevel === 'dangerous'
      ? (cfg.language === 'zh' ? '• 场景氛围：危险区→警觉/逃跑/避险的选项' : '• Atmosphere: dangerous→alert/flee/avoid-threat options')
      : scene.dangerLevel === 'wilderness'
      ? (cfg.language === 'zh' ? '• 场景氛围：野外→探索/生存/暴露的选项' : '• Atmosphere: wilderness→explore/survive/exposure options')
      : scene.dangerLevel === 'night'
      ? (cfg.language === 'zh' ? '• 场景氛围：深夜→隐秘/阴影/不安的选项' : '• Atmosphere: night→stealthy/shadowy/uneasy options')
      : scene.dangerLevel === 'safe'
      ? (cfg.language === 'zh' ? '• 场景氛围：安全区→闲逛/社交/放松的选项' : '• Atmosphere: safe→stroll/social/relax options')
      : '';
    var gameLinks = getGameLinks();
    var gameLinksBlock = gameLinks.length
      ? '<game_links>\n当前可前往的地点：' + gameLinks.join('、') + '\n</game_links>\n'
      : '';

    // Build progression hint when in AI replace mode (player clicked [AI] on a location link)
    var progressionHint = '';
    if (targetPassage && targetLabel) {
      progressionHint = cfg.language === 'zh'
        ? '★ 重要：玩家正在前往「' + targetLabel + '」的途中。请确保至少第 1 个选项直接导向该目的地（如"继续前往' + targetLabel + '"），其余选项为途中的随机遭遇。'
        : '★ IMPORTANT: The player is on the way to "' + targetLabel + '". Ensure at least option #1 directly leads there ("Continue to ' + targetLabel + '"), other options are encounters along the way.';
    }
    var storyFollowHint = '';
    if (Number(cfg.aiChoiceMode || 0) === 1) {
      storyFollowHint = currentAiStoryBlock
        ? (cfg.language === 'zh'
          ? '★ 选项生成模式：剧情后续。必须优先读取 <current_ai_story> 的最后状态来生成选项；如果正文已经离开旧地点或到达新地点，选项必须承接新地点和新状态，不要回到旧目的地。'
          : '★ Choice mode: story-follow. Prioritize the final state in <current_ai_story>; if the story has left the old place or arrived somewhere new, choices must continue from the new place/state.')
        : (cfg.language === 'zh'
          ? '★ 选项生成模式：剧情后续。但当前没有仍挂在页面上的 AI 正文，因此必须以 <current_native_page>、<scene> 和 <world_context> 为准，不得续写旧记忆地点。'
          : '★ Choice mode: story-follow. There is no current AI story still mounted on the page, so follow <current_native_page>, <scene>, and <world_context>; do not continue an old memory location.');
    }

    var promptLines;
    if (cfg.language === 'zh') {
      promptLines = [
        _buildPromptStateBlock(state, choiceQuery, 'choices'),
        '',
        '<scene>',
        sceneBlock,
        '</scene>',
        '',
        worldContextBlock,
        recentBlock,
        buildKnownNpcNamesBlock(choiceQuery),
        gameLinksBlock,
        _buildNarrativeDataPolicyBlock(cfg),
        '<instruction>',
        '当前页面权威顺序：<current_native_page>、<scene>、<world_context> 和 <game_links> 是当前原版页面事实；<recent_story> 与 <long_term_memory> 只作背景，不得把选项带回旧地点、旧房间或旧 NPC 场景。',
        '生成 5 个玩家此刻可以主动执行的下一步行动。每项必须从当前可见地点、当前正文末态或原版可见链接出发。',
        '<state> 只用于排除不可能动作；不要为了利用状态数据而强行加入金钱、房租、声望、任务、技能或变身话题。',
        '只有 <state>.presentNpcDetails、<state>.nearbyNpcs 或当前页面明确点名的 NPC 才能作为在场互动对象；不得宣称离场 NPC 正在某处做某事。',
        '可以提供“去查看某人/某地”的玩家行动，但不得在选项中提前写出查看结果或离场人物的当前行为。',
        '若当前动作确实涉及身体不适、服装、金钱、技能、任务或物品，可据当前状态生成合理行动；否则不要主动引入这些机制。',
        dangerHint ? dangerHint : '',
        '这些选项是游戏原版内容的补充，应是玩家可执行的动作，不是已经发生的随机事件或旁白结论。',
        '不得重复 <current_ai_story> 里刚刚已经完成的动作；每个选项都必须让姿势、关注对象、地点或明确意图至少有一项发生推进。',
        '如果 <game_links> 没有对应原版入口，不要提供会直接完成换装/脱衣、正式入睡或醒来、购买付款、消耗物品、进入战斗或任务结算的选项；可以改写为准备、查看、接近或尝试。',
        '每个选项一句简短中文，第二人称现在时，符合本游戏文风。',
        '选项应多样化，必须基于当前地点，可引用 <game_links> 中可前往的地点。',
        storyFollowHint ? storyFollowHint : '',
        progressionHint ? progressionHint : '',
        hint ? '侧重点：' + hint : '',
        '只返回 JSON 数组：["选项1 (0:05)", "选项2 (0:10)", ...]。每个选项末尾必须标注时间消耗(H:MM)，与原版游戏一致。不要额外说明。',
        '禁止输出正文、标题、编号列表、[STATS]、[AI_META]、[AI_EVENT]、HTML 或任何非 JSON 数组内容。',
      ];
    } else {
      promptLines = [
        _buildPromptStateBlock(state, choiceQuery, 'choices'),
        '',
        '<scene>',
        sceneBlock,
        '</scene>',
        '',
        worldContextBlock,
        recentBlock,
        buildKnownNpcNamesBlock(choiceQuery),
        gameLinksBlock,
        _buildNarrativeDataPolicyBlock(cfg),
        '<instruction>',
        'Current-page authority: <current_native_page>, <scene>, <world_context>, and <game_links> are the current original-game facts. <recent_story> and <long_term_memory> are background only; never move choices back to an old location, room, or NPC scene from memory.',
        'Generate 5 player actions that can be performed now. Every option must start from the current visible location, the final state of the current story, or a visible native-game link.',
        '<state> only rules out impossible actions. Do not force money, rent, fame, quests, skills, or transformations into choices merely because the data exists.',
        'Only NPCs in <state>.presentNpcDetails, <state>.nearbyNpcs, or explicitly named on the current page may be treated as present interaction targets.',
        'You may offer going to check on an off-screen NPC or place, but never pre-declare what that NPC is currently doing or the result of checking.',
        'Use body, clothing, money, skill, quest, or item facts only when the current action actually concerns them.',
        dangerHint ? dangerHint : '',
        'These enrich the original game as executable player actions, not already-resolved random events or narration conclusions.',
        'Do not repeat an action already completed in <current_ai_story>. Every choice must advance the pose, focus, location, or explicit intent.',
        'If <game_links> has no matching native entry, do not offer an option that directly completes changing/removing equipment, formal sleep/wake, a purchase/payment, item consumption, combat entry, or quest settlement; offer preparation, checking, approaching, or attempting instead.',
        'Each option ONE short sentence, second person present tense. Varied styles, grounded in location.',
        'May reference destinations from <game_links>. Do not repeat the recent story text.',
        storyFollowHint ? storyFollowHint : '',
        progressionHint ? progressionHint : '',
        hint ? 'Focus on: ' + hint : '',
        'Return ONLY a JSON array: ["choice1 (0:05)", "choice2 (0:10)", ...]. Each choice MUST end with time annotation (H:MM) like the original game. No extra text.',
        'Never output prose, headings, numbered lists, [STATS], [AI_META], [AI_EVENT], HTML, or anything outside the JSON array.',
      ];
    }
    var prompt = promptLines.filter(function (l) { return l !== ''; }).join('\n');

    var messages = [
      { role: 'system', content: buildChoiceSystem(cfg) },
      { role: 'user', content: prompt },
    ];
    var content;
    var choiceTimeoutMs = 45000;
    var choiceTimeoutId = null;
    try {
      var request = _fetchAI(messages, { temperature: 0.95, max_tokens: 350, signal: signal, purpose: 'choices' });
      var timeout = new Promise(function (_, reject) {
        choiceTimeoutId = setTimeout(function () {
          var timeoutErr = new Error(cfg.language === 'zh' ? '连接超时 (45秒)' : 'Request timed out (45s)');
          timeoutErr.name = 'AbortError';
          reject(timeoutErr);
        }, choiceTimeoutMs);
      });
      content = await Promise.race([request, timeout]);
    } catch (e) {
      throw classifyError(e, cfg.language);
    } finally {
      if (choiceTimeoutId) clearTimeout(choiceTimeoutId);
    }

    var parsedChoices = parseChoiceArray(content);
    if (parsedChoices) return _groundGeneratedChoicesToNativePage(parsedChoices, nativePageText, cfg);

    var fallbackChoices = StoryRuntimeModule.extractFallbackChoices(content, { maxChoices: 5 });
    if (fallbackChoices) return _groundGeneratedChoicesToNativePage(fallbackChoices, nativePageText, cfg);

    throw new Error(cfg.language === 'zh' ? 'AI 返回的选项无法解析' : 'Could not parse choices from AI response');
  }

  function normalizeChoiceArray(value) {
    var cfg = loadCfg();
    return StoryRuntimeModule.normalizeChoiceArray(value, {
      maxChoices: 5,
      localizeChoice: cfg.language === 'zh' ? _localizeNamesInText : null
    });
  }

  function parseChoiceArray(content) {
    return StoryRuntimeModule.parseChoiceArray(content, {
      normalizeChoiceArray: normalizeChoiceArray
    });
  }

  function _getCurrentAiNarrativeTextForLocation() {
    try {
      var $scope = $('#passages .ai-narrative-section, #passages .ai-replaced-content .ai-narrative-section').last();
      if (!$scope.length) $scope = $('#passages .ai-narrative-wrap, #passages .ai-replaced-content').last();
      if (!$scope.length) return '';
      var $clone = $scope.clone();
      $clone.find([
        'script',
        'style',
        'a',
        'button',
        'input',
        'select',
        'textarea',
        '.ai-narrative-toolbar',
        '.ai-pickup-line',
        '.ai-stats-line',
        '.ai-choices',
        '.ai-choices-list',
        '.ai-choice-row',
        '.ai-choices-custom',
        '.ai-bottom-actions',
        '.ai-manual-arrive-panel',
        '.apg-pixel-placeholder',
        '.apg-pixel-controls'
      ].join(',')).remove();
      return String($clone.text() || '').replace(/\s+/g, ' ').trim();
    } catch (e) {
      return '';
    }
  }

  function _refreshLocationFromCurrentAiNarrative() {
    var text = _getCurrentAiNarrativeTextForLocation();
    if (!text) return false;
    if (_inferPriorityLocationFromText(text)) return true;
    if (_lastAiEventSuppressesLocationFallback()) return false;
    return inferLocationFromText(_lastChoiceText || '', text);
  }

  function _repairAiArriveButtonsFromCurrentNarrative(reason) {
    try {
      if (!_refreshLocationFromCurrentAiNarrative()) return false;
      var cfg = loadCfg();
      var statePassage = (typeof State !== 'undefined' && State.passage ? State.passage : '');
      var arriveModel = _aiLocationTools.buildArriveButtonModel({
        language: cfg.language,
        replaceActive: _aiReplaceActive,
        replaceOriginalEventMode: _aiReplaceOriginalEventMode,
        locationArrived: _aiLocationArrived,
        currentLocationPassage: _aiCurrentLocationPassage,
        currentLocationLabel: _aiCurrentLocationLabel,
        replaceTargetPassage: _aiReplaceTargetPassage,
        replaceTargetLabel: _aiReplaceTargetLabel,
        statePassage: statePassage
      });
      var rawPassage = arriveModel.rawPassage || statePassage;
      var destLabel = arriveModel.destLabel || rawPassage;
      var arriveTxt = arriveModel.text || (cfg.language === 'zh' ? '📍 返回原版章节' : '📍 Return to original passage');
      $('#passages .ai-back-link[data-ai-arrive-raw], #passages .ai-back-link[data-ai-arrive-label]').each(function () {
        $(this)
          .text(arriveTxt)
          .attr('data-ai-arrive-raw', rawPassage || '')
          .attr('data-ai-arrive-label', destLabel || '')
          .attr('title', rawPassage || '');
      });
      _recordAiReturnButtonModel(arriveModel, {
        source: reason || 'repair-ai-arrive-button',
        replaceActive: _aiReplaceActive,
        replaceOriginalEventMode: _aiReplaceOriginalEventMode,
        locationArrived: _aiLocationArrived,
        statePassage: statePassage
      });
      return true;
    } catch (e) {
      try { console.warn('[AIStoryGen] repair arrive button failed:', e); } catch (_) {}
      return false;
    }
  }

  function _scheduleAiArriveButtonRepair(reason, delay) {
    setTimeout(function () {
      _repairAiArriveButtonsFromCurrentNarrative(reason);
    }, Number(delay || 80));
  }

  function renderChoices($container, choices, cfg) {
    _clearAIUserMessage();
    _clearSexTargetPicker();
    _removeMalformedAIEventDom();
    _refreshLocationFromCurrentAiNarrative();
    // Save for potential re-render on cancel
    _lastChoicesData = { choices: choices, cfg: cfg };

    var $list = $('<div class="ai-choices-list"></div>');
    var $customInput = null;

    function showLoadingAndCall(promptText, opts) {
      opts = opts || {};
      var actionToken = _createAiRoundActionToken();
      function rollbackChoiceAction(reason) {
        _rollbackAiRoundAction(actionToken, reason);
      }
      function commitChoiceAction() {
        _commitAiRoundAction(actionToken);
      }
      _autoChoicesBusy = true;  // prevent :passagedisplay from nuking this panel
      var controller = new AbortController();
      _currentAbortController = controller;
      $list.find('button, input, textarea').prop('disabled', true);
      var extraStoryHint = (!opts.fromCustom && $customInput && $customInput.length)
        ? String($customInput.val() || '').replace(/\s+/g, ' ').trim()
        : '';
      if (extraStoryHint) {
        promptText += cfg.language === 'zh'
          ? '\n\u73a9\u5bb6\u8865\u5145\u4e0b\u4e00\u6bb5\u5267\u60c5\u8981\u6c42\uff1a' + extraStoryHint
          : '\nPlayer extra instruction for the next story: ' + extraStoryHint;
      }

      var $loadingRow = $('<div class="ai-choices-loading-row"></div>');
      var loadingTxt = cfg.language === 'zh' ? 'AI 剧情生成中…' : 'AI generating…';
      var $out = $('<span class="ai-gen ai-gen-loading"></span>').text(loadingTxt);
      var cancelTxt = cfg.language === 'zh' ? '× 取消' : '× Cancel';
      var $cancelBtn = $('<button class="ai-cancel-btn"></button>').text(cancelTxt);
      var regenTxt = cfg.language === 'zh' ? '重新生成' : 'Regen';
      var $regenBtn = $('<button class="ai-regen-btn"></button>').text(regenTxt);
      var returnTxt = cfg.language === 'zh' ? '返回' : 'Return';
      var $returnBtn = $('<button class="ai-return-btn"></button>').text(returnTxt);

      function safeAbort() {
        if (_currentAbortController) { _currentAbortController.abort(); _currentAbortController = null; }
      }

      function restoreChoices() {
        safeAbort();
        rollbackChoiceAction('cancel');
        if (_lastChoicesData) {
          $container.empty().removeClass('ai-choices-result');
          renderChoices($container, _lastChoicesData.choices, _lastChoicesData.cfg);
          _scheduleAIPixelAssistRefresh('choices restored', 300);
        }
      }

      function regenerateChoices() {
        safeAbort();
        rollbackChoiceAction('regenerate choices');
        var retryController = new AbortController();
        _currentAbortController = retryController;
        $container.empty();
        var ldrTxt = cfg.language === 'zh' ? 'AI 正在生成选项…' : 'AI generating choices…';
        var $ldr = $('<div class="ai-choices-loading ai-gen-loading"></div>').text(ldrTxt);
        $container.append($ldr);
        generateChoices(cfg, '', retryController.signal).then(function (newChoices) {
          if (_currentAbortController === retryController) _currentAbortController = null;
          $ldr.remove();
          renderChoices($container, newChoices, cfg);
          _scheduleAIPixelAssistRefresh('choices regenerated', 300);
        }).catch(function (e) {
          if (e && e.name === 'AbortError') return;
          if (_currentAbortController === retryController) _currentAbortController = null;
          $ldr.removeClass('ai-gen-loading').addClass('ai-choices-error');
          $ldr.text((cfg.language === 'zh' ? '选项生成失败: ' : 'Choice error: ') + (e && e.message ? e.message : e));
          _appendChoiceRetryButton($container, cfg, regenerateChoices);
        });
      }

      $cancelBtn.on('click', restoreChoices);
      $regenBtn.on('click', regenerateChoices);
      $returnBtn.on('click', function () {
        safeAbort();
        rollbackChoiceAction('return button');
        _releaseAutoChoicesBusy('return button');
        if (_tryAiBackward()) {
          return;
        }
        var returnEngine = _getNativeEngine();
        if (returnEngine && returnEngine.play) {
          returnEngine.play('Start');
        }
      });

      $loadingRow.append($out).append($cancelBtn).append($regenBtn).append($returnBtn);
      $container.empty().addClass('ai-choices-result').append($loadingRow);

      try {
        _prepareAiRoundAction(actionToken, { timeCost: Number(opts.timeCost || 0) });
      } catch (_) {}

      // Build full context prompt — not just bare choice text
      var choiceState = buildState(cfg);
      var choiceScene = buildScene();
      var choiceWorldContextBlock = buildWorldContextBlock(choiceState, choiceScene, cfg);
      var aiItemsToUse = _takePendingAiItemUses();
      var aiItemUseBlock = _buildAiItemUseBlock(aiItemsToUse, cfg, promptText);
      var narrativeQuery = [
        promptText,
        _getCurrentNativePageText(1400),
        _extractCurrentAiStoryText(),
        buildScenePromptText(choiceScene)
      ].join(' ');
      var fullPrompt = cfg.language === 'zh'
        ? [
            _buildPromptStateBlock(choiceState, narrativeQuery, 'choice-result'),
            '',
            choiceWorldContextBlock,
            buildRecentBlock({ query: narrativeQuery }),
            buildCurrentAiStoryBlock(),
            aiItemUseBlock,
            buildNativeContextAuthorityBlock(),
            buildKnownNpcNamesBlock(narrativeQuery),
            _buildNarrativeDataPolicyBlock(cfg),
            '<scene>',
            buildScenePromptText(choiceScene),
            '</scene>',
            '',
            '<instruction>',
            '玩家做出了选择：「' + promptText + '」',
            '这条选择是本轮即时结果的最高优先级锚点。正文必须直接描写玩家完成或尝试这个行动的过程和结果；不得改写成近期剧情里另一个未被选择的行动，也不得无缘由跳到另一处地点或互动。',
            '基于玩家当前状态、近期剧情和场景氛围，生成这个选择带来的即时结果叙事（1-2个短段）。',
            '第二人称现在时，符合游戏风格。叙事应自然衔接 <recent_story> 中的上下文。',
            '不要回顾整段路线，不要列出账户余额、精确属性、任务计数或“状态数据”；只有本轮选择直接涉及这些机制时，才描写其可见结果。',
            '不得编造未在场 NPC 此刻正在做什么。长期记忆只用于保持关系与已发生事件的连续性，不代表人物当前在场。',
            '穿着装备、正式睡眠/醒来、战斗、交易、物品消耗等原版机制状态仍以 <state> 和当前原版页面为准。没有原版可执行入口或已校验事务字段时，只描写准备、尝试或临时动作，不得在正文中宣称机制状态已被改写。',
            '中文正文里不要直接写 arousal/stress/pain/trauma/control/lust 等英文内部变量名；如需描述状态，请写“兴奋/压力/疼痛/创伤/自控/欲望”等自然中文。',
            '如果这个行动会导致状态变化，请添加 [STATS: ...] 标记。',
            '如果玩家获得明确的非金钱物品，请添加 [ITEMS: 道具名 x1; 道具名 x2] 标记。该标记会进入日志库存的 AI道具 区。',
            'ITEMS 里只能写简短物品名，不要把门开着/房间状态/环境描述/完整句子写成道具。',
            '如果玩家获得或失去金钱，正文必须明确写出具体金额和原因，并在 AI_EVENT 的 moneyChange 写同一 signed pence，例如 +250 或 -8000。不要用 [STATS: money+...] 表示金钱；金额不明确、只是进入挑战或猜测奖励/花费时不要写金钱变化。',
            'Use only allowed non-money stat keys from the AI runtime stat schema: ' + _formatAiRuntimeNonMoneyStatAllowlist() + '.',
            'If the player gains a concrete non-money item, append [ITEMS: item name x1; item name x2].',
            'If writing Chinese narration, ITEMS names must also be Chinese short names. Do not output English item names.',
            'ITEMS must be short concrete inventory names only. Do not output feelings, moods, doors, open/closed states, rooms, scenery, or full sentence descriptions as items.',
            buildKnownPlacesBlock(),
            buildLocationResponseFormatBlock('current'),
            PromptBuilderModule.buildLocationMarkerRule('zh'),
            buildAIEventResponseFormatBlock(),
            '</instruction>',
          ].join('\n')
        : [
            _buildPromptStateBlock(choiceState, narrativeQuery, 'choice-result'),
            '',
            choiceWorldContextBlock,
            buildRecentBlock({ query: narrativeQuery }),
            buildCurrentAiStoryBlock(),
            aiItemUseBlock,
            buildNativeContextAuthorityBlock(),
            buildKnownNpcNamesBlock(narrativeQuery),
            _buildNarrativeDataPolicyBlock(cfg),
            '<scene>',
            buildScenePromptText(choiceScene),
            '</scene>',
            '',
            '<instruction>',
            'The player chose: "' + promptText + '"',
            'This choice is the highest-priority anchor for the immediate outcome. Directly depict the player attempting or completing this action; do not substitute an unchosen recent action or jump to a different location or interaction without a clear causal transition.',
            'Based on current state, recent story, and atmosphere, generate the immediate outcome narrative (1-2 paragraphs).',
            'Second person present tense, game style. Naturally connect with <recent_story> context.',
            'Do not recap the whole route or list account balances, exact stats, quest counters, or "state data". Narrate mechanics only when the selected action directly involves them.',
            'Do not invent what off-screen NPCs are currently doing. Long-term memory preserves continuity but does not prove current presence.',
            'Worn equipment, formal sleep/wake state, combat, transactions, and item consumption remain native mechanical state. Without an executable native entry or validated transaction field, narrate only preparation, an attempt, or a temporary action; do not claim the mechanical state was rewritten.',
            'If this action would change stats, append [STATS: ...] markers.',
            'If the player gains or loses money, the prose must clearly state the exact amount and reason, and AI_EVENT moneyChange must contain the same signed pence amount such as +250 or -8000. Do not use [STATS: money+...] for money; if the amount is unclear, or you are only guessing a challenge reward/cost, do not write a money change.',
            'Use only allowed non-money stat keys from the AI runtime stat schema: ' + _formatAiRuntimeNonMoneyStatAllowlist() + '.',
            'If the player gains a concrete non-money item, append [ITEMS: item name x1; item name x2].',
            'If writing Chinese narration, ITEMS names must also be Chinese short names. Do not output English item names or abstract feelings as items.',
            buildKnownPlacesBlock(),
            buildLocationResponseFormatBlock('current'),
            PromptBuilderModule.buildLocationMarkerRule('en'),
            buildAIEventResponseFormatBlock(),
            '</instruction>',
          ].join('\n');

      _lastNarrativePrompt = fullPrompt;

      callAI(fullPrompt, controller.signal, { storyStyle: true, structuredPrompt: true, purpose: 'story-choice-result' }).then(function (text) {
        _currentAbortController = null;
        $container.remove(); // clean up old container before advanceWithNarrative regenerates
        _lastChoiceText = promptText;
        try {
          advanceWithNarrative(text);
          commitChoiceAction();
        } catch (e) {
          console.error('[AIStoryGen] advanceWithNarrative crashed:', e);
          rollbackChoiceAction('advanceWithNarrative crashed');
          _autoChoicesBusy = false;
          // Try to recover: re-inject choices on the current passage
          autoInjectChoices(typeof State !== 'undefined' ? State.passage : '');
        }
      }).catch(function (err) {
        if (err && err.name === 'AbortError') {
          rollbackChoiceAction('abort');
          _autoChoicesBusy = false;
          return;
        }
        _currentAbortController = null;
        rollbackChoiceAction('AI request failed');
        _autoChoicesBusy = false;
        $out.removeClass('ai-gen-loading').addClass('ai-gen-error');
        $out.text((cfg.language === 'zh' ? '[生成失败] ' : '[Error] ') + (err && err.message ? err.message : err));
        // Re-enable recovery buttons
        $loadingRow.find('button').prop('disabled', false);
        _appendChoiceRetryButton($container, cfg, regenerateChoices);
      });
    }

    // Bottom action buttons: refresh choices + arrive at current location
    // (built first, appended last — so it always sits at the very bottom)
    if (_aiReplaceActive) _refreshOriginalEventModeFromLink();
    var $bottomActions = $('<div class="ai-back-to-game"></div>');

    // "刷新选项" — re-generate AI choices without producing new narrative
    (function () {
      var refreshTxt = cfg.language === 'zh' ? '🔄 刷新选项' : '🔄 Refresh';
      var $refreshBtn = $('<a class="ai-back-link" href="javascript:void(0)"></a>').text(refreshTxt);
      $refreshBtn.on('click', function () {
        _clearSexTargetPicker();
        $container.empty();
        var ldrTxt = cfg.language === 'zh' ? 'AI 正在刷新选项…' : 'AI refreshing choices…';
        var $ldr = $('<div class="ai-choices-loading ai-gen-loading"></div>').text(ldrTxt);
        $container.append($ldr);
        generateChoices(cfg, '', new AbortController().signal).then(function (newChoices) {
          $ldr.remove();
          renderChoices($container, newChoices, cfg);
          _scheduleAIPixelAssistRefresh('choices refreshed', 300);
        }).catch(function (e) {
          if (e && e.name === 'AbortError') return;
          $ldr.removeClass('ai-gen-loading').addClass('ai-choices-error');
          $ldr.text((cfg.language === 'zh' ? '刷新失败: ' : 'Refresh error: ') + (e && e.message ? e.message : e));
          _appendChoiceRetryButton($container, cfg, function () { $refreshBtn.trigger('click'); });
        });
      });
      // Hidden from the bottom toolbar; recovery refresh remains available on failure panels.
    })();

    (function () {
      var useTxt = cfg.language === 'zh' ? '\u4f7f\u7528\u9053\u5177' : 'Use items';
      var $useBtn = $('<a class="ai-back-link" href="javascript:void(0)"></a>').text(useTxt);
      _updateAiItemUseButtonLabel($useBtn, cfg);
      $useBtn.on('click', function () {
        _openAiItemUseDialog($useBtn, cfg);
      });
      $bottomActions.append($useBtn);
    })();

    // "到达XX" — show current/native location while keeping AI features active.
    (function () {
      var statePassage = (typeof State !== 'undefined' && State.passage ? State.passage : '');
      var arriveModel = _aiLocationTools.buildArriveButtonModel({
        language: cfg.language,
        replaceActive: _aiReplaceActive,
        replaceOriginalEventMode: _aiReplaceOriginalEventMode,
        locationArrived: _aiLocationArrived,
        currentLocationPassage: _aiCurrentLocationPassage,
        currentLocationLabel: _aiCurrentLocationLabel,
        replaceTargetPassage: _aiReplaceTargetPassage,
        replaceTargetLabel: _aiReplaceTargetLabel,
        statePassage: statePassage
      });
      var rawPassage = arriveModel.rawPassage || statePassage;
      var destLabel = arriveModel.destLabel || rawPassage;
      var arriveTxt = arriveModel.text || (cfg.language === 'zh' ? '📍 返回原版章节' : '📍 Return to original passage');
      _recordAiReturnButtonModel(arriveModel, {
        source: 'choice-bottom-actions',
        replaceActive: _aiReplaceActive,
        replaceOriginalEventMode: _aiReplaceOriginalEventMode,
        locationArrived: _aiLocationArrived,
        statePassage: statePassage
      });
      var $arriveBtn = $('<a class="ai-back-link" href="javascript:void(0)"></a>')
        .text(arriveTxt)
        .attr('data-ai-arrive-raw', rawPassage || '')
        .attr('data-ai-arrive-label', destLabel || '');
      $arriveBtn.on('click', function () {
        var clickRawPassage = _normalizePassageName($arriveBtn.attr('data-ai-arrive-raw') || rawPassage || '');
        if (_aiReplaceActive) {
          try { console.log('[AIStoryGen] arrive button target=' + clickRawPassage + ', arrived=' + _aiLocationArrived + ', current=' + _aiCurrentLocationPassage + ', eventMode=' + _aiReplaceOriginalEventMode); } catch (_) {}
          if (!_aiReplaceOriginalEventMode && !(_aiLocationArrived && _aiCurrentLocationPassage) && !clickRawPassage) {
            restoreOriginalPassage({ keepAIFunctionality: true });
            return;
          }
          _finishAiReplaceAndGo(clickRawPassage, {
            skipOriginal: !!(!_aiReplaceOriginalEventMode && clickRawPassage),
            keepAIFunctionality: true,
            preserveRoundHistory: true,
            suppressAutoChoices: false
          });
          return;
        }
        if ((arriveModel.canNavigateNative || clickRawPassage) && (_aiCurrentLocationPassage || clickRawPassage)) {
          if (_finishNormalAiAndGo(_aiCurrentLocationPassage || clickRawPassage, {
            keepAIFunctionality: true,
            preserveRoundHistory: true,
            suppressAutoChoices: false
          })) return;
        }
        _archiveAiRoundHistoryForNativeHandoff('bottom return original page');
        // Normal mode fallback: restore original passage content but keep AI controls available.
        var $passage = $('#passages .passage');
        if ($passage.length) {
          _clearAiOverlayResidue($passage, 'native');
          var $origWrap = $passage.find('.ai-original-wrap');
          if ($origWrap.length) {
            // Use replaceWith(contents()) to preserve text nodes
            $origWrap.replaceWith($origWrap.contents());
          }
        }
        _clearAiLocationState('bottom return original page');
        $('#passages .ai-choices, #passages .ai-choices-end').remove();
        _clearAISaveNavigationState('bottom return original page', { preserveRoundHistory: true });
        _releaseAutoChoicesBusy('bottom return original page keep AI');
        setTimeout(function () {
          injectAILinkClones();
          autoInjectChoices(typeof State !== 'undefined' ? State.passage : '');
        }, 50);
      });
      $bottomActions.append($arriveBtn);

      var $manualPanel = $('<div class="ai-manual-arrive-panel" style="display:none;margin-top:0.45em;padding:0.45em;border:1px solid #334;background:#171722;border-radius:3px;"></div>');
      _bindAiInteractionShield($manualPanel, 'manual-arrive-panel');
      var $manualBtn = $('<a class="ai-back-link ai-manual-arrive-toggle" href="javascript:void(0)"></a>')
        .text(cfg.language === 'zh' ? '\u624b\u52a8\u9009\u62e9\u5230\u8fbe\u5730\u70b9' : 'Choose destination manually');
      var manualOpen = false;
      function renderManualArrivePanel() {
        var options = _collectManualArriveCandidates(rawPassage);
        $manualPanel.empty();
        var $title = $('<div style="margin-bottom:0.35em;color:#bbb;font-size:0.92em;"></div>')
          .text(cfg.language === 'zh' ? '\u9009\u62e9\u5b9e\u9645\u5230\u8fbe\u7684\u539f\u7248\u5730\u70b9\uff1a' : 'Choose the actual native destination:');
        $manualPanel.append($title);
        if (!options.length) {
          $manualPanel.append($('<div class="ai-cfg-msg"></div>').text(cfg.language === 'zh' ? '\u6682\u65f6\u627e\u4e0d\u5230\u53ef\u5230\u8fbe\u7684\u4e34\u8fd1\u5730\u70b9\u3002' : 'No nearby destinations found.'));
          return;
        }
        var $grid = $('<div style="display:flex;flex-wrap:wrap;gap:0.35em;"></div>');
        options.forEach(function (opt) {
          var title = opt.raw === rawPassage
            ? (cfg.language === 'zh' ? '\u5f53\u524d\u6309\u94ae\u76ee\u6807' : 'Current button target')
            : opt.raw;
          var $opt = $('<button type="button" class="ai-manual-arrive-option" style="font:inherit;padding:0.25em 0.55em;border:1px solid #556;background:#202030;color:#f0d060;cursor:pointer;border-radius:2px;"></button>')
            .text(opt.label || opt.raw)
            .attr('title', title);
          $opt.on('click', function () {
            if (_forceManualArriveTo(opt.raw)) return;
            var selected = _selectManualArriveTargetInAi(opt.raw);
            if (!selected) return;
            rawPassage = selected.raw;
            destLabel = selected.label;
            $arriveBtn
              .text((cfg.language === 'zh' ? '\ud83d\udccd \u5230\u8fbe ' : '\ud83d\udccd Arrive at ') + selected.label)
              .attr('data-ai-arrive-raw', selected.raw)
              .attr('data-ai-arrive-label', selected.label)
              .attr('title', selected.raw);
            manualOpen = false;
            $manualPanel.hide();
          });
          $grid.append($opt);
        });
        $manualPanel.append($grid);
      }
      $manualBtn.on('click', function () {
        manualOpen = !manualOpen;
        if (manualOpen) {
          renderManualArrivePanel();
          $manualPanel.show();
        } else {
          $manualPanel.hide();
        }
      });
      $bottomActions.append($manualBtn).append($manualPanel);
    })();

    var ChoiceUI = ChoiceUIModule.create({
      $: $,
      cfg: cfg,
      formatChoiceTime: formatChoiceTime,
      parseTimeFromChoice: parseTimeFromChoice,
      stripTimeFromChoice: stripTimeFromChoice,
      buildChoiceTextWithTime: buildChoiceTextWithTime,
      inferDefaultTimeCost: inferDefaultTimeCost,
      bindInteractionShield: _bindAiInteractionShield
    });
    var readChoiceTimeFromRow = ChoiceUI.readChoiceTimeFromRow;
    var createChoiceTimeEditor = ChoiceUI.createChoiceTimeEditor;
    var showChoiceEditPanel = ChoiceUI.showChoiceEditPanel;

    choices.forEach(function (choice, i) {
      var displayText = choice;
      var parsedTime = parseChoiceTimeParts(displayText);
      var baseText = stripTimeFromChoice(displayText);
      var rawDefaultTime = parsedTime ? parsedTime.total : inferDefaultTimeCost(baseText);
      var defaultTime = normalizeGeneratedChoiceTimeCost(baseText, rawDefaultTime);
      var choiceTextWithTime = buildChoiceTextWithTime(baseText, defaultTime);
      var $row = $('<div class="ai-choice-row"></div>');
      var $editBtn = $('<button type="button" class="ai-choice-edit-btn"></button>')
        .attr('title', cfg.language === 'zh' ? '\u5fae\u8c03\u8fd9\u4e2a\u5267\u60c5\u9009\u9879' : 'Refine this story choice')
        .text(cfg.language === 'zh' ? '\u6539' : 'Edit');
      var $btn = $('<button class="ai-choice-btn"></button>')
        .append($('<span class="ai-choice-index"></span>').text('(' + (i + 1) + ') '))
        .attr('data-choice-text', choiceTextWithTime)
        .attr('data-choice-base-text', baseText);
      var $label = $('<span class="ai-choice-label"></span>').text(baseText);
      $btn.append(createChoiceTimeEditor(defaultTime, baseText, { editable: false })).append(' ').append($label);
      $row.append($editBtn).append($btn);
      $list.append($row);
    });

    $list.on('click', '.ai-choice-edit-btn', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      showChoiceEditPanel($(this).closest('.ai-choice-row'));
    });

    // Use event delegation — survives DOM replacement
    $list.on('click', '.ai-choice-btn', function (ev) {
      console.log('[AIStoryGen] button delegated-click:', ($(this).attr('data-choice-text') || '').slice(0, 40));
      if ($(this).hasClass('ai-choice-custom-btn')) return;
      var $row = $(this).closest('.ai-choice-row');
      var baseText = $(this).attr('data-choice-base-text') || $(this).attr('data-choice-text');
      var timeCost = 0;
      try {
        timeCost = readChoiceTimeFromRow($row, baseText);
      } catch (_) {}
      var choiceText = buildChoiceTextWithTime(baseText, timeCost);
      if (choiceText && !$(this).prop('disabled')) {
        showLoadingAndCall(choiceText, { timeCost: timeCost });
      }
    });

    // Custom input row
    var $customRow = $('<div class="ai-choices-custom"></div>');
    var placeholderTxt = cfg.language === 'zh' ? '\u81ea\u5df1\u5199\u53d1\u5c55\u65b9\u5411\uff0c\u70b9\u9009\u9879\u6216\u56de\u8f66\u63d0\u4ea4...' : 'Write your own direction; click a choice or press Enter...';
    $customInput = $('<input type="text" class="ai-choices-input">').attr('placeholder', placeholderTxt);
    $customInput.attr('placeholder', cfg.language === 'zh' ? '\u81ea\u5df1\u5199\u53d1\u5c55\u65b9\u5411\uff0c\u70b9\u9009\u9879\u6216\u56de\u8f66\u63d0\u4ea4...' : 'Write your own direction; click a choice or press Enter...');
    var $customTime = createChoiceTimeEditor(5, cfg.language === 'zh' ? '\u81ea\u5b9a\u4e49\u884c\u52a8' : 'custom action');
    var $customBtn = $('<button class="ai-choice-btn ai-choice-custom-btn">→</button>');

    $customBtn.text(cfg.language === 'zh' ? '\u53d1\u9001' : 'Send');

    function submitCustom() {
      var text = $customInput.val().trim();
      if (!text) return;
      var timeCost = 0;
      try {
        if (!$customTime.attr('data-ai-time-touched')) {
          var inferred = normalizeGeneratedChoiceTimeCost(text, inferDefaultTimeCost(text));
          $customTime.attr('data-minutes', String(Math.max(0, inferred)));
          $customTime.text('(' + formatChoiceTime(inferred) + ')');
        }
        timeCost = readChoiceTimeFromRow($customRow, text);
      } catch (_) {}
      showLoadingAndCall(buildChoiceTextWithTime(text, timeCost), { fromCustom: true, timeCost: timeCost });
    }

    $customTime.on('ai-choice-timechange', function () { $customTime.attr('data-ai-time-touched', '1'); });
    $customBtn.on('click', submitCustom);
    $customInput.on('keydown', function (e) { if (e.key === 'Enter') submitCustom(); });
    $customRow.append($customInput).append($customTime).append($customBtn);
    $list.append($customRow);

    // Return button always at the very bottom
    $list.append($bottomActions);
    _dedupeSexModeButtons();

    $container.append($list);
    _dedupeSexModeButtons();
  }

  window.AIStoryGen.generateChoices = generateChoices;
  window.AIStoryGen.renderChoices = renderChoices;

  // ---------- 8. 等待 SugarCube 就绪后注册宏 ----------
  function registerMacros() {
    if (typeof Macro === 'undefined' || !Macro.add) {
      setTimeout(registerMacros, 50);
      return;
    }

    // <<aigen "instruction">>
    Macro.add('aigen', {
      tags: null,
      handler: function () {
        var instruction = (this.args[0] != null ? String(this.args[0]) : '').trim();
        var cfg = loadCfg();
        var placeholderTxt = cfg.language === 'zh' ? '生成中…' : 'Generating…';
        var $out = $('<span class="ai-gen ai-gen-loading"></span>').text(placeholderTxt);
        $(this.output).append($out);

        callAI(instruction, { storyStyle: true }).then(function (text) {
          $out.removeClass('ai-gen-loading').addClass('ai-gen-done').empty();
          try {
            new Wikifier($out[0], text);
          } catch (e) {
            $out.text(text);
          }
        }).catch(function (err) {
          $out.removeClass('ai-gen-loading').addClass('ai-gen-error');
          $out.text('[' + (cfg.language === 'zh' ? 'AI 调用失败' : 'AI error') + '] ' + (err && err.message ? err.message : err));
          console.error('[AIStoryGen]', err);
        });
      },
    });

    // <<aichoices "optional hint">>
    // Generates 5 branching choices + a custom input option.
    Macro.add('aichoices', {
      tags: null,
      handler: function () {
        var hint = (this.args[0] != null ? String(this.args[0]) : '').trim();
        var cfg = loadCfg();
        var $container = $('<div class="ai-choices"></div>');
        var loadingTxt = cfg.language === 'zh' ? 'AI 正在生成选项…' : 'AI generating choices…';
        var $loading = $('<div class="ai-choices-loading ai-gen-loading"></div>').text(loadingTxt);
        $container.append($loading);
        $(this.output).append($container);

        generateChoices(cfg, hint).then(function (choices) {
          $loading.remove();
          renderChoices($container, choices, cfg);
          _scheduleAIPixelAssistRefresh('macro choices rendered', 300);
        }).catch(function (err) {
          $loading.removeClass('ai-gen-loading').addClass('ai-choices-error');
          $loading.text((cfg.language === 'zh' ? '选项生成失败: ' : 'Choice error: ') + (err && err.message ? err.message : err));
          _appendChoiceRetryButton($container, cfg, function () {
            $container.empty().append($loading.removeClass('ai-choices-error').addClass('ai-gen-loading').text(loadingTxt));
            generateChoices(cfg, hint).then(function (choices) {
              $loading.remove();
              renderChoices($container, choices, cfg);
              _scheduleAIPixelAssistRefresh('macro choices retry rendered', 300);
            }).catch(function (e) {
              $loading.removeClass('ai-gen-loading').addClass('ai-choices-error');
              $loading.text((cfg.language === 'zh' ? '选项生成失败: ' : 'Choice error: ') + (e && e.message ? e.message : e));
            });
          });
          console.error('[AIStoryGen] choices error', err);
        });
      },
    });

    // <<aiconfig>>
    // Renders the config form standalone (used in AIStoryGen_Config passage)
    Macro.add('aiconfig', {
      tags: null,
      handler: function () {
        buildUnifiedConfigForm($(this.output), false);
      },
    });

    // <<aimemory>> standalone AI memory viewer
    Macro.add('aimemory', {
      tags: null,
      handler: function () {
        // Memory editing is intentionally only exposed through the Journal overlay
        // AI记忆 tab, so ordinary passages never render an inline memory window.
      },
    });

    console.log('[AIStoryGen] macros registered v' + (window.AIStoryGen && window.AIStoryGen.VERSION || 'unknown') + ': <<aigen>>, <<aichoices>>, <<aiconfig>>, <<aimemory>>');
    console.log('[AIStoryGen] Settings page hook installed for "织境空间" tab');
  }

  registerMacros();

  window.AIStoryGen.combatRuntimeBridge = Object.freeze({
    schemaVersion: 1,
    safeRead: safeRead,
    loadCfg: loadCfg,
    classifyError: classifyError,
    buildStatusDetail: _aiBuildStatusDetail,
    buildNpcExtra: _aiBuildNpcExtra,
    relationObject: _aiRelationObject,
    clearAISexModeUi: _clearAISexModeUi,
    fetchAI: _fetchAI,
    getNativeEngine: _getNativeEngine,
    getNativeSexActionBridgeModule: _getNativeSexActionBridgeModule,
    getNativeSceneBridge: function () { return window.AIStoryGen && window.AIStoryGen.NativeSceneBridge; },
    isAdultContentUnlocked: _isAdultContentUnlocked,
    isAISexModeEnabled: _isAISexModeEnabled,
    isIntimateAddonLoaded: _isIntimateAddonLoaded,
    isNativeSexOrCombatPassage: _isNativeSexOrCombatPassage,
    localizeNamesInText: _localizeNamesInText,
    nativeStoryHas: _nativeStoryHas,
    recordNativeCombatActionMemory: _recordNativeCombatActionMemory,
    runNativeWikifier: _runNativeWikifier,
    showAIUserMessage: _showAIUserMessage
  });

  var NativeSceneBridge = NativeSceneBridgeModule.create({
    publicSchemaVersion: 3,
    getStatus: function (reason) {
      return _getNativeSceneStatus(reason || 'api');
    },
    isCombatActive: function () {
      return _isNativeCombatActive();
    },
    isNativeSexOrCombatPassage: function (name) {
      return _isNativeSexOrCombatPassage(name);
    },
    shouldShowSexModeOption: function () {
      return _shouldShowSexModeOption();
    },
    collectSexTargets: function (contextText) {
      return _getDirectNativeSexTargets(contextText);
    },
    collectSexTargetSummaries: function (contextText) {
      return _getDirectNativeSexTargets(contextText).map(_summarizeNativeSexTarget).filter(Boolean);
    },
    enterSexMode: function () {
      return _enterNativeSexMode();
    },
    showSexTargetPicker: function (targets) {
      return _showNativeSexTargetPicker(targets || _getDirectNativeSexTargets(), { mode: 'native' });
    },
    jumpSexTargets: function (targets) {
      return _jumpNativeSexTargets(targets);
    },
    clearTargetPicker: function () {
      return _clearSexTargetPicker();
    },
    prepareNativeModeJump: function () {
      return _prepareNativeModeJump();
    },
    dedupeSexModeButtons: function () {
      return _dedupeSexModeButtons();
    },
    injectSexModeEntry: function () {
      return _ensureSexModeEntryInExistingActions();
    },
    refreshControls: function (reason) {
      return _refreshNativeSceneControls(reason || 'api');
    },
    injectCombatIntentInputs: function () {
      return _callIntimateCombatRuntime('injectCustomIntentInputs', [], false);
    },
    injectEndCombatButton: function () {
      return _callIntimateCombatRuntime('injectEndCombatButton', [], false);
    },
    forceEndCombat: function (mode) {
      return _callIntimateCombatRuntime('forceEndCombat', [mode], false);
    },
    syncCombatLifecycle: function () {
      return _callIntimateCombatRuntime('syncLifecycle', [], { sd: false, ed: false, sc: false });
    }
  });
  window.AIStoryGen.nativeSceneBridge = NativeSceneBridge;
  window.AIStoryGen.NativeSceneBridge = NativeSceneBridge;

  // ---------- 19. CDP / debug dump ----------
  function _getAiControllerDebugState() {
    function _schema(obj) {
      return obj && obj.schemaVersion ? obj.schemaVersion : null;
    }
    var intimateAddon = window.AIStoryGenIntimateAddon || null;
    var dynamicNativeTargetModule = window.AIStoryGenNativeTargetDetectorModule || (window.AIStoryGen && window.AIStoryGen.NativeTargetDetectorModule) || NativeTargetDetectorModule;
    var dynamicNativeTarget = (intimateAddon && intimateAddon.detector) || (window.AIStoryGen && window.AIStoryGen.NativeTargetDetector) || NativeTargetDetector;
    var dynamicNativeSceneModule = window.AIStoryGenNativeSceneBridgeModule || (window.AIStoryGen && window.AIStoryGen.NativeSceneBridgeModule) || NativeSceneBridgeModule;
    var dynamicNativeScene = (window.AIStoryGen && window.AIStoryGen.NativeSceneBridge) || NativeSceneBridge;
    var intimateCombatRuntime = window.AIStoryGenIntimateCombatRuntime || null;
    return {
      core: _schema(Core),
      apiClientModule: _schema(ApiClientModule),
      providerPresetsModule: _schema(ProviderPresetsModule),
      requestLogModule: _schema(RequestLogModule),
      requestLog: RequestLog && RequestLog.getDebugState ? _cloneForAiSnapshot(RequestLog.getDebugState()) : null,
      errorReportUIModule: _schema(ErrorReportUIModule),
      errorReportUI: _schema(ErrorReportUI),
      changeSummaryModule: _schema(ChangeSummaryModule),
      mobileCompatModule: _schema(MobileCompatModule),
      mobileCompat: MobileCompat && MobileCompat.getDebugState ? _cloneForAiSnapshot(MobileCompat.getDebugState()) : null,
      lastProviderProbe: _cloneForAiSnapshot(window.AIStoryGen.lastProviderProbe || null),
      lastApiError: _cloneForAiSnapshot(window.AIStoryGen.lastApiError || null),
      storyRuntimeModule: _schema(StoryRuntimeModule),
      runtimeEventsModule: _schema(RuntimeEventsModule),
      runtimeEvents: _aiRuntimeEvents && typeof _aiRuntimeEvents.getDebugState === 'function'
        ? _cloneForAiSnapshot(_aiRuntimeEvents.getDebugState())
        : null,
      combatNarratorModule: _schema(window.AIStoryGenCombatNarratorModule || (window.AIStoryGen && window.AIStoryGen.CombatNarratorModule)),
      intimateCombatRuntime: _schema(intimateCombatRuntime),
      intimateCombatRuntimeState: intimateCombatRuntime && typeof intimateCombatRuntime.getDebugState === 'function'
        ? _cloneForAiSnapshot(intimateCombatRuntime.getDebugState())
        : null,
      stateStoreModule: _schema(StateStoreModule),
      stateStore: _schema(window.AIStoryGen.stateStore),
      linkClassifierModule: _schema(LinkClassifierModule),
      pageClassifierModule: _schema(PageClassifierModule),
      worldKnowledgeModule: _schema(WorldKnowledgeModule),
      worldKnowledge: WorldKnowledge && typeof WorldKnowledge.getDebugState === 'function'
        ? _cloneForAiSnapshot(WorldKnowledge.getDebugState())
        : null,
      npcContextModule: _schema(NpcContextModule),
      npcContext: _schema(NpcContext),
      worldContextModule: _schema(WorldContextModule),
      worldContext: _schema(WorldContext),
      eventParserModule: _schema(EventParserModule),
      eventSchemaModule: _schema(EventSchemaModule),
      itemSchemaModule: _schema(ItemSchemaModule),
      eventValidatorModule: _schema(EventValidatorModule),
      eventValidator: _schema(AIEventValidator),
      consistencyGuardModule: _schema(ConsistencyGuardModule),
      consistencyGuard: _schema(ConsistencyGuard),
      consistencyDiagnostics: _cloneForAiSnapshot(_lastConsistencyDiagnostics || []),
      consistencyBlockedEffects: _cloneForAiSnapshot(_lastConsistencyBlockedEffects || []),
      consistencyBlockedEffectSummary: _getConsistencyBlockedEffectSummary(),
      lastTransactionPlan: _cloneForAiSnapshot(_lastAiTransactionPlan || null),
      transactionAuditModule: _schema(TransactionAuditModule),
      transactionAudit: _aiTransactionAuditor && typeof _aiTransactionAuditor.getDebugState === 'function'
        ? _cloneForAiSnapshot(_aiTransactionAuditor.getDebugState())
        : null,
      lastTransactionAudit: _cloneForAiSnapshot(_lastAiTransactionAudit || null),
      memoryPolicyModule: _schema(MemoryPolicyModule),
      memoryUIModule: _schema(MemoryUIModule),
      memoryUI: _schema(MemoryUI),
      configUIModule: _schema(ConfigUIModule),
      configUI: _schema(ConfigUI),
      locationModule: _schema(LocationControllerModule),
      locationTools: _schema(window.AIStoryGen.locationTools),
      location: _schema(LocationController),
      panelModule: _schema(PanelManagerModule),
      panel: _schema(PanelManager),
      transactionModule: _schema(TransactionModule),
      transaction: _schema(AITransaction),
      nativeTargetModule: _schema(dynamicNativeTargetModule),
      nativeTarget: _schema(dynamicNativeTarget),
      nativeEventGuardModule: _schema(NativeEventGuardModule),
      nativeEventGuard: _schema(NativeEventGuard),
      nativeSceneModule: _schema(dynamicNativeSceneModule),
      nativeScene: _schema(dynamicNativeScene),
      nativeSexActionBridgeModule: _schema(_getNativeSexActionBridgeModule()),
    };
  }

  function _getAiStorageDebugState() {
    var keys = [];
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        if (/^(aiStoryGen|AIStoryGen|__AIStoryGen)/.test(key || '')) {
          keys.push({
            key: key,
            len: String(localStorage.getItem(key) || '').length,
          });
        }
      }
    } catch (_) {}
    return {
      localStorageKeys: keys,
      recentBufLen: recentBuf.length,
      longTermMemLen: longTermMem.length,
      aiItemsLen: (_getAiItemStore() || []).length,
      pendingAiItemUsesLen: (_pendingAiItemUses || []).length,
      lastAiItemsUsedForTurn: _cloneForAiSnapshot(_lastAiItemsUsedForTurn || []),
      eventLogLen: (typeof _aiEventLog !== 'undefined' && _aiEventLog && _aiEventLog.length) || 0,
      stateStoreSchema: (window.AIStoryGen.stateStore && window.AIStoryGen.stateStore.schemaVersion) || null,
      stateStore: window.AIStoryGen.stateStore && typeof window.AIStoryGen.stateStore.getDiagnostics === 'function'
        ? _cloneForAiSnapshot(window.AIStoryGen.stateStore.getDiagnostics())
        : null,
    };
  }

  function _getAiDomMaintenanceDebugState() {
    return {
      globalObserverActive: !!window._aiOptionsGlobalObserver,
      globalMaintenancePending: !!window._aiGlobalDomMaintenanceTimer,
      globalMaintenanceIgnoreUntil: Number(_aiGlobalDomMaintenanceIgnoreUntil || 0),
      globalMaintenanceStats: _cloneForAiSnapshot(_aiGlobalDomMaintenanceStats),
      settingsObserverActive: !!window._aiSettingsPassageObserver,
      nativeOverlayHoistPendingDelays: Object.keys(_nativeOverlayHoistTimers || {}).map(Number).sort(function (a, b) { return a - b; }),
      inventoryTabInjectionPending: !!_aiInventoryTabInjectionTimer
    };
  }

  function _getAiPanelDebugState() {
    var pixelSelector = '#passages .apg-ai-assist, #passages [data-ai-pixel-panel="1"], #passages .aipixel-panel, #passages #aipixel-panel';
    var panelManagerStatus = null;
    var legacyUiStatus = OptionalAddonBridge.getLegacyUiStatus();
    try {
      panelManagerStatus = PanelManager && typeof PanelManager.getStatus === 'function' ? PanelManager.getStatus() : null;
    } catch (_) {}
    return {
      storyChoices: $('#passages .ai-choices').length,
      storyChoiceButtons: $('#passages [data-ai-story-choice-button="1"]').length,
      storyUseItemPanels: $('#passages .ai-use-item-panel').length,
      sexMenus: legacyUiStatus.sexMenus,
      pixelPanels: $(pixelSelector).length,
      pixelAssistPanels: $('#passages .apg-ai-assist').length,
      combatIntentInputs: $('#passages [data-ai-combat-intent-input="1"]').length,
      endCombatControls: $('#passages .ai-end-combat-wrap, #passages [data-ai-end-combat="1"]').length,
      blockingBackdrops: $('.ai-item-use-backdrop').length,
      itemUseDialogOpen: !!_aiItemUseDialogState,
      intimateFixedActions: legacyUiStatus.intimateFixedActions,
      legacyPixelOrderObserver: !!window._apgAssistOrderObserver,
      legacyPoseOrderObserver: !!window._apgPoseAssistOrderObserver,
      panelManager: panelManagerStatus,
    };
  }

  function _getAiSettingsInjectionDebugState() {
    var mountState = _aiMountController && typeof _aiMountController.getDebugState === 'function'
      ? _aiMountController.getDebugState()
      : null;
    return {
      diagnostics: _cloneForAiSnapshot(_aiSettingsInjectionDiagnostics || {}),
      mountController: mountState,
      main: {
        hasSettingsOptions: !!document.getElementById('settingsOptions'),
        hasSettingsDiv: !!document.getElementById('settingsDiv'),
        hasNativeSettingsTab: MountControllerModule.hasNativeTab ? MountControllerModule.hasNativeTab('main', document) : !!document.getElementById('aiStoryGenSettingsNativeTab'),
        hasSettingsTab: !!document.getElementById('aiSettingsTab'),
        hasFallbackEntry: !!document.getElementById('aiSettingsFallbackEntry'),
        hasFallbackPanel: !!document.getElementById('aiSettingsFallbackPanel'),
        fallbackPanelHasForm: $('#aiSettingsFallbackPanel .ai-unified-settings').length > 0
      },
      overlay: {
        hasCustomOverlay: !!document.getElementById('customOverlay'),
        hasOverlayTabs: !!document.getElementById('overlayTabs'),
        hasOverlayContent: !!document.getElementById('customOverlayContent'),
        hasNativeOptionsTab: MountControllerModule.hasNativeTab ? MountControllerModule.hasNativeTab('overlay', document) : _hasNativeOptionsSettingsTab(),
        hasOptionsTab: !!document.getElementById('aiOptionsTab'),
        hasFallbackEntry: !!document.getElementById('aiOptionsFallbackEntry'),
        hasFallbackPanel: !!document.getElementById('aiOptionsFallbackPanel'),
        fallbackPanelHasForm: $('#aiOptionsFallbackPanel .ai-unified-settings').length > 0
      }
    };
  }

  function _getAiRuntimeStatsDebugState() {
    var V = getV();
    var keys = [
      'arousal', 'stress', 'pain', 'trauma', 'tiredness', 'control',
      'seductionskill', 'money'
    ];
    var values = {};
    if (V) {
      keys.forEach(function (key) {
        if (Object.prototype.hasOwnProperty.call(V, key)) values[key] = _cloneForAiSnapshot(V[key]);
      });
    }
    var sidebar = {};
    try {
      var snap = MobileCompat && typeof MobileCompat.getSidebarSnapshot === 'function'
        ? MobileCompat.getSidebarSnapshot()
        : (MobileCompatModule.getSidebarSnapshot ? MobileCompatModule.getSidebarSnapshot(document) : {});
      sidebar.desktopText = _cleanAIReportText(snap.desktopText || '', 800);
      sidebar.mobileText = _cleanAIReportText(snap.mobileText || '', 800);
      sidebar.hasDesktopStats = !!snap.hasDesktopStats;
      sidebar.hasMobileStats = !!snap.hasMobileStats;
      sidebar.hasUiBar = !!snap.hasUiBar;
    } catch (_) {}
    return {
      observer: _aiRuntimeChangeObserver && typeof _aiRuntimeChangeObserver.getDebugState === 'function'
        ? _aiRuntimeChangeObserver.getDebugState({
          lastTransactionStats: (_lastAiTransactionPlan && _lastAiTransactionPlan.stats) || null
        })
        : null,
      stateVariablesKnown: !!V,
      values: values,
      statLimits: _getAiStatFieldLimits(loadCfg()),
      lastTransactionStats: _cloneForAiSnapshot((_lastAiTransactionPlan && _lastAiTransactionPlan.stats) || null),
      lastTransactionAudit: _cloneForAiSnapshot(_lastAiTransactionAudit || null),
      sidebar: sidebar
    };
  }

  function _readAiModLoaderCacheInfo() {
    return new Promise(function (resolve) {
      if (!window.indexedDB) {
        resolve({ available: false, reason: 'indexedDB unavailable' });
        return;
      }
      var req;
      try {
        req = indexedDB.open('ModLoader_IndexDBLoader');
      } catch (e) {
        resolve({ available: false, reason: String(e && e.message || e) });
        return;
      }
      req.onerror = function () {
        resolve({ available: false, reason: String(req.error || 'open failed') });
      };
      req.onsuccess = function () {
        var db = req.result;
        var out = { available: true, hasAIStoryGenZip: false, zipBytes: 0, list: [] };
        try {
          if (!db.objectStoreNames || !db.objectStoreNames.contains('ModLoader_IndexDBLoader')) {
            db.close();
            resolve({ available: true, reason: 'store missing' });
            return;
          }
          var tx = db.transaction('ModLoader_IndexDBLoader', 'readonly');
          var st = tx.objectStore('ModLoader_IndexDBLoader');
          function isAiStoryGenCacheName(name) {
            var text = String(name || '').toLowerCase();
            return text.indexOf('aistorygen') >= 0 || text.indexOf('wovenrealm') >= 0 || text.indexOf('织境空间') >= 0;
          }
          var zipReq = st.get('modDataIndexDBZip:AIStoryGen');
          var listReq = st.get('modDataIndexDBZipList');
          zipReq.onsuccess = function () {
            var value = zipReq.result;
            out.hasAIStoryGenZip = !!value;
            out.zipBytes = value && typeof value.length === 'number' ? value.length : 0;
          };
          listReq.onsuccess = function () {
            try {
              out.list = JSON.parse(listReq.result || '[]');
            } catch (_) {
              out.list = [];
            }
          };
          tx.oncomplete = function () {
            var hasList = Array.isArray(out.list) && out.list.length > 0;
            var listHasAi = hasList && out.list.some(function (entry) {
              if (typeof entry === 'string') return isAiStoryGenCacheName(entry);
              return isAiStoryGenCacheName(entry && (entry.name || entry.id || entry.modName || entry.fileName || entry.filename));
            });
            if (listHasAi) out.hasAIStoryGenZip = true;
            if (!hasList && !out.hasAIStoryGenZip) {
              out.hasAIStoryGenZip = null;
              out.reason = 'cache empty or embedded test page';
            }
            db.close();
            resolve(out);
          };
          tx.onerror = function () {
            db.close();
            resolve({ available: true, reason: String(tx.error || 'read failed') });
          };
        } catch (e2) {
          try { db.close(); } catch (_) {}
          resolve({ available: true, reason: String(e2 && e2.message || e2) });
        }
      };
    });
  }

  function _isAiModLoaderCacheName(name) {
    var text = String(name || '').toLowerCase();
    return text.indexOf('aistorygen') >= 0
      || text.indexOf('aipixelgen') >= 0
      || text.indexOf('wovenrealm') >= 0
      || text.indexOf('woven realm') >= 0
      || text.indexOf('织境空间') >= 0;
  }

  function _aiBytesFromCacheValue(value) {
    return new Promise(function (resolve) {
      try {
        if (!value) return resolve(null);
        if (value instanceof Uint8Array) return resolve(value);
        if (value instanceof ArrayBuffer) return resolve(new Uint8Array(value));
        if (value.buffer instanceof ArrayBuffer && typeof value.byteLength === 'number') {
          return resolve(new Uint8Array(value.buffer, value.byteOffset || 0, value.byteLength));
        }
        if (typeof Blob !== 'undefined' && value instanceof Blob) {
          var reader = new FileReader();
          reader.onload = function () { resolve(new Uint8Array(reader.result)); };
          reader.onerror = function () { resolve(null); };
          reader.readAsArrayBuffer(value);
          return;
        }
        if (typeof value === 'string') {
          var text = value.trim();
          if (/^[A-Za-z0-9+/=\s]+$/.test(text) && text.length > 64) {
            try {
              var binary = atob(text.replace(/\s+/g, ''));
              var bytes = new Uint8Array(binary.length);
              for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
              return resolve(bytes);
            } catch (_) {}
          }
        }
      } catch (_) {}
      resolve(null);
    });
  }

  function _aiU16(bytes, offset) {
    return bytes[offset] | (bytes[offset + 1] << 8);
  }

  function _aiU32(bytes, offset) {
    return (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;
  }

  function _aiDecodeUtf8(bytes) {
    try { return new TextDecoder('utf-8').decode(bytes); } catch (_) {
      var out = '';
      for (var i = 0; i < bytes.length; i++) out += String.fromCharCode(bytes[i]);
      try { return decodeURIComponent(escape(out)); } catch (_) { return out; }
    }
  }

  function _aiInflateRaw(bytes) {
    if (typeof DecompressionStream === 'undefined') {
      return Promise.reject(new Error('DecompressionStream unavailable'));
    }
    try {
      var ds = new DecompressionStream('deflate-raw');
      var writer = ds.writable.getWriter();
      writer.write(bytes);
      writer.close();
      return new Response(ds.readable).arrayBuffer().then(function (buffer) {
        return new Uint8Array(buffer);
      });
    } catch (e) {
      return Promise.reject(e);
    }
  }

  function _extractAiBootFromZipValue(value) {
    return _aiBytesFromCacheValue(value).then(function (bytes) {
      if (!bytes || bytes.length < 32) return null;
      var sig0 = 0x50, sig1 = 0x4b, sig2 = 0x03, sig3 = 0x04;
      var max = Math.min(bytes.length - 30, 8 * 1024 * 1024);
      function nextHeader(start) {
        for (var p = start; p < max; p++) {
          if (bytes[p] === sig0 && bytes[p + 1] === sig1 && bytes[p + 2] === sig2 && bytes[p + 3] === sig3) return p;
        }
        return -1;
      }
      var chain = Promise.resolve(null);
      var offset = 0;
      function scanFrom(pos) {
        var p = nextHeader(pos);
        if (p < 0) return Promise.resolve(null);
        var method = _aiU16(bytes, p + 8);
        var compSize = _aiU32(bytes, p + 18);
        var nameLen = _aiU16(bytes, p + 26);
        var extraLen = _aiU16(bytes, p + 28);
        var nameStart = p + 30;
        var dataStart = nameStart + nameLen + extraLen;
        var dataEnd = dataStart + compSize;
        if (nameLen <= 0 || dataStart > bytes.length || dataEnd > bytes.length || compSize <= 0) {
          return scanFrom(p + 4);
        }
        var name = _aiDecodeUtf8(bytes.slice(nameStart, nameStart + nameLen));
        if (name !== 'boot.json') return scanFrom(dataEnd);
        var data = bytes.slice(dataStart, dataEnd);
        var dataPromise = method === 0 ? Promise.resolve(data) : (method === 8 ? _aiInflateRaw(data) : Promise.reject(new Error('unsupported zip method ' + method)));
        return dataPromise.then(function (plain) {
          try {
            var boot = JSON.parse(_aiDecodeUtf8(plain).replace(/^\uFEFF/, ''));
            return {
              name: boot.name || '',
              version: boot.version || '',
              scriptFileList: Array.isArray(boot.scriptFileList) ? boot.scriptFileList.slice() : []
            };
          } catch (_) {
            return null;
          }
        }, function () {
          return null;
        });
      }
      return chain.then(function () { return scanFrom(offset); });
    });
  }

  function _readAiModLoaderCacheEntry(name) {
    return new Promise(function (resolve) {
      if (!window.indexedDB || !name) return resolve(null);
      var req;
      try { req = indexedDB.open('ModLoader_IndexDBLoader'); } catch (_) { return resolve(null); }
      req.onerror = function () { resolve(null); };
      req.onsuccess = function () {
        var db = req.result;
        try {
          if (!db.objectStoreNames || !db.objectStoreNames.contains('ModLoader_IndexDBLoader')) {
            db.close();
            resolve(null);
            return;
          }
          var tx = db.transaction('ModLoader_IndexDBLoader', 'readonly');
          var st = tx.objectStore('ModLoader_IndexDBLoader');
          var getReq = st.get('modDataIndexDBZip:' + name);
          var value = null;
          getReq.onsuccess = function () { value = getReq.result || null; };
          tx.oncomplete = function () {
            db.close();
            if (!value) resolve(null);
            else _extractAiBootFromZipValue(value).then(function (boot) {
              resolve({ name: name, boot: boot, hasValue: true });
            }, function () {
              resolve({ name: name, boot: null, hasValue: true });
            });
          };
          tx.onerror = function () { db.close(); resolve(null); };
        } catch (_) {
          try { db.close(); } catch (__) {}
          resolve(null);
        }
      };
    });
  }

  function _clearAiModLoaderCache(options) {
    options = options || {};
    var force = !!options.force;
    var runtimeVersion = String(window.AIStoryGen && window.AIStoryGen.VERSION || '');
    var expectedMacroFile = String(window.AIStoryGen && window.AIStoryGen.EXPECTED_MACRO_FILE || '');
    var runtimeAddonVersion = String(window.AIStoryGenIntimateAddon && window.AIStoryGenIntimateAddon.version || '');
    return new Promise(function (resolve) {
      if (!window.indexedDB) return resolve({ ok: false, reason: 'indexedDB unavailable', removed: [] });
      var req;
      try { req = indexedDB.open('ModLoader_IndexDBLoader'); } catch (e) {
        return resolve({ ok: false, reason: String(e && e.message || e), removed: [] });
      }
      req.onerror = function () { resolve({ ok: false, reason: String(req.error || 'open failed'), removed: [] }); };
      req.onsuccess = function () {
        var db = req.result;
        try {
          if (!db.objectStoreNames || !db.objectStoreNames.contains('ModLoader_IndexDBLoader')) {
            db.close();
            resolve({ ok: false, reason: 'store missing', removed: [] });
            return;
          }
          var tx = db.transaction('ModLoader_IndexDBLoader', 'readonly');
          var st = tx.objectStore('ModLoader_IndexDBLoader');
          var list = [];
          var candidateNames = ['AIStoryGen', 'AIStoryGenIntimateAddon', 'AIPixelGen', 'WovenRealm', 'Woven Realm', '织境空间'];
          var listReq = st.get('modDataIndexDBZipList');
          listReq.onsuccess = function () {
            try { list = JSON.parse(listReq.result || '[]'); } catch (_) { list = []; }
            if (!Array.isArray(list)) list = [];
            list.forEach(function (entry) {
              var name = typeof entry === 'string' ? entry : (entry && (entry.name || entry.id || entry.modName || entry.fileName || entry.filename));
              if (name && _isAiModLoaderCacheName(name) && candidateNames.indexOf(name) < 0) candidateNames.push(String(name));
            });
          };
          tx.oncomplete = function () {
            db.close();
            var reads = candidateNames.map(function (name) { return _readAiModLoaderCacheEntry(name); });
            Promise.all(reads).then(function (entries) {
              entries = entries.filter(function (entry) { return entry && entry.hasValue; });
              var removeNames = [];
              var kept = [];
              entries.forEach(function (entry) {
                var boot = entry.boot || null;
                var cacheName = String(entry.name || '');
                var bootName = String(boot && boot.name || cacheName);
                var bootVersion = String(boot && boot.version || '');
                var scriptList = boot && Array.isArray(boot.scriptFileList) ? boot.scriptFileList : [];
                var sameRuntime = bootVersion && runtimeVersion && bootVersion === runtimeVersion;
                var hasExpectedMacro = !expectedMacroFile || scriptList.indexOf(expectedMacroFile) >= 0;
                var isIntimateAddonCache = cacheName === 'AIStoryGenIntimateAddon' || bootName === 'AIStoryGenIntimateAddon';
                var stale = false;
                if (force) stale = true;
                else if (isIntimateAddonCache) {
                  // The optional addon is a separate valid package. Preserve it
                  // when the public-only build is running, and only replace a
                  // loaded addon's cache when its version is actually stale.
                  stale = !boot || (!!runtimeAddonVersion && bootVersion !== runtimeAddonVersion);
                }
                else if (cacheName !== 'AIStoryGen') stale = true;
                else if (boot && (!sameRuntime || !hasExpectedMacro)) stale = true;
                if (stale) removeNames.push(cacheName);
                else kept.push({ name: cacheName, version: bootVersion || 'unknown' });
              });
              if (!removeNames.length) {
                resolve({ ok: true, removed: [], kept: kept, reason: 'no stale AI cache' });
                return;
              }
              var req2 = indexedDB.open('ModLoader_IndexDBLoader');
              req2.onerror = function () { resolve({ ok: false, reason: String(req2.error || 'open write failed'), removed: [] }); };
              req2.onsuccess = function () {
                var db2 = req2.result;
                try {
                  var tx2 = db2.transaction('ModLoader_IndexDBLoader', 'readwrite');
                  var st2 = tx2.objectStore('ModLoader_IndexDBLoader');
                  var list2 = list.slice();
                  var removeSet = {};
                  removeNames.forEach(function (name) { removeSet[name] = true; });
                  list2 = list2.filter(function (entry) {
                    var name = typeof entry === 'string' ? entry : (entry && (entry.name || entry.id || entry.modName || entry.fileName || entry.filename));
                    return !removeSet[String(name || '')];
                  });
                  removeNames.forEach(function (name) {
                    st2.delete('modDataIndexDBZip:' + name);
                  });
                  st2.put(JSON.stringify(list2), 'modDataIndexDBZipList');
                  tx2.oncomplete = function () {
                    db2.close();
                    resolve({ ok: true, removed: removeNames, kept: kept, reason: options.reason || (force ? 'manual' : 'auto stale cache cleanup') });
                  };
                  tx2.onerror = function () { db2.close(); resolve({ ok: false, reason: String(tx2.error || 'write failed'), removed: [] }); };
                  tx2.onabort = function () { db2.close(); resolve({ ok: false, reason: String(tx2.error || 'write aborted'), removed: [] }); };
                } catch (e2) {
                  try { db2.close(); } catch (_) {}
                  resolve({ ok: false, reason: String(e2 && e2.message || e2), removed: [] });
                }
              };
            });
          };
          tx.onerror = function () { db.close(); resolve({ ok: false, reason: String(tx.error || 'read list failed'), removed: [] }); };
        } catch (e1) {
          try { db.close(); } catch (_) {}
          resolve({ ok: false, reason: String(e1 && e1.message || e1), removed: [] });
        }
      };
    }).then(function (result) {
      try {
        window.AIStoryGen._lastModLoaderCacheCleanup = result;
        if (result && result.removed && result.removed.length) {
          console.warn('[AIStoryGen] cleared stale ModLoader cache: ' + result.removed.join(', '));
        }
      } catch (_) {}
      return result;
    });
  }

  function _scheduleAiModLoaderCacheAutoCleanup() {
    try {
      if (window.AIStoryGen._autoModLoaderCacheCleanupScheduled) return;
      window.AIStoryGen._autoModLoaderCacheCleanupScheduled = true;
      setTimeout(function () {
        _clearAiModLoaderCache({ force: false, reason: 'startup stale cache cleanup' }).catch(function (e) {
          try { console.warn('[AIStoryGen] stale ModLoader cache cleanup failed', e); } catch (_) {}
        });
      }, 5000);
    } catch (_) {}
  }

  function _collectVisibleAIErrorTexts() {
    var out = [];
    try {
      $('#passages .ai-gen-error, #passages .ai-choices-error, #passages .ai-cfg-msg.err, #passages .error-view, #passages .error')
        .each(function () {
          var text = String($(this).text() || '').replace(/\s+/g, ' ').trim();
          if (text) out.push(text.slice(0, 1000));
        });
    } catch (_) {}
    return out.slice(-20);
  }

  function _cleanAIReportText(text, maxLen) {
    return String(text || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[ \t\r\n]+/g, ' ')
      .trim()
      .slice(0, maxLen || 4000);
  }

  function _cloneReportText($nodes, removeSelector, maxLen) {
    try {
      if (!$nodes || !$nodes.length) return '';
      var $clone = $nodes.clone();
      $clone.find(removeSelector || 'script, style, input, textarea, select, button').remove();
      return _cleanAIReportText($clone.text(), maxLen || 4000);
    } catch (_) {
      return '';
    }
  }

  function _collectCurrentAIPageSnapshot() {
    var snapshot = {
      passage: '',
      stateIndex: null,
      visibleText: '',
      aiStoryText: '',
      originalStoryText: '',
      visibleChoices: [],
      aiChoices: [],
      panelState: {},
      flags: {},
    };
    try {
      snapshot.passage = (typeof State !== 'undefined' && State.passage) || '';
      snapshot.stateIndex = (typeof State !== 'undefined' && State.activeIndex != null) ? State.activeIndex : null;
    } catch (_) {}
    try {
      var $passage = $('#passages .passage').last();
      var removeSelector = [
        'script', 'style', 'input', 'textarea', 'select', 'button',
        '.ai-cfg', '.ai-unified-settings', '.ai-merged-settings',
        '.ai-narrative-toolbar', '.ai-memory-inline', '.ai-item-use-panel',
        OptionalAddonBridge.managedDedupeSelector(),
        '.ai-pixel-panel', '.ai-pixelgen-panel', '[data-ai-pixel-panel]',
        '#settingsOptions', '#settingsDiv', '#customOverlayContent'
      ].join(', ');
      snapshot.visibleText = _cloneReportText($passage, removeSelector, 12000);
      snapshot.aiStoryText = _cloneReportText(
        $passage.find('.ai-replaced-content, .ai-narrative-wrap, .ai-story-current, .ai-story-text'),
        removeSelector + ', .ai-choices, .ai-choices-end, .ai-back-to-game',
        12000
      );
      snapshot.originalStoryText = _cloneReportText(
        $passage.find('.ai-original-wrap'),
        removeSelector + ', .ai-injected-row, .ai-injected-link',
        12000
      );
      snapshot.panelState = {
        hasAIStory: $passage.find('.ai-replaced-content, .ai-narrative-wrap').length > 0,
        hasOriginalWrap: $passage.find('.ai-original-wrap').length > 0,
        originalWrapHidden: $passage.find('.ai-original-wrap').filter(function () {
          return this.style.display === 'none' || $(this).css('display') === 'none';
        }).length > 0,
        hasChoicesPanel: $('#passages .ai-choices, #passages .ai-choices-end').length > 0,
        hasPixelPanel: $('#passages .ai-pixel-panel, #passages .ai-pixelgen-panel, #passages [data-ai-pixel-panel]').length > 0,
        hasLoading: $('#passages .ai-gen-loading').length > 0,
      };
      snapshot.flags = {
        containsAIMetaVisible: /\[AI_META\]/.test(snapshot.visibleText),
        containsStatsVisible: /\[(?:STATS|AI道具|AI_ITEM|AI_ITEMS|AI道具使用|AI道具已消耗)/i.test(snapshot.visibleText),
      };
      $passage.find('a[data-passage]').each(function () {
        if (snapshot.visibleChoices.length >= 80) return false;
        var $a = $(this);
        var label = _cleanAIReportText($a.clone().children().remove().end().text(), 200);
        var passage = _cleanAIReportText($a.attr('data-passage') || '', 200);
        if (!label && !passage) return;
        snapshot.visibleChoices.push({
          label: label,
          passage: passage,
          aiInjected: $a.closest('.ai-injected-row, .ai-injected-link, .ai-choices, .ai-choices-end').length > 0,
        });
      });
      function isReportUtilityChoice($el, label) {
        label = _cleanAIReportText(label, 200);
        if (!label) return true;
        if (/^(?:改|发送|使用道具|生成提示词|调整提示词|复制生图诊断|生成图片|一键生成图片|确定并生成图片|手动选择到达地点)$/i.test(label)) return true;
        if (/^[+-](?:1|5|10)$/.test(label)) return true;
        if (/^\(\d{1,2}:\d{2}\)$/.test(label)) return true;
        if ($el.closest('.ai-choice-edit-tools, .ai-choice-time-editor, .ai-choice-time-popover, .ai-item-use-panel, .apg-pixel-panel, .apg-pixel-placeholder').length) return true;
        if ($el.hasClass('ai-choice-edit-btn') || $el.hasClass('ai-choice-time-adjust') || $el.hasClass('apg-pixel-btn')) return true;
        return false;
      }
      $('#passages .ai-choices a, #passages .ai-choices button, #passages .ai-choices-end a, #passages .ai-choices-end button').each(function () {
        if (snapshot.aiChoices.length >= 80) return false;
        var $el = $(this);
        var label = _cleanAIReportText($el.text(), 200);
        var passage = _cleanAIReportText($el.attr('data-passage') || '', 200);
        if (isReportUtilityChoice($el, label)) return;
        if (!label && !passage) return;
        snapshot.aiChoices.push({ label: label, passage: passage });
      });
    } catch (e) {
      snapshot.collectError = String(e && e.message || e);
    }
    return snapshot;
  }

  function _getSafeAIConfigSummary() {
    var cfg = {};
    try { cfg = loadCfg() || {}; } catch (_) {}
    return {
      language: cfg.language || '',
      apiProvider: cfg.apiProvider || '',
      providerDiagnostic: ProviderPresetsModule.getDiagnostic(cfg),
      lastProviderProbe: _cloneForAiSnapshot(window.AIStoryGen.lastProviderProbe || null),
      lastApiError: _cloneForAiSnapshot(window.AIStoryGen.lastApiError || null),
      apiRequestLog: RequestLog && RequestLog.getRecent ? _cloneForAiSnapshot(RequestLog.getRecent(10)) : [],
      endpoint: cfg.endpoint || '',
      model: cfg.model || '',
      highQualityMode: Number(cfg.highQualityMode || 0),
      highQualityEndpoint: cfg.highQualityEndpoint || '',
      highQualityModel: cfg.highQualityModel || '',
      hasApiKey: !!(cfg.apiKey && String(cfg.apiKey).trim()),
      aiPixelEnabled: AI_PIXEL_TEMP_DISABLED ? 0 : Number(cfg.aiPixelEnabled == null ? DEFAULT_CFG.aiPixelEnabled : cfg.aiPixelEnabled),
      aiReplaceLinks: Number(cfg.aiReplaceLinks == null ? 0 : cfg.aiReplaceLinks),
      choiceTriggerMode: _getChoiceTriggerMode(cfg),
      autoChoices: Number(cfg.autoChoices == null ? 0 : cfg.autoChoices),
      aiChoiceMode: Number(cfg.aiChoiceMode == null ? 0 : cfg.aiChoiceMode),
      tier: Number(cfg.tier || 0),
      temperature: Number(cfg.temperature || 0),
      max_tokens: Number(cfg.max_tokens || 0),
      recentMax: Number(cfg.recentMax || 0),
      recentLimit: Number(cfg.recentLimit || 0),
      summarizeTrigger: Number(cfg.summarizeTrigger || 0),
      cacheEnabled: Number(cfg.cacheEnabled == null ? 0 : cfg.cacheEnabled),
      cacheTTLMinutes: Number(cfg.cacheTTLMinutes || 0),
    };
  }

  function _getSafeAIPixelConfigSummary() {
    var cfg = {};
    try { cfg = loadCfg() || {}; } catch (_) {}
    return {
      imgApiType: cfg.imgApiType || '',
      imgEndpoint: cfg.imgEndpoint || '',
      imgModel: cfg.imgModel || '',
      hasImgApiKey: !!(cfg.imgKey && String(cfg.imgKey).trim()),
      llmEndpoint: cfg.llmEndpoint || '',
      llmModel: cfg.llmModel || '',
      hasLlmApiKey: !!(cfg.llmKey && String(cfg.llmKey).trim()),
      defaultStyleKey: cfg.defaultStyleKey || '',
      sceneStyleKey: cfg.sceneStyleKey || '',
      outputSize: cfg.outputSize || '',
      specialImgEndpointSet: !!(cfg.specialImgEndpoint && String(cfg.specialImgEndpoint).trim()),
      specialImgModelSet: !!(cfg.specialImgModel && String(cfg.specialImgModel).trim()),
    };
  }

  function _clipImagePromptDiagnosticText(value, maxLen) {
    return _cleanAIReportText(value, maxLen || 2400);
  }

  function _buildAIPixelDiagnosticSourceFromSnapshot(snapshot) {
    snapshot = snapshot || {};
    var text = snapshot.aiStoryText || snapshot.visibleText || snapshot.originalStoryText || '';
    var choices = Array.isArray(snapshot.aiChoices) && snapshot.aiChoices.length ? snapshot.aiChoices : (Array.isArray(snapshot.visibleChoices) ? snapshot.visibleChoices : []);
    var choiceText = choices.slice(0, 8).map(function (choice) {
      return String(choice && choice.label || '').replace(/\s+/g, ' ').trim();
    }).filter(Boolean).join('；');
    return _cleanAIReportText([text, choiceText ? '当前可见选项：' + choiceText : ''].filter(Boolean).join('\n'), 4200);
  }

  function _getSafeAIPixelPromptDiagnostic(snapshot) {
    try {
      var pixel = window.AIPixelGen || null;
      if (!pixel || typeof pixel.debugBuildImagePromptDiagnostic !== 'function') {
        return { available: false, reason: 'AIPixel diagnostic API unavailable' };
      }
      var sourcePrompt = _buildAIPixelDiagnosticSourceFromSnapshot(snapshot);
      var raw = pixel.debugBuildImagePromptDiagnostic('scene', sourcePrompt) || {};
      var imageWorld = raw.imageWorld || {};
      return {
        available: true,
        schemaVersion: raw.schemaVersion || null,
        mode: raw.mode || '',
        passage: _clipImagePromptDiagnosticText(raw.passage || '', 120),
        styleKey: _clipImagePromptDiagnosticText(raw.styleKey || '', 80),
        promptProtocol: _clipImagePromptDiagnosticText(raw.promptProtocol || '', 80),
        scene: {
          location: _clipImagePromptDiagnosticText(raw.scene && raw.scene.location || '', 120),
          area: _clipImagePromptDiagnosticText(raw.scene && raw.scene.area || '', 120),
          hour: raw.scene && raw.scene.hour,
          minute: raw.scene && raw.scene.minute
        },
        locationPrompt: _clipImagePromptDiagnosticText(raw.locationPrompt || '', 260),
        visualAction: _clipImagePromptDiagnosticText(raw.visualAction || '', 500),
        sourcePrompt: _clipImagePromptDiagnosticText(raw.sourcePrompt || '', 3000),
        cleanedPrompt: _clipImagePromptDiagnosticText(raw.cleanedPrompt || '', 2600),
        finalPrompt: _clipImagePromptDiagnosticText(raw.finalPrompt || '', 3000),
        negativePrompt: _clipImagePromptDiagnosticText(raw.negativePrompt || '', 1600),
        stylePrompt: _clipImagePromptDiagnosticText(raw.stylePrompt || '', 1200),
        story: _clipImagePromptDiagnosticText(raw.story || '', 2000),
        imageWorld: {
          locationPrompt: _clipImagePromptDiagnosticText(imageWorld.locationPrompt || '', 260),
          visibleActionHint: _clipImagePromptDiagnosticText(imageWorld.visibleActionHint || '', 500),
          visibleCharacters: _clipImagePromptDiagnosticText(imageWorld.visibleCharacters || '', 300),
          summaryText: _clipImagePromptDiagnosticText(imageWorld.summaryText || '', 1200)
        },
        lengths: _cloneForAiSnapshot(raw.lengths || {}),
        risks: Array.isArray(raw.risks) ? raw.risks.slice(0, 12).map(function (risk) {
          return {
            id: _clipImagePromptDiagnosticText(risk && risk.id || '', 120),
            message: _clipImagePromptDiagnosticText(risk && risk.message || '', 240)
          };
        }) : [],
        limits: _cloneForAiSnapshot(raw.limits || {})
      };
    } catch (e) {
      return {
        available: false,
        reason: _clipImagePromptDiagnosticText(e && e.message || e, 240)
      };
    }
  }

  function _buildAIErrorReport(baseDebug, cacheInfo) {
    var V = getV();
    var report = {
      reportSchemaVersion: 2,
      privacyNote: 'This report contains game/mod diagnostic information, including the current visible story/page text and choices. It does not include API keys, full saves, localStorage contents, or personal prompt text.',
      generatedAt: new Date().toISOString(),
      page: {
        href: String(location && location.href || ''),
        title: String(document && document.title || ''),
        userAgent: String(navigator && navigator.userAgent || ''),
      },
      versions: {
        modName: 'AIStoryGen',
        modVersion: window.AIStoryGen.VERSION || 'unknown',
        expectedBootVersion: window.AIStoryGen.EXPECTED_BOOT_VERSION || 'unknown',
        expectedMacroFile: window.AIStoryGen.EXPECTED_MACRO_FILE || 'unknown',
        versionDiagnostics: _getAiVersionDiagnostics(),
        gameVersionText: (function () {
          try {
            var text = $('#gameVersionDisplay, #gameVersionDisplay2').map(function () { return $(this).text(); }).get().join(' ');
            return String(text || '').replace(/\s+/g, ' ').trim().slice(0, 120);
          } catch (_) {
            return '';
          }
        })(),
      },
      state: {
        passage: (typeof State !== 'undefined' && State.passage) || '',
        stateIndex: (typeof State !== 'undefined' && State.activeIndex != null) ? State.activeIndex : null,
        variablesKnown: !!V,
      },
      configSummary: _getSafeAIConfigSummary(),
      pixelConfigSummary: _getSafeAIPixelConfigSummary(),
      runtimeStats: _getAiRuntimeStatsDebugState(),
      currentPageSnapshot: _collectCurrentAIPageSnapshot(),
      visibleErrors: _collectVisibleAIErrorTexts(),
      recentErrors: _cloneForAiSnapshot(_aiErrorLog || []),
      consistencyBlockedEffectSummary: _getConsistencyBlockedEffectSummary(),
      debugState: baseDebug || null,
      modLoaderCache: cacheInfo || null,
    };
    report.pixelPromptDiagnostic = _getSafeAIPixelPromptDiagnostic(report.currentPageSnapshot);
    try {
      report.diagnosticSummary = ErrorReportSummaryModule.build(report);
    } catch (summaryError) {
      report.diagnosticSummary = {
        schemaVersion: ErrorReportSummaryModule && ErrorReportSummaryModule.schemaVersion || null,
        severity: 'warning',
        headline: '错误报告摘要生成失败。',
        error: String(summaryError && summaryError.message || summaryError)
      };
    }
    try {
      if (report.debugState && report.debugState.cfg) {
        report.debugState.cfg.hasApiKey = !!report.debugState.cfg.hasApiKey;
      }
    } catch (_) {}
    return report;
  }

  var ErrorReportUI = ErrorReportUIModule.create({
    $: $,
    mountFloatingPanel: _mountAiFloatingPanel,
    recordError: _recordAIError,
    showUserMessage: _showAIUserMessage
  });
  window.AIStoryGen.ErrorReportUI = ErrorReportUI;

  function _copyTextToClipboard(text) {
    return ErrorReportUI.copyTextToClipboard(text);
  }

  function _showAITextCopyFallback(title, hint, text, reason) {
    return ErrorReportUI.showTextFallback(title, hint, text, reason);
  }

  function _formatIssueList(lines, fallback) {
    lines = Array.isArray(lines) ? lines : [];
    lines = lines.map(function (line) { return String(line || '').trim(); }).filter(Boolean);
    if (!lines.length && fallback) lines = [fallback];
    return lines.map(function (line) { return '- ' + line; }).join('\n');
  }

  function _isIgnorableAIReportIssueText(text) {
    text = String(text || '');
    return /\[manual_export\]|User exported error report|manual_export/i.test(text)
      || /请先在侧边栏[「"]?OPTIONS|请先在侧边栏.*配置 API 密钥|configure API key/i.test(text);
  }

  function _isIgnorableAIRecentError(entry) {
    var type = String(entry && entry.type || '');
    var message = String(entry && entry.message || entry || '');
    return type === 'manual_export' || _isIgnorableAIReportIssueText('[' + type + '] ' + message);
  }

  function _formatIssueNumberedList(lines, fallback) {
    lines = Array.isArray(lines) ? lines : [];
    lines = lines.map(function (line) { return String(line || '').replace(/^\d+\.\s*/, '').trim(); }).filter(Boolean);
    if (!lines.length && fallback) lines = [fallback];
    return lines.map(function (line, idx) { return String(idx + 1) + '. ' + line; }).join('\n');
  }

  function _clipIssueText(text, maxLen) {
    text = _cleanAIReportText(text, maxLen || 2400);
    return text || '（无可见文本）';
  }

  function _buildAIErrorIssueTemplate(report) {
    report = report || {};
    var summary = report.diagnosticSummary || {};
    var config = report.configSummary || {};
    var page = report.page || {};
    var versions = report.versions || {};
    var state = report.state || {};
    var snapshot = report.currentPageSnapshot || {};
    var lines = [];
    var summaryLines = Array.isArray(summary.lines) ? summary.lines.slice(0, 8) : [];
    if (summaryLines.length && summary.headline && summaryLines[0] === summary.headline) summaryLines = summaryLines.slice(1);
    var actions = Array.isArray(summary.actionLines) ? summary.actionLines.slice(0, 8) : [];
    var visibleErrors = Array.isArray(report.visibleErrors) ? report.visibleErrors.filter(function (line) {
      return !_isIgnorableAIReportIssueText(line);
    }).slice(-6) : [];
    var recentErrors = Array.isArray(report.recentErrors) ? report.recentErrors.filter(function (entry) {
      return !_isIgnorableAIRecentError(entry);
    }).slice(-6).map(function (entry) {
      return '[' + (entry && entry.type || 'unknown') + '] ' + String(entry && entry.message || entry || '').slice(0, 220);
    }) : [];
    var blockedSummary = Array.isArray(report.consistencyBlockedEffectSummary)
      ? report.consistencyBlockedEffectSummary.slice(0, 8)
      : [];
    if (!blockedSummary.length && report.debugState && Array.isArray(report.debugState.consistencyBlockedEffectSummary)) {
      blockedSummary = report.debugState.consistencyBlockedEffectSummary.slice(0, 8);
    }
    var consistencyDiagnostics = report.debugState && Array.isArray(report.debugState.consistencyDiagnostics)
      ? report.debugState.consistencyDiagnostics.slice(-8).map(function (diag) {
        diag = diag || {};
        var parts = ['[' + (diag.level || 'info') + '] ' + (diag.code || 'unknown')];
        if (diag.field) parts.push('field=' + diag.field);
        if (diag.value != null) parts.push('value=' + String(diag.value).slice(0, 80));
        if (diag.rule) parts.push('rule=' + String(diag.rule).slice(0, 120));
        if (diag.message) parts.push(String(diag.message).slice(0, 180));
        return parts.join(' / ');
      })
      : [];
    var apiLog = Array.isArray(config.apiRequestLog) ? config.apiRequestLog.slice(0, 5).map(function (entry) {
      entry = entry || {};
      var parts = [
        '[' + (entry.status || 'unknown') + ']',
        entry.purpose ? ('purpose=' + entry.purpose) : '',
        entry.provider || config.apiProvider || '自定义',
        entry.model || config.model || '未填写模型'
      ].filter(Boolean);
      if (entry.durationMs != null) parts.push(String(entry.durationMs) + 'ms');
      if (entry.finishReason) parts.push('finish=' + entry.finishReason);
      if (entry.error && entry.error.type) parts.push('error=' + entry.error.type + (entry.error.statusCode ? ' HTTP ' + entry.error.statusCode : ''));
      return parts.join(' / ');
    }) : [];
    var choices = Array.isArray(snapshot.aiChoices) && snapshot.aiChoices.length ? snapshot.aiChoices : (Array.isArray(snapshot.visibleChoices) ? snapshot.visibleChoices : []);
    choices = choices.slice(0, 12).map(function (choice) {
      return String(choice && choice.label || '').slice(0, 160) + (choice && choice.passage ? ' -> ' + String(choice.passage).slice(0, 80) : '');
    }).filter(Boolean);
    var pixelDiag = report.pixelPromptDiagnostic || {};
    var pixelRiskLines = Array.isArray(pixelDiag.risks) ? pixelDiag.risks.slice(0, 8).map(function (risk) {
      return '[' + String(risk && risk.id || 'unknown').slice(0, 80) + '] ' + String(risk && risk.message || '').slice(0, 180);
    }) : [];

    lines.push('## 问题描述');
    lines.push('请在这里简单写清楚：你点击了什么、预期发生什么、实际发生什么。');
    lines.push('');
    lines.push('## 诊断摘要');
    lines.push('- 严重度：' + (summary.severity || 'unknown'));
    lines.push('- ' + (summary.headline || '暂无诊断摘要'));
    lines.push(_formatIssueList(summaryLines, '暂无额外诊断线索。'));
    lines.push('');
    lines.push('## 最近被系统拦截的 AI 变化');
    lines.push(_formatIssueList(blockedSummary, '没有记录到被一致性系统拦截的变化。'));
    lines.push('');
    lines.push('## 最近一致性诊断');
    lines.push(_formatIssueList(consistencyDiagnostics, '没有记录到一致性诊断。'));
    lines.push('');
    lines.push('## 建议操作');
    lines.push(_formatIssueNumberedList(actions, '暂无自动建议。请附加完整错误报告 JSON。'));
    lines.push('');
    lines.push('## 环境');
    lines.push('- Mod：织境空间 ' + (versions.modVersion || window.AIStoryGen.VERSION || 'unknown'));
    lines.push('- 游戏版本：' + (versions.gameVersionText || 'unknown'));
    lines.push('- Passage：' + (state.passage || snapshot.passage || 'unknown'));
    lines.push('- State index：' + (state.stateIndex != null ? state.stateIndex : (snapshot.stateIndex != null ? snapshot.stateIndex : 'unknown')));
    lines.push('- URL：' + String(page.href || '').slice(0, 260));
    lines.push('- 浏览器：' + String(page.userAgent || '').slice(0, 260));
    lines.push('- API：' + (config.apiProvider || 'custom') + ' / ' + (config.model || '未填写模型'));
    lines.push('- 剧情生成模式：choiceTriggerMode=' + String(config.choiceTriggerMode == null ? 'unknown' : config.choiceTriggerMode) + '，aiReplaceLinks=' + String(config.aiReplaceLinks == null ? 'unknown' : config.aiReplaceLinks));
    lines.push('');
    lines.push('## 当前页面文本（安全截断）');
    lines.push('```text');
    lines.push(_clipIssueText(snapshot.aiStoryText || snapshot.visibleText || snapshot.originalStoryText, 2400));
    lines.push('```');
    lines.push('');
    lines.push('## 当前选项（安全截断）');
    lines.push(_formatIssueList(choices, '没有采集到当前选项。'));
    lines.push('');
    lines.push('## 可见错误 / 最近内部错误');
    lines.push(_formatIssueList(visibleErrors.concat(recentErrors), '没有采集到可见错误。'));
    lines.push('');
    lines.push('## 最近 API 请求摘要');
    lines.push(_formatIssueList(apiLog, '没有最近 API 请求记录。'));
    lines.push('');
    lines.push('## 生图提示词诊断（安全截断）');
    if (pixelDiag && pixelDiag.available) {
      lines.push('- Passage：' + String(pixelDiag.passage || 'unknown').slice(0, 120));
      lines.push('- 游戏状态：location=' + String(pixelDiag.scene && pixelDiag.scene.location || 'unknown').slice(0, 80) + '，area=' + String(pixelDiag.scene && pixelDiag.scene.area || 'unknown').slice(0, 80));
      lines.push('- 场景提示：' + String(pixelDiag.locationPrompt || '未识别').slice(0, 240));
      lines.push('- 可视动作：' + String(pixelDiag.visualAction || '未识别').slice(0, 320));
      lines.push('- 长度：final=' + String(pixelDiag.lengths && pixelDiag.lengths.finalPrompt || 0) + '，negative=' + String(pixelDiag.lengths && pixelDiag.lengths.negativePrompt || 0) + '，negative发送上限=' + String(pixelDiag.limits && pixelDiag.limits.negativePromptApiLimit || 800));
      lines.push('- 风险：');
      lines.push(_formatIssueList(pixelRiskLines, '没有记录到明显生图提示词风险。'));
      lines.push('```text');
      lines.push('finalPrompt: ' + _clipIssueText(pixelDiag.finalPrompt || '', 1800));
      lines.push('');
      lines.push('negativePrompt: ' + _clipIssueText(pixelDiag.negativePrompt || '', 1000));
      lines.push('```');
    } else {
      lines.push(_formatIssueList([pixelDiag && pixelDiag.reason ? String(pixelDiag.reason) : '当前没有可用生图诊断。'], '当前没有可用生图诊断。'));
    }
    lines.push('');
    lines.push('## 隐私说明');
    lines.push('此模板不包含 API Key、完整存档或 localStorage 内容，但包含当前可见剧情文本和选项；如果剧情内容不想公开，请发出前自行删减。若需要进一步排查，请同时附加“导出错误报告到文件”生成的 JSON。');
    return lines.join('\n');
  }

  function _createAIErrorReportPayload() {
    var base = null;
    try {
      base = window.AIStoryGen && typeof window.AIStoryGen.dumpDebugState === 'function'
        ? window.AIStoryGen.dumpDebugState()
        : null;
    } catch (e) {
      _recordAIError('report_dump_failed', e);
    }
    return _readAiModLoaderCacheInfo().catch(function (e) {
      _recordAIError('report_modloader_cache_failed', e);
      return { available: false, reason: String(e && e.message || e) };
    }).then(function (cacheInfo) {
      var report = _buildAIErrorReport(base, cacheInfo);
      var stamp = new Date().toISOString().replace(/[:.]/g, '-');
      var filename = 'WovenRealm-error-report-' + stamp + '.json';
      var jsonText = JSON.stringify(report, null, 2);
      var issueText = _buildAIErrorIssueTemplate(report);
      return { report: report, filename: filename, jsonText: jsonText, issueText: issueText };
    });
  }

  function exportAIErrorReportToFile() {
    return ErrorReportUI.exportReportToFile(_createAIErrorReportPayload);
  }

  function exportAIErrorReportToClipboard() {
    return ErrorReportUI.exportReportToClipboard(_createAIErrorReportPayload);
  }

  function exportAIErrorIssueTemplateToClipboard() {
    return ErrorReportUI.exportIssueTemplateToClipboard(_createAIErrorReportPayload);
  }

  function _buildApiDiagnosticSnippet() {
    var cfg = loadCfg();
    var recent = [];
    try { recent = RequestLog && RequestLog.getRecent ? RequestLog.getRecent(5) : []; } catch (_) { recent = []; }
    return RequestLogModule.buildDiagnosticSnippet({
      config: {
        apiProvider: cfg.apiProvider || '',
        endpoint: cfg.endpoint || '',
        model: cfg.model || '',
        hasApiKey: !!String(cfg.apiKey || '').trim()
      },
      recent: recent,
      lastProviderProbe: _cloneForAiSnapshot(window.AIStoryGen.lastProviderProbe || null),
      lastApiError: _cloneForAiSnapshot(window.AIStoryGen.lastApiError || null),
      limit: 5
    });
  }

  function copyApiDiagnosticSnippetToClipboard() {
    var text = _buildApiDiagnosticSnippet();
    return _copyTextToClipboard(text).then(function () {
      _showAITextCopyFallback('API 诊断片段已准备好', '如果手机剪贴板没有内容，请长按下方文本手动复制。', text, '');
      _showAIUserMessage('API 诊断片段已复制到剪贴板。');
      return text;
    }, function (err) {
      _showAITextCopyFallback('API 诊断片段', '复制失败，请长按下方文本手动复制。', text, err && err.message || err);
      _showAIUserMessage('复制失败，请手动复制 API 诊断片段。', true);
      return text;
    });
  }

  function exportAIErrorReport() {
    return exportAIErrorReportToFile();
  }

  window.AIStoryGen.dumpDebugState = function () {
    var $passage = $('#passages .passage');
    return {
      version: window.AIStoryGen.VERSION || 'unknown',
      intimateAddonLoaded: _isIntimateAddonLoaded(),
      intimateAddonVersion: window.AIStoryGenIntimateAddon && window.AIStoryGenIntimateAddon.version || '',
      versionDiagnostics: _getAiVersionDiagnostics(),
      layout: _applyUILayoutMode('debug dump'),
      passage: (typeof State !== 'undefined' && State.passage) || null,
      sceneStructure: _cloneForAiSnapshot(buildScene()),
      lastStructuredEvent: (function () {
        var vars = _getStateVariables();
        var log = vars && Array.isArray(vars.aiStoryGenEventLog) ? vars.aiStoryGenEventLog : [];
        return log.length ? _cloneForAiSnapshot(log[log.length - 1]) : null;
      })(),
      controllerSchemas: _getAiControllerDebugState(),
      replace: {
        active: _aiReplaceActive,
        originPassage: _aiReplaceOriginPassage,
        targetLabel: _aiReplaceTargetLabel,
        targetPassage: _aiReplaceTargetPassage,
        roundCount: _aiReplaceRoundCount,
        locationArrived: _aiLocationArrived,
        currentLocationLabel: _aiCurrentLocationLabel,
        currentLocationPassage: _aiCurrentLocationPassage,
        lastLocationDecision: _cloneForAiSnapshot(_aiLastLocationDecision || null),
        availableDestinations: (_aiAvailableDestinations || []).slice(0, 20).map(function (d) {
          return { raw: d.raw, label: d.label, source: d.source || '' };
        }),
        sessionHTMLLen: (_aiReplaceSessionHTML || '').length,
        autoChoicesBusy: _autoChoicesBusy,
        roundHistoryLen: _aiRoundHistory.length,
        forwardStackLen: _aiForwardStack.length,
      },
      dom: {
        passageTextLen: ($passage.text() || '').trim().length,
        hasRegenBtn: $passage.find('.ai-regen-narrative-link').length > 0,
        hasBookmarkBtn: $passage.find('.ai-bookmark-link').length > 0,
        hasOriginalWrap: $passage.find('.ai-original-wrap').length > 0,
        originalWrapHidden: $passage.find('.ai-original-wrap').filter(function () {
          return this.style.display === 'none' || $(this).css('display') === 'none';
        }).length > 0,
        hasReplacedContent: $passage.find('.ai-replaced-content').length > 0,
        hasNarrativeWrap: $passage.find('.ai-narrative-wrap').length > 0,
        hasLoading: $passage.find('.ai-gen-loading').length > 0,
        aiInjectedLinks: $passage.find('.ai-injected-link').length,
        aiChoices: $('#passages .ai-choices').length,
        aiInjectedRows: $passage.find('.ai-injected-row').length,
        blockingBackdrops: $('.ai-item-use-backdrop').length,
        intimateFixedActions: OptionalAddonBridge.getLegacyUiStatus().intimateFixedActions,
        customOverlay: (function () {
          var overlay = document.getElementById('customOverlay');
          if (!overlay) return null;
          return {
            hidden: overlay.classList ? overlay.classList.contains('hidden') : null,
            dataOverlay: overlay.getAttribute('data-overlay') || '',
            display: $(overlay).css('display') || ''
          };
        })(),
        topElementAtCenter: (function () {
          try {
            var el = document.elementFromPoint(Math.floor(window.innerWidth / 2), Math.floor(window.innerHeight / 2));
            if (!el) return '';
            return (el.tagName || '').toLowerCase() + (el.id ? '#' + el.id : '') + (el.className ? '.' + String(el.className).replace(/\s+/g, '.') : '');
          } catch (_) {
            return '';
          }
        })(),
      },
      panels: _getAiPanelDebugState(),
      domMaintenance: _getAiDomMaintenanceDebugState(),
      settingsInjection: _getAiSettingsInjectionDebugState(),
      runtimeStats: _getAiRuntimeStatsDebugState(),
      storage: _getAiStorageDebugState(),
      modLoaderCacheCleanup: _cloneForAiSnapshot(window.AIStoryGen._lastModLoaderCacheCleanup || null),
      nativeEventGuard: NativeEventGuard && typeof NativeEventGuard.getStatus === 'function' ? NativeEventGuard.getStatus() : null,
      nativeScene: _getNativeSceneStatus('debug dump'),
      cfg: (function () {
        var c = loadCfg();
        return {
          aiReplaceLinks: c.aiReplaceLinks,
          choiceTriggerMode: _getChoiceTriggerMode(c),
          autoChoices: c.autoChoices,
          language: c.language,
          hasApiKey: _isApiConfigured(c),
          endpoint: c.endpoint || '',
        };
      })(),
    };
  };

  window.AIStoryGen.dumpDebugStateAsync = function () {
    var base = window.AIStoryGen.dumpDebugState();
    return _readAiModLoaderCacheInfo().then(function (cacheInfo) {
      base.modLoaderCache = cacheInfo;
      return base;
    });
  };
  window.AIStoryGen.exportErrorReport = exportAIErrorReport;
  window.AIStoryGen.exportErrorReportToFile = exportAIErrorReportToFile;
  window.AIStoryGen.exportErrorReportToClipboard = exportAIErrorReportToClipboard;
  window.AIStoryGen.exportErrorIssueTemplateToClipboard = exportAIErrorIssueTemplateToClipboard;
  window.AIStoryGen.copyApiDiagnosticSnippetToClipboard = copyApiDiagnosticSnippetToClipboard;
  window.AIStoryGen.clearModLoaderCache = function () {
    return _clearAiModLoaderCache({ force: true, reason: 'manual api call' });
  };
  window.AIStoryGen.clearStaleModLoaderCache = function () {
    return _clearAiModLoaderCache({ force: false, reason: 'manual stale-only api call' });
  };
  _scheduleAiModLoaderCacheAutoCleanup();

  window.AIStoryGen.tryAiBackward = _tryAiBackward;
  window.AIStoryGen.tryAiForward = _tryAiForward;
  window.AIStoryGen.debugPendingItemUses = function () {
    return _cloneForAiSnapshot(_pendingAiItemUses || []);
  };
  window.AIStoryGen.debugLastItemUses = function () {
    return _cloneForAiSnapshot(_lastAiItemsUsedForTurn || []);
  };

})();











