/* ============================================================
 * AIStoryGen world knowledge base
 * Provides compact, retrieved DoL background facts for prompts.
 * Static knowledge supplements native state, but never overrides it.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var KNOWLEDGE_VERSION = '2026-07-14.1';
  var KNOWLEDGE_SOURCE = 'wovenrealm-static-dol-context';

  function text(value, maxLen) {
    var out = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    if (maxLen && out.length > maxLen) out = out.slice(0, maxLen).trim();
    return out;
  }

  function lower(value) {
    return text(value).toLowerCase();
  }

  function compact(value) {
    return lower(value).replace(/\s+/g, '');
  }

  function pushUnique(list, value, max) {
    value = text(value, 180);
    if (!value || list.indexOf(value) >= 0) return;
    if (max && list.length >= max) return;
    list.push(value);
  }

  function getReleaseSummary() {
    return root.AIStoryGenWorldSummaryGenerated ||
      (root.AIStoryGen && root.AIStoryGen.WorldSummaryGenerated) ||
      null;
  }

  function releaseSummaryMeta(summary) {
    summary = summary || getReleaseSummary();
    if (!summary) {
      return {
        available: false
      };
    }
    return {
      available: true,
      schemaVersion: summary.schemaVersion || null,
      generatedAt: text(summary.generatedAt || '', 80),
      policy: text(summary.policy || '', 80),
      sourceMeta: summary.sourceMeta || null,
      sourceCounts: summary.sourceCounts || {},
      counts: summary.counts || {
        locations: (summary.locations || []).length,
        npcs: (summary.npcs || []).length,
        routines: (summary.routines || []).length,
        sublocations: (summary.sublocations || []).length
      }
    };
  }

  function compactReleaseLocation(row) {
    if (!row) return null;
    return {
      locId: text(row.locId || '', 80),
      suggestedPassage: text(row.suggestedPassage || '', 100),
      passageCount: row.passageCount || 0,
      definition: row.definition || null,
      exits: (row.exits || []).slice(0, 5).map(function (exit) {
        return {
          label: text(exit.label || '', 60),
          target: text(exit.target || '', 100)
        };
      }),
      candidates: (row.candidates || []).slice(0, 5).map(function (candidate) {
        return {
          passage: text(candidate.passage || '', 100),
          linkCount: candidate.linkCount || 0
        };
      })
    };
  }

  function matchReleaseLocation(summary, context) {
    if (!summary || !summary.locations) return null;
    context = context || {};
    var facts = context.facts || {};
    var currentMap = context.currentMap || {};
    var current = currentMap.current || {};
    var keys = [
      current.locId,
      current.passage,
      current.label,
      facts.location,
      facts.passage
    ].map(function (value) { return compact(value); }).filter(Boolean);
    for (var i = 0; i < summary.locations.length; i++) {
      var row = summary.locations[i];
      var rowKeys = [row.locId, row.suggestedPassage].map(function (value) { return compact(value); });
      var candidates = row.candidates || [];
      for (var c = 0; c < candidates.length; c++) rowKeys.push(compact(candidates[c].passage));
      for (var k = 0; k < keys.length; k++) {
        if (rowKeys.indexOf(keys[k]) >= 0) return row;
      }
    }
    return null;
  }

  function collectReleaseAdjacent(summary, context) {
    var out = [];
    if (!summary || !summary.locations || !context || !context.currentMap) return out;
    var adjacent = context.currentMap.adjacent || [];
    adjacent.forEach(function (node) {
      if (out.length >= 5) return;
      var key = compact(node.locId || node.passage || node.label);
      if (!key) return;
      for (var i = 0; i < summary.locations.length; i++) {
        var row = summary.locations[i];
        if (compact(row.locId) === key || compact(row.suggestedPassage) === key) {
          out.push(compactReleaseLocation(row));
          return;
        }
      }
    });
    return out;
  }

  function collectReleaseSublocations(summary, context) {
    var out = [];
    if (!summary || !summary.sublocations) return out;
    var facts = (context && context.facts) || {};
    var currentMap = (context && context.currentMap) || {};
    var hay = [
      facts.passage,
      facts.location,
      currentMap.current && currentMap.current.passage,
      currentMap.current && currentMap.current.label
    ].join(' ');
    var compactHay = compact(hay).replace(/_/g, '');
    summary.sublocations.forEach(function (row) {
      if (out.length >= 5) return;
      var compactId = compact(row.id || '').replace(/_/g, '');
      if (containsAny(hay, (row.passages || []).concat([row.id])) || (compactId && compactHay.indexOf(compactId) >= 0)) {
        out.push({
          id: text(row.id || '', 80),
          passageCount: row.passageCount || 0,
          passages: (row.passages || []).slice(0, 5).map(function (name) { return text(name, 100); }),
          locs: (row.locs || []).slice(0, 5).map(function (loc) { return text(loc, 80); })
        });
      }
    });
    return out;
  }

  function collectReleaseNpcs(summary, context) {
    var out = [];
    if (!summary || !summary.npcs) return out;
    var names = [];
    var canon = (context && context.npcCanonicalNames) || {};
    Object.keys(canon).forEach(function (key) {
      names.push(key);
      names.push(canon[key]);
    });
    var npcContext = context && context.npcContext;
    ((npcContext && npcContext.visible) || []).forEach(function (npc) {
      names.push(npc.key);
      names.push(npc.name);
      names.push(npc.canonicalName);
    });
    var hay = names.join(' ');
    summary.npcs.forEach(function (npc) {
      if (out.length >= 5) return;
      if (!containsAny(hay, [npc.key, npc.zh])) return;
      out.push({
        key: text(npc.key || '', 80),
        zh: text(npc.zh || '', 80),
        evidenceCount: npc.evidenceCount || 0,
        hasNnpcImages: !!npc.hasNnpcImages
      });
    });
    return out;
  }

  function collectReleaseSummary(context, input) {
    var summary = getReleaseSummary();
    if (!summary) return null;
    var matchedLocation = matchReleaseLocation(summary, context);
    var meta = releaseSummaryMeta(summary);
    return {
      schemaVersion: meta.schemaVersion,
      generatedAt: meta.generatedAt,
      policy: meta.policy,
      sourceMeta: meta.sourceMeta,
      counts: meta.counts,
      sourceCounts: meta.sourceCounts,
      currentLocation: compactReleaseLocation(matchedLocation),
      adjacentLocations: collectReleaseAdjacent(summary, context),
      sublocations: collectReleaseSublocations(summary, context),
      npcs: collectReleaseNpcs(summary, context),
      routineIds: (summary.routines || []).slice(0, 8).map(function (row) { return text(row.id || '', 80); }),
      note: 'Release summary is structural only and contains no original passage prose. Native current state and handwritten knowledge still win.'
    };
  }

  function containsAny(haystack, values) {
    haystack = lower(haystack);
    var tight = compact(haystack);
    values = values || [];
    for (var i = 0; i < values.length; i++) {
      var raw = text(values[i]);
      if (!raw) continue;
      if (haystack.indexOf(raw.toLowerCase()) >= 0) return true;
      if (tight.indexOf(compact(raw)) >= 0) return true;
    }
    return false;
  }

  var LOCATION_KNOWLEDGE = [
    {
      id: 'school',
      label: '学校',
      match: ['school', '学校', '教室', '课堂', 'School Library', '学校图书馆', 'School Toilets', 'School Hallways', 'Science Classroom'],
      facts: [
        '学校包含前院、走廊、教室、科学教室、厕所、医务室、图书馆、泳池、屋顶和后院等细分空间。',
        '上课日的课程状态必须服从原版当前时间；上午上课时不要写成第一节课还没开始。',
        '学校图书馆是安静的学习/查资料空间，适合写阅读、躲避、整理线索或等待下课。'
      ],
      cautions: [
        '不要把学校统称覆盖当前细分地点；如果 current_map 写着学校图书馆、厕所或医务室，就使用该细分空间。',
        '不要自行发明精确课表、老师安排或考试，除非当前页面文本或原版状态支持。'
      ]
    },
    {
      id: 'temple',
      label: '神殿',
      match: ['temple', '神殿', '修道院', 'Temple Library', 'Temple Garden', 'Temple Cloister'],
      facts: [
        '神殿包含主厅、回廊、花园、宿舍、床铺、淋浴间、忏悔室和图书馆等空间。',
        '神殿氛围通常更安静、克制，和悉尼相关剧情常与信仰、纯洁、规训或犹豫有关。'
      ],
      cautions: [
        '不要把神殿图书馆写成学校图书馆；两者是不同地点。',
        '神殿仪式、试炼或特殊事件必须以当前页面和可见选项为准。'
      ]
    },
    {
      id: 'forest_cabin',
      label: '森林小屋',
      match: ['forest cabin', 'eden', '伊甸', 'Eden Clearing', 'Forest Cabin', 'cabin'],
      facts: [
        '伊甸小屋位于森林区域，常见空间包括小屋内、空地、炉边、泉水、种植圃和周边林地。',
        '伊甸相关互动应重视沉默、警觉、照料、狩猎、炉火、木屋和森林边界感。'
      ],
      cautions: [
        '不要把伊甸小屋和孤儿院的家混为一谈。',
        '远离森林小屋时，不要让伊甸突然在场，除非原版状态或剧情明确支持。'
      ]
    },
    {
      id: 'farm',
      label: '农场',
      match: ['farm', '农场', 'Farm Work', 'Farm Kennel', 'Farm Lab', 'Alex'],
      facts: [
        '农场包含田地、犬舍、淋浴间、实验室、住处和周边林地等空间。',
        '亚历克斯相关剧情常与农活、动物、农场经营和信任变化有关。'
      ],
      cautions: [
        '不要把农场实验室写成凯拉尔宅邸实验室。',
        '农场工作、动物和任务进度以当前原版状态为准。'
      ]
    },
    {
      id: 'kylar_manor',
      label: '凯拉尔宅邸',
      match: ['kylar manor', 'manor', '宅邸', '凯拉尔', 'Kylar', 'Manor Lab', 'Manor Kylar Room', 'Manor Garden'],
      facts: [
        '凯拉尔宅邸包含卧室、实验室、花园和宅邸内部空间。',
        '凯拉尔相关剧情常带有窥视、执着、紧张或过分亲近的气氛，但必须服从当前在场状态。'
      ],
      cautions: [
        '不要把宅邸实验室、凯拉尔卧室和浴室互相混写；使用 current_map 的当前细分地点。',
        '不要把“Kylar”翻译成乔丹或其他近似名字，标准中文名是凯拉尔。'
      ]
    },
    {
      id: 'hospital',
      label: '医院',
      match: ['hospital', '医院', 'ward', '病房', '候诊', 'infirmary'],
      facts: [
        '医院通常是治疗、检查、等待和恢复相关地点，和学校医务室不是同一个地点。',
        '疼痛、创伤、疲劳等状态高时，医院场景应体现医疗环境和身体状况。'
      ],
      cautions: [
        '检查流程、治疗结算和医疗 UI 以原版选项为准，不要把价格或按钮当成剧情事实。'
      ]
    },
    {
      id: 'shop',
      label: '商店/交易页面',
      match: ['shop', 'store', 'market', '商店', '市场', '购物', 'Adult Shop', 'Connudatus Markets'],
      facts: [
        '商店、市场和交易页面包含价格、购买、出售、工作或浏览选项。',
        '商品价格、货币变化和库存变化必须来自原版状态或 AI_EVENT 的明确结构化字段。'
      ],
      cautions: [
        '不要把商店 UI、价格表、按钮或商品列表扩写成已经发生的剧情。',
        '金钱变化必须在正文明确写出具体金额和原因，并在 AI_EVENT moneyChange 中一致。'
      ]
    },
    {
      id: 'orphanage_home',
      label: '孤儿院/卧室',
      match: ['orphanage', '孤儿院', 'bedroom', '卧室', 'home', 'Bathroom', 'bathroom', '浴室', 'Loft', 'Ward'],
      facts: [
        '玩家的家与孤儿院相关，常见空间包括卧室、浴室、走廊、宿舍、阁楼和孤儿院大厅。',
        '卧室和浴室是室内私人空间；除非当前页面或在场状态明确支持，不要写成森林、街道或公共场所。',
        '罗宾、贝利等孤儿院相关人物是否在场必须服从当前页面和在场 NPC。'
      ],
      cautions: [
        '不要把 home/bathroom/bedroom 的室内场景误写成森林小屋或户外林地。',
        '读取到 Bathroom 时优先表现浴室环境，不要沿用上一轮地点。'
      ]
    },
    {
      id: 'town_streets',
      label: '城镇街区',
      match: ['town', 'street', 'Domus Street', 'Danube Street', 'Elk Street', 'Oxford Street', '街', '巷', '商业街', '住宅区'],
      facts: [
        '城镇街区包含住宅区、商业区、学校周边、商店、咖啡馆、警察局、公园、医院和车站等日常空间。',
        '街道场景通常适合移动、偶遇、观察、等待、躲避和进入建筑。',
        '街道不是具体室内地点；如果 current_map 有更细的建筑或房间，应优先使用细分地点。'
      ],
      cautions: [
        '不要把“跑、走、离开、躲避”等动作词当成地点。',
        '城镇远距离跳转需要可见链接、交通、追逐、带路或其他明确过渡。'
      ]
    },
    {
      id: 'pub_brothel_club',
      label: '酒吧/妓院/俱乐部',
      match: ['pub', 'bar', 'brothel', 'strip club', '酒吧', '妓院', '脱衣舞', '俱乐部', 'stage', 'kitchen', 'dressing room'],
      facts: [
        '酒吧、妓院和脱衣舞俱乐部是不同经营场所，可能包含吧台、舞台、包间、厨房、浴室、化妆间和管理区域。',
        '工作、服务、表演、结算和雇佣流程以原版当前页面和可见选项为准。',
        '布赖尔常与妓院经营相关，但是否在场必须由原版状态或页面文本支持。'
      ],
      cautions: [
        '不要把服务菜单、价格、工作按钮或结算行写成已经发生的剧情。',
        '不要把酒吧舞台、妓院房间和脱衣舞俱乐部化妆间互相混写。'
      ]
    },
    {
      id: 'beach_lake_sewers',
      label: '海滩/湖/下水道',
      match: ['beach', 'lake', 'sewer', 'sewers', 'ruins', '海滩', '湖', '湖中遗迹', '下水道', '遗迹', 'cave', '洞穴'],
      facts: [
        '海滩、湖边、湖中遗迹和下水道是不同区域；可见水域、洞穴、遗迹、管道或潮湿空间时应按当前细分地点描写。',
        '湖中遗迹和下水道常包含石门、通道、瀑布、工作间、箱匣或符号等局部空间。',
        '海滩洞穴和森林洞穴不是同一个地点。'
      ],
      cautions: [
        '不要因为出现“洞穴/遗迹”就自动写成狼洞或森林。',
        '危险遭遇、衣物丢失、探索流程必须服从原版当前页面。'
      ]
    },
    {
      id: 'museum_arcade_cafe',
      label: '博物馆/街机厅/咖啡馆',
      match: ['museum', 'arcade', 'cafe', 'café', 'coffee', '博物馆', '街机', '咖啡馆', '木马', '鉴定'],
      facts: [
        '博物馆偏向展品、鉴定、展厅和安静观察；街机厅偏向机器、灯光、游戏与人群；咖啡馆偏向餐桌、饮品、兼职和日常社交。',
        '这些地点都属于城镇公共空间，但气氛和可互动物件差异明显。'
      ],
      cautions: [
        '不要把博物馆展品、街机机器和咖啡馆柜台混成同一个场景。',
        '商品、兼职和鉴定收益必须由原版状态或明确 AI_EVENT 支持。'
      ]
    },
    {
      id: 'wolf_cave',
      label: '狼洞',
      match: ['wolf cave', 'Wolf Cave', '狼洞', 'Wolf Cave Clearing', 'Wolf Cave Bed', 'Wolf Cave Wash'],
      facts: [
        '狼洞区域包含洞穴、空地、床铺、溪流、菜地和植物丛等细分空间。',
        '狼洞与森林相关，但不是伊甸小屋；空间更偏洞穴、兽群、野外营地和生存痕迹。'
      ],
      cautions: [
        '不要把狼洞和伊甸森林小屋混为一谈。',
        '如果 current_map 写着狼洞床铺、溪流或菜地，就使用该细分空间。'
      ]
    },
    {
      id: 'tower_high_places',
      label: '高塔/高处',
      match: ['tower', 'Bird Tower', '塔', '高塔', 'rooftop', '屋顶'],
      facts: [
        '高塔、鸟塔、屋顶等高处场景通常强调高度、风、视野、石阶/平台和远处城镇或森林。',
        '鸟塔相关场景可能出现鹰或鸟类意象，但额外动物必须由正文或当前状态支持。'
      ],
      cautions: [
        '不要把高塔室内外空间和普通森林空地混写。',
        '不要自动添加未提到的宠物、猫或人群。'
      ]
    },
    {
      id: 'asylum',
      label: '疗养院',
      match: ['asylum', 'Asylum', '疗养院', '精神病院', '病院', 'Asylum Cell', 'Asylum Hallway', 'Asylum Yard'],
      facts: [
        '疗养院是封闭、管束和医疗监控色彩更强的地点，常见空间包括病房、走廊、院区、检查室、看守区和限制行动的房间。',
        '疗养院相关剧情应强调当前原版页面展示的房间、看守、治疗、约束、等待或逃离条件，而不是把它泛化成普通医院。',
        '如果当前页面是疗养院内的具体子区域，优先写该子区域的墙面、门、床、灯光、走廊、监控和可见出口。'
      ],
      cautions: [
        '疗养院不是普通医院；不要把 hospital 的候诊、治疗或公开服务流程套到 asylum 页面上。',
        '疗养院的逃离、惩罚、检查、治疗和行动限制必须服从当前原版可见选项或结构化事件，不要自行宣布已经脱离管束。',
        '不要用旧记忆或 AI 猜测覆盖当前 passage；如果当前页面写的是 Asylum，就以疗养院封闭环境为准。'
      ]
    },
    {
      id: 'moor',
      label: '荒原',
      match: ['moor', 'Moor', '荒原', '沼泽荒地', 'wasteland', 'bog', 'Bog', 'heath', 'Moor Path'],
      facts: [
        '荒原是开阔、潮湿、偏僻且方向感较弱的野外区域，常见元素包括泥地、草丛、雾气、冷风、低矮植被、远处路径和难辨方向的地形。',
        '荒原移动应更重视可见路径、当前地图相邻地点和原版链接；玩家可能只是穿过荒原、迷路、躲避、采集或观察地形。',
        '如果页面同时出现沼泽、泥水、芦苇或低地，应保持荒原/沼泽氛围，不要自动写成森林小屋、狼洞或城市街道。'
      ],
      cautions: [
        '不要把“跑、逃、离开、穿过”等动作词当成地点名；荒原到其他地点必须看 current_map、可见链接或明确剧情过渡。',
        '荒原不是森林小屋、狼洞或农场；只有当前 passage 或链接支持时才写到达这些地点。',
        '不要因为 area 或旧记忆含有 forest/town 就覆盖当前 Moor/Bog 页面。'
      ]
    },
    {
      id: 'docks',
      label: '码头',
      match: ['docks', 'Docks', 'dock', 'harbour', 'harbor', 'pier', '码头', '港口', '栈桥', '船坞', 'Docks Robin'],
      facts: [
        '码头是靠水、船只、仓库、木栈道、货物、绳索、湿冷空气和海风相关的地点，常见空间包括栈桥、仓库边、船边、码头道路和临水平台。',
        '码头剧情应优先呈现水面、船只、货物、工人、仓库或靠岸设施等当前页面支持的元素。',
        '如果码头页面与罗宾或其他角色事件相连，也必须先判断当前角色是否真正可见或被页面文本提到。'
      ],
      cautions: [
        '不要把码头事件页直接归为孤儿院、卧室或普通城镇街道；如果需要返回家中，必须有原版链接、剧情过渡或结构化到达结果支持。',
        '不要把码头的商品、任务、船只或运输选项写成已经发生，除非玩家已点击原版选项或 AI_EVENT 明确提交。',
        '生图或剧情提示词遇到 Docks 时，应避免沿用上一轮室内/森林场景。'
      ]
    },
    {
      id: 'bog',
      label: '沼泽',
      match: ['bog', 'Bog', '沼泽', '湿地', '泥沼', 'brook downstream', 'wooden pathway'],
      facts: [
        '沼泽位于森林和荒原之间，环境通常潮湿、泥泞、水浅可站立，并可能有木栈道、湿叶、溪流下游和遮蔽视线的植物。',
        '沼泽场景应优先表现湿地、水面、泥地、木板路、低矮植物和难以快速行动的地形。',
        '如果当前页面是 Bog 或 Bog Intro，应把它当作荒原/森林边缘的湿地过渡空间，而不是普通森林或普通湖边。'
      ],
      cautions: [
        '不要因为出现植物、触手或昏迷事件就把稳定沼泽地点改写成完全无关的森林小屋或地下空间。',
        '沼泽移动仍需服从 current_map、可见链接或明确剧情过渡，不要自行跳到狼洞、伊甸小屋或城镇。'
      ]
    },
    {
      id: 'chalets',
      label: '海边小屋',
      match: ['chalets', 'Chalets', 'chalet', '海边小屋', '度假小屋', '小屋岛', 'chalet island'],
      facts: [
        '海边小屋位于靠近海滩的小岛或沙地附近，常见元素包括海风、雨、沙地、潮汐、通往小屋区的道路和管理者办公室。',
        'Chalets 相关场景应保持海边、岛屿、沙地、潮湿天气和度假小屋区域的空间感。',
        '如果页面是 Chalets Work，应注意它可能是工作入口或管理页面，工作完成与收益必须服从原版状态或结构化事件。'
      ],
      cautions: [
        '不要把 Chalets 写成普通孤儿院、森林小屋或城市旅馆。',
        '不要把工作按钮、管理者提示或可选服务直接写成已经完成的剧情。'
      ]
    },
    {
      id: 'meadow',
      label: '林间草地',
      match: ['meadow', 'Meadow', '林间草地', '草地', 'solitary oak', 'long grass', 'ringed by tall trees'],
      facts: [
        '林间草地通常被高树环绕，长草拂过腿边，中间可能有一棵孤立的橡树，气氛比密林更开阔。',
        'Meadow 场景适合表现长草、树环、开阔空地、孤立橡树、昆虫声、风和从森林进入空地的过渡。',
        '如果草地页面由特殊植物或幻觉事件进入，仍应优先服从当前页面文本，不要沿用旧的室内或城市地点。'
      ],
      cautions: [
        '不要把 Meadow 自动写成 Farm、Forest Cabin 或普通 Park；它是森林中的独立开阔草地。',
        '特殊 Gwylan/催眠/植物事件必须以当前页面文本为准，静态草地知识只补充环境。'
      ]
    },
    {
      id: 'studio',
      label: '摄影工作室',
      match: ['studio', 'Photo', 'Photo Entrance', 'Photo Intro', 'photography studio', '摄影工作室', '照相馆', '拍摄棚'],
      facts: [
        '摄影工作室是一座医院对面的旧建筑，入口可能有台阶、门环、前厅、拍摄空间、服装或灯光设备。',
        'Photo/Studio 页面可能包含拍摄、等候、进入建筑、服装、摄影师或工作流程；实际拍摄和报酬必须服从原版选项或结构化事件。',
        '生图提示遇到 Photo/Studio 时，应优先表现室内拍摄空间、灯光、背景布、相机或旧建筑入口，而不是森林或街道。'
      ],
      cautions: [
        '不要把“Photo”误解成已经生成的图片或 UI 截图；这里是原版摄影工作室地点。',
        '不要把模特、服装、报酬或拍摄结果写成已发生，除非当前页面或 AI_EVENT 明确支持。'
      ]
    },
    {
      id: 'castle',
      label: '废弃城堡',
      match: ['castle', 'Castle', '废弃城堡', '城堡', 'ruined castle', 'courtyard', 'half-sunk'],
      facts: [
        '废弃城堡位于荒原区域，常见元素包括半沉没的废墟、庭院、高耸残墙、潮湿石面、流水和破败的历史感。',
        'Castle 页面应优先表现城堡庭院、石墙、废墟、水流、荒原边缘和压迫性的高大结构。',
        '城堡与鸟塔、高处和荒原可能相邻，但当前地点必须以 passage/location 为准。'
      ],
      cautions: [
        '不要把 Castle 写成普通神殿、学校或城镇建筑。',
        '如果要从城堡移动到鸟塔、荒原或其他地点，必须看原版链接、current_map 或明确剧情过渡。'
      ]
    },
    {
      id: 'hotel',
      label: '酒店',
      match: ['hotel', 'Avery Hotel', '酒店', '旅馆', 'hotel lobby', 'chandeliers', 'fountain'],
      facts: [
        '艾弗里相关酒店通常是豪华室内地点，常见元素包括大堂、吊灯、喷泉、昂贵装饰、服务人员和上层社交氛围。',
        'Avery Hotel 页面应优先表现豪华酒店内景、灯光、家具、前台/大堂和艾弗里相关社交压力。',
        '如果艾弗里在场或被明确提到，应使用原版角色名和当前可见状态；否则不要因为 hotel 自动让艾弗里出现。'
      ],
      cautions: [
        '不要把酒店写成孤儿院卧室、普通商店或摄影工作室。',
        '酒店消费、约会、金钱变化和离开方式必须服从原版状态或结构化事件。'
      ]
    },
    {
      id: 'pirate_ship',
      label: '海盗船',
      match: ['pirate_ship', 'Pirate Deck', 'Pirate Cabin', 'Pirate Bilge', 'pirate ship', '海盗船', '船舱', '甲板', '舱底', 'Captain Zephyr', 'Zephyr'],
      facts: [
        '海盗船是海上特殊地点，常见空间包括甲板、船舱、舱底、走廊、船员区域和靠近城镇或岛屿的水路。',
        'Pirate Deck 应表现海面、月光、冷风、雨雪、甲板、船帆和船体摇晃；Pirate Cabin/Bilge 应表现狭窄船内、木墙、摇晃地板、船员声响和阴影。',
        '海盗船相关剧情可能出现 Captain Zephyr、船员、被从海中带上船、走私入口或返回城镇的航行，但角色在场仍必须以当前页面文本为准。'
      ],
      cautions: [
        '不要把海盗船写成普通湖边、码头或森林洞穴；它是船上空间，除非页面已经明确靠岸或离船。',
        '不要自行宣布玩家已经逃离、靠岸或回到城镇；离开海盗船必须看原版链接、current_map 或结构化到达结果。',
        '不要把 Zephyr 或船员自动加入每一幕，除非当前文本或可见 NPC 说明他们在场。'
      ]
    },
    {
      id: 'prison',
      label: '监狱',
      match: ['prison', 'Prison Yard', 'Prison Beach', '监狱', '监狱院子', '秘密海滩', 'inmates', 'prison yard'],
      facts: [
        '监狱是受墙体、看守和囚犯活动约束的地点，常见空间包括监狱院子、围墙、锻炼区域、社交区域和监狱外秘密海滩。',
        'Prison Yard 应表现高墙、囚犯、锻炼或看守视线；Prison Beach 应表现监狱外的秘密海滩、猛烈海浪、叛乱声和可见船只。',
        '监狱相关剧情的逃离、骚乱、转移、惩罚和状态变化必须服从原版当前页面和结构化事件。'
      ],
      cautions: [
        '不要把监狱写成普通海滩、普通城镇或医院；即使在 Prison Beach，也要保留监狱外逃/封锁背景。',
        '不要自行解除囚禁、消除追捕或改变原版进程；这些必须由原版链接或 AI_EVENT 明确提交。',
        '不要因为 parent 是 sea 就把 Prison Yard 写成船上或普通海面。'
      ]
    }
  ];

  var SUBLOCATION_KNOWLEDGE = [
    {
      id: 'school_library',
      label: '学校图书馆',
      match: ['School Library', 'school library', '学校图书馆', '图书馆'],
      facts: [
        '学校图书馆是学校内部的安静学习空间，重点元素是书架、书桌、借阅区、资料、低声交谈和躲避人群。',
        '如果当前 passage 是 School Library，应优先写学校图书馆，而不是普通教室、走廊或镇上的公共图书馆。'
      ],
      cautions: [
        '不要因为地点属于 school 就把学校图书馆写成正在上课的教室；课程状态仍参考原版时间和页面文本。',
        '不要把学校图书馆和神殿图书馆混在一起。'
      ]
    },
    {
      id: 'school_toilets',
      label: '学校厕所',
      match: ['School Toilets', 'school toilets', '学校厕所', '厕所'],
      facts: [
        '学校厕所是学校内部的洗手池、隔间、瓷砖、镜子和门锁构成的封闭空间。',
        '如果当前 passage 是 School Toilets，应表现厕所/洗手间环境，而不是课堂、图书馆或室外操场。'
      ],
      cautions: [
        '不要把学校厕所写成浴室或玩家卧室浴室；它属于学校公共空间。',
        'NPC 是否在厕所内必须服从当前页面文本或可见 NPC 状态。'
      ]
    },
    {
      id: 'school_classroom',
      label: '学校教室',
      match: ['School Classroom', 'Science Classroom', 'classroom', '教室', '科学教室'],
      facts: [
        '学校教室/科学教室应表现课桌、讲台、黑板、实验器材、教师和同学等课堂元素。',
        '科学教室比普通教室更偏实验台、玻璃器皿、化学品和安全柜。'
      ],
      cautions: [
        '不要自行发明精确课程内容、考试或教师安排，除非当前页面或原版状态支持。',
        '课堂是否正在进行应服从原版时钟，而不是旧记忆。'
      ]
    },
    {
      id: 'school_rear_courtyard',
      label: '学校后院',
      match: ['School Rear Courtyard', 'rear courtyard', '学校后院', '后院'],
      facts: [
        '学校后院是学校建筑背后的室外空间，重点元素是围墙、后门、草地、阴影、操场边缘和避开主入口的人流。',
        '如果当前 passage 是 School Rear Courtyard，应写学校室外后院，而不是教室、图书馆或普通街道。'
      ],
      cautions: [
        '不要因为地点属于 school 就把后院写成正在上课的室内课堂。',
        '不要把学校后院和孤儿院后院、宅邸花园或森林空地混在一起。'
      ]
    },
    {
      id: 'school_pool',
      label: '学校泳池',
      match: ['School Pool', 'School Pool Entrance', 'pool entrance', 'school pool', '学校泳池', '泳池入口'],
      facts: [
        '学校泳池/泳池入口属于学校体育设施，重点元素是池水、瓷砖、潮湿地面、更衣入口、氯味和回声。',
        '如果当前 passage 是 School Pool Entrance，应先写泳池入口或池边过渡空间，而不是普通走廊。'
      ],
      cautions: [
        '不要把学校泳池写成海滩、湖边或公共浴室。',
        '是否正在游泳、换衣或上课必须服从当前页面文本和可见选项。'
      ]
    },
    {
      id: 'school_infirmary',
      label: '学校医务室',
      match: ['School Infirmary', 'School Infirmary Bed', 'infirmary', '医务室', '保健室'],
      facts: [
        '学校医务室是校园内的小型医疗休息空间，重点元素是病床、帘子、药柜、消毒水气味和临时休息。',
        '如果当前 passage 是 School Infirmary Bed，应写校内医务室病床，而不是医院病房。'
      ],
      cautions: [
        '不要把学校医务室和医院混淆；医疗权限、规模和人物关系不同。',
        '治疗结果、状态恢复和离开医务室必须服从原版状态或结构化事件。'
      ]
    },
    {
      id: 'kylar_manor_lab',
      label: '凯拉尔宅邸实验室',
      match: ['Manor Lab', 'manor lab', '宅邸实验室', '实验室'],
      facts: [
        '凯拉尔宅邸实验室是宅邸内部的实验空间，重点元素是工作台、玻璃器皿、试剂、柜架、化学气味和私人研究痕迹。',
        '如果当前 passage 是 Manor Lab，应写宅邸实验室，而不是凯拉尔卧室、浴室、学校实验室或农场实验室。'
      ],
      cautions: [
        '不要把 Manor Lab 和 Manor Kylar Room 混写；实验室与卧室是不同细分空间。',
        '不要因为出现实验器材就自动把凯拉尔写成在场；角色在场仍以当前页面文本和 NPC 上下文为准。'
      ]
    },
    {
      id: 'kylar_manor_room',
      label: '凯拉尔卧室',
      match: ['Manor Kylar Room', 'Kylar Room', '凯拉尔卧室', '卧室'],
      facts: [
        '凯拉尔卧室是宅邸内部的私人房间，重点元素是床、家具、窗帘、私人物品、被观察感和封闭的私人空间。',
        '如果当前 passage 是 Manor Kylar Room，应写凯拉尔卧室，而不是实验室、浴室或普通孤儿院卧室。'
      ],
      cautions: [
        '不要把凯拉尔卧室和玩家卧室混在一起；它属于凯拉尔宅邸。',
        '不要仅凭地点名让凯拉尔强制在场，仍需当前页面文本、可见 NPC 或结构化状态支持。'
      ]
    },
    {
      id: 'manor_garden',
      label: '宅邸花园',
      match: ['Manor Garden', 'Manor Garden Trim', 'manor garden', '宅邸花园', '花园'],
      facts: [
        '宅邸花园是宅邸外部庭院空间，重点元素是树篱、花坛、草地、小径、修剪工具、窗户和可能的窥视感。',
        '如果当前 passage 是 Manor Garden Trim，应表现修剪树篱、园艺工具和宅邸庭院，而不是室内实验室。'
      ],
      cautions: [
        '不要把宅邸花园写成森林、农场或普通公园。',
        '树篱后的人影或眼睛必须作为当前页面疑点处理，不要自动宣布某 NPC 已在场。'
      ]
    },
    {
      id: 'orphanage_bathroom',
      label: '孤儿院浴室',
      match: ['Bathroom', 'bathroom', '浴室'],
      facts: [
        '孤儿院/玩家居住区浴室是室内洗浴空间，重点元素是水汽、瓷砖、浴缸或淋浴、毛巾、镜子和换洗动作。',
        '如果当前 passage 是 Bathroom，应优先写浴室洗浴环境，不要沿用上一轮森林、街道或宅邸场景。'
      ],
      cautions: [
        '不要把 Bathroom 写成学校厕所或公共浴场，除非 current_map 或页面文本明确说明。',
        '生图和剧情都应优先使用当前 Bathroom，而不是 area 字段里的旧大区。'
      ]
    },
    {
      id: 'orphanage_bedroom',
      label: '玩家卧室',
      match: ['Bedroom', 'bedroom', 'Loft', '玩家卧室', '孤儿院卧室', '阁楼'],
      facts: [
        '玩家卧室/阁楼是玩家私人物品和休息空间，重点元素是床、柜子、衣物、门、窗、灯光和个人整理动作。',
        '如果当前 passage 是 Bedroom 或 Loft，应写室内个人空间，而不是街道、森林或公共建筑。'
      ],
      cautions: [
        '不要因为记忆里有其他地点就覆盖当前卧室。',
        'NPC 是否进入玩家卧室必须服从当前页面文本、原版状态或明确玩家选择。'
      ]
    },
    {
      id: 'farm_lab',
      label: '农场实验室',
      match: ['Farm Lab', 'farm lab', '农场实验室'],
      facts: [
        '农场实验室属于亚历克斯农场相关空间，重点元素是农场设施、实验设备、动物/农业研究痕迹和乡间建筑感。',
        '如果当前 passage 是 Farm Lab，应写农场实验室，不要写成凯拉尔宅邸实验室或学校科学教室。'
      ],
      cautions: [
        '实验室类型必须看当前 passage；不要只凭“实验室”三个字混淆不同地点。',
        '亚历克斯是否在场仍以当前页面文本和 NPC 上下文为准。'
      ]
    },
    {
      id: 'hospital_corridor',
      label: '医院走廊',
      match: ['Hospital Corridor', 'hospital corridor', '医院走廊'],
      facts: [
        '医院走廊是医院内部连接房间、病房、出口或特殊设施的过渡空间，重点元素是门、墙面、灯光、脚步声、警报或医疗建筑的封闭感。',
        '如果当前 passage 是 Hospital Corridor 或 Abduction Hospital Corridor，应写医院内部走廊/通道，而不是普通病房、街道或户外水道。'
      ],
      cautions: [
        '不要把医院走廊直接写成已经逃出医院；离开医院必须服从原版链接、当前页面文本或结构化到达结果。',
        '绑架医院相关 passage 可能是特殊事件链，剧情推进应保留当前危险和封闭环境。'
      ]
    },
    {
      id: 'temple_library',
      label: '神殿图书馆',
      match: ['Temple Library', 'temple library', '神殿图书馆'],
      facts: [
        '神殿图书馆属于神殿内部，重点元素是典籍、宗教文本、木架、安静回廊和克制的神殿氛围。',
        '如果当前 passage 是 Temple Library，应写神殿图书馆，而不是学校图书馆。'
      ],
      cautions: [
        '不要把神殿图书馆写成学校学习场景；两者的社会关系和氛围不同。',
        '悉尼或乔丹是否在场仍需当前页面或 NPC 上下文支持。'
      ]
    },
    {
      id: 'temple_confessional',
      label: '神殿忏悔室',
      match: ['Temple Confess', 'Temple Confessional', 'confessional', '忏悔室'],
      facts: [
        '神殿忏悔室是神殿内更私密、压低声音的宗教空间，重点元素是隔板、木质小间、低声告解和克制氛围。',
        '如果当前 passage 是 Temple Confess，应写忏悔室，而不是神殿主厅、图书馆或卧室。'
      ],
      cautions: [
        '不要把忏悔室写成普通对话室；它带有宗教规训和隐私限制。',
        '乔丹或悉尼是否在场仍以当前页面和 NPC 上下文为准。'
      ]
    },
    {
      id: 'temple_garden',
      label: '神殿花园',
      match: ['Temple Garden', 'temple garden', '神殿花园'],
      facts: [
        '神殿花园是神殿内外衔接的安静庭院，重点元素是石径、植物、墙影、钟声、回廊和远离街道的静默。',
        '如果当前 passage 是 Temple Garden，应写神殿庭院/花园，而不是宅邸花园、公园或森林。'
      ],
      cautions: [
        '不要把神殿花园和宅邸花园混淆；社会氛围和角色关联不同。',
        '不要仅凭花园地点自动加入无关 NPC。'
      ]
    },
    {
      id: 'wolf_cave_spaces',
      label: '狼洞细分空间',
      match: ['Wolf Cave Clearing', 'Wolf Cave Wash', 'Wolf Cave Bed', 'cave clearing', 'cave stream', '狼洞空地', '狼洞溪流', '狼洞床铺'],
      facts: [
        '狼洞包含洞内床铺、洞口空地和附近溪流等细分空间；洞内偏昏暗封闭，空地偏森林边缘，溪流偏洗濯和水声。',
        '如果当前 passage 是 Wolf Cave Wash，应写溪流/水边；如果是 Wolf Cave Clearing，应写洞口空地，而不是笼统狼洞。'
      ],
      cautions: [
        '不要把狼洞写成伊甸小屋；两者同属森林但生活结构不同。',
        '狼、野外威胁或同伴是否在场必须服从当前页面文本。'
      ]
    },
    {
      id: 'farm_outbuildings',
      label: '农场细分空间',
      match: ['Farm Woodland', 'Farm Kennel', 'Farm Work', 'farm woodland', 'farm kennel', '农场林地', '农场犬舍'],
      facts: [
        '亚历克斯农场包含田地、农舍、犬舍、林地和工作区等空间；犬舍偏动物照料，林地偏农场边缘和树木遮蔽。',
        '如果当前 passage 是 Farm Kennel，应写犬舍和动物设施；如果是 Farm Woodland，应写农场边缘林地。'
      ],
      cautions: [
        '不要把农场林地写成伊甸森林小屋或普通森林深处。',
        '动物、农活收益和任务进度必须以当前页面文本、可见选项或结构化事件为准。'
      ]
    },
    {
      id: 'public_venue_rooms',
      label: '公共场所细分房间',
      match: ['Shopping Centre Restroom', 'Pub Exposed Kitchen', 'Brothel Bathroom', 'Strip Club Dressing Room', 'Strip Club Shower', '购物中心洗手间', '酒吧厨房', '妓院浴室', '化妆间'],
      facts: [
        '公共场所里的洗手间、厨房、浴室、淋浴间和化妆间是具体房间；应优先写房间里的设施、门、镜子、灯光和工作/顾客动线。',
        '如果当前 passage 是 Pub Exposed Kitchen，应写酒吧厨房；如果是 Shopping Centre Restroom，应写购物中心洗手间。'
      ],
      cautions: [
        '不要把公共场所细分房间退回成大厅、街道或整个建筑。',
        '服务、交易、工作或消费是否发生必须服从原版状态或结构化事件。'
      ]
    }
  ];

  var NPC_KNOWLEDGE = [
    { key: 'Robin', zh: '罗宾', match: ['Robin', '罗宾'], facts: ['罗宾通常与孤儿院、家、照料和亲近关系相关。'] },
    { key: 'Bailey', zh: '贝利', match: ['Bailey', '贝利'], facts: ['贝利与孤儿院、债务、租金和管束压力相关；租金金额以原版状态为准。'] },
    { key: 'Sydney', zh: '悉尼', match: ['Sydney', '悉尼', '西德尼'], facts: ['悉尼的标准中文名是悉尼，常与神殿、信仰、纯洁/腐化和克制冲突相关。'] },
    { key: 'Kylar', zh: '凯拉尔', match: ['Kylar', '凯拉尔', '乔丹'], facts: ['凯拉尔的标准中文名是凯拉尔，常与宅邸、学校、执着和窥视相关。'] },
    { key: 'Eden', zh: '伊甸', match: ['Eden', '伊甸'], facts: ['伊甸常与森林小屋、狩猎、警觉、照料和沉默陪伴相关。'] },
    { key: 'Whitney', zh: '惠特尼', match: ['Whitney', '惠特尼'], facts: ['惠特尼常与学校、欺凌、支配和同龄社交压力相关。'] },
    { key: 'Avery', zh: '艾弗里', match: ['Avery', '艾弗里'], facts: ['艾弗里常与财富、约会、车辆和上层社交压力相关。'] },
    { key: 'Alex', zh: '亚历克斯', match: ['Alex', '亚历克斯'], facts: ['亚历克斯常与农场、农活、动物和信任建立相关。'] },
    { key: 'Jordan', zh: '乔丹', match: ['Jordan', '乔丹'], facts: ['乔丹是神殿相关角色；不要把 Jordan 和 Kylar 混淆。'] },
    { key: 'Leighton', zh: '莱顿', match: ['Leighton', '莱顿'], facts: ['莱顿与学校、校长室、纪律和权力压力相关。'] },
    { key: 'Briar', zh: '布赖尔', match: ['Briar', '布赖尔'], facts: ['布赖尔与妓院经营和相关工作场景有关。'] },
    { key: 'Mason', zh: '梅森', match: ['Mason', '梅森'], facts: ['梅森常与学校、课堂、体育或教师身份相关；具体课程状态以当前时间和页面为准。'] },
    { key: 'Harper', zh: '哈珀', match: ['Harper', '哈珀'], facts: ['哈珀常与医疗、治疗、观察和压力相关；医疗流程以原版页面为准。'] },
    { key: 'Doren', zh: '多伦', match: ['Doren', '多伦'], facts: ['多伦常与历史、研究、博物馆或学术线索相关。'] },
    { key: 'Morgan', zh: '摩根', match: ['Morgan', '摩根'], facts: ['摩根常与下水道、隐秘据点和地下空间相关；是否在场以当前页面为准。'] },
    { key: 'Great Hawk', zh: '大鹰', match: ['Great Hawk', 'great hawk', 'hawk', 'eagle', '大鹰', '鹰'], facts: ['大鹰相关场景常与高处、巢、鸟塔、风和携带物有关；不要额外加入其他动物。'] }
  ];

  var ROUTINE_KNOWLEDGE = [
    {
      id: 'school_native_clock',
      match: ['school', 'School', '学校', '教室', '课堂', 'lesson', 'class'],
      facts: [
        '学校日程必须跟随原版当前时间和页面文本；AI 只能概括当前时段，不能自创精确课表。',
        '如果当前时间已经在上午或下午上课时段，叙事应默认课程/校园活动已经在进行，而不是第一节课尚未开始。'
      ],
      cautions: [
        '不要用记忆里的旧时间覆盖原版当前时间。',
        '不要把学校总地点覆盖掉厕所、图书馆、医务室、教室等细分地点。'
      ]
    },
    {
      id: 'business_and_public_ui',
      match: ['shop', 'store', 'market', 'cafe', 'café', 'pub', 'bar', 'hospital', 'museum', 'arcade', '商店', '市场', '咖啡馆', '酒吧', '医院', '博物馆', '街机'],
      facts: [
        '商店、医院、博物馆、咖啡馆、酒吧和街机厅等公共/营业页面常包含按钮、价格、服务列表、工作入口或管理行。',
        '这些 UI 元素只说明可执行选项；只有玩家点击、原版状态变化或 AI_EVENT 明确写出时，才算已经发生。',
        '营业/关门/打烊/开门状态必须服从原版页面文字、可见控件、Time.dayState 和原版时钟。'
      ],
      cautions: [
        '不要把价格、按钮名、服务菜单、工作列表直接写成已经完成的剧情。',
        '金钱、物品、治疗、工作收益必须以原版状态或 AI_EVENT 的结构化结果为准。',
        '不要在原版页面显示关闭、夜间或打烊时写成正常营业。'
      ]
    },
    {
      id: 'private_room_context',
      match: ['Bathroom', 'bathroom', 'Bedroom', 'bedroom', 'home', 'orphanage', 'Loft', 'Ward', '浴室', '卧室', '孤儿院', '阁楼'],
      facts: [
        '卧室、浴室、阁楼和孤儿院室内空间属于当前室内场景；应优先表现房间、家具、墙面、门、床、浴具等可见环境。',
        '室内私人空间不应沿用上一轮的森林、街道、农场或户外小径，除非当前页面明确已经移动。'
      ],
      cautions: [
        '生成剧情或生图提示词时，先读当前 passage/location/pageText，再使用记忆。',
        '不要因为 area 或旧记忆含有 forest/town 就覆盖当前 Bathroom/Bedroom。'
      ]
    },
    {
      id: 'movement_requires_native_support',
      match: ['arrive', 'return', 'leave', 'go to', '返回', '离开', '到达', '前往', '走向'],
      facts: [
        '移动应优先参考 current_map.current 和 current_map.adjacent；可见链接和原版相邻地点比 AI 猜测更可靠。',
        '远距离跳转需要正文中有交通、追逐、被带走、救援、传送或明确时间跳跃等过渡。'
      ],
      cautions: [
        '不要把“跑、躲、离开、返回”等动作词当作地点名。',
        '如果当前地图没有目标地点，AI 应把它写成意图或过渡，而不是强制到达。'
      ]
    }
  ];

  function matchLocation(entry, context, input) {
    context = context || {};
    input = input || {};
    var facts = context.facts || {};
    var map = context.currentMap || {};
    var current = map.current || {};
    var fields = [
      facts.passage,
      facts.location,
      facts.area,
      current.passage,
      current.locId,
      current.parent,
      current.label,
      input.pageText
    ].join(' ');
    if (containsAny(fields, entry.match)) return true;
    var adjacent = Array.isArray(map.adjacent) ? map.adjacent : [];
    for (var i = 0; i < adjacent.length; i++) {
      if (containsAny([adjacent[i].passage, adjacent[i].label].join(' '), entry.match)) return true;
    }
    return false;
  }

  function collectLocationKnowledge(context, input) {
    var out = [];
    for (var i = 0; i < LOCATION_KNOWLEDGE.length && out.length < 4; i++) {
      var entry = LOCATION_KNOWLEDGE[i];
      if (!matchLocation(entry, context, input)) continue;
      out.push({
        id: entry.id,
        label: entry.label,
        facts: entry.facts.slice(0, 4),
        cautions: entry.cautions.slice(0, 3)
      });
    }
    return out;
  }

  function matchSublocation(entry, context, input) {
    context = context || {};
    input = input || {};
    var facts = context.facts || {};
    var map = context.currentMap || {};
    var current = map.current || {};
    var fields = [
      facts.passage,
      facts.location,
      current.passage,
      current.locId,
      current.label,
      input.scene && input.scene.passageName
    ].join(' ');
    return containsAny(fields, entry.match);
  }

  function collectSublocationKnowledge(context, input) {
    var out = [];
    for (var i = 0; i < SUBLOCATION_KNOWLEDGE.length && out.length < 3; i++) {
      var entry = SUBLOCATION_KNOWLEDGE[i];
      if (!matchSublocation(entry, context, input)) continue;
      out.push({
        id: entry.id,
        label: entry.label,
        facts: entry.facts.slice(0, 3),
        cautions: entry.cautions.slice(0, 2)
      });
    }
    return out;
  }

  function collectNpcKnowledge(context, input) {
    context = context || {};
    input = input || {};
    var state = input.state || {};
    var hay = [
      input.pageText || '',
      JSON.stringify(context.npcCanonicalNames || []),
      JSON.stringify(state.presentNpcDetails || []),
      JSON.stringify(state.nearbyNpcs || []),
      JSON.stringify(state.npcDetails || [])
    ].join(' ');
    var out = [];
    for (var i = 0; i < NPC_KNOWLEDGE.length && out.length < 6; i++) {
      var npc = NPC_KNOWLEDGE[i];
      if (!containsAny(hay, npc.match)) continue;
      out.push({
        key: npc.key,
        canonicalName: npc.zh,
        facts: npc.facts.slice(0, 3)
      });
    }
    return out;
  }

  function collectTimeKnowledge(context) {
    context = context || {};
    var facts = context.facts || {};
    var school = context.timeRules && context.timeRules.school;
    var business = context.timeRules && context.timeRules.business;
    var out = [];
    if (school && school.applies) {
      pushUnique(out, 'School schedule interpretation: ' + school.summary + '. Follow the native clock instead of inventing a timetable.', 3);
      if (/lessons are underway/i.test(school.summary || '')) {
        pushUnique(out, 'Lessons are already underway; do not describe the first class as not yet started.', 3);
      }
    }
    if (facts.clockPhase && facts.clockPhase !== 'unknown') {
      pushUnique(out, 'Current broad time phase: ' + facts.clockPhase + '.', 3);
    }
    if (business && business.applies && business.summary) {
      pushUnique(out, 'Business/opening interpretation: ' + business.summary + '. Follow native page text and visible controls.', 4);
      if (business.caution) pushUnique(out, business.caution, 4);
    }
    return out;
  }

  function matchRoutine(entry, context, input) {
    context = context || {};
    input = input || {};
    var facts = context.facts || {};
    var map = context.currentMap || {};
    var current = map.current || {};
    var fields = [
      facts.passage,
      facts.location,
      facts.area,
      facts.clockPhase,
      current.passage,
      current.locId,
      current.parent,
      current.label,
      JSON.stringify(context.visibleLinks || []),
      JSON.stringify(context.visibleControls || []),
      input.pageText
    ].join(' ');
    return containsAny(fields, entry.match);
  }

  function collectRoutineKnowledge(context, input) {
    var out = [];
    for (var i = 0; i < ROUTINE_KNOWLEDGE.length && out.length < 4; i++) {
      var entry = ROUTINE_KNOWLEDGE[i];
      if (!matchRoutine(entry, context, input)) continue;
      out.push({
        id: entry.id,
        facts: entry.facts.slice(0, 3),
        cautions: entry.cautions.slice(0, 3)
      });
    }
    return out;
  }

  function collectCautions(context, locationKnowledge, sublocationKnowledge, npcKnowledge, routineKnowledge) {
    var out = [];
    (locationKnowledge || []).forEach(function (entry) {
      (entry.cautions || []).forEach(function (line) { pushUnique(out, line, 8); });
    });
    (sublocationKnowledge || []).forEach(function (entry) {
      (entry.cautions || []).forEach(function (line) { pushUnique(out, line, 10); });
    });
    (npcKnowledge || []).forEach(function (entry) {
      if (entry.key === 'Sydney') pushUnique(out, 'Use 悉尼 for Sydney; avoid 西德尼 unless quoting player text.', 8);
      if (entry.key === 'Kylar') pushUnique(out, 'Use 凯拉尔 for Kylar; do not confuse Kylar with Jordan/乔丹.', 8);
    });
    (routineKnowledge || []).forEach(function (entry) {
      (entry.cautions || []).forEach(function (line) { pushUnique(out, line, 10); });
    });
    if (context && context.page && context.page.skip) {
      pushUnique(out, 'Current page is classified as ' + context.page.type + '; avoid treating UI choices, prices, or management rows as story events.', 10);
    }
    return out;
  }

  function getKnowledgeMeta() {
    var summaryMeta = releaseSummaryMeta();
    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      knowledgeVersion: KNOWLEDGE_VERSION,
      source: KNOWLEDGE_SOURCE,
      policy: 'supplement_only_native_state_wins',
      locationEntries: LOCATION_KNOWLEDGE.length,
      sublocationEntries: SUBLOCATION_KNOWLEDGE.length,
      npcEntries: NPC_KNOWLEDGE.length,
      routineEntries: ROUTINE_KNOWLEDGE.length,
      releaseSummary: summaryMeta
    };
  }

  function retrieve(input) {
    input = input || {};
    var context = input.context || {};
    var locations = collectLocationKnowledge(context, input);
    var sublocations = collectSublocationKnowledge(context, input);
    var npcs = collectNpcKnowledge(context, input);
    var time = collectTimeKnowledge(context);
    var routine = collectRoutineKnowledge(context, input);
    var cautions = collectCautions(context, locations, sublocations, npcs, routine);
    var releaseSummary = collectReleaseSummary(context, input);
    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      knowledgeVersion: KNOWLEDGE_VERSION,
      source: KNOWLEDGE_SOURCE,
      policy: 'supplement_only_native_state_wins',
      locations: locations,
      sublocations: sublocations,
      npcs: npcs,
      routine: routine,
      time: time,
      cautions: cautions,
      releaseSummary: releaseSummary
    };
  }

  function create() {
    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      knowledgeVersion: KNOWLEDGE_VERSION,
      retrieve: retrieve,
      getMeta: getKnowledgeMeta,
      getDebugState: getKnowledgeMeta
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    knowledgeVersion: KNOWLEDGE_VERSION,
    source: KNOWLEDGE_SOURCE,
    getMeta: getKnowledgeMeta,
    create: create,
    retrieve: retrieve
  };

  root.AIStoryGen.WorldKnowledgeModule = api;
  root.AIStoryGenWorldKnowledgeModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
