(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  function create(deps) {
    deps = deps || {};
    var $ = deps.$;
    var getStateStoreReady = typeof deps.getStateStoreReady === 'function' ? deps.getStateStoreReady : function () { return false; };
    var clearIntimateScene = typeof deps.clearIntimateScene === 'function' ? deps.clearIntimateScene : function () {};
    var restoreOriginalCombatNarrative = typeof deps.restoreOriginalCombatNarrative === 'function' ? deps.restoreOriginalCombatNarrative : function () {};

    function isLoaded() {
      try {
        return !!(root.AIStoryGenIntimateAddon && root.AIStoryGenIntimateAddon.loaded);
      } catch (_) {
        return false;
      }
    }

    function getApi() {
      try {
        if (!isLoaded()) return null;
        var addon = root.AIStoryGenIntimateAddon;
        return addon && typeof addon === 'object' ? addon : null;
      } catch (_) {
        return null;
      }
    }

    function isSexModeButtonText(text) {
      return /\u8fdb\u5165\u8272\u8272(?:\u6a21\u5f0f)?|\u8fdb\u5165\u91cd\u8f7d\u5267\u60c5|Enter sex(?: mode)?|Reload scene/i.test(String(text || ''));
    }

    function isAIIntimateModeButtonText(text) {
      return /\u81ea\u5b9a\u4e49\u8272\u8272(?:\u6a21\u5f0f)?|\u8272\u8272\u6a21\u5f0f\u751f\u6210|Custom\s*(?:sex|intimate)(?:\s*mode)?|AI\s*free\s*sex\s*mode/i.test(String(text || ''));
    }

    function isAnySexModeButtonText(text) {
      text = String(text || '').trim();
      return isSexModeButtonText(text) || isAIIntimateModeButtonText(text) || /\ud83d\udc9e\s*(\u8272\u8272|Intimate)$/.test(text);
    }

    function isAIEntryElement($el, text) {
      try {
        return !!($el && $el.hasClass && $el.hasClass('ai-intimate-mode-entry')) || isAIIntimateModeButtonText(text);
      } catch (_) {
        return isAIIntimateModeButtonText(text);
      }
    }

    function isNativeEntryElement($el, text) {
      try {
        return !!($el && $el.hasClass && $el.hasClass('ai-sex-mode-entry')) || isSexModeButtonText(text);
      } catch (_) {
        return isSexModeButtonText(text);
      }
    }

    function legacyPanelSelector() {
      return '.ai-sex-target-picker, .ai-native-sex-picker';
    }

    function managedPanelSelector() {
      return '.ai-choices, .ai-choices-end, .ai-manual-choice-trigger, .ai-back-to-game, ' +
        legacyPanelSelector() + ', .ai-reload-scene-panel, .ai-item-use-panel, .ai-memory-inline, .ai-gen-loading';
    }

    function managedDedupeSelector() {
      return legacyPanelSelector() + ', .ai-reload-scene-panel, .ai-item-use-panel, .ai-memory-inline';
    }

    function cloneCleanupSelector(base) {
      var prefix = base ? String(base) + ', ' : '';
      return prefix + legacyPanelSelector();
    }

    function panelKindForNode(node) {
      if (!node || !$) return '';
      var $node = $(node);
      if ($node.hasClass('ai-sex-target-picker')) return 'sex-target-picker';
      if ($node.hasClass('ai-native-sex-picker')) return 'native-sex-picker';
      return '';
    }

    function clearTargetPicker() {
      if (!$) return;
      try { $('#passages > .ai-sex-target-picker, #passages > .ai-sex-engine-picker').remove(); } catch (_) {}
    }

    function clearStandalone() {
      if (!$) return;
      try { $('#passages > .ai-sex-standalone').remove(); } catch (_) {}
    }

    function clearIntimateSceneDom() {
      if (!$) return;
      try { $('#passages .ai-intimate-scene, #passages .ai-intimate-bottom-actions').remove(); } catch (_) {}
      try { $('#passages .passage').removeClass('ai-intimate-has-fixed-actions'); } catch (_) {}
    }

    function clearFixedIntimateActions() {
      if (!$) return;
      try { $('#passages .ai-intimate-bottom-actions, #passages .ai-intimate-fixed-bottom-actions').remove(); } catch (_) {}
      try { $('#passages .passage').removeClass('ai-intimate-has-fixed-actions'); } catch (_) {}
      try { if (root.jQuery || root.$) $(root).off('resize.aiIntimateBottomActions'); } catch (_) {}
    }

    function getLegacyUiStatus() {
      if (!$) return {
        targetPickerOpen: false,
        sexModeButtons: 0,
        sexMenus: 0,
        intimateFixedActions: 0
      };
      var sexModeButtons = 0;
      try {
        sexModeButtons = $('#passages .ai-sex-mode-entry, #passages .ai-intimate-mode-entry, #passages .ai-back-link').filter(function () {
          return isAnySexModeButtonText($(this).text());
        }).length;
      } catch (_) {}
      return {
        targetPickerOpen: $('#passages > .ai-sex-target-picker').length > 0,
        sexModeButtons: sexModeButtons,
        sexMenus: $('#passages .ai-sex-target-menu, #passages .ai-sex-target-panel').length,
        intimateFixedActions: $('#passages .ai-intimate-fixed-bottom-actions, #passages .ai-intimate-bottom-actions').length
      };
    }

    function clearLegacyUi(reason) {
      if (!$) return;
      try { clearTargetPicker(); } catch (_) {}
      if (getStateStoreReady()) {
        try { clearIntimateScene(reason || 'clear sex mode ui'); } catch (_) {}
      }
      try { $('#passages .ai-native-sex-picker, #passages .ai-sex-standalone, #passages .ai-sex-engine-picker').remove(); } catch (_) {}
      try {
        $('#passages .ai-sex-mode-entry, #passages .ai-intimate-mode-entry, #passages .ai-sex-engine-entry, #passages .ai-back-link').filter(function () {
          if ($(this).closest('.wr-intimate-entry').length) return false;
          return isAnySexModeButtonText($(this).text());
        }).each(function () {
          var $el = $(this);
          var $wrap = $el.closest('.ai-sex-standalone');
          if ($wrap.length) $wrap.remove();
          else $el.remove();
        });
      } catch (_) {}
      try { $('#passages .ai-combat-custom, #passages .ai-end-combat-wrap, #passages .doli-cn-block').remove(); } catch (_) {}
      try { restoreOriginalCombatNarrative(); } catch (_) {}
    }

    return {
      isLoaded: isLoaded,
      getApi: getApi,
      isSexModeButtonText: isSexModeButtonText,
      isAIIntimateModeButtonText: isAIIntimateModeButtonText,
      isAnySexModeButtonText: isAnySexModeButtonText,
      isAIEntryElement: isAIEntryElement,
      isNativeEntryElement: isNativeEntryElement,
      managedPanelSelector: managedPanelSelector,
      managedDedupeSelector: managedDedupeSelector,
      cloneCleanupSelector: cloneCleanupSelector,
      panelKindForNode: panelKindForNode,
      clearTargetPicker: clearTargetPicker,
      clearStandalone: clearStandalone,
      clearIntimateSceneDom: clearIntimateSceneDom,
      clearFixedIntimateActions: clearFixedIntimateActions,
      getLegacyUiStatus: getLegacyUiStatus,
      clearLegacyUi: clearLegacyUi
    };
  }

  var OptionalAddonBridgeModule = {
    schemaVersion: 1,
    create: create
  };

  root.AIStoryGen.OptionalAddonBridgeModule = OptionalAddonBridgeModule;
  root.AIStoryGenOptionalAddonBridgeModule = OptionalAddonBridgeModule;
})(typeof window !== 'undefined' ? window : globalThis);
