/* ============================================================
 * AIStoryGen error report delivery UI
 * Owns download, clipboard, and mobile-safe text fallback panels.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  function create(deps) {
    deps = deps || {};
    var $ = deps.$ || root.jQuery || root.$;
    if (!$) throw new Error('[AIStoryGen] ai-error-report-ui requires jQuery');
    var mountFloatingPanel = deps.mountFloatingPanel || function ($box) {
      var $root = $('#passages');
      ($root.length ? $root : $('body')).prepend($box);
    };
    var recordError = deps.recordError || function () {};
    var showUserMessage = deps.showUserMessage || function () {};

    function downloadTextFile(filename, text, mime) {
      try {
        var blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function () {
          try { document.body.removeChild(a); } catch (_) {}
          try { URL.revokeObjectURL(url); } catch (_) {}
        }, 0);
        return true;
      } catch (error) {
        recordError('report_download_failed', error);
        return false;
      }
    }

    function copyTextToClipboard(text) {
      text = String(text || '');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }
      return new Promise(function (resolve, reject) {
        try {
          var textarea = document.createElement('textarea');
          textarea.value = text;
          textarea.setAttribute('readonly', 'readonly');
          textarea.style.position = 'fixed';
          textarea.style.left = '-9999px';
          document.body.appendChild(textarea);
          textarea.focus();
          textarea.select();
          var ok = document.execCommand && document.execCommand('copy');
          document.body.removeChild(textarea);
          ok ? resolve() : reject(new Error('copy command failed'));
        } catch (error) {
          reject(error);
        }
      });
    }

    function mountTextFallback(options) {
      options = options || {};
      try { $('#passages > .ai-error-report-fallback').remove(); } catch (_) {}
      var text = String(options.text || '');
      if (!text) return null;
      var hint = String(options.hint || '');
      if (options.reason) hint += ' (' + String(options.reason).slice(0, 120) + ')';
      var $box = $('<div class="ai-error-report-fallback"></div>').css({
        margin: '0.6em 0',
        padding: '0.6em',
        border: '1px solid #668',
        background: 'rgba(40, 50, 80, 0.35)',
        color: '#ddd'
      });
      var $title = $('<div></div>').css({ fontWeight: 'bold', marginBottom: '0.35em' }).text(String(options.title || '文本'));
      var $hint = $('<div></div>').css({ fontSize: '0.9em', marginBottom: '0.35em' }).text(hint);
      var $text = $('<textarea readonly></textarea>')
        .attr('rows', Number(options.rows || 8))
        .css({
          width: '100%',
          boxSizing: 'border-box',
          fontSize: '0.85em',
          lineHeight: '1.35',
          whiteSpace: 'pre-wrap'
        })
        .val(text);
      var $select = $('<button type="button" class="ai-cfg-btn"></button>').text(String(options.selectLabel || '选中文本'));
      var $close = $('<button type="button" class="ai-cfg-btn"></button>').css('margin-left', '0.5em').text('关闭');
      $select.on('click', function () {
        try {
          $text[0].focus();
          $text[0].select();
          $text[0].setSelectionRange(0, text.length);
        } catch (_) {}
      });
      $close.on('click', function () { $box.remove(); });
      $box
        .append($title)
        .append($hint)
        .append($text)
        .append($('<div style="margin-top:0.4em;"></div>').append($select).append($close));
      mountFloatingPanel($box, options.panelKey || 'ai-text-copy-fallback', {
        className: 'ai-mobile-floating-panel ai-mobile-report-fallback',
        mode: 'prepend',
        getRoot: function () {
          var $root = $('#passages');
          return $root.length ? $root : $('body');
        },
        shield: true
      });
      return $box;
    }

    function showReportFallback(payload, mode, reason) {
      if (!payload || !payload.jsonText) return null;
      return mountTextFallback({
        title: mode === 'file' ? '错误报告已生成：' + payload.filename : '错误报告文本',
        hint: mode === 'file'
          ? '手机端文件通常会进入浏览器下载/Download 文件夹。若没有看到下载提示，可长按下方文本手动复制。'
          : '如果手机剪贴板没有内容，请长按下方文本手动复制。',
        text: payload.jsonText,
        reason: reason,
        rows: 6,
        selectLabel: '选中报告文本',
        panelKey: 'ai-error-report-fallback'
      });
    }

    function showTextFallback(title, hint, text, reason) {
      return mountTextFallback({
        title: title,
        hint: hint,
        text: text,
        reason: reason,
        rows: 8,
        selectLabel: '选中模板文本',
        panelKey: 'ai-text-copy-fallback'
      });
    }

    function exportReportToFile(createPayload) {
      return createPayload().then(function (payload) {
        var ok = downloadTextFile(payload.filename, payload.jsonText, 'application/json;charset=utf-8');
        showReportFallback(payload, 'file', ok ? '' : '浏览器拒绝自动下载');
        showUserMessage(
          ok ? '错误报告已生成。手机端请查看浏览器下载/Download 文件夹。' : '浏览器拒绝自动下载，请手动复制页面中的错误报告文本。',
          !ok
        );
        return payload.report;
      });
    }

    function exportReportToClipboard(createPayload) {
      return createPayload().then(function (payload) {
        return copyTextToClipboard(payload.jsonText).then(function () {
          showReportFallback(payload, 'clipboard', '');
          showUserMessage('错误报告已复制到剪贴板。若手机剪贴板为空，可手动复制页面中的报告文本。');
          return payload.report;
        }, function (error) {
          showReportFallback(payload, 'clipboard', error && error.message || error);
          showUserMessage('复制失败，请手动复制页面中的错误报告文本。', true);
          return payload.report;
        });
      });
    }

    function exportIssueTemplateToClipboard(createPayload) {
      return createPayload().then(function (payload) {
        return copyTextToClipboard(payload.issueText).then(function () {
          showTextFallback('反馈模板已准备好', '如果手机剪贴板没有内容，请长按下方文本手动复制。', payload.issueText, '');
          showUserMessage('反馈模板已复制到剪贴板。若手机剪贴板为空，可手动复制页面中的模板文本。');
          return payload.report;
        }, function (error) {
          showTextFallback('反馈模板文本', '复制失败，请长按下方文本手动复制。', payload.issueText, error && error.message || error);
          showUserMessage('复制失败，请手动复制页面中的反馈模板文本。', true);
          return payload.report;
        });
      });
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      downloadTextFile: downloadTextFile,
      copyTextToClipboard: copyTextToClipboard,
      showReportFallback: showReportFallback,
      showTextFallback: showTextFallback,
      exportReportToFile: exportReportToFile,
      exportReportToClipboard: exportReportToClipboard,
      exportIssueTemplateToClipboard: exportIssueTemplateToClipboard
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: create
  };

  root.AIStoryGen.ErrorReportUIModule = api;
  root.AIStoryGenErrorReportUIModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
