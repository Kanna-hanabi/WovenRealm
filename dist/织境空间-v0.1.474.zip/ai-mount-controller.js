/* ============================================================
 * AIStoryGen mount controller
 * Tracks and plans native/fallback mount attempts for Settings and Options.
 * This module provides shared decision, fallback insertion, state, history,
 * and debug snapshots so mobile/iOS mounting behavior stays centralized.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var MAX_HISTORY = 80;

  function nowIso() {
    try { return new Date().toISOString(); } catch (_) { return ''; }
  }

  function cloneValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function stripFunctions(value) {
    if (!value || typeof value !== 'object') return value;
    var out = Array.isArray(value) ? [] : {};
    Object.keys(value).forEach(function (key) {
      var next = value[key];
      if (typeof next === 'function') return;
      if (next && typeof next === 'object') out[key] = stripFunctions(next);
      else out[key] = next;
    });
    return out;
  }

  function normalizeScope(scope) {
    return scope === 'overlay' ? 'overlay' : 'main';
  }

  function normalizeZoneId(id) {
    return String(id || '').replace(/\s+/g, '-').replace(/[^A-Za-z0-9:_-]/g, '').trim();
  }

  function normalizeZoneSpec(id, spec) {
    spec = spec || {};
    var zoneId = normalizeZoneId(id || spec.id);
    if (!zoneId) return null;
    return {
      id: zoneId,
      zone: String(spec.zone || spec.area || zoneId).trim(),
      scope: normalizeScope(spec.scope),
      kind: String(spec.kind || spec.type || 'entry').trim(),
      label: String(spec.label || zoneId).trim(),
      priority: isFinite(Number(spec.priority)) ? Number(spec.priority) : 0,
      enabled: spec.enabled !== false,
      selector: String(spec.selector || '').trim(),
      targetSelector: String(spec.targetSelector || '').trim(),
      status: 'registered',
      reason: String(spec.reason || '').slice(0, 160),
      at: Date.now(),
      iso: nowIso(),
      mount: typeof spec.mount === 'function' ? spec.mount : null,
      canMount: typeof spec.canMount === 'function' ? spec.canMount : null
    };
  }

  function zonePublicSnapshot(zone) {
    if (!zone) return null;
    return stripFunctions(zone);
  }

  function sortZones(list) {
    return list.sort(function (a, b) {
      if (b.priority !== a.priority) return b.priority - a.priority;
      return String(a.id).localeCompare(String(b.id));
    });
  }

  function isWovenRealmTabText(value) {
    var text = String(value || '').replace(/\s+/g, '').trim();
    return text === '\u7ec7\u5883\u7a7a\u95f4'
      || text === 'WovenRealm'
      || text === 'WovenRealmSettings'
      || text === '\u6253\u5f00\u7ec7\u5883\u7a7a\u95f4\u8bbe\u7f6e';
  }

  function hasNativeSettingsTab(doc) {
    if (!doc) return false;
    if (doc.getElementById('aiStoryGenSettingsNativeTab')) return true;
    var settingsOptions = doc.getElementById('settingsOptions');
    if (!settingsOptions || !settingsOptions.querySelectorAll) return false;
    var nodes = settingsOptions.querySelectorAll('button, span, a, div');
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!node || node.id === 'aiSettingsTab' || node.id === 'aiSettingsFallbackEntry') continue;
      if (isWovenRealmTabText(node.textContent)) return true;
    }
    return false;
  }

  function hasNativeOptionsTab(doc) {
    if (!doc) return false;
    if (doc.getElementById('aiStoryGenOptionsNativeTab')) return true;
    var tabs = doc.getElementById('overlayTabs');
    if (!tabs || !tabs.querySelectorAll) return false;
    var nodes = tabs.querySelectorAll('button, span, a, div');
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!node || node.id === 'aiOptionsTab' || node.id === 'aiOptionsFallbackEntry') continue;
      if (isWovenRealmTabText(node.textContent)) return true;
    }
    return false;
  }

  function hasNativeTab(scope, doc) {
    scope = normalizeScope(scope);
    doc = doc || root.document;
    return scope === 'overlay' ? hasNativeOptionsTab(doc) : hasNativeSettingsTab(doc);
  }

  function defaultDomState(scope) {
    var doc = root.document;
    if (!doc) return {};
    if (scope === 'overlay') {
      return {
        hasCustomOverlay: !!doc.getElementById('customOverlay'),
        hasOverlayTabs: !!doc.getElementById('overlayTabs'),
        hasOverlayContent: !!doc.getElementById('customOverlayContent'),
        hasNativeOptionsTab: hasNativeTab('overlay', doc),
        hasOptionsTab: !!doc.getElementById('aiOptionsTab'),
        hasFallbackEntry: !!doc.getElementById('aiOptionsFallbackEntry'),
        hasFallbackPanel: !!doc.getElementById('aiOptionsFallbackPanel')
      };
    }
    return {
      hasSettingsOptions: !!doc.getElementById('settingsOptions'),
      hasSettingsDiv: !!doc.getElementById('settingsDiv'),
      hasNativeSettingsTab: hasNativeTab('main', doc),
      hasSettingsTab: !!doc.getElementById('aiSettingsTab'),
      hasFallbackEntry: !!doc.getElementById('aiSettingsFallbackEntry'),
      hasFallbackPanel: !!doc.getElementById('aiSettingsFallbackPanel')
    };
  }

  function planMount(scope, domState, opts) {
    scope = normalizeScope(scope);
    domState = domState || {};
    opts = opts || {};
    if (scope === 'overlay') {
      if (domState.overlayCandidate === false) {
        return { action: 'skip', status: 'skipped', reason: 'not options overlay' };
      }
      if (domState.hasNativeOptionsTab) {
        return { action: 'ready', status: 'ready', reason: 'native options tab already mounted' };
      }
      if (domState.hasOptionsTab) {
        return { action: 'ready', status: 'ready', reason: 'options tab already mounted' };
      }
      if (!domState.hasOverlayTabs) {
        if (domState.hasOverlayContent || opts.allowFallbackWithoutContent) {
          return { action: 'fallback', status: 'fallback', reason: 'missing #overlayTabs' };
        }
        return { action: 'retry', status: 'retry', reason: 'missing #overlayTabs and overlay content' };
      }
      return { action: 'tab', status: 'tab-inserted', reason: 'native overlay tab bar' };
    }
    if (domState.hasNativeSettingsTab) {
      return { action: 'ready', status: 'ready', reason: 'native settings tab already mounted' };
    }
    if (domState.hasSettingsTab) {
      return { action: 'ready', status: 'ready', reason: 'settings tab already mounted' };
    }
    if (!domState.hasSettingsOptions) {
      return { action: 'fallback', status: 'fallback', reason: 'missing #settingsOptions container' };
    }
    if (!domState.hasSettingsDiv && opts.opening) {
      return { action: 'fallback', status: 'fallback', reason: 'missing #settingsDiv' };
    }
    return { action: 'tab', status: 'tab-inserted', reason: 'native Settings tab container' };
  }

  function fallbackSpec(scope) {
    scope = normalizeScope(scope);
    if (scope === 'overlay') {
      return {
        scope: 'overlay',
        entryId: 'aiOptionsFallbackEntry',
        panelId: 'aiOptionsFallbackPanel',
        entryClass: 'ai-options-fallback-entry',
        panelClass: 'ai-options-fallback-panel',
        buttonText: '\u6253\u5f00\u7ec7\u5883\u7a7a\u95f4\u8bbe\u7f6e',
        helpText: ' \u5982\u679c OPTIONS \u91cc\u6ca1\u6709\u6807\u7b7e\uff0c\u8bf7\u4f7f\u7528\u6b64\u5165\u53e3\u3002',
        insertMode: 'prepend',
        openedReason: 'fallback button',
        insertedReason: 'missing overlay tabs'
      };
    }
    return {
      scope: 'main',
      entryId: 'aiSettingsFallbackEntry',
      panelId: 'aiSettingsFallbackPanel',
      entryClass: 'ai-settings-fallback-entry',
      panelClass: 'ai-settings-fallback-panel',
      buttonText: '\u6253\u5f00\u7ec7\u5883\u7a7a\u95f4\u8bbe\u7f6e',
      helpText: ' \u5982\u679c\u8bbe\u7f6e\u9875\u6ca1\u6709\u663e\u793a\u6807\u7b7e\uff0c\u8bf7\u4f7f\u7528\u6b64\u5165\u53e3\u3002',
      insertMode: 'append',
      openedReason: 'fallback button',
      insertedReason: 'missing settings tab container'
    };
  }
  function ensureFallbackEntry(scope, deps, reason) {
    scope = normalizeScope(scope);
    deps = deps || {};
    var $ = deps.$;
    if (typeof $ !== 'function') return false;
    if (typeof deps.canMount === 'function' && !deps.canMount(scope)) return false;

    var spec = fallbackSpec(scope);
    if ($('#' + spec.entryId).length) return true;

    var $target = typeof deps.getTarget === 'function' ? deps.getTarget(scope) : null;
    if (!$target || !$target.length) return false;

    var $entry = $('<div></div>').attr('id', spec.entryId).addClass('ai-cfg-hint').addClass(spec.entryClass);
    var $btn = $('<button type="button" class="ai-cfg-btn"></button>').text(spec.buttonText);
    var $panel = $('<div></div>').attr('id', spec.panelId).addClass(spec.panelClass);

    $btn.on('click', function () {
      if (typeof deps.setActive === 'function') deps.setActive(scope, true);
      if (typeof deps.hidePanels === 'function') deps.hidePanels(scope);
      if (typeof deps.clearNativeSelection === 'function') deps.clearNativeSelection(scope);
      if (typeof deps.render === 'function') deps.render($panel, scope);
      if (typeof deps.record === 'function') deps.record(scope, 'fallback-opened', reason || spec.openedReason);
    });

    $entry.append($btn).append($('<span></span>').text(spec.helpText));
    if (spec.insertMode === 'prepend' && typeof $target.prepend === 'function') {
      $target.prepend($panel).prepend($entry);
    } else {
      $target.append($entry).append($panel);
    }
    if (typeof deps.record === 'function') deps.record(scope, 'fallback-inserted', reason || spec.insertedReason);
    return true;
  }

  function insertTab(scope, deps, opts) {
    scope = normalizeScope(scope);
    deps = deps || {};
    opts = opts || {};
    var $ = deps.$;
    if (typeof $ !== 'function') return false;
    var id = String(opts.id || (scope === 'overlay' ? 'aiOptionsTab' : 'aiSettingsTab'));
    if (!id) return false;
    if ($('#' + id).length) return true;
    var $container = typeof deps.getContainer === 'function' ? deps.getContainer(scope) : null;
    if (!$container || !$container.length) return false;
    var label = String(opts.label || 'Woven Realm');
    var $tab;
    if (scope === 'overlay') {
      $tab = $('<button type="button"></button>').attr('id', id).text(label);
    } else {
      $tab = $('<div></div>')
        .attr('id', id)
        .addClass(opts.active ? String(opts.activeClass || 'gold buttonStartSelected') : String(opts.inactiveClass || 'buttonStart'))
        .append($('<button type="button"></button>').text(label));
    }
    if (typeof deps.onClick === 'function') {
      $tab.on('click', function () { deps.onClick($tab, scope); });
    }
    var inserted = false;
    if (scope === 'overlay' && typeof deps.getBefore === 'function') {
      var $before = deps.getBefore(scope);
      if ($before && $before.length && typeof $tab.insertBefore === 'function') {
        $tab.insertBefore($before);
        inserted = true;
      }
    }
    if (!inserted) {
      if (opts.insertMode === 'prepend' && typeof $container.prepend === 'function') $container.prepend($tab);
      else $container.append($tab);
    }
    if (typeof deps.record === 'function') deps.record(scope, opts.status || 'tab-inserted', opts.reason || (scope === 'overlay' ? 'native overlay tab bar' : 'native Settings tab container'));
    return true;
  }

  function renderSettingsPanel(scope, deps, opts) {
    scope = normalizeScope(scope);
    deps = deps || {};
    opts = opts || {};
    var $ = deps.$;
    var $target = deps.$target || (typeof deps.getTarget === 'function' ? deps.getTarget(scope) : null);
    if (typeof $ !== 'function' || !$target || !$target.length) return false;
    var wrapClass = String(opts.wrapClass || 'solidBorderContainer settings-container');
    var gridClass = String(opts.gridClass || 'settingsGrid');
    var $wrap = $('<div></div>').addClass(wrapClass);
    var $grid = $('<div></div>').addClass(gridClass);
    $wrap.append($grid);
    $target.empty().append($wrap);
    if (typeof deps.render === 'function') {
      deps.render($grid, {
        scope: scope,
        target: $target,
        wrap: $wrap,
        grid: $grid,
        overlay: scope === 'overlay'
      });
    }
    if (typeof deps.record === 'function') {
      deps.record(scope, opts.status || 'settings-rendered', opts.reason || 'settings panel rendered');
    }
    return true;
  }

  function scheduleRetries(scope, deps, opts) {
    scope = normalizeScope(scope);
    deps = deps || {};
    opts = opts || {};
    var timer = typeof deps.setTimeout === 'function'
      ? deps.setTimeout
      : (typeof root.setTimeout === 'function' ? root.setTimeout.bind(root) : function (fn) { fn(); return 0; });
    var attempts = Math.max(1, Number(opts.attempts) || 1);
    var initialDelay = Math.max(0, Number(opts.delay) || 0);
    var retryDelay = Math.max(0, opts.retryDelay == null ? 150 : Number(opts.retryDelay) || 0);
    var immediate = opts.immediate === true;
    var tries = 0;
    var done = false;
    var lastTimer = 0;
    var extra = cloneValue(opts.extra || {});
    extra.delay = initialDelay;
    extra.attempts = attempts;
    extra.retryDelay = retryDelay;
    extra.immediate = immediate;
    if (typeof deps.recordSchedule === 'function') {
      deps.recordSchedule(scope, opts.reason || 'mount retry', extra);
    }

    function fail(err) {
      if (typeof deps.onError === 'function') deps.onError(err, { scope: scope, tries: tries });
    }

    function exhausted() {
      done = true;
      if (typeof deps.onExhausted === 'function') deps.onExhausted(scope, tries);
    }

    function tick() {
      if (done) return;
      tries += 1;
      var ok = false;
      try {
        ok = !!(typeof deps.attempt === 'function' && deps.attempt(scope, tries));
      } catch (e) {
        fail(e);
      }
      if (ok) {
        done = true;
        return;
      }
      if (tries >= attempts) {
        exhausted();
        return;
      }
      lastTimer = timer(tick, retryDelay);
    }

    if (immediate && initialDelay <= 0) tick();
    else lastTimer = timer(tick, initialDelay);

    return {
      scope: scope,
      attempts: attempts,
      get tries() { return tries; },
      get done() { return done; },
      get lastTimer() { return lastTimer; }
    };
  }

  function executeMountPlan(scope, controller, mountPlan, handlers) {
    scope = normalizeScope(scope);
    mountPlan = mountPlan || {};
    handlers = handlers || {};
    var action = String(mountPlan.action || '').trim();
    function call(name) {
      return typeof handlers[name] === 'function'
        ? !!handlers[name](mountPlan, scope)
        : false;
    }
    if (action === 'ready') {
      return typeof handlers.onReady === 'function' ? !!handlers.onReady(mountPlan, scope) : true;
    }
    if (action === 'skip') {
      return call('onSkip');
    }
    if (action === 'fallback') {
      return call('onFallback');
    }
    if (action === 'retry') {
      return call('onRetry');
    }
    if (action === 'tab') {
      var zoneId = normalizeZoneId(handlers.zoneId || '');
      if (controller && zoneId && typeof controller.mountZone === 'function') {
        return controller.mountZone(zoneId, {
          mount: function (zone, depsForZone) {
            if (typeof handlers.onTab !== 'function') return false;
            return !!handlers.onTab(mountPlan, scope, zone, depsForZone);
          }
        });
      }
      return call('onTab');
    }
    return call('onUnknown');
  }

  function create(deps) {
    deps = deps || {};
    var diagnostics = {
      main: { status: 'init', reason: '', at: 0, iso: '' },
      overlay: { status: 'init', reason: '', at: 0, iso: '' }
    };
    var history = [];
    var zones = {};

    function getDomState(scope) {
      scope = normalizeScope(scope);
      try {
        if (typeof deps.getDomState === 'function') {
          return deps.getDomState(scope) || {};
        }
      } catch (e) {
        return { error: String(e && e.message || e) };
      }
      return defaultDomState(scope);
    }

    function record(scope, status, reason, extra) {
      scope = normalizeScope(scope);
      var entry = {
        scope: scope,
        status: String(status || ''),
        reason: String(reason || '').slice(0, 160),
        at: Date.now(),
        iso: nowIso(),
        dom: getDomState(scope)
      };
      if (extra && typeof extra === 'object') entry.extra = cloneValue(extra);
      diagnostics[scope] = {
        status: entry.status,
        reason: entry.reason,
        at: entry.at,
        iso: entry.iso
      };
      history.push(entry);
      if (history.length > MAX_HISTORY) history.splice(0, history.length - MAX_HISTORY);
      return entry;
    }

    function recordSchedule(scope, reason, extra) {
      return record(scope, 'scheduled', reason || 'scheduled mount retry', extra || null);
    }

    function recordPatch(scope, status, reason) {
      return record(scope, status || 'native-patch', reason || 'native patch mount');
    }

    function registerZone(id, spec) {
      var zone = normalizeZoneSpec(id, spec || {});
      if (!zone) return null;
      zones[zone.id] = zone;
      record(zone.scope, 'zone-registered', zone.zone + ':' + zone.id, {
        zoneId: zone.id,
        zone: zone.zone,
        kind: zone.kind,
        priority: zone.priority
      });
      return zonePublicSnapshot(zone);
    }

    function unregisterZone(id, reason) {
      var zoneId = normalizeZoneId(id);
      if (!zoneId || !zones[zoneId]) return false;
      var zone = zones[zoneId];
      delete zones[zoneId];
      record(zone.scope, 'zone-unregistered', reason || zone.zone + ':' + zone.id, {
        zoneId: zone.id,
        zone: zone.zone,
        kind: zone.kind
      });
      return true;
    }

    function getZone(id) {
      return zonePublicSnapshot(zones[normalizeZoneId(id)] || null);
    }

    function listZones(filter) {
      filter = filter || {};
      var scope = filter.scope == null ? '' : normalizeScope(filter.scope);
      var zoneName = filter.zone == null ? '' : String(filter.zone || '').trim();
      var kind = filter.kind == null ? '' : String(filter.kind || '').trim();
      var list = Object.keys(zones).map(function (key) { return zones[key]; }).filter(function (zone) {
        if (scope && zone.scope !== scope) return false;
        if (zoneName && zone.zone !== zoneName) return false;
        if (kind && zone.kind !== kind) return false;
        return true;
      });
      return sortZones(list.map(zonePublicSnapshot));
    }

    function mountZone(id, depsForZone) {
      depsForZone = depsForZone || {};
      var zoneId = normalizeZoneId(id);
      var zone = zones[zoneId];
      if (!zone) {
        record('main', 'zone-missing', zoneId || 'missing zone id', { zoneId: zoneId });
        return false;
      }
      if (!zone.enabled) {
        zone.status = 'disabled';
        zone.reason = 'zone disabled';
        record(zone.scope, 'zone-disabled', zone.zone + ':' + zone.id, { zoneId: zone.id, zone: zone.zone });
        return false;
      }
      try {
        if (zone.canMount && !zone.canMount(zonePublicSnapshot(zone), depsForZone)) {
          zone.status = 'skipped';
          zone.reason = 'canMount returned false';
          record(zone.scope, 'zone-skipped', zone.zone + ':' + zone.id, { zoneId: zone.id, zone: zone.zone });
          return false;
        }
        var mountFn = zone.mount || depsForZone.mount;
        if (typeof mountFn !== 'function') {
          zone.status = 'missing-mount';
          zone.reason = 'missing mount function';
          record(zone.scope, 'zone-missing-mount', zone.zone + ':' + zone.id, { zoneId: zone.id, zone: zone.zone });
          return false;
        }
        var ok = !!mountFn(zonePublicSnapshot(zone), depsForZone);
        zone.status = ok ? 'mounted' : 'not-mounted';
        zone.reason = ok ? '' : 'mount returned false';
        zone.at = Date.now();
        zone.iso = nowIso();
        record(zone.scope, ok ? 'zone-mounted' : 'zone-not-mounted', zone.zone + ':' + zone.id, {
          zoneId: zone.id,
          zone: zone.zone,
          kind: zone.kind
        });
        return ok;
      } catch (e) {
        zone.status = 'failed';
        zone.reason = String(e && e.message || e).slice(0, 160);
        zone.at = Date.now();
        zone.iso = nowIso();
        record(zone.scope, 'zone-failed', zone.reason, { zoneId: zone.id, zone: zone.zone, kind: zone.kind });
        return false;
      }
    }

    function plan(scope, opts) {
      scope = normalizeScope(scope);
      var mountPlan = planMount(scope, getDomState(scope), opts || {});
      record(scope, mountPlan.status, mountPlan.reason, { action: mountPlan.action, plan: true });
      return mountPlan;
    }

    function schedule(scope, opts) {
      opts = opts || {};
      return scheduleRetries(scope, {
        setTimeout: deps.setTimeout,
        recordSchedule: recordSchedule,
        attempt: opts.attempt,
        onExhausted: opts.onExhausted,
        onError: opts.onError
      }, {
        reason: opts.reason,
        attempts: opts.attempts,
        delay: opts.delay,
        retryDelay: opts.retryDelay,
        immediate: opts.immediate,
        extra: opts.extra
      });
    }

    function getDiagnostics() {
      return cloneValue(diagnostics);
    }

    function getDebugState() {
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        diagnostics: getDiagnostics(),
        main: getDomState('main'),
        overlay: getDomState('overlay'),
        zones: listZones(),
        history: cloneValue(history.slice(-20))
      };
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      record: record,
      recordSchedule: recordSchedule,
      recordPatch: recordPatch,
      registerZone: registerZone,
      unregisterZone: unregisterZone,
      getZone: getZone,
      listZones: listZones,
      mountZone: mountZone,
      plan: plan,
      schedule: schedule,
      getDiagnostics: getDiagnostics,
      getDebugState: getDebugState
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    planMount: planMount,
    hasNativeTab: hasNativeTab,
    fallbackSpec: fallbackSpec,
    ensureFallbackEntry: ensureFallbackEntry,
    insertTab: insertTab,
    renderSettingsPanel: renderSettingsPanel,
    executeMountPlan: executeMountPlan,
    scheduleRetries: scheduleRetries,
    normalizeZoneSpec: normalizeZoneSpec,
    create: create
  };

  root.MountControllerModule = api;
  root.AIStoryGenMountControllerModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
