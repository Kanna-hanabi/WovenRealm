/* ============================================================
 * Woven Realm config store
 * Owns synchronous local JSON persistence and save-scope merging.
 * IndexedDB remains an optional backup managed by the caller.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  function clone(value, fallback) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return fallback; }
  }

  function keyMap(keys) {
    var out = {};
    if (Array.isArray(keys)) {
      keys.forEach(function (key) { if (key) out[String(key)] = true; });
      return out;
    }
    if (keys && typeof keys === 'object') {
      Object.keys(keys).forEach(function (key) { if (keys[key]) out[key] = true; });
    }
    return out;
  }

  function readLocalJSON(storage, key, fallback) {
    var base = clone(fallback, {}) || {};
    if (!storage || !key || typeof storage.getItem !== 'function') return base;
    try {
      var raw = storage.getItem(key);
      if (!raw) return base;
      var parsed = JSON.parse(raw);
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : base;
    } catch (_) {
      return base;
    }
  }

  function writeLocalJSON(storage, key, value) {
    if (!storage || !key || typeof storage.setItem !== 'function') return false;
    try {
      storage.setItem(key, JSON.stringify(value && typeof value === 'object' ? value : {}));
      return true;
    } catch (_) {
      return false;
    }
  }

  function copyExcept(source, blockedKeys) {
    var blocked = keyMap(blockedKeys);
    var out = {};
    if (!source || typeof source !== 'object') return out;
    Object.keys(source).forEach(function (key) {
      if (blocked[key] || typeof source[key] === 'function') return;
      var copied = clone(source[key], undefined);
      if (copied !== undefined) out[key] = copied;
    });
    return out;
  }

  function mergeScoped(current, scoped, localOnlyKeys) {
    current = current && typeof current === 'object' ? current : {};
    scoped = scoped && typeof scoped === 'object' ? scoped : {};
    var localOnly = keyMap(localOnlyKeys);
    var out = Object.assign({}, current, copyExcept(scoped, localOnly));
    Object.keys(localOnly).forEach(function (key) {
      if (current[key] !== undefined) out[key] = current[key];
      else delete out[key];
    });
    return out;
  }

  function create(opts) {
    opts = opts || {};
    var storage = opts.storage || root.localStorage || null;
    var storageKey = String(opts.storageKey || '');
    var defaults = clone(opts.defaults || {}, {}) || {};
    var localOnly = keyMap(opts.localOnlyKeys);
    var normalize = typeof opts.normalize === 'function' ? opts.normalize : function (value) { return value; };

    function normalizeValue(value) {
      var merged = Object.assign({}, defaults, value && typeof value === 'object' ? value : {});
      try {
        var normalized = normalize(merged);
        return normalized && typeof normalized === 'object' ? normalized : merged;
      } catch (_) {
        return merged;
      }
    }

    function load() {
      return normalizeValue(readLocalJSON(storage, storageKey, {}));
    }

    function save(value) {
      var normalized = normalizeValue(value);
      return { ok: writeLocalJSON(storage, storageKey, normalized), value: normalized };
    }

    function captureSaveScoped(value) {
      return copyExcept(value || load(), localOnly);
    }

    function restoreSaveScoped(scoped) {
      var result = save(mergeScoped(load(), scoped, localOnly));
      return result.value;
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      storageKey: storageKey,
      localOnlyKeys: Object.keys(localOnly),
      load: load,
      save: save,
      normalize: normalizeValue,
      captureSaveScoped: captureSaveScoped,
      restoreSaveScoped: restoreSaveScoped
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    clone: clone,
    keyMap: keyMap,
    readLocalJSON: readLocalJSON,
    writeLocalJSON: writeLocalJSON,
    copyExcept: copyExcept,
    mergeScoped: mergeScoped,
    create: create
  };

  root.AIStoryGen.ConfigStoreModule = api;
  root.AIStoryGenConfigStoreModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
