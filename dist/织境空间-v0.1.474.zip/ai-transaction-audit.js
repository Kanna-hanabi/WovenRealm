(function () {
  'use strict';

  var root = (typeof window !== 'undefined') ? window : globalThis;
  root.AIStoryGen = root.AIStoryGen || {};

  var SCHEMA_VERSION = 1;

  function clone(value) {
    if (value == null) return value;
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function stableStringify(value) {
    if (value == null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(stableStringify).join(',') + ']';
    return '{' + Object.keys(value).sort().map(function (key) {
      return JSON.stringify(key) + ':' + stableStringify(value[key]);
    }).join(',') + '}';
  }

  function hashString(text) {
    var s = String(text || '');
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16);
  }

  function num(value) {
    var n = Number(value);
    return Number.isFinite(n) ? n : null;
  }

  function getGame(snapshot) {
    return (snapshot && snapshot.game) || {};
  }

  function itemName(item) {
    return String(item && (item.name || item.label || item.id || item.cn || item.en) || '').trim();
  }

  function itemQty(item) {
    var n = num(item && (item.qty == null ? item.count == null ? item.quantity : item.count : item.qty));
    return n == null ? 1 : n;
  }

  function mapItems(items) {
    var out = {};
    (Array.isArray(items) ? items : []).forEach(function (item) {
      var name = itemName(item);
      if (!name) return;
      out[name] = (out[name] || 0) + itemQty(item);
    });
    return out;
  }

  function readNpcField(rel, field) {
    if (!rel || !field) return null;
    var value = rel[field];
    if (value && typeof value === 'object') {
      if (value.v != null) return num(value.v);
      if (value.value != null) return num(value.value);
      if (value.current != null) return num(value.current);
    }
    return num(value);
  }

  function relationshipMap(game) {
    var raw = game.__aiNpcRelations || game.aiNpcRelations || {};
    var out = {};
    Object.keys(raw || {}).forEach(function (name) {
      var rel = raw[name] || {};
      out[name] = {};
      ['love', 'lust', 'trust', 'dom', 'rage', 'respect', 'fear'].forEach(function (field) {
        var value = readNpcField(rel, field);
        if (value != null) out[name][field] = value;
      });
    });
    return out;
  }

  function summarizeMemory(memory, game) {
    memory = memory || {};
    game = game || {};
    var recent = Array.isArray(memory.recentBuf) ? memory.recentBuf : [];
    var longTerm = Array.isArray(memory.longTermMem) ? memory.longTermMem : [];
    var state = game.aiStoryGenState && typeof game.aiStoryGenState === 'object' ? game.aiStoryGenState : {};
    var eventLog = Array.isArray(game.aiStoryGenEventLog)
      ? game.aiStoryGenEventLog
      : (Array.isArray(state.eventLog) ? state.eventLog : []);
    var compact = {
      recentCount: recent.length,
      longCount: longTerm.length,
      eventCount: eventLog.length,
      hash: hashString(stableStringify({ recentBuf: recent, longTermMem: longTerm, eventLog: eventLog }))
    };
    return compact;
  }

  function summarizeRuntimeSnapshot(snapshot) {
    snapshot = snapshot || {};
    var game = getGame(snapshot);
    var day = num(game.day);
    var hour = num(game.hour);
    var minute = num(game.minute);
    var totalMinutes = null;
    if (hour != null && minute != null) {
      totalMinutes = (day == null ? 0 : day * 1440) + hour * 60 + minute;
    }
    var stats = {};
    [
      'money', 'arousal', 'stress', 'pain', 'trauma', 'tiredness',
      'control', 'seductionskill', 'fatigue', 'drunk', 'drugged'
    ].forEach(function (key) {
      if (Object.prototype.hasOwnProperty.call(game, key)) stats[key] = num(game[key]);
    });
    var location = snapshot.location || {};
    return {
      time: {
        day: day,
        hour: hour,
        minute: minute,
        totalMinutes: totalMinutes
      },
      stats: stats,
      items: mapItems(game.aiStoryGenItems || game.aiItems || []),
      npcRelations: relationshipMap(game),
      memory: summarizeMemory(snapshot.memory, game),
      location: {
        currentLabel: String(location.currentLocationLabel || location.currentLabel || ''),
        currentPassage: String(location.currentLocationPassage || location.currentPassage || ''),
        targetLabel: String(location.targetLabel || location.targetLocationLabel || ''),
        targetPassage: String(location.targetPassage || location.targetLocationPassage || ''),
        arrived: !!location.locationArrived
      }
    };
  }

  function pushWarning(warnings, code, detail) {
    warnings.push(Object.assign({ code: code }, detail || {}));
  }

  function parseStatChange(text) {
    var m = String(text || '').match(/^\s*([A-Za-z_][\w]*)\s*([+-]\s*\d+)/);
    if (!m) return null;
    return { key: m[1], delta: parseInt(m[2].replace(/\s+/g, ''), 10) || 0 };
  }

  function sameSign(a, b) {
    if (!a || !b) return false;
    return (a > 0 && b > 0) || (a < 0 && b < 0);
  }

  function auditTime(plan, before, after, warnings) {
    var expected = num(plan && plan.time && plan.time.minutes);
    if (!expected || expected <= 0) return { expected: expected || 0, actual: null, status: 'none' };
    if (plan.time && plan.time.preApplied) {
      return { expected: expected, actual: null, status: 'preApplied' };
    }
    var b = before.time.totalMinutes;
    var a = after.time.totalMinutes;
    var actual = (b == null || a == null) ? null : a - b;
    if (actual == null) {
      pushWarning(warnings, 'time_snapshot_missing', { expected: expected });
    } else if (actual !== expected) {
      pushWarning(warnings, 'time_delta_mismatch', { expected: expected, actual: actual });
    }
    return { expected: expected, actual: actual, status: actual === expected ? 'ok' : 'mismatch' };
  }

  function auditStats(plan, before, after, warnings) {
    var changed = plan && plan.stats && Array.isArray(plan.stats.changed) ? plan.stats.changed : [];
    var details = [];
    changed.forEach(function (entry) {
      var parsed = parseStatChange(entry);
      if (!parsed) return;
      var b = before.stats[parsed.key];
      var a = after.stats[parsed.key];
      var actual = (b == null || a == null) ? null : a - b;
      details.push({ key: parsed.key, expected: parsed.delta, actual: actual });
      if (actual == null) {
        pushWarning(warnings, 'stat_snapshot_missing', { key: parsed.key, expected: parsed.delta });
      } else if (actual === 0) {
        pushWarning(warnings, 'stat_not_changed', { key: parsed.key, expected: parsed.delta, actual: actual });
      } else if (!sameSign(parsed.delta, actual)) {
        pushWarning(warnings, 'stat_delta_direction_mismatch', { key: parsed.key, expected: parsed.delta, actual: actual });
      }
    });
    if ((!changed.length) && plan && plan.stats && Array.isArray(plan.stats.parts) && plan.stats.parts.length && !plan.stats.blockedReason) {
      pushWarning(warnings, 'stats_planned_but_not_applied', { parts: clone(plan.stats.parts) });
    }
    return details;
  }

  function auditItems(plan, before, after, warnings) {
    var consumed = plan && plan.items && Array.isArray(plan.items.consumed) ? plan.items.consumed : [];
    var details = [];
    consumed.forEach(function (item) {
      var name = itemName(item);
      if (!name) return;
      var expected = itemQty(item);
      var b = before.items[name] || 0;
      var a = after.items[name] || 0;
      var actual = b - a;
      details.push({ name: name, expectedConsumed: expected, actualConsumed: actual });
      if (actual < expected) {
        pushWarning(warnings, 'item_not_consumed', { name: name, expected: expected, actual: actual });
      }
    });
    return {
      consumed: details,
      pickupQueued: !!(plan && plan.items && plan.items.pickupQueued),
      pickupItems: clone((plan && plan.items && plan.items.pickupItems) || [])
    };
  }

  function auditRelationships(plan, before, after, warnings) {
    var rels = plan && Array.isArray(plan.relationships) ? plan.relationships : [];
    var details = [];
    rels.forEach(function (rel) {
      if (!rel || !rel.applied) return;
      var npc = String(rel.npc || rel.name || '').trim();
      var field = String(rel.field || '').trim();
      if (!npc || !field) return;
      var b = before.npcRelations[npc] && before.npcRelations[npc][field];
      var a = after.npcRelations[npc] && after.npcRelations[npc][field];
      var actual = (b == null || a == null) ? null : a - b;
      var expected = num(rel.appliedDelta == null ? rel.delta : rel.appliedDelta);
      details.push({ npc: npc, field: field, expected: expected, actual: actual });
      if (actual == null) {
        pushWarning(warnings, 'relationship_snapshot_missing', { npc: npc, field: field, expected: expected });
      } else if (expected != null && actual !== expected && !sameSign(expected, actual)) {
        pushWarning(warnings, 'relationship_delta_mismatch', { npc: npc, field: field, expected: expected, actual: actual });
      }
    });
    return details;
  }

  function auditLocation(plan, before, after, warnings) {
    var loc = plan && plan.location;
    if (!loc || !loc.applyRequested) return { status: 'none' };
    var target = String(loc.resolvedLabel || loc.targetLocation || loc.location || '').trim();
    var beforeKey = before.location.currentLabel + '|' + before.location.currentPassage + '|' + before.location.arrived;
    var afterKey = after.location.currentLabel + '|' + after.location.currentPassage + '|' + after.location.arrived;
    var changed = beforeKey !== afterKey;
    var matches = !target || after.location.currentLabel === target || after.location.targetLabel === target || after.location.currentPassage === target || after.location.targetPassage === target;
    if (loc.applied && !changed && !matches) {
      pushWarning(warnings, 'location_applied_but_unchanged', { target: target });
    }
    return {
      target: target,
      applied: !!loc.applied,
      changed: changed,
      after: clone(after.location)
    };
  }

  function auditMemory(plan, before, after, warnings) {
    var mem = plan && plan.memory;
    if (!mem || !mem.recordRequested) return { status: 'none' };
    var changed = before.memory.hash !== after.memory.hash;
    if (mem.applied && !changed) {
      pushWarning(warnings, 'memory_not_changed', { recentCount: after.memory.recentCount, longCount: after.memory.longCount });
    }
    return {
      applied: !!mem.applied,
      changed: changed,
      before: clone(before.memory),
      after: clone(after.memory)
    };
  }

  function summarizePlan(plan) {
    plan = plan || {};
    return {
      schemaVersion: plan.schemaVersion || null,
      timeMinutes: plan.time && plan.time.minutes || 0,
      statChangeCount: plan.stats && Array.isArray(plan.stats.changed) ? plan.stats.changed.length : 0,
      itemConsumedCount: plan.items && Array.isArray(plan.items.consumed) ? plan.items.consumed.length : 0,
      pickupQueued: !!(plan.items && plan.items.pickupQueued),
      relationshipCount: Array.isArray(plan.relationships) ? plan.relationships.length : 0,
      locationTarget: plan.location && (plan.location.targetLocation || plan.location.resolvedLabel || ''),
      memoryRequested: !!(plan.memory && plan.memory.recordRequested)
    };
  }

  var STAT_LABELS = {
    money: '金钱',
    arousal: '性奋',
    stress: '压力',
    pain: '疼痛',
    trauma: '创伤',
    tiredness: '疲劳',
    fatigue: '疲劳',
    control: '自控',
    seductionskill: '诱惑',
    drunk: '醉酒',
    drugged: '药物影响'
  };

  var RELATION_LABELS = {
    love: '好感',
    lust: '欲望',
    trust: '信任',
    dom: '支配',
    rage: '怒气',
    respect: '尊重',
    fear: '恐惧'
  };

  function labelStat(key) {
    key = String(key || '');
    return STAT_LABELS[key] || key || '未知数值';
  }

  function labelRelation(key) {
    key = String(key || '');
    return RELATION_LABELS[key] || key || '未知关系';
  }

  function fmtDelta(value) {
    var n = num(value);
    if (n == null) return '未知';
    return (n > 0 ? '+' : '') + String(n);
  }

  function readableWarning(warning) {
    warning = warning || {};
    switch (warning.code) {
      case 'time_snapshot_missing':
        return '计划让游戏时间前进 ' + (warning.expected || 0) + ' 分钟，但提交前后快照缺少时间字段，无法确认是否生效。';
      case 'time_delta_mismatch':
        return '计划让游戏时间前进 ' + (warning.expected || 0) + ' 分钟，但实际只变化 ' + (warning.actual == null ? '未知' : warning.actual) + ' 分钟。';
      case 'stat_snapshot_missing':
        return '计划修改' + labelStat(warning.key) + ' ' + fmtDelta(warning.expected) + '，但提交前后快照缺少该数值，无法确认是否生效。';
      case 'stat_not_changed':
        return '计划修改' + labelStat(warning.key) + ' ' + fmtDelta(warning.expected) + '，但实际没有变化。';
      case 'stat_delta_direction_mismatch':
        return '计划修改' + labelStat(warning.key) + ' ' + fmtDelta(warning.expected) + '，但实际变化方向不一致：' + fmtDelta(warning.actual) + '。';
      case 'stats_planned_but_not_applied':
        return 'AI 输出里包含数值变化，但事务计划没有记录任何已应用数值，可能被校验器拦截或格式不合规。';
      case 'item_not_consumed':
        return '计划消耗 AI 道具“' + (warning.name || '未知道具') + '” x' + (warning.expected || 0) + '，但实际只消耗 x' + (warning.actual == null ? '未知' : warning.actual) + '。';
      case 'relationship_snapshot_missing':
        return '计划修改 ' + (warning.npc || '未知 NPC') + ' 的' + labelRelation(warning.field) + ' ' + fmtDelta(warning.expected) + '，但快照缺少对应 NPC 关系数据。';
      case 'relationship_delta_mismatch':
        return '计划修改 ' + (warning.npc || '未知 NPC') + ' 的' + labelRelation(warning.field) + ' ' + fmtDelta(warning.expected) + '，但实际变化为 ' + fmtDelta(warning.actual) + '。';
      case 'location_applied_but_unchanged':
        return '计划到达“' + (warning.target || '未知地点') + '”，事务标记为已应用，但提交后地点快照没有变化。';
      case 'memory_not_changed':
        return '计划写入 AI 记忆，事务标记为已应用，但提交后记忆快照没有变化。';
      default:
        return '事务审计发现未分类问题：' + String(warning.code || 'unknown') + '。';
    }
  }

  function buildReadableSummary(result) {
    var plan = result.planSummary || {};
    var lines = [];
    lines.push(result.ok ? 'AI 剧情事务审计通过：计划中的可验证变化已经反映到运行时快照。' : 'AI 剧情事务审计发现异常：部分计划变化没有反映到运行时快照。');
    var planned = [];
    if (plan.timeMinutes) planned.push('时间+' + plan.timeMinutes + '分钟');
    if (plan.statChangeCount) planned.push('人物数值' + plan.statChangeCount + '项');
    if (plan.itemConsumedCount) planned.push('AI道具消耗' + plan.itemConsumedCount + '项');
    if (plan.relationshipCount) planned.push('NPC关系' + plan.relationshipCount + '项');
    if (plan.locationTarget) planned.push('地点“' + plan.locationTarget + '”');
    if (plan.memoryRequested) planned.push('记忆写入');
    lines.push(planned.length ? '本轮计划检查：' + planned.join('、') + '。' : '本轮没有可审计的事务变化。');
    var warningLines = (result.warnings || []).map(readableWarning);
    warningLines.forEach(function (line) { lines.push(line); });
    return {
      zh: lines.join('\n'),
      lines: lines,
      warningLines: warningLines
    };
  }

  function audit(plan, beforeSnapshot, afterSnapshot, opts) {
    opts = opts || {};
    var before = summarizeRuntimeSnapshot(beforeSnapshot);
    var after = summarizeRuntimeSnapshot(afterSnapshot);
    var warnings = [];
    var result = {
      schemaVersion: SCHEMA_VERSION,
      id: 'txa-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8),
      at: new Date().toISOString(),
      source: String(opts.source || ''),
      reason: String(opts.reason || ''),
      ok: true,
      warnings: warnings,
      planSummary: summarizePlan(plan),
      actual: {
        time: auditTime(plan, before, after, warnings),
        stats: auditStats(plan, before, after, warnings),
        items: auditItems(plan, before, after, warnings),
        relationships: auditRelationships(plan, before, after, warnings),
        location: auditLocation(plan, before, after, warnings),
        memory: auditMemory(plan, before, after, warnings)
      },
      before: before,
      after: after
    };
    result.ok = warnings.length === 0;
    result.readable = buildReadableSummary(result);
    return result;
  }

  function create(opts) {
    opts = opts || {};
    var limit = Math.max(1, Math.min(200, num(opts.limit) || 30));
    var recent = [];
    return {
      schemaVersion: SCHEMA_VERSION,
      record: function (plan, beforeSnapshot, afterSnapshot, recordOpts) {
        var entry = audit(plan, beforeSnapshot, afterSnapshot, recordOpts);
        recent.push(entry);
        while (recent.length > limit) recent.shift();
        return entry;
      },
      getRecent: function (count) {
        var n = Math.max(1, Math.min(recent.length, num(count) || recent.length));
        return clone(recent.slice(Math.max(0, recent.length - n)));
      },
      getDebugState: function () {
        return {
          schemaVersion: SCHEMA_VERSION,
          limit: limit,
          count: recent.length,
          last: clone(recent.length ? recent[recent.length - 1] : null),
          recent: clone(recent.slice(-10))
        };
      },
      clear: function () {
        recent.length = 0;
      },
      audit: audit,
      summarizeRuntimeSnapshot: summarizeRuntimeSnapshot,
      readableWarning: readableWarning
    };
  }

  var api = {
    schemaVersion: SCHEMA_VERSION,
    create: create,
    audit: audit,
    summarizeRuntimeSnapshot: summarizeRuntimeSnapshot,
    readableWarning: readableWarning
  };

  root.AIStoryGenTransactionAuditModule = api;
  root.AIStoryGen.TransactionAuditModule = api;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})();
