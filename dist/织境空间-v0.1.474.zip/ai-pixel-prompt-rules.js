/* ============================================================
 * Woven Realm image prompt rule module
 * Pure prompt/style protocol helpers for aipixel-module.js.
 * ============================================================ */
(function () {
  'use strict';

  var root = window.AIStoryGen = window.AIStoryGen || {};
  var MODULE_SCHEMA_VERSION = 2;

  var DEFAULT_WORLD_STYLE_PROMPT = 'near-modern British setting, contemporary English interiors and architecture, grounded small-town British environment style';

  var STYLE_PRESETS = {
    dol_pixel: {
      label: '\u0044\u006f\u004c\u50cf\u7d20\u98ce',
      prompt: 'DoL game style, retro pixel art, small sprite-like illustration, limited palette, clean 1px outline, soft pastel colors, readable silhouettes, no text, no watermark',
    },
    vn_illustration: {
      label: '\u89c6\u89c9\u5c0f\u8bf4\u63d2\u753b',
      prompt: 'visual novel scene illustration, clean line art, expressive lighting, soft cel shading, polished character composition, atmospheric background, no text, no watermark',
    },
    painterly: {
      label: '\u6c1b\u56f4\u539a\u6d82',
      prompt: 'painterly atmospheric illustration, cinematic lighting, rich shadows, textured brushwork, dramatic mood, detailed environment, no text, no watermark',
    },
    anime_cg: {
      label: '\u7cbe\u81f4\u0043\u0047',
      prompt: 'high quality anime game CG, refined linework, detailed lighting, polished composition, expressive pose, clean background detail, no text, no watermark',
    },
    cinematic: {
      label: '\u7535\u5f71\u611f',
      prompt: 'cinematic illustration, grounded lighting, strong composition, moody color grading, depth of field feel, realistic environment detail, no text, no watermark',
    },
    dol_scene: {
      label: '\u0044\u006f\u004c\u573a\u666f\u56fe',
      prompt: 'Degrees of Lewdity inspired scene illustration, small game scene, clear character and environment, muted clear colors, simple painterly pixel feel, clean unmarked image',
    },
    character_sheet: {
      label: '\u89d2\u8272\u8bbe\u5b9a\u56fe',
      prompt: 'character design reference, full-body view, clear outfit details, readable silhouette, simple background, accurate clothing and accessories, no text, no watermark',
    },
    soft_watercolor: {
      label: '\u67d4\u548c\u6c34\u5f69',
      prompt: 'soft watercolor illustration, gentle light, delicate colors, airy atmosphere, subtle paper texture, elegant composition, no text, no watermark',
    },
    bright_anime: {
      label: '\u660e\u4eae\u52a8\u753b',
      prompt: 'bright anime illustration, clean colors, soft lighting, crisp outfit details, expressive but not exaggerated, polished game art, no text, no watermark',
    },
    gothic_mood: {
      label: '\u6697\u8c03\u54e5\u7279',
      prompt: 'dark gothic illustration, dramatic shadows, ornate environment, moody lighting, elegant silhouette, detailed fabric, no text, no watermark',
    },
    storybook: {
      label: '\u7ae5\u8bdd\u7ed8\u672c',
      prompt: 'storybook illustration, whimsical atmosphere, soft shapes, warm lighting, detailed environment, gentle colors, no text, no watermark',
    },
  };

  var STYLE_PRESET_TAGS = {
    dol_pixel: 'pixel art, retro game style, small sprite, limited palette, clean outline, soft pastel colors, readable silhouette, no text, no watermark',
    vn_illustration: 'visual novel CG, clean lineart, soft cel shading, expressive lighting, atmospheric background, polished composition, no text, no watermark',
    painterly: 'painterly, atmospheric lighting, rich shadows, textured brushwork, dramatic mood, detailed environment, no text, no watermark',
    anime_cg: 'anime game CG, high quality, refined lineart, detailed lighting, polished composition, expressive pose, no text, no watermark',
    cinematic: 'cinematic lighting, strong composition, moody color grading, depth of field, realistic environment detail, no text, no watermark',
    dol_scene: 'Degrees of Lewdity inspired scene, small game scene, clear character, clear environment, muted clear colors, clean unmarked image',
    character_sheet: 'character design sheet, full body, clear outfit details, readable silhouette, simple background, accurate accessories, no text, no watermark',
    soft_watercolor: 'watercolor, soft colors, gentle lighting, airy atmosphere, paper texture, elegant composition, no text, no watermark',
    bright_anime: 'bright anime style, vivid colors, clean shading, crisp outfit details, polished game art, no text, no watermark',
    gothic_mood: 'gothic atmosphere, dramatic shadows, ornate environment, moody lighting, elegant silhouette, detailed fabric, no text, no watermark',
    storybook: 'storybook illustration, whimsical atmosphere, soft shapes, warm lighting, detailed environment, gentle colors, no text, no watermark',
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function cleanFallback(text, maxLen) {
    var out = String(text == null ? '' : text)
      .replace(/[\r\n\t]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    return maxLen && out.length > maxLen ? out.slice(0, maxLen) : out;
  }

  function cleanText(deps, text, maxLen) {
    if (deps && typeof deps.cleanText === 'function') return deps.cleanText(text, maxLen);
    return cleanFallback(text, maxLen);
  }

  function normalizeCustomStyles(deps, styles) {
    if (deps && typeof deps.normalizeCustomStyles === 'function') return deps.normalizeCustomStyles(styles);
    return [];
  }

  function resolvePromptProtocol(cfg) {
    cfg = cfg || {};
    var p = String(cfg.promptProtocol || 'auto').toLowerCase();
    if (p === 'natural' || p === 'tags') return p;
    var api = String(cfg.imgApiType || 'siliconflow').toLowerCase();
    if (/sd|stable|webui|novel|nai|comfy/.test(api)) return 'tags';
    return 'natural';
  }

  function toTagPrompt(text, deps) {
    return cleanText(deps, String(text || '')
      .replace(/\b(MANDATORY character design|must include exact character details|composition)\s*:/gi, '')
      .replace(/\b(Scene illustration prompt|Scene|Visual details|Time and lighting|Mood|Visible characters)\s*:/gi, '')
      .replace(/[\u3002\uff1b;.!?\uff01\uff1f]/g, ',')
      .replace(/[\r\n]+/g, ', ')
      .replace(/\s*,\s*/g, ', ')
      .replace(/,\s*,+/g, ', ')
      .replace(/^\s*,\s*|\s*,\s*$/g, ''), 2200);
  }

  function adaptPromptForProtocol(prompt, cfg, deps) {
    if (resolvePromptProtocol(cfg) === 'tags') return toTagPrompt(prompt, deps);
    return cleanText(deps, prompt, 2200);
  }

  function parseScenePromptPlan(raw, deps) {
    var text = String(raw == null ? '' : raw).replace(/^\uFEFF/, '').trim();
    var plan = {};
    if (!text) return { ok: false, plan: plan, error: 'empty_response', rawLength: 0 };

    text = text
      .replace(/^\s*```(?:json)?\s*/i, '')
      .replace(/\s*```\s*$/i, '')
      .trim();
    var firstBrace = text.indexOf('{');
    var lastBrace = text.lastIndexOf('}');
    if (firstBrace < 0 || lastBrace <= firstBrace) {
      return { ok: false, plan: plan, error: 'missing_json_object', rawLength: text.length };
    }

    var parsed;
    try {
      parsed = JSON.parse(text.slice(firstBrace, lastBrace + 1));
    } catch (error) {
      return {
        ok: false,
        plan: plan,
        error: 'invalid_json: ' + String(error && error.message || error).slice(0, 180),
        rawLength: text.length
      };
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return { ok: false, plan: plan, error: 'json_root_not_object', rawLength: text.length };
    }

    var aliases = {
      scene: ['scene', 'environment', 'location'],
      characters: ['characters', 'visible_characters', 'visibleCharacters'],
      player_appearance: ['player_appearance', 'playerAppearance', 'appearance'],
      action: ['action', 'visual_action', 'visualAction'],
      props: ['props', 'key_props', 'keyProps'],
      lighting: ['lighting', 'light'],
      camera: ['camera', 'composition']
    };
    var knownKeys = { schema_version: true, schemaVersion: true };
    var presentFields = [];
    Object.keys(aliases).forEach(function (target) {
      var keys = aliases[target];
      var value = '';
      for (var i = 0; i < keys.length; i++) {
        knownKeys[keys[i]] = true;
        if (typeof parsed[keys[i]] === 'string') {
          value = parsed[keys[i]];
          break;
        }
      }
      value = cleanText(deps, value, target === 'action' ? 460 : 320);
      if (value) {
        plan[target] = value;
        presentFields.push(target);
      }
    });
    if (plan.player_appearance) plan.playerAppearance = plan.player_appearance;
    var fieldCount = Object.keys(plan).filter(function (key) { return key !== 'playerAppearance'; }).length;
    var missingCoreFields = ['scene', 'action'].filter(function (key) { return !plan[key]; });
    var unexpectedFields = Object.keys(parsed).filter(function (key) { return !knownKeys[key]; });
    return {
      ok: fieldCount > 0,
      coreReady: missingCoreFields.length === 0,
      plan: plan,
      error: fieldCount > 0 ? '' : 'json_has_no_supported_fields',
      rawLength: text.length,
      fieldCount: fieldCount,
      presentFields: presentFields,
      missingCoreFields: missingCoreFields,
      unexpectedFields: unexpectedFields
    };
  }

  function defaultStyleKeyForMode(cfg) {
    cfg = cfg || {};
    if (String(cfg._apgMode || '') === 'pose') return String(cfg.poseStyleKey || cfg.defaultStyleKey || 'dol_pixel');
    if (String(cfg._apgMode || '') === 'scene') return String(cfg.sceneStyleKey || 'dol_scene');
    return String(cfg.defaultStyleKey || 'dol_pixel');
  }

  function getCustomStyleByKey(styleKey, cfg, deps) {
    if (deps && typeof deps.getCustomStyleByKey === 'function') return deps.getCustomStyleByKey(styleKey, cfg);
    styleKey = String(styleKey || '');
    var m = styleKey.match(/^custom:(\d+)$/);
    if (!m) return null;
    var list = normalizeCustomStyles(deps, (cfg || {}).customStyles);
    return list[Number(m[1])] || null;
  }

  function stylePresetPrompt(styleKey, cfg, deps) {
    cfg = cfg || {};
    deps = deps || {};
    if (String(cfg._apgMode || '') === 'scene' && String(styleKey || '') === 'dol_pixel') styleKey = 'dol_scene';
    var extraStyle = cleanText(deps, cfg.styleSuffix || '', 700);
    var defaultStyle = cleanText(deps, deps.defaultStyleSuffix || '', 700);
    if (extraStyle === defaultStyle) extraStyle = '';
    if (String(cfg._apgMode || '') === 'scene' && /\b(?:sprite|transparent background|icon|isolated item)\b/i.test(extraStyle)) extraStyle = '';
    if (extraStyle && resolvePromptProtocol(cfg) === 'tags') extraStyle = toTagPrompt(extraStyle, deps);
    function sanitize(value) {
      if (String(cfg._apgMode || '') === 'scene' && typeof deps.sanitizeScenePositivePrompt === 'function') {
        return deps.sanitizeScenePositivePrompt(value);
      }
      return value;
    }
    function withExtraStyle(base) {
      base = cleanText(deps, base || '', 1200);
      base = sanitize(base);
      extraStyle = sanitize(extraStyle);
      if (!extraStyle) return base;
      if (base.indexOf(extraStyle) !== -1) return base;
      return cleanText(deps, [base, extraStyle].filter(Boolean).join(', '), 1400);
    }
    var custom = getCustomStyleByKey(styleKey, cfg, deps);
    if (custom) {
      if (resolvePromptProtocol(cfg) === 'tags') return withExtraStyle(custom.tags || toTagPrompt(custom.prompt, deps));
      return withExtraStyle(custom.prompt || custom.tags);
    }
    if (resolvePromptProtocol(cfg) === 'tags') {
      return withExtraStyle(STYLE_PRESET_TAGS[styleKey] || STYLE_PRESET_TAGS.dol_pixel);
    }
    return withExtraStyle((STYLE_PRESETS[styleKey] && STYLE_PRESETS[styleKey].prompt) || STYLE_PRESETS.dol_pixel.prompt);
  }

  function getStyleOptions(cfg, deps) {
    var out = [];
    Object.keys(STYLE_PRESETS).forEach(function (key) {
      out.push({ key: key, label: STYLE_PRESETS[key].label });
    });
    normalizeCustomStyles(deps, (cfg || {}).customStyles).forEach(function (style, index) {
      out.push({ key: 'custom:' + index, label: '\u81ea\u5b9a\u4e49\uff1a' + style.label });
    });
    return out;
  }

  function promptControlSignature(cfg, deps) {
    cfg = cfg || {};
    return [
      'scenePromptRules-v20-validated-scene-plan',
      cfg.imgApiType || '',
      cfg.promptProtocol || '',
      cfg.sceneStyleKey || '',
      cfg.defaultStyleKey || '',
      cfg.aiStorySceneBackend || '',
      cfg.specialSceneEnabled || '',
      cfg.specialImgEndpoint || '',
      cfg.specialImgModel || '',
      cfg.specialImgSize || '',
      cfg.specialImgSteps || '',
      cfg.specialComfySampler || '',
      cfg.specialComfyScheduler || '',
      cfg.specialComfyCfgScale || '',
      cfg.specialComfySeed || '',
      cfg.specialPoseControlEnabled || '',
      cfg.specialPoseControlNetModel || '',
      cfg.specialPoseControlStrength || '',
      cfg.specialPoseControlEnd || '',
      cfg.styleSuffix || '',
      cfg.lockedAppearance || '',
      cfg.personalPrompt || '',
      cfg.negativePrompt || '',
      cfg.compositionPreset || '',
      JSON.stringify(normalizeCustomStyles(deps, cfg.customStyles)),
      JSON.stringify(cfg.npcAppearances || {}),
      cfg.customNpcAppearances || ''
    ].join('|');
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    defaultWorldStylePrompt: DEFAULT_WORLD_STYLE_PROMPT,
    getStylePresets: function () { return clone(STYLE_PRESETS); },
    getStylePresetTags: function () { return clone(STYLE_PRESET_TAGS); },
    resolvePromptProtocol: resolvePromptProtocol,
    toTagPrompt: toTagPrompt,
    adaptPromptForProtocol: adaptPromptForProtocol,
    parseScenePromptPlan: parseScenePromptPlan,
    defaultStyleKeyForMode: defaultStyleKeyForMode,
    stylePresetPrompt: stylePresetPrompt,
    getStyleOptions: getStyleOptions,
    promptControlSignature: promptControlSignature
  };

  root.PixelPromptRulesModule = api;
  window.AIStoryGenPixelPromptRulesModule = api;
})();
