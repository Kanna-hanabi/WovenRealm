/* ============================================================
 * AIStoryGen extra-long hair appearance
 * Adds semantic lengths and a colour-filtered paper-doll overlay
 * beyond the native floor-length stage without mutating game state.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var NATIVE_MAX_LENGTH = 1000;
  var STYLES = {
    off: {
      label: '\u4f7f\u7528\u539f\u7248\u957f\u5ea6',
      story: '',
      prompt: ''
    },
    pooled: {
      label: '\u94fa\u6563\u811a\u8fb9',
      story: '\u67d4\u987a\u7684\u957f\u53d1\u50cf\u5b8c\u6574\u53d1\u5e55\u822c\u5782\u8fc7\u811a\u8e1d\uff0c\u4e34\u8fd1\u5730\u9762\u624d\u5206\u6210\u5c16\u7ec6\u53d1\u675f\uff0c\u53d1\u5c3e\u81ea\u7136\u94fa\u6563\u5728\u811a\u8fb9',
      prompt: 'silky very long hair falling as a smooth continuous curtain, separating into fine tapered locks only near the floor, with the ends pooling naturally around the feet'
    },
    trailing: {
      label: '\u8eab\u540e\u62d6\u66f3',
      story: '\u5934\u53d1\u4ee5\u5bbd\u9614\u67d4\u987a\u7684\u53d1\u5e55\u5782\u843d\uff0c\u63a5\u8fd1\u5730\u9762\u540e\u5206\u6210\u7ec6\u957f\u53d1\u675f\uff0c\u5728\u8eab\u540e\u62d6\u66f3\u7ea6\u4e00\u4eba\u8eab\u957f',
      prompt: 'silky extremely long hair descending in a broad coherent curtain, splitting into slender tapered locks near the floor and trailing about one body length behind the character'
    },
    cascade: {
      label: '\u8d85\u957f\u53d1\u7011',
      story: '\u4e1d\u7ed2\u822c\u7684\u5934\u53d1\u8fdc\u8d85\u8eab\u9ad8\uff0c\u4e0a\u534a\u6bb5\u5982\u5b8c\u6574\u53d1\u7011\u5782\u843d\uff0c\u53d1\u5c3e\u5206\u6210\u5c16\u7ec6\u957f\u675f\u5728\u8eab\u540e\u5ef6\u5c55',
      prompt: 'silky fantastically long hair, a smooth continuous cascade through most of its length, separating into graceful tapered locks that form an extended train far behind the character'
    },
    serpentine: {
      label: '\u873f\u8712\u62d6\u5c3e',
      story: '\u67d4\u987a\u53d1\u5e55\u5728\u811a\u540e\u5206\u6210\u5c16\u7ec6\u957f\u675f\uff0c\u8d85\u957f\u53d1\u5c3e\u5728\u5730\u9762\u4e0a\u7ed5\u51fa\u8f7b\u67d4\u800c\u8fde\u7eed\u7684\u66f2\u7ebf',
      prompt: 'silky exceptionally long hair falling as one coherent curtain before tapering into fine locks that wind in soft continuous curves across the ground'
    },
    fan: {
      label: '\u6247\u5f62\u94fa\u5c55',
      story: '\u6781\u957f\u7684\u67d4\u987a\u53d1\u5e55\u5728\u811a\u540e\u5206\u6210\u591a\u7ec4\u5c16\u7ec6\u53d1\u675f\uff0c\u5411\u56db\u5468\u5c42\u6b21\u5206\u660e\u5730\u94fa\u6210\u5bbd\u9614\u6247\u5f62',
      prompt: 'silky extremely long hair with a smooth curtain-like upper mass, separating near the floor into many graceful tapered locks spread broadly in a layered fan'
    },
    endless: {
      label: '\u65e0\u5c3d\u957f\u53d1',
      story: '\u4e1d\u7ed2\u822c\u7684\u5934\u53d1\u957f\u8fbe\u6570\u500d\u8eab\u9ad8\uff0c\u6574\u4f53\u5982\u53d1\u5e55\u8fde\u7eed\u5782\u843d\uff0c\u4ec5\u5728\u5730\u9762\u5206\u6210\u5927\u91cf\u5c16\u7ec6\u53d1\u675f\uff0c\u957f\u8ddd\u79bb\u62d6\u66f3\u5e76\u8f7b\u67d4\u76d8\u7ed5',
      prompt: 'silky mythically long hair several body lengths long, descending as a continuous curtain and dividing only at ground level into many fine tapered locks that trail far behind in gentle layered coils'
    }
  };

  function normalizeStyle(value) {
    value = String(value == null ? 'off' : value).trim().toLowerCase();
    return Object.prototype.hasOwnProperty.call(STYLES, value) ? value : 'off';
  }

  function numericHairLength(variables) {
    var value = variables && variables.hairlength;
    value = Number(value);
    return Number.isFinite(value) ? value : 0;
  }

  function resolve(cfg, variables) {
    cfg = cfg || {};
    variables = variables || {};
    var style = normalizeStyle(cfg.extraLongHairStyle);
    var hairLength = numericHairLength(variables);
    var selected = style !== 'off';
    var active = selected && hairLength >= NATIVE_MAX_LENGTH;
    var definition = STYLES[style] || STYLES.off;
    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      style: style,
      label: definition.label,
      selected: selected,
      active: active,
      pendingNativeMax: selected && !active,
      nativeHairLength: hairLength,
      nativeHairStage: String(variables.hairlengthstage || ''),
      storyDescriptor: active ? definition.story : '',
      promptDescriptor: active ? definition.prompt : '',
      paperDollStage: active ? 'feet' : String(variables.hairlengthstage || '')
    };
  }

  function create(deps) {
    deps = deps || {};
    var installed = false;
    var rendererInstalled = false;
    var lastRendererError = '';

    function loadCfg() {
      try {
        if (typeof deps.loadCfg === 'function') return deps.loadCfg() || {};
      } catch (_) {}
      try {
        if (root.AIStoryGen && typeof root.AIStoryGen.loadCfg === 'function') {
          return root.AIStoryGen.loadCfg() || {};
        }
      } catch (_) {}
      return {};
    }

    function getVariables() {
      try {
        if (typeof deps.getVariables === 'function') return deps.getVariables() || {};
      } catch (_) {}
      try {
        if (root.State && root.State.variables) return root.State.variables;
      } catch (_) {}
      return {};
    }

    function getDiagnostics(cfgOverride) {
      var state = resolve(cfgOverride || loadCfg(), getVariables());
      state.installed = installed;
      state.rendererInstalled = rendererInstalled;
      state.lastRendererError = lastRendererError;
      state.spritePath = state.active ? 'img/hair/wr-extra-long/' + state.style + '.png' : '';
      return state;
    }

    function getStoryState() {
      var state = getDiagnostics();
      if (!state.active) return null;
      return {
        native_length: state.nativeHairLength,
        native_stage: state.nativeHairStage || 'feet',
        extra_long_style: state.style,
        description: state.storyDescriptor
      };
    }

    function clearMainRendererCache() {
      try {
        var renderer = root.Renderer;
        if (renderer && renderer.CanvasModelCaches && renderer.CanvasModelCaches.main) {
          renderer.CanvasModelCaches.main = {};
        }
      } catch (_) {}
    }

    function installRendererLayer() {
      try {
        var renderer = root.Renderer;
        var model = renderer && renderer.CanvasModels && renderer.CanvasModels.main;
        if (!model || !model.layers) return false;
        if (!model.layers.wr_extra_long_hair) {
          model.layers.wr_extra_long_hair = {
            filters: ['hair'],
            animation: 'idle',
            srcfn: function () {
              var state = getDiagnostics();
              return state.active ? state.spritePath : '';
            },
            zfn: function () {
              var indices = root.ZIndices || {};
              return Number(indices.backhair == null ? 10 : indices.backhair) - 0.1;
            },
            showfn: function (options) {
              return !!(options && options.show_hair && getDiagnostics().active);
            }
          };
          clearMainRendererCache();
        }
        rendererInstalled = true;
        lastRendererError = '';
        return true;
      } catch (error) {
        rendererInstalled = false;
        lastRendererError = String(error && error.message || error).slice(0, 180);
        return false;
      }
    }

    function install() {
      if (installed) return installRendererLayer();
      installed = true;
      installRendererLayer();
      var jq = deps.$ || root.jQuery || root.$;
      var doc = deps.document || root.document;
      if (typeof jq === 'function' && doc) {
        try {
          jq(doc)
            .off('.aiExtraLongHair')
            .on(':passagestart.aiExtraLongHair :passagerender.aiExtraLongHair AIStoryGen:configSaved.aiExtraLongHair', function () {
              installRendererLayer();
              clearMainRendererCache();
            });
        } catch (_) {}
      }
      try {
        if (typeof root.setTimeout === 'function') {
          root.setTimeout(function () { installRendererLayer(); }, 0);
        }
      } catch (_) {}
      return rendererInstalled;
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      install: install,
      installRendererLayer: installRendererLayer,
      getDiagnostics: getDiagnostics,
      getStoryState: getStoryState,
      getStoryDescriptor: function () { return getDiagnostics().storyDescriptor; },
      getPromptDescriptor: function () { return getDiagnostics().promptDescriptor; }
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    nativeMaxLength: NATIVE_MAX_LENGTH,
    styles: STYLES,
    normalizeStyle: normalizeStyle,
    resolve: resolve,
    create: create
  };

  root.AIStoryGen.ExtraLongHairModule = api;
  root.AIStoryGenExtraLongHairModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
