/* ============================================================
 * AIStoryGen runtime events
 * Lightweight time/state event bus inspired by DoL mod frameworks.
 * It keeps post-transaction hooks explicit, prioritized, testable,
 * and diagnosable without taking over original game flow.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var MAX_HISTORY = 80;
  var EVENT_TYPES = {
    change: true,
    time: true,
    stats: true,
    state: true
  };

  function nowIso() {
    try { return new Date().toISOString(); } catch (_) { return ''; }
  }

  function cloneValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function normalizeType(type) {
    type = String(type || '').trim().toLowerCase();
    return EVENT_TYPES[type] ? type : 'change';
  }

  function normalizeId(id) {
    return String(id || '').trim().replace(/\s+/g, '-').replace(/[^A-Za-z0-9:_-]/g, '');
  }

  function publicEventSpec(spec) {
    if (!spec) return null;
    return {
      id: spec.id,
      type: spec.type,
      label: spec.label,
      priority: spec.priority,
      once: spec.once,
      enabled: spec.enabled,
      runCount: spec.runCount,
      lastAt: spec.lastAt || '',
      lastStatus: spec.lastStatus || '',
      lastReason: spec.lastReason || ''
    };
  }

  function create(opts) {
    opts = opts || {};
    var events = {};
    var history = [];

    function record(type, id, status, reason, extra) {
      var entry = {
        type: normalizeType(type),
        id: String(id || ''),
        status: String(status || ''),
        reason: String(reason || '').slice(0, 180),
        at: Date.now(),
        iso: nowIso()
      };
      if (extra && typeof extra === 'object') entry.extra = cloneValue(extra);
      history.push(entry);
      if (history.length > MAX_HISTORY) history.splice(0, history.length - MAX_HISTORY);
      return entry;
    }

    function register(type, id, spec) {
      type = normalizeType(type);
      spec = spec || {};
      id = normalizeId(id || spec.id);
      if (!id) return null;
      var next = {
        id: id,
        type: type,
        label: String(spec.label || id),
        priority: isFinite(Number(spec.priority)) ? Number(spec.priority) : 0,
        once: spec.once === true,
        enabled: spec.enabled !== false,
        cond: typeof spec.cond === 'function' ? spec.cond : null,
        action: typeof spec.action === 'function' ? spec.action : null,
        runCount: 0,
        lastAt: '',
        lastStatus: 'registered',
        lastReason: ''
      };
      events[type] = events[type] || {};
      events[type][id] = next;
      record(type, id, 'registered', next.label, { priority: next.priority, once: next.once });
      return publicEventSpec(next);
    }

    function unregister(type, id, reason) {
      type = normalizeType(type);
      id = normalizeId(id);
      if (!id || !events[type] || !events[type][id]) return false;
      delete events[type][id];
      record(type, id, 'unregistered', reason || '');
      return true;
    }

    function list(type) {
      var out = [];
      var types = type ? [normalizeType(type)] : Object.keys(EVENT_TYPES);
      types.forEach(function (t) {
        var bucket = events[t] || {};
        Object.keys(bucket).forEach(function (id) {
          out.push(publicEventSpec(bucket[id]));
        });
      });
      out.sort(function (a, b) {
        if (b.priority !== a.priority) return b.priority - a.priority;
        return String(a.id).localeCompare(String(b.id));
      });
      return out;
    }

    function emit(type, payload) {
      type = normalizeType(type);
      payload = payload || {};
      var bucket = events[type] || {};
      var queue = Object.keys(bucket).map(function (id) { return bucket[id]; }).filter(function (spec) {
        return spec && spec.enabled;
      }).sort(function (a, b) {
        if (b.priority !== a.priority) return b.priority - a.priority;
        return String(a.id).localeCompare(String(b.id));
      });
      var results = [];
      queue.forEach(function (spec) {
        var result = {
          id: spec.id,
          type: type,
          status: 'skipped',
          reason: ''
        };
        try {
          if (spec.cond && !spec.cond(payload, publicEventSpec(spec))) {
            result.status = 'skipped';
            result.reason = 'condition false';
            spec.lastStatus = result.status;
            spec.lastReason = result.reason;
            record(type, spec.id, result.status, result.reason);
            results.push(result);
            return;
          }
          if (spec.action) spec.action(payload, publicEventSpec(spec));
          spec.runCount += 1;
          spec.lastAt = nowIso();
          spec.lastStatus = 'ran';
          spec.lastReason = '';
          result.status = 'ran';
          record(type, spec.id, 'ran', '', { runCount: spec.runCount });
          if (spec.once) delete bucket[spec.id];
        } catch (e) {
          result.status = 'failed';
          result.reason = String(e && e.message || e).slice(0, 180);
          spec.lastStatus = result.status;
          spec.lastReason = result.reason;
          record(type, spec.id, 'failed', result.reason);
        }
        results.push(result);
      });
      if (!queue.length) record(type, '', 'empty', 'no registered events');
      return {
        type: type,
        count: results.length,
        results: results
      };
    }

    function getDebugState() {
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        events: list(),
        history: cloneValue(history.slice(-20))
      };
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      register: register,
      unregister: unregister,
      list: list,
      emit: emit,
      getDebugState: getDebugState
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    normalizeType: normalizeType,
    create: create
  };

  root.RuntimeEventsModule = api;
  root.AIStoryGenRuntimeEventsModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
