/* ============================================================
 * AIStoryGen API request log
 * Keeps a small in-memory diagnostic log without storing API keys or prompts.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 2;
  var DEFAULT_LIMIT = 30;
  var nextId = 1;

  function nowIso() {
    try { return new Date().toISOString(); } catch (_) { return ''; }
  }

  function cloneValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function clampText(value, maxLen) {
    value = String(value == null ? '' : value);
    maxLen = maxLen || 300;
    return value.length > maxLen ? value.slice(0, maxLen) : value;
  }

  function summarizeMessages(messages) {
    messages = Array.isArray(messages) ? messages : [];
    var chars = 0;
    var roles = {};
    messages.forEach(function (msg) {
      if (!msg || typeof msg !== 'object') return;
      var role = String(msg.role || 'unknown');
      roles[role] = (roles[role] || 0) + 1;
      var content = msg.content;
      if (Array.isArray(content)) {
        content.forEach(function (part) {
          if (typeof part === 'string') chars += part.length;
          else if (part && typeof part.text === 'string') chars += part.text.length;
          else if (part && typeof part.content === 'string') chars += part.content.length;
        });
      } else if (typeof content === 'string') {
        chars += content.length;
      }
    });
    return {
      count: messages.length,
      chars: chars,
      roles: roles
    };
  }

  function errorSummary(err) {
    err = err || {};
    return {
      type: clampText(err.type || err.name || 'unknown', 80),
      message: clampText(err.message || err.userMessage || err.reason || err, 300),
      detail: clampText(err.detail || err.responseBody || '', 300),
      statusCode: Number(err.statusCode || err.status || 0) || 0
    };
  }

  function formatEntryLine(entry, fallbackConfig) {
    entry = entry || {};
    fallbackConfig = fallbackConfig || {};
    var parts = [
      '[' + clampText(entry.status || 'unknown', 40) + ']',
      clampText(entry.provider || fallbackConfig.apiProvider || 'custom', 80),
      clampText(entry.model || fallbackConfig.model || '未填写模型', 160)
    ];
    if (entry.endpoint) parts.push('endpoint=' + clampText(entry.endpoint, 180));
    if (entry.purpose) parts.push('purpose=' + clampText(entry.purpose, 80));
    if (entry.durationMs != null) parts.push(String(entry.durationMs) + 'ms');
    if (entry.inputChars != null) parts.push('inputChars=' + entry.inputChars);
    if (entry.outputChars != null) parts.push('outputChars=' + entry.outputChars);
    if (entry.retryCount) parts.push('retry=' + entry.retryCount);
    if (entry.finishReason) parts.push('finish=' + clampText(entry.finishReason, 80));
    if (entry.error && entry.error.type) {
      parts.push('error=' + clampText(entry.error.type, 80) + (entry.error.statusCode ? ' HTTP ' + entry.error.statusCode : ''));
      if (entry.error.message) parts.push('message=' + clampText(entry.error.message, 180));
    }
    return parts.join(' / ');
  }

  function buildDiagnosticSnippet(opts) {
    opts = opts || {};
    var cfg = opts.config || {};
    var recent = Array.isArray(opts.recent) ? opts.recent.slice(0, opts.limit || 5) : [];
    var probe = opts.lastProviderProbe || {};
    var compat = probe.compatSummary || {};
    var latestError = opts.lastApiError || {};
    var lines = [];
    lines.push('## API 诊断片段');
    lines.push('- 服务商：' + clampText(cfg.apiProvider || 'custom', 80));
    lines.push('- 接口：' + clampText(cfg.endpoint || '', 240));
    lines.push('- 模型：' + clampText(cfg.model || '', 160));
    lines.push('- API Key：' + (cfg.hasApiKey ? '已填写（未导出）' : '未填写/本地接口可为空'));
    if (compat && compat.lines && compat.lines.length) {
      lines.push('- 兼容性：' + clampText((compat.lines || []).slice(0, 4).join('；'), 500));
    } else if (probe.status || probe.message) {
      lines.push('- 探测：' + clampText(probe.message || probe.status, 300));
    } else {
      lines.push('- 探测：未完成测试连接');
    }
    if (latestError && (latestError.type || latestError.message)) {
      lines.push('- 最近错误：' + clampText((latestError.type || 'unknown') + ': ' + (latestError.message || ''), 300));
    }
    lines.push('');
    lines.push('### 最近请求');
    if (!recent.length) {
      lines.push('- 没有最近请求记录。');
    } else {
      recent.forEach(function (entry) {
        lines.push('- ' + formatEntryLine(entry, cfg));
      });
    }
    lines.push('');
    lines.push('隐私：此片段不包含 API Key、完整提示词、完整响应正文、完整存档或 localStorage。');
    return lines.join('\n');
  }

  function create(opts) {
    opts = opts || {};
    var limit = Math.max(5, Math.min(100, Number(opts.limit || DEFAULT_LIMIT) || DEFAULT_LIMIT));
    var entries = [];

    function find(id) {
      for (var i = entries.length - 1; i >= 0; i--) {
        if (entries[i].id === id) return entries[i];
      }
      return null;
    }

    function push(entry) {
      entries.push(entry);
      if (entries.length > limit) entries.splice(0, entries.length - limit);
      return entry;
    }

    function begin(info) {
      info = info || {};
      var messages = summarizeMessages(info.messages || []);
      return push({
        id: nextId++,
        at: nowIso(),
        startedAtMs: Date.now(),
        status: 'pending',
        provider: clampText(info.provider || '', 80),
        endpoint: clampText(info.endpoint || '', 240),
        model: clampText(info.model || '', 160),
        purpose: clampText(info.purpose || '', 80),
        highQuality: !!info.highQuality,
        temperature: info.temperature == null ? null : Number(info.temperature),
        maxTokens: info.maxTokens == null ? null : Number(info.maxTokens),
        messageCount: messages.count,
        inputChars: messages.chars,
        roles: messages.roles,
        attempts: [],
        retryCount: 0
      }).id;
    }

    function noteAttempt(id, info) {
      var entry = find(id);
      if (!entry) return null;
      info = info || {};
      entry.attempts.push({
        at: nowIso(),
        type: clampText(info.type || 'attempt', 80),
        maxTokens: info.maxTokens == null ? null : Number(info.maxTokens),
        temperature: info.temperature == null ? null : Number(info.temperature),
        reason: clampText(info.reason || '', 180)
      });
      if (info.type === 'empty_retry') entry.retryCount += 1;
      return entry;
    }

    function finishSuccess(id, result) {
      var entry = find(id);
      if (!entry) return null;
      result = result || {};
      entry.status = 'success';
      entry.finishedAt = nowIso();
      entry.durationMs = Math.max(0, Date.now() - Number(entry.startedAtMs || Date.now()));
      entry.outputChars = Number(result.outputChars || 0) || 0;
      entry.finishReason = clampText(result.finishReason || '', 80);
      entry.responseModel = clampText(result.responseModel || '', 160);
      entry.usage = cloneValue(result.usage || null);
      delete entry.startedAtMs;
      return entry;
    }

    function finishError(id, err) {
      var entry = find(id);
      if (!entry) return null;
      entry.status = 'error';
      entry.finishedAt = nowIso();
      entry.durationMs = Math.max(0, Date.now() - Number(entry.startedAtMs || Date.now()));
      entry.error = errorSummary(err);
      delete entry.startedAtMs;
      return entry;
    }

    function getRecent(count) {
      count = Math.max(1, Math.min(limit, Number(count || limit) || limit));
      return cloneValue(entries.slice(-count).reverse());
    }

    function clear() {
      entries.length = 0;
    }

    function getDebugState() {
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        limit: limit,
        count: entries.length,
        recent: getRecent(Math.min(10, limit))
      };
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      begin: begin,
      noteAttempt: noteAttempt,
      finishSuccess: finishSuccess,
      finishError: finishError,
      getRecent: getRecent,
      clear: clear,
      getDebugState: getDebugState
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: create,
    summarizeMessages: summarizeMessages,
    errorSummary: errorSummary,
    formatEntryLine: formatEntryLine,
    buildDiagnosticSnippet: buildDiagnosticSnippet
  };

  root.AIStoryGen.RequestLogModule = api;
  root.AIStoryGenRequestLogModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
