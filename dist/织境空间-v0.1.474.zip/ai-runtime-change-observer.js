/* ============================================================
 * AIStoryGen runtime change observer
 * Centralizes post-transaction visual refresh scheduling and
 * diagnostics for desktop/mobile sidebars.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  function cloneValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function nowIso() {
    try { return new Date().toISOString(); } catch (_) { return ''; }
  }

  function normalizeDelayList(delays) {
    if (!Array.isArray(delays)) return [50, 250];
    return delays.map(function (v) {
      v = Number(v);
      return isFinite(v) && v >= 0 ? Math.floor(v) : null;
    }).filter(function (v) { return v != null; });
  }

  function defaultSidebarSnapshot() {
    var sidebar = {};
    try {
      var doc = root.document;
      if (!doc) return sidebar;
      var desktop = doc.getElementById('stats');
      var mobile = doc.getElementById('mobileStats');
      sidebar.hasDesktopStats = !!desktop;
      sidebar.hasMobileStats = !!mobile;
      sidebar.desktopText = desktop ? String(desktop.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 800) : '';
      sidebar.mobileText = mobile ? String(mobile.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 800) : '';
    } catch (_) {}
    return sidebar;
  }

  function create(deps) {
    deps = deps || {};
    var lastRefresh = null;
    var lastStats = null;
    var lastEvents = null;
    var checkpoints = [];

    function getClock() {
      try {
        if (typeof deps.getClock === 'function') return deps.getClock();
      } catch (_) {}
      return null;
    }

    function refresh(reason) {
      var clock = null;
      try {
        if (typeof deps.refreshVisualState === 'function') {
          clock = deps.refreshVisualState(reason || 'runtime');
        }
      } catch (e) {
        try {
          if (typeof deps.warn === 'function') deps.warn('[AIStoryGen] runtime visual refresh failed', e);
          else if (root.console && root.console.warn) root.console.warn('[AIStoryGen] runtime visual refresh failed', e);
        } catch (_) {}
      }
      lastRefresh = {
        at: nowIso(),
        reason: String(reason || 'runtime'),
        clock: cloneValue(clock || getClock()),
        sidebar: getSidebarSnapshot()
      };
      return lastRefresh;
    }

    function notifyChange(reason, opts) {
      opts = opts || {};
      var first = refresh(reason || 'runtime');
      var changeEvents = emitRuntimeEvents('change', {
        reason: reason || 'runtime',
        refresh: first
      });
      normalizeDelayList(opts.delays).forEach(function (delay) {
        try {
          root.setTimeout(function () { refresh((reason || 'runtime') + ' delayed'); }, delay);
        } catch (_) {}
      });
      first.events = changeEvents;
      return first;
    }

    function notifyTimeChange(minutes, opts) {
      opts = opts || {};
      var result = notifyChange(opts.reason || 'time', opts);
      result.minutes = Number(minutes) || 0;
      result.timeEvents = emitRuntimeEvents('time', {
        reason: opts.reason || 'time',
        minutes: result.minutes,
        refresh: result
      });
      return result;
    }

    function notifyStatsApplied(changed, transactionPlan, opts) {
      opts = opts || {};
      lastStats = {
        at: nowIso(),
        changed: Array.isArray(changed) ? changed.slice() : [],
        transactionStats: cloneValue(transactionPlan && transactionPlan.stats || null)
      };
      var result = notifyChange(opts.reason || 'stats', opts);
      result.statsEvents = emitRuntimeEvents('stats', {
        reason: opts.reason || 'stats',
        changed: lastStats.changed,
        transactionPlan: cloneValue(transactionPlan || null),
        refresh: result
      });
      return result;
    }

    function recordCheckpoint(type, detail) {
      var entry = {
        at: nowIso(),
        type: String(type || 'state'),
        detail: cloneValue(detail || {}),
        sidebar: getSidebarSnapshot()
      };
      checkpoints.push(entry);
      if (checkpoints.length > 20) checkpoints.splice(0, checkpoints.length - 20);
      emitRuntimeEvents('state', {
        reason: entry.type,
        checkpoint: cloneValue(entry)
      });
      return cloneValue(entry);
    }

    function getSidebarSnapshot() {
      try {
        if (typeof deps.getSidebarSnapshot === 'function') return deps.getSidebarSnapshot();
      } catch (_) {}
      return defaultSidebarSnapshot();
    }

    function emitRuntimeEvents(type, payload) {
      var bus = deps.runtimeEvents || null;
      try {
        if (!bus && root.AIStoryGen && root.AIStoryGen.runtimeEvents) bus = root.AIStoryGen.runtimeEvents;
      } catch (_) {}
      if (!bus || typeof bus.emit !== 'function') return null;
      try {
        lastEvents = bus.emit(type, payload || {});
        return cloneValue(lastEvents);
      } catch (e) {
        lastEvents = {
          type: type,
          error: String(e && e.message || e)
        };
        return cloneValue(lastEvents);
      }
    }

    function getDebugState(extra) {
      extra = extra || {};
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        lastRefresh: cloneValue(lastRefresh),
        lastStats: cloneValue(lastStats),
        lastEvents: cloneValue(lastEvents),
        lastCheckpoint: cloneValue(checkpoints[checkpoints.length - 1] || null),
        checkpoints: cloneValue(checkpoints.slice(-10)),
        runtimeEvents: deps.runtimeEvents && typeof deps.runtimeEvents.getDebugState === 'function'
          ? cloneValue(deps.runtimeEvents.getDebugState())
          : null,
        sidebar: getSidebarSnapshot(),
        values: typeof deps.getStateValues === 'function' ? deps.getStateValues() : {},
        statLimits: typeof deps.getStatLimits === 'function' ? deps.getStatLimits() : {},
        lastTransactionStats: cloneValue(extra.lastTransactionStats || (lastStats && lastStats.transactionStats) || null)
      };
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      notifyChange: notifyChange,
      notifyTimeChange: notifyTimeChange,
      notifyStatsApplied: notifyStatsApplied,
      recordCheckpoint: recordCheckpoint,
      getSidebarSnapshot: getSidebarSnapshot,
      getDebugState: getDebugState
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: create
  };

  root.RuntimeChangeObserverModule = api;
  root.AIStoryGenRuntimeChangeObserverModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
