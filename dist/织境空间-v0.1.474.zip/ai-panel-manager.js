/* ============================================================
 * AIStoryGen panel manager
 * Owns panel-layout ordering, scheduling, observer lifecycle, and debug status.
 * Concrete DOM reads/writes are injected from aiMacro.js for compatibility.
 * ============================================================ */
(function () {
  'use strict';

  var root = window.AIStoryGen = window.AIStoryGen || {};
  var MODULE_SCHEMA_VERSION = 1;
  var PUBLIC_SCHEMA_VERSION = 5;

  function createPanelManager(deps) {
    deps = deps || {};
    var timers = {};
    var runCount = 0;
    var lastAt = 0;
    var minFlushInterval = Math.max(0, Number(deps.minFlushInterval || 0) || 0);
    var publicSchemaVersion = deps.publicSchemaVersion || PUBLIC_SCHEMA_VERSION;
    var observerKey = deps.observerKey || '_aiChoiceOrderObserver';

    function warn(message, error) {
      try {
        if (typeof deps.warn === 'function') {
          deps.warn(message, error);
          return;
        }
        if (typeof console !== 'undefined' && console.warn) console.warn(message, error);
      } catch (_) {}
    }

    function getPanelRoot() {
      try {
        if (typeof deps.getPanelRoot === 'function') return deps.getPanelRoot();
      } catch (_) {}
      return null;
    }

    function hasPanelHost(rootEl) {
      try {
        if (typeof deps.hasPanelHost === 'function') return !!deps.hasPanelHost(rootEl);
      } catch (_) {
        return false;
      }
      return !!rootEl;
    }

    function getPanels(kind) {
      try {
        if (typeof deps.getPanels === 'function') {
          var nodes = deps.getPanels(kind);
          return Array.isArray(nodes) ? nodes.filter(Boolean) : [];
        }
      } catch (_) {}
      return [];
    }

    function dedupePanels(kind) {
      try {
        if (typeof deps.dedupePanels === 'function') return Number(deps.dedupePanels(kind)) || 0;
      } catch (_) {}
      if (kind === 'pixel' && typeof deps.dedupePixelPanels === 'function') {
        try { return Number(deps.dedupePixelPanels()) || 0; } catch (_) {}
      }
      return 0;
    }

    function getChildren(rootEl) {
      try {
        if (typeof deps.getChildren === 'function') {
          var children = deps.getChildren(rootEl);
          return Array.isArray(children) ? children : [];
        }
      } catch (_) {}
      try {
        if (rootEl && rootEl.children) return Array.prototype.slice.call(rootEl.children);
      } catch (_) {}
      return [];
    }

    function appendPanelNode(rootEl, node) {
      try {
        if (typeof deps.appendPanelNode === 'function') return !!deps.appendPanelNode(rootEl, node);
      } catch (_) {
        return false;
      }
      try {
        if (rootEl && typeof rootEl.appendChild === 'function') {
          rootEl.appendChild(node);
          return true;
        }
      } catch (_) {}
      return false;
    }

    function markZone(id, hasPanels) {
      if (!hasPanels) return;
      try {
        if (typeof deps.markZone === 'function') deps.markZone(id);
      } catch (_) {}
    }

    function isAlreadyOrdered(rootEl, desired) {
      var children = getChildren(rootEl);
      var start = children.length - desired.length;
      if (start < 0) return false;
      for (var i = 0; i < desired.length; i++) {
        if (children[start + i] !== desired[i]) return false;
      }
      return true;
    }

    function orderPanels(reason) {
      var rootEl = getPanelRoot();
      if (!rootEl || !hasPanelHost(rootEl)) return false;
      try {
        if (typeof deps.isLayoutMoving === 'function' && deps.isLayoutMoving()) {
          var stale = typeof deps.isLayoutStale === 'function' ? deps.isLayoutStale() : false;
          if (!stale) return false;
          if (typeof deps.releaseLayoutLock === 'function') deps.releaseLayoutLock('stale');
        }
      } catch (_) {}

      dedupePanels('pixel');
      dedupePanels('managed');
      var pixels = getPanels('pixel');
      var managed = getPanels('managed');
      markZone('wovenrealm-story-panels', managed.length > 0);
      markZone('wovenrealm-pixel-panel', pixels.length > 0);
      if (!pixels.length && !managed.length) return false;

      var desired = managed.concat(pixels);
      if (isAlreadyOrdered(rootEl, desired)) return false;

      var changed = false;
      var token = String(Date.now()) + ':' + Math.random();
      try {
        if (typeof deps.acquireLayoutLock === 'function') deps.acquireLayoutLock(token, reason || 'order panels');
        for (var mi = 0; mi < managed.length; mi++) {
          if (appendPanelNode(rootEl, managed[mi])) changed = true;
        }
        for (var pi = 0; pi < pixels.length; pi++) {
          if (appendPanelNode(rootEl, pixels[pi])) changed = true;
        }
      } finally {
        try {
          if (typeof deps.releaseLayoutLock === 'function') deps.releaseLayoutLock('complete', token);
        } catch (_) {}
      }
      return changed;
    }

    function layout(reason) {
      if (typeof deps.layout === 'function') return !!deps.layout(reason);
      return orderPanels(reason || 'layout');
    }

    function normalizeOrder() {
      return layout();
    }

    function flush(reason) {
      runCount += 1;
      lastAt = Date.now();
      try {
        if (typeof deps.runLayout === 'function') return !!deps.runLayout(reason || 'manual flush');
        return layout();
      } catch (e) {
        warn('[AIStoryGen] panel layout failed' + (reason ? ' (' + reason + ')' : ''), e);
        return false;
      }
    }

    function scheduleLayout(delay) {
      clearLegacyPixelObservers();
      delay = Math.max(0, Number(delay || 0) || 0);
      var now = Date.now();
      if (lastAt && now - lastAt < minFlushInterval) {
        delay = Math.max(delay, minFlushInterval - (now - lastAt));
      }
      if (delay <= 0) {
        flush('scheduled 0ms');
        return true;
      }
      var key = minFlushInterval > 0 ? 'layout' : String(delay);
      if (timers[key]) return false;
      timers[key] = setTimeout(function () {
        delete timers[key];
        flush('scheduled ' + delay + 'ms');
      }, delay || 0);
      return true;
    }

    function clearLegacyPixelObservers() {
      var cleared = 0;
      ['_apgAssistOrderObserver', '_apgPoseAssistOrderObserver'].forEach(function (key) {
        try {
          if (typeof window !== 'undefined' && window[key]) {
            if (typeof window[key].disconnect === 'function') window[key].disconnect();
            window[key] = null;
            cleared += 1;
          }
        } catch (_) {}
      });
      return cleared;
    }

    function isPixelOnlyMutations(mutations) {
      if (!mutations || !mutations.length) return false;
      if (typeof deps.isPixelOnlyMutations === 'function') {
        try { return !!deps.isPixelOnlyMutations(mutations); } catch (_) {}
      }
      for (var i = 0; i < mutations.length; i++) {
        var target = mutations[i] && mutations[i].target;
        if (!(target && target.closest && target.closest('.apg-ai-assist, .apg-pixel-placeholder, .apg-pixel-result, .apg-pixel-controls, .apg-pixel-spinner'))) {
          return false;
        }
      }
      return true;
    }

    function getObserverRoot() {
      try {
        if (typeof deps.getObserverRoot === 'function') return deps.getObserverRoot();
      } catch (_) {}
      try {
        return document.getElementById('passages') || document.body;
      } catch (_) {
        return null;
      }
    }

    function installOrderObserver() {
      try {
        clearLegacyPixelObservers();
        if (window[observerKey]) window[observerKey].disconnect();
        var rootEl = getObserverRoot();
        if (!rootEl || typeof MutationObserver === 'undefined') return false;
        window[observerKey] = new MutationObserver(function (mutations) {
          if (isPixelOnlyMutations(mutations)) return;
          scheduleLayout(40);
        });
        window[observerKey].observe(rootEl, { childList: true });
        [0, 400, 1200, 3000].forEach(scheduleLayout);
        return true;
      } catch (e) {
        warn('[AIStoryGen] choice order observer failed', e);
        return false;
      }
    }

    function count(name) {
      try {
        if (typeof deps.countPanels === 'function') return Number(deps.countPanels(name)) || 0;
      } catch (_) {}
      return 0;
    }

    function getStatus() {
      return {
        pendingDelays: Object.keys(timers).map(function (key) {
          return /^\d+(?:\.\d+)?$/.test(key) ? Number(key) : key;
        }).sort(function (a, b) {
          if (typeof a === 'number' && typeof b === 'number') return a - b;
          return String(a).localeCompare(String(b));
        }),
        moving: !!(typeof window !== 'undefined' && window._aiPanelLayoutMoving),
        runCount: runCount,
        lastAt: lastAt,
        managedPanels: count('managed'),
        pixelPanels: count('pixel'),
        legacyPixelOrderObserver: !!(typeof window !== 'undefined' && window._apgAssistOrderObserver),
        legacyPoseOrderObserver: !!(typeof window !== 'undefined' && window._apgPoseAssistOrderObserver),
        orderObserver: !!(typeof window !== 'undefined' && window[observerKey])
      };
    }

    function dedupePixelPanels() {
      if (typeof deps.dedupePixelPanels === 'function') return deps.dedupePixelPanels();
      return 0;
    }

    function removeChoicePanels() {
      if (typeof deps.removeChoicePanels === 'function') return deps.removeChoicePanels();
      return undefined;
    }

    return {
      schemaVersion: publicSchemaVersion,
      moduleSchemaVersion: MODULE_SCHEMA_VERSION,
      layout: layout,
      normalizeOrder: normalizeOrder,
      orderPanels: orderPanels,
      scheduleLayout: scheduleLayout,
      flush: flush,
      getStatus: getStatus,
      installOrderObserver: installOrderObserver,
      dedupePixelPanels: dedupePixelPanels,
      removeChoicePanels: removeChoicePanels,
      clearLegacyPixelObservers: clearLegacyPixelObservers,
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: createPanelManager,
  };

  root.PanelManagerModule = api;
  window.AIStoryGenPanelManagerModule = api;
})();
