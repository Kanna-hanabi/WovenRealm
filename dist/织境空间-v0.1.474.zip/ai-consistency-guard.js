/* ============================================================
 * Woven Realm consistency guard
 * Checks normalized AI_EVENT data against world context.
 * Low-risk phase: normalize obvious name variants, flag conflicts,
 * and suppress unsafe structured fields where confidence is low.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 3;

  function text(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function splitList(value) {
    if (Array.isArray(value)) return value.map(text).filter(Boolean);
    return text(value).split(/[;\uff1b,\uff0c\u3001]/).map(text).filter(Boolean);
  }

  function joinList(list) {
    var out = [];
    var seen = {};
    (list || []).forEach(function (item) {
      item = text(item);
      if (!item) return;
      var key = item.toLowerCase();
      if (seen[key]) return;
      seen[key] = 1;
      out.push(item);
    });
    return out.join(';');
  }

  function buildNpcMap(worldContext) {
    var map = {};
    var rows = worldContext && Array.isArray(worldContext.npcCanonicalNames)
      ? worldContext.npcCanonicalNames
      : [];
    rows.forEach(function (row) {
      row = row || {};
      var key = text(row.key);
      var name = text(row.name || row.title || row.key);
      var title = text(row.title || row.name || row.key);
      if (!key) return;
      map[key.toLowerCase()] = name || title || key;
      if (name) map[name.toLowerCase()] = name;
      if (title) map[title.toLowerCase()] = name || title;
    });
    return map;
  }

  function canonicalizeName(name, npcMap, diagnostics) {
    var raw = text(name);
    if (!raw) return '';
    var lower = raw.toLowerCase();
    if (npcMap[lower]) return npcMap[lower];

    var fixed = raw;
    if (npcMap.sydney === '\u6089\u5c3c') {
      fixed = fixed.replace(/\u897f\u5fb7\u5c3c/g, '\u6089\u5c3c');
    }
    if (npcMap.jordan === '\u7ea6\u65e6') {
      fixed = fixed.replace(/\u4e54\u4e39/g, '\u7ea6\u65e6');
    }
    if (npcMap.alex === '\u827e\u5229\u514b\u65af') {
      fixed = fixed.replace(/\u4e9a\u5386\u514b\u65af/g, '\u827e\u5229\u514b\u65af');
    }
    if (npcMap.avery === '\u827e\u5f17\u5229') {
      fixed = fixed.replace(/\u827e\u5f17\u91cc/g, '\u827e\u5f17\u5229');
    }
    if (fixed !== raw) {
      diagnostics.push({ level: 'info', code: 'npc_name_variant_fixed', from: raw, to: fixed });
    }
    return fixed;
  }

  function canonicalizeNameList(value, npcMap, diagnostics) {
    return joinList(splitList(value).map(function (name) {
      return canonicalizeName(name, npcMap, diagnostics);
    }));
  }

  function npcKey(name) {
    return text(name).toLowerCase();
  }

  function addNpcName(set, name, npcMap, diagnostics) {
    name = canonicalizeName(name, npcMap || {}, diagnostics || []);
    if (!name) return false;
    set[npcKey(name)] = name;
    return true;
  }

  function addNpcLike(set, row, npcMap, diagnostics) {
    if (!row) return false;
    if (typeof row === 'string') return addNpcName(set, row, npcMap, diagnostics);
    return addNpcName(set, row.name || row.title || row.key || row.label || row.canonicalName, npcMap, diagnostics);
  }

  function collectVisibleNpcNames(worldContext, npcMap, diagnostics) {
    var set = {};
    var hasPresenceEvidence = false;
    function addMany(rows) {
      if (!Array.isArray(rows)) return;
      rows.forEach(function (row) {
        if (addNpcLike(set, row, npcMap, diagnostics)) hasPresenceEvidence = true;
      });
    }

    try {
      addMany(worldContext && worldContext.visibleFacts && worldContext.visibleFacts.presentCharacters);
      addMany(worldContext && worldContext.npcContext && worldContext.npcContext.present);
      addMany(worldContext && worldContext.npcContext && worldContext.npcContext.visible);
      addMany(worldContext && worldContext.presentCharacters);
      var nativeNearby = worldContext && worldContext.facts && worldContext.facts.nativeNearby;
      splitList(nativeNearby).forEach(function (name) {
        if (addNpcName(set, name, npcMap, diagnostics)) hasPresenceEvidence = true;
      });
    } catch (_) {}

    return {
      names: set,
      hasPresenceEvidence: hasPresenceEvidence
    };
  }

  function filterPresentCharacters(out, worldContext, npcMap, diagnostics, blocked) {
    if (!out || !out.presentCharacters) return;
    var visible = collectVisibleNpcNames(worldContext, npcMap, diagnostics);

    var kept = [];
    splitList(out.presentCharacters).forEach(function (name) {
      var canonical = canonicalizeName(name, npcMap, diagnostics);
      if (visible.names[npcKey(canonical)]) {
        kept.push(canonical);
        return;
      }
      diagnostics.push({
        level: 'warn',
        code: visible.hasPresenceEvidence ? 'present_character_not_visible_suppressed' : 'present_character_without_authority_suppressed',
        field: 'presentCharacters',
        npc: canonical,
        value: name
      });
      addBlockedEffect(blocked, 'presentCharacters', visible.hasPresenceEvidence ? 'present_character_not_visible_suppressed' : 'present_character_without_authority_suppressed', name, undefined);
    });

    out.presentCharacters = joinList(kept);
    if (!out.presentCharacters) delete out.presentCharacters;
  }

  function knownNpcNameSet(npcMap) {
    var set = {};
    Object.keys(npcMap || {}).forEach(function (key) {
      var value = text(npcMap[key]);
      if (key) set[key.toLowerCase()] = true;
      if (value) set[value.toLowerCase()] = true;
    });
    return set;
  }

  function filterPresentEntities(out, npcMap, diagnostics, blocked) {
    if (!out || !out.presentEntities) return;
    var knownNpc = knownNpcNameSet(npcMap);
    var kept = [];
    splitList(out.presentEntities).forEach(function (name) {
      var raw = text(name);
      var canonical = canonicalizeName(raw, npcMap, diagnostics);
      if (!knownNpc[raw.toLowerCase()] && !knownNpc[canonical.toLowerCase()]) {
        kept.push(raw);
        return;
      }
      diagnostics.push({
        level: 'warn',
        code: 'human_npc_removed_from_present_entities',
        field: 'presentEntities',
        npc: canonical,
        value: raw
      });
      addBlockedEffect(blocked, 'presentEntities', 'human_npc_removed_from_present_entities', raw, undefined);
    });
    out.presentEntities = joinList(kept);
    if (!out.presentEntities) delete out.presentEntities;
  }

  function filterRelationshipChanges(out, worldContext, npcMap, diagnostics, blocked) {
    if (!out || !out.relationshipChanges) return;
    var visible = collectVisibleNpcNames(worldContext, npcMap, diagnostics);

    var kept = [];
    splitList(out.relationshipChanges).forEach(function (part) {
      var m = part.match(/^([^:\uff1a]+)([:\uff1a].*)$/);
      if (!m) {
        kept.push(part);
        return;
      }
      var name = canonicalizeName(m[1], npcMap, diagnostics);
      var key = npcKey(name);
      if (visible.names[key]) {
        kept.push(name + m[2]);
        return;
      }
      diagnostics.push({
        level: 'warn',
        code: visible.hasPresenceEvidence ? 'relationship_npc_not_visible_suppressed' : 'relationship_npc_without_authority_suppressed',
        field: 'relationshipChanges',
        npc: name,
        value: part
      });
      addBlockedEffect(blocked, 'relationshipChanges', visible.hasPresenceEvidence ? 'relationship_npc_not_visible_suppressed' : 'relationship_npc_without_authority_suppressed', part, undefined);
    });

    out.relationshipChanges = joinList(kept);
    if (!out.relationshipChanges) delete out.relationshipChanges;
  }

  function filterSexTargets(out, worldContext, npcMap, diagnostics, blocked) {
    if (!out || !out.sexTargets) return;
    var visible = collectVisibleNpcNames(worldContext, npcMap, diagnostics);
    splitList(out.presentCharacters).concat(splitList(out.presentEntities)).forEach(function (name) {
      addNpcName(visible.names, name, npcMap, diagnostics);
      visible.hasPresenceEvidence = true;
    });

    var kept = [];
    splitList(out.sexTargets).forEach(function (name) {
      var canonical = canonicalizeName(name, npcMap, diagnostics);
      if (visible.names[npcKey(canonical)]) {
        kept.push(canonical);
        return;
      }
      diagnostics.push({
        level: 'warn',
        code: visible.hasPresenceEvidence ? 'sex_target_not_visible_suppressed' : 'sex_target_without_authority_suppressed',
        field: 'sexTargets',
        npc: canonical,
        value: name
      });
      addBlockedEffect(blocked, 'sexTargets', visible.hasPresenceEvidence ? 'sex_target_not_visible_suppressed' : 'sex_target_without_authority_suppressed', name, undefined);
    });

    out.sexTargets = joinList(kept);
    if (!out.sexTargets) delete out.sexTargets;
  }

  function mapPassageSet(worldContext) {
    var set = {};
    function add(raw) {
      raw = text(raw);
      if (raw) set[raw.toLowerCase()] = raw;
    }
    var current = worldContext && worldContext.currentMap && worldContext.currentMap.current;
    add(current && current.passage);
    var adjacent = worldContext && worldContext.currentMap && Array.isArray(worldContext.currentMap.adjacent)
      ? worldContext.currentMap.adjacent
      : [];
    adjacent.forEach(function (node) { add(node && node.passage); });
    var links = worldContext && Array.isArray(worldContext.visibleLinks) ? worldContext.visibleLinks : [];
    links.forEach(function (link) { add(link && link.passage); });
    var controls = worldContext && Array.isArray(worldContext.visibleControls) ? worldContext.visibleControls : [];
    controls.forEach(function (control) { add(control && control.passage); });
    var facts = worldContext && worldContext.facts;
    add(facts && facts.passage);
    add(facts && facts.location);
    return set;
  }

  function copySet(set) {
    var out = {};
    Object.keys(set || {}).forEach(function (key) {
      out[key] = set[key];
    });
    return out;
  }

  function currentLocationFallback(worldContext) {
    var current = worldContext && worldContext.currentMap && worldContext.currentMap.current;
    var facts = worldContext && worldContext.facts;
    return text(current && current.passage) || text(facts && facts.passage) || 'current';
  }

  function looksLikeActionLocation(raw) {
    var compact = text(raw).replace(/\s+/g, '');
    if (!compact) return false;
    if (/^(?:\u8dd1|\u9003|\u9003\u8dd1|\u8eb2|\u8eb2\u907f|\u907f\u5f00|\u79fb\u52a8|\u884c\u52a8|\u524d\u8fdb|\u7ee7\u7eed|\u79bb\u5f00|\u8fd4\u56de|\u56de\u53bb|\u8d70|\u8d70\u8def|\u8d76\u8def|\u884c\u8d70|\u5954\u8dd1|run|flee|escape|hide|move|walk|go|leave|return|continue|action)$/i.test(compact)) return true;
    if (/^(?:\u8dd1\u53bb|\u8dd1\u5230|\u9003\u5230|\u8eb2\u5230|\u524d\u5f80|\u53bb|\u8fdb\u5165|\u5230\u8fbe|\u62b5\u8fbe)$/i.test(compact)) return true;
    return /^(?:\u8dd1|\u9003|\u8eb2|\u8d70|\u53bb|\u5230|\u8fdb|\u56de)[\s:\uff1a-]*$/i.test(text(raw));
  }

  function hasMovementCue(rawText) {
    rawText = text(rawText);
    return /(\u5230\u8fbe|\u62b5\u8fbe|\u6765\u5230|\u8d70\u5230|\u8d70\u8fdb|\u8fdb\u5165|\u56de\u5230|\u524d\u5f80|\u53bb\u5f80|\u8d76\u5230|\u79bb\u5f00|arriv|reach|enter|walk(?:ed|s|ing)?\s+to|go(?:es|ing|ne)?\s+to|went\s+to|return(?:ed|s|ing)?\s+to|leave(?:s|ing)?\s+for)/i.test(rawText);
  }

  function hasArrivalCue(rawText) {
    rawText = removeStructuredBlocks(rawText);
    return /(\u5230\u8fbe|\u62b5\u8fbe|\u6765\u5230|\u8d70\u5230|\u8d70\u8fdb|\u8fdb\u5165|\u8e0f\u5165|\u56de\u5230|\u8d76\u5230|\u8d70\u4e86\u8fdb\u53bb|\u8d70\u8fdb\u53bb|(?:\u7ad9|\u505c|\u7b49)\u5728[^\u3002\uff01\uff1f.!?]{0,20}(?:\u95e8\u53e3|\u95e8\u524d|\u5165\u53e3)|\u63a8\u5f00[^\u3002\uff01\uff1f.!?]{0,24}\u95e8[^\u3002\uff01\uff1f.!?]{0,16}(?:\u8fdb\u5165|\u8d70\u8fdb|\u8d70\u4e86\u8fdb\u53bb)|arriv(?:e|es|ed|ing)|reach(?:es|ed|ing)?|enter(?:s|ed|ing)?|walk(?:s|ed|ing)?\s+into|went\s+inside|step(?:s|ped|ping)?\s+into|stand(?:s|ing)?\s+(?:at|outside|before)\s+[^.!?]{0,24}(?:door|entrance)|return(?:s|ed|ing)?\s+to)/i.test(rawText);
  }

  function hasDirectedMovementTo(rawText, term) {
    rawText = text(rawText);
    term = text(term);
    if (!rawText || !term) return false;
    var hay = rawText.toLowerCase();
    var needle = term.toLowerCase();
    var from = 0;
    while (from < hay.length) {
      var index = hay.indexOf(needle, from);
      if (index < 0) break;
      var prefix = hay.slice(Math.max(0, index - 36), index);
      if (/(?:\u5230\u8fbe|\u62b5\u8fbe|\u6765\u5230|\u8d70\u5230|\u8d70\u8fdb|\u8fdb\u5165|\u8e0f\u5165|\u56de\u5230|\u8fd4\u56de|\u524d\u5f80|\u53bb\u5f80|\u53bb|\u8d76\u5230|\u8d70\u5411|\u8dd1\u5411|arriv(?:e|es|ed|ing)?\s+(?:at\s+)?|reach(?:es|ed|ing)?\s+|enter(?:s|ed|ing)?\s+|walk(?:s|ed|ing)?\s+(?:to|into)\s+|go(?:es|ing|ne)?\s+to\s+|went\s+to\s+|head(?:s|ed|ing)?\s+to\s+|return(?:s|ed|ing)?\s+to\s+)[^\u3002\uff01\uff1f.!?]{0,18}$/i.test(prefix)) return true;
      from = index + Math.max(1, needle.length);
    }
    return false;
  }

  function collectNarrativeLocationEntries(worldContext, knownLocations) {
    var byRaw = {};
    function add(raw, label, aliases, source, meta) {
      raw = text(raw);
      if (!raw) return;
      var key = raw.toLowerCase();
      var entry = byRaw[key] || {
        raw: raw,
        label: '',
        aliases: [],
        sources: {}
      };
      if (label && !entry.label) entry.label = text(label);
      if (meta && meta.narrativeArrival === false) entry.narrativeArrival = false;
      if (meta && meta.isLocation === false) entry.isLocation = false;
      if (source) entry.sources[source] = true;
      [raw, label].concat(Array.isArray(aliases) ? aliases : []).forEach(function (alias) {
        alias = text(alias);
        if (alias && entry.aliases.indexOf(alias) < 0) entry.aliases.push(alias);
      });
      byRaw[key] = entry;
    }
    (Array.isArray(knownLocations) ? knownLocations : []).forEach(function (loc) {
      loc = loc || {};
      add(loc.raw || loc.passage, loc.label, loc.aliases, 'known', loc);
    });
    var current = worldContext && worldContext.currentMap && worldContext.currentMap.current;
    add(current && current.passage, current && current.label, [], 'current', current);
    var adjacent = worldContext && worldContext.currentMap && Array.isArray(worldContext.currentMap.adjacent)
      ? worldContext.currentMap.adjacent
      : [];
    adjacent.forEach(function (loc) { add(loc && loc.passage, loc && loc.label, loc && loc.aliases, 'adjacent', loc); });
    var links = worldContext && Array.isArray(worldContext.visibleLinks) ? worldContext.visibleLinks : [];
    links.forEach(function (loc) { add(loc && loc.passage, loc && (loc.label || loc.text), loc && loc.aliases, 'visible', loc); });
    var controls = worldContext && Array.isArray(worldContext.visibleControls) ? worldContext.visibleControls : [];
    controls.forEach(function (loc) { add(loc && loc.passage, loc && (loc.label || loc.text), loc && loc.aliases, 'visible', loc); });
    return Object.keys(byRaw).map(function (key) { return byRaw[key]; });
  }

  function findNarrativeArrivalCandidate(worldContext, knownLocations, rawText, choiceText) {
    if (!hasArrivalCue(rawText)) return null;
    var contextSet = mapPassageSet(worldContext);
    var current = currentLocationFallback(worldContext).toLowerCase();
    var combined = [choiceText || '', removeStructuredBlocks(rawText)].join(' ');
    var best = null;
    collectNarrativeLocationEntries(worldContext, knownLocations).forEach(function (entry) {
      if (!entry || entry.isLocation === false || entry.narrativeArrival === false) return;
      var rawKey = text(entry.raw).toLowerCase();
      if (!rawKey || rawKey === current || !contextSet[rawKey]) return;
      (entry.aliases || []).forEach(function (alias) {
        alias = text(alias);
        if (!alias || !hasDirectedMovementTo(combined, alias)) return;
        var score = alias.length * 10;
        if (choiceText && text(choiceText).toLowerCase().indexOf(alias.toLowerCase()) >= 0) score += 50;
        if (entry.sources.visible || entry.sources.adjacent) score += 20;
        if (!best || score > best.score) best = { raw: entry.raw, label: entry.label || entry.raw, alias: alias, score: score };
      });
    });
    return best;
  }

  function repairCurrentLocationFromNarrative(out, worldContext, knownLocations, rawText, choiceText, diagnostics) {
    if (!out) return;
    var status = text(out.locationStatus).toLowerCase();
    if (status === 'intransit' || status === 'transit') return;
    if (out.targetLocation && !/^(current|same|\u5f53\u524d|\u4e0d\u53d8)$/i.test(text(out.targetLocation))) return;
    var candidate = findNarrativeArrivalCandidate(worldContext, knownLocations, rawText, choiceText);
    if (!candidate) return;
    out.targetLocation = candidate.raw;
    out.locationStatus = 'arrived';
    diagnostics.push({
      level: 'info',
      code: 'current_location_repaired_from_arrived_narrative',
      from: 'current',
      to: candidate.raw,
      matched: candidate.alias
    });
  }

  function addKnownLocationsToSet(set, locations) {
    set = set || {};
    if (!Array.isArray(locations)) return set;
    locations.forEach(function (loc) {
      loc = loc || {};
      if (loc.isLocation === false) return;
      var raw = text(loc.raw || loc.passage);
      var label = text(loc.label);
      var locId = text(loc.locId);
      if (raw) set[raw.toLowerCase()] = raw;
      if (label && raw) set[label.toLowerCase()] = raw;
      if (locId && raw) set[locId.toLowerCase()] = raw;
      var aliases = Array.isArray(loc.aliases) ? loc.aliases : [];
      aliases.forEach(function (alias) {
        alias = text(alias);
        if (alias && raw) set[alias.toLowerCase()] = raw;
      });
    });
    return set;
  }

  function normalizeLocation(raw, locationSet, diagnostics, field) {
    raw = text(raw);
    if (!raw) return '';
    if (/^(current|same|\u5f53\u524d|\u4e0d\u53d8)$/i.test(raw)) return 'current';
    if (looksLikeActionLocation(raw)) {
      diagnostics.push({ level: 'warn', code: 'action_like_location', field: field || 'location', value: raw });
      return /targetLocation/i.test(field || '') ? 'current' : '';
    }
    var lower = raw.toLowerCase();
    if (locationSet[lower]) return locationSet[lower];
    diagnostics.push({ level: 'warn', code: 'unknown_location', field: field || 'location', value: raw });
    if (/targetLocation/i.test(field || '')) {
      diagnostics.push({ level: 'warn', code: 'unknown_target_location_reset', from: raw, to: 'current' });
      return 'current';
    }
    return raw;
  }

  function guardLocationConflicts(out, worldContext, contextLocations, rawText, diagnostics, blocked) {
    if (!out) return;
    if (out.location === '') {
      var fallback = currentLocationFallback(worldContext);
      diagnostics.push({ level: 'warn', code: 'action_like_location_reset', field: 'location', to: fallback });
      addBlockedEffect(blocked, 'location', 'action_like_location_reset', '', fallback);
      out.location = fallback;
    }
    if (out.targetLocation === 'current') {
      return;
    }
    if (!out.targetLocation) return;
    var targetKey = npcKey(out.targetLocation);
    if (contextLocations && !contextLocations[targetKey] && !hasMovementCue(rawText)) {
      diagnostics.push({
        level: 'warn',
        code: 'target_location_without_movement_cue_reset',
        field: 'targetLocation',
        value: out.targetLocation,
        to: 'current'
      });
      addBlockedEffect(blocked, 'targetLocation', 'target_location_without_movement_cue_reset', out.targetLocation, 'current');
      out.targetLocation = 'current';
      out.locationStatus = 'current';
    }
  }

  function getUnstableSpecialEvent(worldContext) {
    var special = worldContext && worldContext.specialEvent;
    if (special && special.applies && special.stableLocation === false) return special;
    var rows = getRuleFacts(worldContext);
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i] || {};
      if (text(row.id) !== 'special_event_rule') continue;
      var hay = [row.summary, row.caution, Array.isArray(row.tags) ? row.tags.join(' ') : ''].join(' ').toLowerCase();
      if (/special|event|dream|nightmare|transition|mirror|startup|特殊|事件|梦|噩梦|过渡|镜/.test(hay)) {
        return {
          applies: true,
          type: text((row.tags && row.tags[1]) || row.summary || 'special_event'),
          stableLocation: false,
          caution: text(row.caution || ''),
          reason: text(row.summary || '')
        };
      }
    }
    return null;
  }

  function hasStableReturnCue(rawText) {
    rawText = removeStructuredBlocks(rawText).toLowerCase();
    return /(醒来|清醒|回到现实|返回现实|离开梦境|脱离梦境|走出镜子|穿过镜子回到|离开特殊空间|回到稳定地点|回到原来的|回到真正的|wake(?:s|d)?\s+up|woke\s+up|return(?:s|ed|ing)?\s+to\s+reality|back\s+in\s+the\s+real|leave(?:s|d|ing)?\s+the\s+(?:dream|nightmare|mirror|special space)|through\s+the\s+mirror\s+back)/i.test(rawText);
  }

  function guardSpecialEventLocation(out, worldContext, rawText, diagnostics, blocked) {
    if (!out || !out.targetLocation || out.targetLocation === 'current') return;
    var special = getUnstableSpecialEvent(worldContext);
    if (!special) return;
    if (hasStableReturnCue(rawText)) {
      diagnostics.push({
        level: 'info',
        code: 'special_event_location_allowed_by_return_cue',
        field: 'targetLocation',
        value: out.targetLocation,
        specialEvent: text(special.type || special.reason || 'special_event')
      });
      return;
    }
    diagnostics.push({
      level: 'warn',
      code: 'special_event_target_location_reset',
      field: 'targetLocation',
      value: out.targetLocation,
      to: 'current',
      specialEvent: text(special.type || special.reason || 'special_event')
    });
    addBlockedEffect(blocked, 'targetLocation', 'special_event_target_location_reset', out.targetLocation, 'current');
    out.targetLocation = 'current';
    out.locationStatus = 'current';
  }

  function looksLikeUiPage(worldContext) {
    var page = worldContext && worldContext.page;
    if (!page) return false;
    return !!page.skip || /^(shop|management|settings|ui|inventory)$/i.test(text(page.type));
  }

  function getRuleFacts(worldContext) {
    return worldContext && Array.isArray(worldContext.ruleFacts) ? worldContext.ruleFacts : [];
  }

  function getRestrictedBusinessRule(worldContext) {
    var rows = getRuleFacts(worldContext);
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i] || {};
      if (text(row.id) !== 'business_opening_rule') continue;
      var tags = Array.isArray(row.tags) ? row.tags.map(function (tag) { return text(tag).toLowerCase(); }) : [];
      var hay = [
        row.summary,
        row.caution,
        row.source,
        tags.join(' ')
      ].join(' ').toLowerCase();
      if (tags.indexOf('closed') >= 0 || tags.indexOf('night') >= 0 || tags.indexOf('closing') >= 0 || /closed|after hours|closing time|night state|关门|关闭|打烊|夜间/.test(hay)) {
        return row;
      }
    }
    return null;
  }

  function hasNonBusinessAcquisitionCue(rawText) {
    rawText = removeStructuredBlocks(rawText).toLowerCase();
    return /(偷|偷走|偷取|盗|抢|抢走|抢夺|撬锁|破门|闯入|搜刮|捡到|拾起|发现|steal|stole|stolen|rob|loot|pick(?:ed|ing)?\s+the\s+lock|break(?:s|ing)?\s+in|found|picked\s+up)/i.test(rawText);
  }

  function suppressRestrictedBusinessEffects(out, worldContext, rawText, diagnostics, blocked) {
    if (!out) return;
    var rule = getRestrictedBusinessRule(worldContext);
    if (!rule) return;
    var exceptional = hasNonBusinessAcquisitionCue(rawText);
    var reason = text(rule.summary || rule.id || 'restricted business state');
    if (!exceptional) {
      suppressField(out, 'itemsGained', diagnostics, blocked, 'restricted_business_items_gained_suppressed');
      suppressField(out, 'itemsLost', diagnostics, blocked, 'restricted_business_items_lost_suppressed');
    }
    if (out.moneyChange) {
      diagnostics.push({
        level: 'warn',
        code: 'restricted_business_money_change_suppressed',
        field: 'moneyChange',
        value: out.moneyChange,
        rule: reason
      });
      addBlockedEffect(blocked, 'moneyChange', 'restricted_business_money_change_suppressed', out.moneyChange, undefined);
      delete out.moneyChange;
    }
    diagnostics.push({
      level: 'info',
      code: exceptional ? 'restricted_business_rule_observed_exceptional_action' : 'restricted_business_rule_applied',
      rule: reason
    });
  }

  function getSchoolTimeRule(worldContext) {
    var rows = getRuleFacts(worldContext);
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i] || {};
      if (text(row.id) === 'school_time_rule') return row;
    }
    return null;
  }

  function schoolRuleMeansLessonsUnderway(rule) {
    if (!rule) return false;
    var hay = [rule.summary, rule.caution, (Array.isArray(rule.tags) ? rule.tags.join(' ') : '')].join(' ').toLowerCase();
    return /lessons are underway|morning_lessons|afternoon_lessons|class(?:es)? (?:are )?(?:underway|in session)|上课中|正在上课|课程已开始/.test(hay);
  }

  function schoolRuleMeansBreakOrAfterSchool(rule) {
    if (!rule) return '';
    var hay = [rule.summary, rule.caution, (Array.isArray(rule.tags) ? rule.tags.join(' ') : '')].join(' ').toLowerCase();
    if (/lunch|midday break|lunch_break|午休|午餐/.test(hay)) return 'lunch_break';
    if (/after school|after_school|放学/.test(hay)) return 'after_school';
    return '';
  }

  function hasSchoolNotStartedText(rawText) {
    rawText = removeStructuredBlocks(rawText).toLowerCase();
    return /(?:第一节课|第一堂课|课程|课堂|上课|学校|早课)[^。！？.!?\n]{0,24}(?:还没|尚未|没有|未曾|并未)[^。！？.!?\n]{0,16}(?:开始|开课|上课)|(?:还没|尚未|没有|并未)[^。！？.!?\n]{0,16}(?:开始上课|开课|到上课时间)|(?:classes?|lessons?|school)[^.!?\n]{0,32}(?:has not|haven't|have not|had not|isn't|is not|are not|aren't)[^.!?\n]{0,24}(?:started|begun|begin|in session|underway)|(?:first class|first lesson)[^.!?\n]{0,32}(?:has not|hasn't|had not|hadn't|is not|isn't)[^.!?\n]{0,24}(?:started|begun|begin)/i.test(rawText);
  }

  function hasSchoolInClassText(rawText) {
    rawText = removeStructuredBlocks(rawText).toLowerCase();
    return /(?:正在|仍在|还在|继续|已经)[^。！？.!?\n]{0,18}(?:上课|听课|课堂|课程|第一节课|第二节课)|(?:课堂|课程|第一节课|第二节课|老师讲课)[^。！？.!?\n]{0,24}(?:正在|进行中|还在|继续)|(?:class|lesson)[^.!?\n]{0,32}(?:is|are|was|were|continues?|underway|in session)/i.test(rawText);
  }

  function diagnoseSchoolTimeTextConflicts(worldContext, rawText, diagnostics) {
    var rule = getSchoolTimeRule(worldContext);
    if (schoolRuleMeansLessonsUnderway(rule) && hasSchoolNotStartedText(rawText)) {
      diagnostics.push({
        level: 'warn',
        code: 'school_time_text_conflict',
        field: 'narrativeText',
        rule: text(rule.summary || 'school lessons are underway'),
        message: 'AI narrative says school/classes have not started, but world_context ruleFacts says lessons are underway.'
      });
      return;
    }
    var nonLessonPhase = schoolRuleMeansBreakOrAfterSchool(rule);
    if (nonLessonPhase && hasSchoolInClassText(rawText)) {
      diagnostics.push({
        level: 'warn',
        code: 'school_time_text_conflict',
        field: 'narrativeText',
        rule: text(rule.summary || nonLessonPhase),
        message: 'AI narrative describes active class time, but world_context ruleFacts says the school phase is ' + nonLessonPhase + '.'
      });
    }
  }

  function hasNormalBusinessServiceText(rawText) {
    rawText = removeStructuredBlocks(rawText).toLowerCase();
    return /(\u6b63\u5e38\u8425\u4e1a|\u4ecd\u7136\u8425\u4e1a|\u7167\u5e38\u8425\u4e1a|\u95e8\u5e97\u5f00\u7740|\u5546\u5e97\u5f00\u7740|\u4eba\u7fa4\u7199\u6518|\u987e\u5ba2\u5f88\u591a|\u5e97\u5458\u70ed\u60c5|\u5e97\u5458\u63a5\u5f85|\u6b63\u5e38\u8d2d\u7269|\u968f\u610f\u8d2d\u4e70|\u67dc\u53f0\u7ed3\u8d26|normal(?:ly)?\s+open|open\s+for\s+(?:business|service)|still\s+open|shops?\s+(?:are|is)\s+open|crowded\s+(?:shop|store|market|mall)|busy\s+(?:shop|store|market|mall)|staff\s+(?:serve|serves|served|serving|welcome|welcomes)|cashier\s+(?:rings|takes|accepts)|normal\s+(?:shopping|service|business))/i.test(rawText);
  }

  function diagnoseBusinessTimeTextConflicts(worldContext, rawText, diagnostics) {
    var rule = getRestrictedBusinessRule(worldContext);
    if (!rule) return;
    if (!hasNormalBusinessServiceText(rawText)) return;
    if (hasNonBusinessAcquisitionCue(rawText)) return;
    diagnostics.push({
      level: 'warn',
      code: 'business_time_text_conflict',
      field: 'narrativeText',
      rule: text(rule.summary || 'restricted business/opening state'),
      message: 'AI narrative describes normal open service, but world_context ruleFacts says the venue is closed, night, or closing.'
    });
  }

  function moneyMentionedInText(rawText, moneyValue) {
    rawText = text(rawText);
    moneyValue = text(moneyValue);
    if (!moneyValue) return false;
    var n = parseInt(moneyValue, 10);
    if (!isFinite(n)) return false;
    var abs = Math.abs(n);
    var pounds = Math.floor(abs / 100);
    var pence = abs % 100;
    var explicitDecimal = new RegExp('(?:[£￡]\\s*)?' + String(pounds).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\.' + String(pence).padStart(2, '0') + '\\b');
    if (explicitDecimal.test(rawText)) return true;
    if (pence === 0) {
      var wholePoundDecimal = new RegExp('(?:[£￡]\\s*)?' + String(pounds).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\.00\\b');
      if (wholePoundDecimal.test(rawText)) return true;
    }
    var rawPence = new RegExp('(^|[^\\d.])' + String(abs).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?:\\s*(?:便士|pence|p\\b)|(?=$|[^\\d.]))', 'i');
    if (rawPence.test(rawText)) return true;
    var wholePoundWithCurrency = new RegExp('(?:[£￡]\\s*' + String(pounds).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b|' + String(pounds).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*(?:英镑|镑|元|块)\\b)', 'i');
    if (abs === pounds * 100 && wholePoundWithCurrency.test(rawText)) return true;
    return false;
  }

  function hasVisibleMoneyAmountRule(worldContext) {
    var rows = getRuleFacts(worldContext);
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i] || {};
      if (text(row.id) === 'visible_money_amount_rule') return true;
    }
    return false;
  }

  function hasMoneyTransactionCue(rawText) {
    rawText = removeStructuredBlocks(rawText).toLowerCase();
    return /(\u652f\u4ed8|\u4ed8\u94b1|\u4ed8\u7ed9|\u4ea4\u4e86|\u7f34\u7eb3|\u4ed8\u6e05|\u4ed8\u6389|\u82b1\u4e86|\u6263\u9664|\u88ab\u6263|\u4e70\u4e0b|\u8d2d\u4e70|\u5356\u51fa|\u6536\u5230|\u6536\u4e0b|\u8d5a\u5230|\u8d5a\u53d6|\u83b7\u5f97|\u5f97\u5230|\u62ff\u5230|\u6361\u5230|\u5077\u5230|\u62a2\u5230|\u635f\u5931|\u5931\u53bb|\u9000\u6b3e|\u8d54\u507f|pay(?:s|ing|ed)?|paid|spend(?:s|ing)?|spent|charge(?:s|d)?|charged|deduct(?:s|ed|ing)?|buy(?:s|ing)?|bought|purchase(?:s|d|ing)?|sell(?:s|ing)?|sold|earn(?:s|ed|ing)?|receive(?:s|d|ing)?|gain(?:s|ed|ing)?|get(?:s|ting)?|got|pick(?:s|ed|ing)?\s+up|steal(?:s|ing)?|stole|stolen|rob(?:s|bed|bing)?|lose(?:s|ing)?|lost|refund(?:s|ed|ing)?|compensat(?:e|es|ed|ing))/i.test(rawText);
  }

  function suppressVisibleMoneyWithoutTransaction(out, worldContext, rawText, diagnostics, blocked) {
    if (!out || !out.moneyChange) return;
    if (!hasVisibleMoneyAmountRule(worldContext)) return;
    if (hasMoneyTransactionCue(rawText)) return;
    diagnostics.push({
      level: 'warn',
      code: 'visible_money_without_transaction_cue',
      field: 'moneyChange',
      value: out.moneyChange,
      message: 'Visible page/control amount was mentioned, but the narrative did not complete a payment or receipt.'
    });
    addBlockedEffect(blocked, 'moneyChange', 'visible_money_without_transaction_cue', out.moneyChange, undefined);
    delete out.moneyChange;
  }

  var ITEM_ALIAS_MAP = {
    '\u72d7\u7cae': ['dog food'],
    '\u6e05\u6c34': ['clean water', 'water'],
    '\u94a5\u5319': ['key'],
    '\u5c0f\u94a5\u5319': ['small key'],
    '\u751f\u9508\u94a5\u5319': ['rusty key'],
    '\u7fbd\u6bdb': ['feather'],
    '\u5927\u7fbd\u6bdb': ['large feather'],
    '\u9e70\u7fbd': ['hawk feather', 'eagle feather'],
    '\u5b9d\u77f3': ['gem', 'gemstone'],
    '\u7ea2\u5b9d\u77f3': ['red gem', 'red gemstone'],
    '\u6697\u7ea2\u5b9d\u77f3': ['dark red gem'],
    '\u9e1f\u86cb': ['egg', 'bird egg'],
    '\u7ef3\u5b50': ['rope'],
    '\u7eb8\u6761': ['note'],
    '\u5730\u56fe': ['map'],
    '\u8349\u836f': ['herb', 'herbs'],
    '\u91ce\u751f\u8349\u836f': ['wild herb'],
    '\u82b1': ['flower'],
    '\u91ce\u82b1': ['wild flower'],
    '\u91ce\u679c': ['berry', 'berries', 'wild berry', 'wild berries'],
    '\u9aa8\u5934': ['bone'],
    '\u6728\u68cd': ['stick']
  };

  function removeStructuredBlocks(rawText) {
    return text(rawText)
      .replace(/\[AI_EVENT\][\s\S]*?\[\/AI_EVENT\]/gi, ' ')
      .replace(/\[AI_EVENT:[\s\S]*?\]/gi, ' ');
  }

  function itemMentionedInText(rawText, itemName) {
    var hay = removeStructuredBlocks(rawText).toLowerCase();
    itemName = text(itemName);
    if (!hay || !itemName) return false;
    var names = [itemName].concat(ITEM_ALIAS_MAP[itemName] || []);
    return names.some(function (name) {
      name = text(name).toLowerCase();
      return !!(name && hay.indexOf(name) >= 0);
    });
  }

  function itemNameFromEntry(entry) {
    entry = text(entry);
    entry = entry.replace(/\s*(?:x|\u00d7|\*)\s*\d+\s*$/i, '').trim();
    return entry;
  }

  function filterItemField(out, field, rawText, diagnostics, blocked) {
    if (!out || !out[field]) return;
    var kept = [];
    splitList(out[field]).forEach(function (entry) {
      var name = itemNameFromEntry(entry);
      if (itemMentionedInText(rawText, name)) {
        kept.push(entry);
        return;
      }
      diagnostics.push({
        level: 'warn',
        code: field === 'itemsLost' ? 'item_lost_without_text_evidence_suppressed' : 'item_gain_without_text_evidence_suppressed',
        field: field,
        item: name,
        value: entry
      });
      addBlockedEffect(
        blocked,
        field,
        field === 'itemsLost' ? 'item_lost_without_text_evidence_suppressed' : 'item_gain_without_text_evidence_suppressed',
        entry,
        undefined
      );
    });
    out[field] = joinList(kept);
    if (!out[field]) delete out[field];
  }

  function getKnowledgeCautions(worldContext) {
    var knowledge = worldContext && worldContext.retrievedKnowledge;
    var cautions = knowledge && Array.isArray(knowledge.cautions) ? knowledge.cautions : [];
    return cautions.map(text).filter(Boolean).slice(0, 8);
  }

  function addBlockedEffect(blocked, field, code, value, replacement) {
    if (!Array.isArray(blocked)) return;
    blocked.push({
      field: field,
      code: code || ('blocked_' + field),
      value: value,
      replacement: replacement
    });
  }

  function suppressField(out, field, diagnostics, blocked, code) {
    if (!out || !Object.prototype.hasOwnProperty.call(out, field) || !out[field]) return;
    diagnostics.push({ level: 'warn', code: code || ('suppressed_' + field), field: field, value: out[field] });
    addBlockedEffect(blocked, field, code || ('suppressed_' + field), out[field], undefined);
    delete out[field];
  }

  function create(deps) {
    deps = deps || {};

    function getWorldContext(input) {
      input = input || {};
      if (input.worldContext) return input.worldContext;
      try {
        if (deps.worldContext && typeof deps.worldContext.build === 'function') {
          return deps.worldContext.build(input);
        }
      } catch (_) {}
      return {};
    }

    function check(eventData, input) {
      input = input || {};
      var diagnostics = [];
      var blockedEffects = [];
      var out = Object.assign({}, eventData || {});
      var worldContext = getWorldContext(input);
      var npcMap = buildNpcMap(worldContext);
      var contextLocations = mapPassageSet(worldContext);
      var locations = copySet(contextLocations);
      var knownLocations = [];
      try {
        knownLocations = typeof deps.getKnownLocations === 'function' ? deps.getKnownLocations() : deps.knownLocations;
        addKnownLocationsToSet(locations, knownLocations);
      } catch (_) {}

      if (out.presentCharacters) {
        out.presentCharacters = canonicalizeNameList(out.presentCharacters, npcMap, diagnostics);
        filterPresentCharacters(out, worldContext, npcMap, diagnostics, blockedEffects);
      }
      if (out.presentEntities) {
        filterPresentEntities(out, npcMap, diagnostics, blockedEffects);
      }
      if (out.sexTargets) {
        out.sexTargets = canonicalizeNameList(out.sexTargets, npcMap, diagnostics);
        filterSexTargets(out, worldContext, npcMap, diagnostics, blockedEffects);
      }
      if (out.relationshipChanges) {
        var relParts = splitList(out.relationshipChanges).map(function (part) {
          var m = part.match(/^([^:\uff1a]+)([:\uff1a].*)$/);
          if (!m) return part;
          return canonicalizeName(m[1], npcMap, diagnostics) + m[2];
        });
        out.relationshipChanges = joinList(relParts);
        filterRelationshipChanges(out, worldContext, npcMap, diagnostics, blockedEffects);
      }

      if (out.location) {
        out.location = normalizeLocation(out.location, locations, diagnostics, 'location');
      }
      if (out.targetLocation) {
        var rawTargetLocation = out.targetLocation;
        out.targetLocation = normalizeLocation(out.targetLocation, locations, diagnostics, 'targetLocation');
        if (out.targetLocation === 'current' && text(rawTargetLocation) && !/^(current|same|\u5f53\u524d|\u4e0d\u53d8)$/i.test(text(rawTargetLocation))) {
          addBlockedEffect(
            blockedEffects,
            'targetLocation',
            looksLikeActionLocation(rawTargetLocation) ? 'action_like_target_location_reset' : 'unknown_target_location_reset',
            rawTargetLocation,
            'current'
          );
          out.locationStatus = 'current';
        }
      }
      repairCurrentLocationFromNarrative(out, worldContext, knownLocations, input.rawText || '', input.choiceText || '', diagnostics);
      guardLocationConflicts(out, worldContext, contextLocations, input.rawText || '', diagnostics, blockedEffects);
      guardSpecialEventLocation(out, worldContext, input.rawText || '', diagnostics, blockedEffects);

      if (looksLikeUiPage(worldContext)) {
        suppressField(out, 'itemsGained', diagnostics, blockedEffects, 'ui_page_items_gained_suppressed');
        suppressField(out, 'itemsLost', diagnostics, blockedEffects, 'ui_page_items_lost_suppressed');
        suppressField(out, 'relationshipChanges', diagnostics, blockedEffects, 'ui_page_relationship_changes_suppressed');
        suppressField(out, 'moneyChange', diagnostics, blockedEffects, 'ui_page_money_change_suppressed');
        if (out.targetLocation && out.targetLocation !== 'current') {
          diagnostics.push({ level: 'warn', code: 'ui_page_target_location_reset', from: out.targetLocation, to: 'current' });
          addBlockedEffect(blockedEffects, 'targetLocation', 'ui_page_target_location_reset', out.targetLocation, 'current');
          out.targetLocation = 'current';
          out.locationStatus = 'current';
        }
        if (out.memoryImportance && Number(out.memoryImportance) > 1) {
          diagnostics.push({ level: 'info', code: 'ui_page_memory_importance_clamped', from: out.memoryImportance, to: 1 });
          out.memoryImportance = 1;
        }
      }

      suppressRestrictedBusinessEffects(out, worldContext, input.rawText || '', diagnostics, blockedEffects);
      diagnoseSchoolTimeTextConflicts(worldContext, input.rawText || '', diagnostics);
      diagnoseBusinessTimeTextConflicts(worldContext, input.rawText || '', diagnostics);

      filterItemField(out, 'itemsGained', input.rawText || '', diagnostics, blockedEffects);
      filterItemField(out, 'itemsLost', input.rawText || '', diagnostics, blockedEffects);

      getKnowledgeCautions(worldContext).forEach(function (caution) {
        diagnostics.push({ level: 'info', code: 'retrieved_knowledge_caution', message: caution });
      });

      if (out.moneyChange && !moneyMentionedInText(input.rawText || '', out.moneyChange)) {
        diagnostics.push({ level: 'warn', code: 'money_without_matching_text_amount', value: out.moneyChange });
        addBlockedEffect(blockedEffects, 'moneyChange', 'money_without_matching_text_amount', out.moneyChange, undefined);
        delete out.moneyChange;
      }
      suppressVisibleMoneyWithoutTransaction(out, worldContext, input.rawText || '', diagnostics, blockedEffects);

      if (diagnostics.length) out._diagnostics = diagnostics;
      if (blockedEffects.length) out._blockedEffects = blockedEffects;
      return out;
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      moduleSchemaVersion: MODULE_SCHEMA_VERSION,
      check: check
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: create
  };

  root.AIStoryGen.ConsistencyGuardModule = api;
  root.AIStoryGenConsistencyGuardModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
