/* ============================================================
 * AIStoryGen barefoot footwear effects
 * Keeps the player visually and mechanically barefoot while
 * exposing selected positive footwear tags to native checks.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var SAFE_EFFECTS = {
    rugged: {
      configKey: 'barefootBuffRugged',
      label: '\u5d0e\u5c96\u5730\u5f62\u978b\u5e95'
    },
    swim: {
      configKey: 'barefootBuffSwim',
      label: '\u6e38\u6cf3\u811a\u8e7c\u6548\u679c'
    }
  };
  var patchedArrays = typeof WeakMap === 'function' ? new WeakMap() : null;

  function rawIncludes(array, value, fromIndex) {
    if (!array) return false;
    if (arguments.length >= 3) return Array.prototype.includes.call(array, value, fromIndex);
    return Array.prototype.includes.call(array, value);
  }

  function rawTags(type) {
    if (!Array.isArray(type)) return [];
    return Array.prototype.slice.call(type);
  }

  function flag(value, fallback) {
    if (value == null) value = fallback;
    return Number(value || 0) !== 0;
  }

  function getVariables(deps) {
    try {
      if (deps && typeof deps.getVariables === 'function') return deps.getVariables() || null;
    } catch (_) {}
    try {
      if (root.State && root.State.variables) return root.State.variables;
    } catch (_) {}
    try {
      if (typeof State !== 'undefined' && State.variables) return State.variables;
    } catch (_) {}
    return null;
  }

  function loadCfg(deps) {
    try {
      if (deps && typeof deps.loadCfg === 'function') return deps.loadCfg() || {};
    } catch (_) {}
    try {
      if (root.AIStoryGen && typeof root.AIStoryGen.loadCfg === 'function') {
        return root.AIStoryGen.loadCfg() || {};
      }
    } catch (_) {}
    return {};
  }

  function getFeet(deps) {
    var variables = getVariables(deps);
    return variables && variables.worn && variables.worn.feet ? variables.worn.feet : null;
  }

  function isBarefoot(feet) {
    if (!feet || !Array.isArray(feet.type)) return false;
    var name = String(feet.name || '').trim().toLowerCase();
    return name === 'naked' || rawIncludes(feet.type, 'naked');
  }

  function configuredTags(cfg) {
    cfg = cfg || {};
    if (!flag(cfg.barefootBuffEnabled, 0)) return [];
    return Object.keys(SAFE_EFFECTS).filter(function (tag) {
      return flag(cfg[SAFE_EFFECTS[tag].configKey], tag === 'rugged' ? 1 : 0);
    });
  }

  function virtualPositionIsVisible(array, fromIndex, hasFromIndex) {
    if (!hasFromIndex) return true;
    var value = Number(fromIndex);
    if (Number.isNaN(value)) value = 0;
    if (value === Infinity) return false;
    if (value === -Infinity) return true;
    var virtualIndex = array.length;
    if (value >= 0) return Math.floor(value) <= virtualIndex;
    var virtualLength = array.length + 1;
    return Math.max(virtualLength + Math.ceil(value), 0) <= virtualIndex;
  }

  function create(deps) {
    deps = deps || {};
    var installed = false;
    var lastReason = '';
    var lastPatchError = '';

    function activeTagsForArray(array) {
      var feet = getFeet(deps);
      if (!feet || feet.type !== array || !isBarefoot(feet)) return [];
      return configuredTags(loadCfg(deps));
    }

    function includesVirtual(array, value, fromIndex, hasFromIndex) {
      value = String(value == null ? '' : value);
      if (!SAFE_EFFECTS[value]) return false;
      if (!virtualPositionIsVisible(array, fromIndex, hasFromIndex)) return false;
      return activeTagsForArray(array).indexOf(value) >= 0;
    }

    function patchTypeArray(type) {
      if (!Array.isArray(type)) return false;
      if (patchedArrays && patchedArrays.has(type)) return true;

      var ownDescriptor = null;
      try { ownDescriptor = Object.getOwnPropertyDescriptor(type, 'includes') || null; } catch (_) {}
      var nativeIncludes = typeof type.includes === 'function' ? type.includes : Array.prototype.includes;
      var wrappedIncludes = function (value, fromIndex) {
        var nativeResult = arguments.length >= 2
          ? nativeIncludes.call(this, value, fromIndex)
          : nativeIncludes.call(this, value);
        if (nativeResult) return true;
        return includesVirtual(this, value, fromIndex, arguments.length >= 2);
      };

      try {
        Object.defineProperty(type, 'includes', {
          configurable: true,
          enumerable: false,
          writable: true,
          value: wrappedIncludes
        });
        if (patchedArrays) {
          patchedArrays.set(type, {
            originalDescriptor: ownDescriptor,
            nativeIncludes: nativeIncludes
          });
        }
        lastPatchError = '';
        return true;
      } catch (error) {
        lastPatchError = String(error && error.message || error).slice(0, 180);
        return false;
      }
    }

    function refresh(reason) {
      lastReason = String(reason || 'refresh');
      var feet = getFeet(deps);
      if (!feet || !Array.isArray(feet.type)) return getDiagnostics();
      patchTypeArray(feet.type);
      return getDiagnostics();
    }

    function getDiagnostics() {
      var cfg = loadCfg(deps);
      var feet = getFeet(deps);
      var type = feet && Array.isArray(feet.type) ? feet.type : null;
      var tags = rawTags(type);
      var activeTags = type && isBarefoot(feet) ? configuredTags(cfg) : [];
      var serialized = '';
      var serializationSafe = true;
      try {
        serialized = JSON.stringify(type || []);
        serializationSafe = serialized === JSON.stringify(tags);
      } catch (_) {
        serializationSafe = false;
      }
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        installed: installed,
        enabled: flag(cfg.barefootBuffEnabled, 0),
        footwearName: String(feet && feet.name || ''),
        barefoot: isBarefoot(feet),
        rawTags: tags,
        activeTags: activeTags,
        activeLabels: activeTags.map(function (tag) { return SAFE_EFFECTS[tag].label; }),
        patched: !!(type && patchedArrays && patchedArrays.has(type)),
        serializationSafe: serializationSafe,
        serializedTags: serialized,
        lastReason: lastReason,
        lastPatchError: lastPatchError
      };
    }

    function install() {
      if (installed) return refresh('install-repeat');
      installed = true;
      var jq = deps.$ || root.jQuery || root.$;
      var doc = deps.document || root.document;
      if (typeof jq === 'function' && doc) {
        try {
          jq(doc)
            .off('.aiBarefootBuffs')
            .on(':passagestart.aiBarefootBuffs :passagerender.aiBarefootBuffs :passagedisplay.aiBarefootBuffs AIStoryGen:configSaved.aiBarefootBuffs', function () {
              refresh('runtime-event');
            });
        } catch (_) {}
      }
      refresh('install');
      try {
        if (typeof root.setTimeout === 'function') {
          root.setTimeout(function () { refresh('install-deferred'); }, 0);
        }
      } catch (_) {}
      return getDiagnostics();
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      install: install,
      refresh: refresh,
      getDiagnostics: getDiagnostics,
      isBarefoot: function () { return isBarefoot(getFeet(deps)); },
      getActiveTags: function () { return getDiagnostics().activeTags.slice(); }
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    safeEffects: SAFE_EFFECTS,
    rawIncludes: rawIncludes,
    isBarefoot: isBarefoot,
    configuredTags: configuredTags,
    create: create
  };

  root.AIStoryGen.BarefootBuffsModule = api;
  root.AIStoryGenBarefootBuffsModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
