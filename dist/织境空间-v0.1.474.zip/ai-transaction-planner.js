/* ============================================================
 * AIStoryGen transaction planner
 * Builds structured transaction plans from AI narrative output.
 * The commit engine still owns apply/rollback order.
 * ============================================================ */
(function () {
  'use strict';

  var root = window.AIStoryGen = window.AIStoryGen || {};
  var MODULE_SCHEMA_VERSION = 5;

  function createTransactionPlanner(deps) {
    deps = deps || {};

    function call(name) {
      var fn = deps[name];
      if (typeof fn !== 'function') throw new Error('AITransactionPlanner missing dependency: ' + name);
      return fn.apply(null, Array.prototype.slice.call(arguments, 1));
    }

    function optional(name, fallback) {
      var fn = deps[name];
      if (typeof fn !== 'function') return fallback;
      try {
        return fn.apply(null, Array.prototype.slice.call(arguments, 2));
      } catch (_) {
        return fallback;
      }
    }

    function clone(value) {
      return optional('clone', value, value);
    }

    function dedupeTextList(list) {
      return optional('dedupeTextList', Array.isArray(list) ? list.slice() : [], list);
    }

    function parseListField(value) {
      return optional('parseListField', [], value);
    }

    function findPlannedMoneyDelta(statParts) {
      statParts = Array.isArray(statParts) ? statParts : [];
      for (var i = 0; i < statParts.length; i++) {
        var m = String(statParts[i] || '').match(/^money\s*([+-]\d+)$/i);
        if (m) return parseInt(m[1], 10) || 0;
      }
      return 0;
    }

    var SHORT_ACTION_CAUSAL_STATS = {
      pain: true,
      arousal: true,
      tiredness: true,
      fatigue: true,
      stress: true,
      trauma: true,
      control: true,
      seduction: true
    };

    function parseStatPart(part) {
      var match = String(part || '').trim().match(/^([a-z_]+)\s*([+-]\d+)$/i);
      if (!match) return null;
      return {
        key: String(match[1] || '').toLowerCase(),
        delta: parseInt(match[2], 10) || 0,
        text: String(part || '').trim()
      };
    }

    function hasDirectStatCause(key, delta, evidence) {
      evidence = String(evidence || '');
      if (!evidence) return false;
      var positive = delta > 0;
      if (key === 'fatigue') key = 'tiredness';
      if (key === 'pain') {
        return positive
          ? /(?:injur|wound|cut|burn|bleed|hit|strike|fall|crash|attack|bite|stab|受伤|伤口|割伤|烧伤|流血|击中|撞伤|跌倒|袭击|咬伤|刺伤)/i.test(evidence)
          : /(?:treat|bandage|medicine|painkiller|heal|recover|first aid|治疗|包扎|服药|止痛|疗伤|急救|恢复)/i.test(evidence);
      }
      if (key === 'arousal') {
        return positive
          ? /(?:kiss|intimat|sexual|caress|fondle|stimulat|orgasm|masturbat|penetrat|arous|亲吻|亲密|性爱|抚摸|爱抚|刺激|高潮|自慰|插入|性奋|兴奋)/i.test(evidence)
          : /(?:stop (?:the )?(?:intimate|sexual)|withdraw|pull away|cool down|结束亲密|停止亲密|停止刺激|抽离|冷静下来)/i.test(evidence);
      }
      if (key === 'tiredness') {
        return positive
          ? /(?:sprint|run|climb|swim|fight|heavy (?:work|labor)|carry|dig|chop|exercise|exert|struggle|chase|flee|冲刺|奔跑|跑步|攀爬|游泳|战斗|搏斗|重体力|搬运|挖掘|砍伐|锻炼|挣扎|追赶|逃跑)/i.test(evidence)
          : /(?:sleep|nap|meaningful rest|go to bed and sleep|睡觉|入睡|小睡|充分休息|好好休息|卧床休息)/i.test(evidence);
      }
      if (key === 'stress') {
        return positive
          ? /(?:danger|threat|panic|attack|ambush|pursu|chase|confront|alarm|terrified|危险|威胁|恐慌|袭击|伏击|追逐|对峙|警报|惊恐)/i.test(evidence)
          : /(?:meaningful rest|relax|calm down|reach safety|comfort|reassur|休息|放松|平静下来|抵达安全处|安慰|安心)/i.test(evidence);
      }
      if (key === 'trauma') {
        return positive
          ? /(?:torture|sexual assault|rape|severe injur|near death|horror|traumatic|酷刑|性侵|强奸|重伤|濒死|骇人|创伤事件)/i.test(evidence)
          : /(?:therapy|counsel|trauma recovery|resolve (?:the )?trauma|心理治疗|心理咨询|创伤恢复|克服创伤)/i.test(evidence);
      }
      if (key === 'control') {
        return /(?:tempt|resist|self-control|lose control|discipline|willpower|诱惑|克制|抵抗|自控|失控|自制|意志)/i.test(evidence);
      }
      if (key === 'seduction') {
        return /(?:seduc|flirt|charm (?:him|her|them)|sexual persu|诱惑|调情|勾引|色诱)/i.test(evidence);
      }
      return true;
    }

    function guardStatChanges(statParts, context) {
      context = context || {};
      var parts = Array.isArray(statParts) ? statParts.slice() : [];
      var minutes = Math.max(0, parseInt(context.timeMinutes, 10) || 0);
      var hasChoiceAction = !!String(context.choiceText || '').trim();
      var isShortChoiceAction = minutes <= 5 && (String(context.source || '') === 'advance' || hasChoiceAction);
      if (!isShortChoiceAction) return { parts: parts, blocked: [] };

      var eventData = context.eventData || {};
      var evidence = [
        context.choiceText,
        eventData.visualAction,
        eventData.visual_action,
        eventData.currentAction,
        eventData.action,
        eventData.eventType,
        eventData.event_type
      ].map(function (value) { return String(value || '').trim(); }).filter(Boolean).join(' | ');
      var allowed = [];
      var blocked = [];
      parts.forEach(function (part) {
        var parsed = parseStatPart(part);
        if (!parsed || !SHORT_ACTION_CAUSAL_STATS[parsed.key] || hasDirectStatCause(parsed.key, parsed.delta, evidence)) {
          allowed.push(part);
          return;
        }
        blocked.push({
          part: parsed.text,
          key: parsed.key === 'fatigue' ? 'tiredness' : parsed.key,
          delta: parsed.delta,
          reason: 'short_action_without_direct_cause',
          timeMinutes: minutes
        });
      });
      return { parts: allowed, blocked: blocked };
    }

    function formatRuntimeItemPlan(items) {
      return (Array.isArray(items) ? items : []).map(function (item) {
        return {
          id: String(item && item.id || ''),
          name: call('normaliseItemName', item && item.name),
          qty: Math.max(1, parseInt(item && item.qty, 10) || 1),
          type: String(item && (item.type || item.category) || call('classifyItem', item || {}))
        };
      }).filter(function (item) { return item.name; });
    }

    function itemNameKey(item) {
      return String(call('normaliseItemName', item && item.name) || '').toLowerCase().replace(/[\s_\-·・'"\u2018\u2019\u201c\u201d]/g, '');
    }

    function suppressSelectedItemsFromGains(itemsGained, selectedUses) {
      var selected = {};
      (Array.isArray(selectedUses) ? selectedUses : []).forEach(function (item) {
        var key = itemNameKey(item);
        if (key) selected[key] = true;
      });
      var kept = [];
      var suppressed = [];
      (Array.isArray(itemsGained) ? itemsGained : []).forEach(function (item) {
        if (selected[itemNameKey(item)]) suppressed.push(item);
        else kept.push(item);
      });
      return { kept: kept, suppressed: suppressed };
    }

    function buildPlan(rawText, cfg, opts) {
      opts = opts || {};
      cfg = cfg || call('loadCfg');
      rawText = String(rawText || '');
      var eventData = call('parseAIEventBlock', rawText);
      var runtimeStats = call('collectRuntimeStatChanges', rawText, eventData, true);
      var itemsGained = call('collectRuntimeItems', rawText, eventData);
      var itemsLost = call('collectRuntimeLostItems', rawText, eventData);
      var selectedUses = clone(optional('getLastItemsUsedForTurn', [], opts));
      var choiceText = optional('getLastChoiceText', '', opts);
      var filteredGains = suppressSelectedItemsFromGains(itemsGained, selectedUses);
      itemsGained = filteredGains.kept;
      var autoConsumed = selectedUses.filter(function (item) {
        return !!optional('isItemConsumableByDefault', false, item) ||
          !!optional('shouldConsumeSelectedItem', false, item, rawText, choiceText, eventData);
      }).map(function (item) {
        return { name: item.name, qty: Math.max(1, parseInt(item.qty, 10) || 1) };
      });
      var relationshipChanges = call('collectNpcRelationshipChanges', rawText, eventData);
      var targetLocation = String(eventData.targetLocation || eventData.target_location || eventData.loc || '').trim();
      var locationStatus = call('normaliseEventStatus', eventData.locationStatus || eventData.location_status || eventData.travelStatus || eventData.arrivalStatus || '') || '';
      var timeMinutes = 0;
      if (opts && opts.source === 'advance') {
        timeMinutes = call('parseTimeFromChoice', choiceText) || 0;
      }
      if (opts && opts.timeCost != null) timeMinutes = Math.max(0, parseInt(opts.timeCost, 10) || 0);
      var statParts = dedupeTextList(runtimeStats.parts || []);
      var guardedStats = guardStatChanges(statParts, {
        source: opts.source,
        timeMinutes: timeMinutes,
        choiceText: choiceText,
        eventData: eventData
      });
      statParts = guardedStats.parts;
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        reason: String(opts.reason || ''),
        source: String(opts.source || ''),
        preflightOnly: false,
        event: {
          schemaVersion: 3,
          summary: String(eventData.summary || '').trim(),
          eventType: String(eventData.eventType || '').trim(),
          physicalLocation: String(eventData.location || '').trim(),
          targetLocation: targetLocation,
          locationStatus: locationStatus,
          sceneFocus: String(eventData.sceneFocus || '').trim(),
          environmentDescription: String(eventData.environmentDescription || '').trim(),
          visualAction: String(eventData.visualAction || '').trim(),
          presentCharacters: parseListField(eventData.presentCharacters || '').slice(0, 10),
          presentEntities: parseListField(eventData.presentEntities || '').slice(0, 10)
        },
        time: {
          minutes: timeMinutes,
          preApplied: timeMinutes > 0 && opts.source === 'advance',
          source: timeMinutes > 0 ? 'choice_time' : ''
        },
        stats: {
          parts: statParts,
          blocked: guardedStats.blocked,
          blockedReason: guardedStats.blocked.length ? 'short_action_without_direct_cause' : '',
          explicitMoneyDelta: runtimeStats.explicitMoneyDelta || 0,
          moneyDelta: findPlannedMoneyDelta(statParts),
          applied: false,
          changed: []
        },
        items: {
          gained: formatRuntimeItemPlan(itemsGained),
          suppressedGained: formatRuntimeItemPlan(filteredGains.suppressed),
          lost: formatRuntimeItemPlan(itemsLost),
          selectedUses: formatRuntimeItemPlan(selectedUses),
          autoConsumed: formatRuntimeItemPlan(autoConsumed),
          pickupQueued: false,
          pickupCandidateId: '',
          consumed: [],
          consumeApplied: false
        },
        relationships: relationshipChanges.map(function (change) {
          return {
            npc: change.npc,
            label: change.label,
            field: change.field,
            delta: change.delta,
            applied: false,
            appliedDelta: 0
          };
        }),
        location: {
          applyRequested: opts.applyLocation !== false,
          targetLocation: targetLocation,
          locationStatus: locationStatus,
          structuredArrival: !!(targetLocation && call('eventIndicatesArrival', eventData)),
          hasDirective: /\[LOC:|\[AI_META\]|\[AI_EVENT\]|\[AI_EVENT:/i.test(rawText),
          applied: false,
          latestStatus: '',
          resolvedPassage: '',
          resolvedLabel: '',
          decision: null,
          decisionReason: '',
          decisionAllowed: false,
          decisionArrived: false,
          failureReason: '',
          fallbackAttempted: false,
          fallbackSuppressed: false,
          fallbackMode: '',
          lastAttempt: null
        },
        memory: {
          recordRequested: opts.recordMemory !== false,
          importance: Math.max(0, Math.min(3, parseInt(eventData.memoryImportance, 10) || 0)),
          tags: parseListField(eventData.memoryTags || '').slice(0, 8),
          applied: false,
          summary: ''
        },
        consistencyDiagnostics: clone(optional('getConsistencyDiagnostics', [], opts)),
        consistencyBlockedEffects: clone(optional('getConsistencyBlockedEffects', [], opts)),
        consistencyBlockedEffectSummary: optional('getConsistencyBlockedEffectSummary', [], opts)
      };
    }

    function getPlanItems(transactionPlan, field) {
      var items = transactionPlan && transactionPlan.items && Array.isArray(transactionPlan.items[field])
        ? transactionPlan.items[field]
        : [];
      return call('filterRuntimeItems', call('mergeItemListByName', items.map(function (item) {
        return {
          id: String(item && item.id || ''),
          name: call('normaliseItemName', item && item.name),
          qty: Math.max(1, parseInt(item && item.qty, 10) || 1),
          type: String(item && (item.type || item.category) || call('classifyItem', item || {}))
        };
      })));
    }

    function getItemsToConsume(transactionPlan, rawText) {
      if (transactionPlan && transactionPlan.items) {
        return call('mergeItemListByName',
          getPlanItems(transactionPlan, 'lost')
            .concat(getPlanItems(transactionPlan, 'autoConsumed'))
        );
      }
      var eventData = call('parseAIEventBlock', rawText);
      var used = call('collectRuntimeLostItems', rawText, eventData);
      var selectedForTurn = clone(optional('getLastItemsUsedForTurn', [], {}));
      var autoConsumed = selectedForTurn.filter(function (item) {
        return !!optional('isItemConsumableByDefault', false, item);
      }).map(function (item) {
        return {
          name: item.name,
          qty: Math.max(1, parseInt(item.qty, 10) || 1)
        };
      });
      return autoConsumed.length ? call('mergeItemListByName', (used || []).concat(autoConsumed)) : used;
    }

    function getPlanStats(transactionPlan, rawText) {
      var planned = transactionPlan && transactionPlan.stats;
      if (planned && Array.isArray(planned.parts)) {
        return {
          parts: planned.parts.slice(),
          explicitMoneyDelta: Number(planned.explicitMoneyDelta || 0)
        };
      }
      return call('collectRuntimeStatChanges', rawText, null, true);
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      buildPlan: buildPlan,
      guardStatChanges: guardStatChanges,
      findPlannedMoneyDelta: findPlannedMoneyDelta,
      formatRuntimeItemPlan: formatRuntimeItemPlan,
      getPlanItems: getPlanItems,
      getItemsToConsume: getItemsToConsume,
      getPlanStats: getPlanStats
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: createTransactionPlanner
  };

  root.TransactionPlannerModule = api;
  window.AIStoryGenTransactionPlannerModule = api;
})();
