/* ============================================================
 * AIStoryGen world context controller
 * Collects compact, authoritative game facts for prompts.
 * This module is read-only; it must not mutate SugarCube state.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 4;

  function asText(value, maxLen) {
    var text = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    if (maxLen && text.length > maxLen) text = text.slice(0, maxLen).trim();
    return text;
  }

  function cloneShallow(obj, keys) {
    var out = {};
    obj = obj || {};
    keys.forEach(function (key) {
      if (obj[key] != null && obj[key] !== '') out[key] = obj[key];
    });
    return out;
  }

  function cloneValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function uniquePush(list, value) {
    value = asText(value);
    if (!value || list.indexOf(value) >= 0) return;
    list.push(value);
  }

  function getLocationGraph(deps) {
    try {
      if (deps && typeof deps.getLocationGraph === 'function') {
        var graph = deps.getLocationGraph();
        if (graph && graph.nodes) return graph;
      }
    } catch (_) {}
    try {
      return root.AIStoryGenLocationGraph && root.AIStoryGenLocationGraph.nodes
        ? root.AIStoryGenLocationGraph
        : null;
    } catch (_) {
      return null;
    }
  }

  function getWorldKnowledge(deps) {
    try {
      if (deps && deps.worldKnowledge && typeof deps.worldKnowledge.retrieve === 'function') {
        return deps.worldKnowledge;
      }
    } catch (_) {}
    try {
      var module = root.AIStoryGenWorldKnowledgeModule || (root.AIStoryGen && root.AIStoryGen.WorldKnowledgeModule);
      if (module && typeof module.create === 'function') return module.create();
      if (module && typeof module.retrieve === 'function') return module;
    } catch (_) {}
    return null;
  }

  function getNpcContextProvider(deps) {
    try {
      if (deps && deps.npcContext && typeof deps.npcContext.build === 'function') {
        return deps.npcContext;
      }
    } catch (_) {}
    try {
      var module = root.AIStoryGenNpcContextModule || (root.AIStoryGen && root.AIStoryGen.NpcContextModule);
      if (module && typeof module.create === 'function') return module.create({
        getKnownNpcNames: deps && deps.getKnownNpcNames
      });
      if (module && typeof module.build === 'function') return module;
    } catch (_) {}
    return null;
  }

  function findGraphNode(graph, raw) {
    raw = asText(raw);
    if (!graph || !graph.nodes || !raw) return null;
    if (graph.nodes[raw]) return graph.nodes[raw];
    var lower = raw.toLowerCase();
    var nodes = graph.nodes;
    for (var key in nodes) {
      if (!Object.prototype.hasOwnProperty.call(nodes, key)) continue;
      var node = nodes[key] || {};
      if (String(node.passage || '').toLowerCase() === lower) return node;
      if (String(node.locId || '').toLowerCase() === lower) return node;
      if (String(node.label || '').toLowerCase() === lower) return node;
      var aliases = Array.isArray(node.aliases) ? node.aliases : [];
      for (var i = 0; i < aliases.length; i++) {
        if (String(aliases[i] || '').toLowerCase() === lower) return node;
      }
    }
    return null;
  }

  function inferClockPhase(scene) {
    scene = scene || {};
    var hour = Number(scene.hour);
    var minute = Number(scene.minute || 0);
    if (!isFinite(hour)) return 'unknown';
    var total = hour * 60 + minute;
    if (total < 360) return 'late_night';
    if (total < 480) return 'early_morning';
    if (total < 720) return 'morning';
    if (total < 1080) return 'afternoon';
    if (total < 1260) return 'evening';
    return 'night';
  }

  function inferSchoolRule(scene, state) {
    scene = scene || {};
    state = state || {};
    var school = state.skills && state.skills.school ? state.skills.school : {};
    var schoolDay = !!scene.schoolDay || !!(state.world && state.world.schoolDay);
    var hour = Number(scene.hour);
    var minute = Number(scene.minute || 0);
    if (!schoolDay) {
      return { applies: false, summary: 'not a school day unless native state says otherwise' };
    }
    if (!isFinite(hour)) {
      return { applies: true, summary: 'school day; exact lesson period unknown' };
    }
    var total = hour * 60 + minute;
    var phase = 'school day';
    var phaseTag = 'school_day';
    if (total < 480) {
      phase = 'before school';
      phaseTag = 'before_school';
    } else if (total < 540) {
      phase = 'arriving before lessons';
      phaseTag = 'arriving_before_lessons';
    } else if (total < 720) {
      phase = 'morning lessons are underway';
      phaseTag = 'morning_lessons';
    } else if (total < 780) {
      phase = 'lunch or midday break';
      phaseTag = 'lunch_break';
    } else if (total < 900) {
      phase = 'afternoon lessons are underway';
      phaseTag = 'afternoon_lessons';
    } else {
      phase = 'after school';
      phaseTag = 'after_school';
    }
    return {
      applies: true,
      summary: phase,
      phase: phaseTag,
      caution: 'do not invent a precise timetable beyond the native clock and visible page text',
      attended: school.attended || null,
      detention: school.detention != null ? school.detention : null
    };
  }

  function readStateTime(state, key) {
    try {
      if (state && state.time && state.time[key] != null) return state.time[key];
      if (state && state.world && state.world[key] != null) return state.world[key];
    } catch (_) {}
    return null;
  }

  function inferBusinessRule(scene, state, facts) {
    scene = scene || {};
    state = state || {};
    facts = facts || {};
    var passage = asText(facts.passage || scene.nativePassage || scene.passageName || scene.passage || '', 120);
    var location = asText(facts.location || scene.physicalLocationPassage || scene.physicalLocationLabel || scene.location || '', 120);
    var area = asText(facts.area || scene.area || '', 80);
    var pageText = asText(facts.pageText || '', 1200);
    var hay = [passage, location, area, pageText].join(' ');
    var hour = Number(scene.hour != null ? scene.hour : readStateTime(state, 'hour'));
    var minute = Number(scene.minute != null ? scene.minute : readStateTime(state, 'minute') || 0);
    var dayState = asText(scene.dayState || readStateTime(state, 'dayState') || '', 40).toLowerCase();

    function result(type, summary, caution, tags) {
      return {
        applies: true,
        type: type,
        source: 'native_time_and_page_text',
        summary: summary,
        caution: caution || 'Do not infer completed purchases, services, work, or item changes from availability text alone.',
        dayState: dayState || '',
        hour: isFinite(hour) ? hour : null,
        minute: isFinite(minute) ? minute : null,
        tags: tags || []
      };
    }

    if (/Adult Shop/i.test(hay) || /\badult_shop\b/i.test(hay)) {
      if (/closed|Opening hours/i.test(pageText) || /Adult Shop (?:Closed|Lock)/i.test(passage)) {
        return result(
          'adult_shop_closed',
          'adult shop is closed or access-limited according to the native page text',
          'The adult shop posted hours are native page facts; do not narrate normal shopping while the page says closed.',
          ['shop', 'closed']
        );
      }
      if (isFinite(hour) && hour === 21 && minute < 10) {
        return result(
          'adult_shop_closing',
          'adult shop is at closing time according to native timing',
          'At closing time, describe staff or security closing the shop rather than normal browsing.',
          ['shop', 'closing']
        );
      }
      if (dayState === 'night') {
        return result(
          'adult_shop_after_hours',
          'adult shop is likely after hours unless the native page explicitly says otherwise',
          'Night state should not be treated as ordinary daytime shopping without visible page support.',
          ['shop', 'night']
        );
      }
      return result(
        'adult_shop_business_page',
        'adult shop page is a business/shop context; visible buttons and prices are availability, not completed events',
        '',
        ['shop', 'business']
      );
    }

    if (/Shopping Centre|shopping_centre|shopping centre/i.test(hay)) {
      if (dayState === 'night') {
        return result(
          'shopping_centre_after_hours',
          'shopping centre is in night state; normal shop service should not be assumed unless visible text supports it',
          'At night, treat shops as closed or restricted unless the native page explicitly presents an open service.',
          ['shopping_centre', 'night']
        );
      }
      if (dayState === 'dusk') {
        return result(
          'shopping_centre_near_closing',
          'shopping centre is still active but nearing closing during dusk',
          'Dusk means shops may still be open but the scene should acknowledge reduced crowds or nearing closing if relevant.',
          ['shopping_centre', 'dusk']
        );
      }
      if (dayState === 'dawn') {
        return result(
          'shopping_centre_opening',
          'shopping centre is opening or not yet busy during dawn',
          'Dawn should not be written as peak shopping crowds unless native text says so.',
          ['shopping_centre', 'dawn']
        );
      }
      return result(
        'shopping_centre_business_page',
        'shopping centre is a public shopping context; buttons and counters are available actions, not completed purchases',
        '',
        ['shopping_centre', 'business']
      );
    }

    if (/Arcade|\barcade\b|街机/i.test(hay)) {
      if (isFinite(hour) && hour === 21) {
        return result(
          'arcade_closing',
          'arcade is at closing time according to native timing',
          'At arcade closing time, do not narrate a long normal play session unless the native page allows staying.',
          ['arcade', 'closing']
        );
      }
      if (dayState === 'night') {
        return result(
          'arcade_silent_after_hours',
          'arcade machines may be silent after hours according to native dayState',
          'Night arcade state should not be described as normal crowded play unless current page text says so.',
          ['arcade', 'night']
        );
      }
      return result(
        'arcade_business_page',
        'arcade is an active public entertainment context when native page/time supports it',
        'Game machines and gambling buttons are available options, not guaranteed completed actions.',
        ['arcade', 'business']
      );
    }

    if (/(?:\bshop\b|\bstore\b|\bmarket\b|Connudatus Markets|cafe|café|pub|bar|museum|hospital|商店|市场|咖啡馆|酒吧|博物馆|医院)/i.test(hay)) {
      return result(
        'public_business_page',
        'current page is a public/business/service context; native page text and visible controls decide availability',
        'Do not turn prices, service lists, work rows, or menu text into completed story events without a clicked action or structured event.',
        ['business', 'ui']
      );
    }

    return {
      applies: false,
      type: '',
      source: '',
      summary: '',
      caution: '',
      dayState: dayState || '',
      hour: isFinite(hour) ? hour : null,
      minute: isFinite(minute) ? minute : null,
      tags: []
    };
  }

  function classifyPage(deps, facts, links) {
    try {
      if (deps && deps.pageClassifier && typeof deps.pageClassifier.classifyPage === 'function') {
        return deps.pageClassifier.classifyPage({
          passageName: facts.passage,
          pageText: facts.pageText || '',
          links: links || [],
          markers: facts.markers || {}
        });
      }
    } catch (_) {}
    return { skip: false, type: 'story', reason: 'default' };
  }

  function classifySpecialEvent(facts, page) {
    facts = facts || {};
    page = page || {};
    var passage = asText(facts.passage || '', 100);
    var location = asText(facts.location || '', 100);
    var area = asText(facts.area || '', 100);
    var text = asText(facts.pageText || '', 1000);
    var hay = [passage, location, area, text].join(' ');
    function event(type, reason, caution, tags) {
      return {
        applies: true,
        type: type,
        reason: reason,
        stableLocation: false,
        caution: caution,
        tags: tags || []
      };
    }
    if (/^gameStartOnly$/i.test(passage) || /^banner$/i.test(location)) {
      return event(
        'startup_widget',
        'new game startup widget, not a player-facing location',
        'Do not treat startup widget or banner variables as current story location or visible scene.',
        ['noise', 'startup']
      );
    }
    if (/Nightmare Office/i.test(passage) || /\bnightmare\b/i.test(hay)) {
      return event(
        'nightmare',
        'nightmare or dream-only passage',
        'Treat this as a dream/nightmare event unless the native page explicitly returns to a stable location.',
        ['dream', 'event']
      );
    }
    if (/tentworld/i.test(location) || /Wraith Snatched|Far Mirror|passes through the mirror/i.test(hay)) {
      return event(
        'wraith_mirror',
        'special mirror/wraith transition space',
        'Treat this as a special transition/event space; do not use it as an ordinary stable map location.',
        ['mirror', 'wraith', 'transition']
      );
    }
    if (/^Underground$/i.test(location) && /Underground Dance/i.test(passage)) {
      return event(
        'single_event_underground_dance',
        'single event-style underground dance passage',
        'Use current page text for the scene, but do not generalize this capitalized Underground id into the normal underground map.',
        ['event', 'underground']
      );
    }
    if (page && page.skip) {
      return {
        applies: false,
        type: '',
        reason: '',
        stableLocation: true,
        caution: '',
        tags: []
      };
    }
    return {
      applies: false,
      type: '',
      reason: '',
      stableLocation: true,
      caution: '',
      tags: []
    };
  }

  function buildVisibleLinks(deps) {
    try {
      if (deps && typeof deps.getVisibleLinks === 'function') {
        var provided = deps.getVisibleLinks();
        if (Array.isArray(provided)) return provided.slice(0, 16);
      }
    } catch (_) {}
    return buildVisibleControls(deps).filter(function (control) {
      return control && control.passage;
    }).slice(0, 16);
  }

  function isIgnoredControlNode(node) {
    try {
      if (!node || !node.closest) return false;
      return !!node.closest([
        '.ai-cfg',
        '.ai-unified-settings',
        '.ai-merged-settings',
        '.ai-narrative-toolbar',
        '.ai-memory-inline',
        '.ai-item-use-panel',
        '.ai-back-to-game',
        '.ai-choices',
        '.ai-choices-end',
        '.ai-pixel-panel',
        '.ai-pixelgen-panel',
        '.apg-panel-wrap',
        '[data-ai-pixel-panel]',
        '#settingsOptions',
        '#settingsDiv',
        '#customOverlayContent'
      ].join(','));
    } catch (_) {
      return false;
    }
  }

  function readControlText(node) {
    try {
      var tag = String(node && node.tagName || '').toLowerCase();
      if (tag === 'input') return asText(node.value || node.getAttribute('value') || '', 80);
      return asText(node.textContent || node.getAttribute('aria-label') || node.getAttribute('title') || '', 80);
    } catch (_) {
      return '';
    }
  }

  function buildVisibleControls(deps) {
    try {
      if (deps && typeof deps.getVisibleControls === 'function') {
        var provided = deps.getVisibleControls();
        if (Array.isArray(provided)) return provided.slice(0, 20);
      }
    } catch (_) {}
    try {
      var out = [];
      var nodes = root.document ? root.document.querySelectorAll([
        '#passages .passage a',
        '#passages .passage button',
        '#passages .passage input[type="button"]',
        '#passages .passage input[type="submit"]',
        '#passages .passage .macro-link',
        '#passages .passage .link-internal'
      ].join(',')) : [];
      var seen = {};
      for (var i = 0; i < nodes.length && out.length < 20; i++) {
        var node = nodes[i];
        if (isIgnoredControlNode(node)) continue;
        var text = readControlText(node);
        var passage = asText(node.getAttribute && node.getAttribute('data-passage'), 80);
        if (!text) continue;
        var type = passage ? 'passage_link' : String(node.tagName || '').toLowerCase() || 'control';
        var key = [type, text, passage].join('|').toLowerCase();
        if (seen[key]) continue;
        seen[key] = 1;
        out.push({ type: type, text: text, passage: passage });
      }
      return out;
    } catch (_) {
      return [];
    }
  }

  function buildMapContext(deps, scene, facts) {
    var graph = getLocationGraph(deps);
    var raw = asText(
      (scene && scene.physicalLocationPassage) ||
      (facts && facts.passage) ||
      (scene && (scene.nativePassage || scene.passageName || scene.passage || scene.location)) ||
      ''
    );
    var node = findGraphNode(graph, raw);
    if (!node && scene && scene.location) node = findGraphNode(graph, scene.location);
    if (!node) return null;
    function labelFor(passage, fallback) {
      try {
        if (deps && typeof deps.resolveLocationLabel === 'function') {
          var label = deps.resolveLocationLabel(passage, fallback);
          if (label) return asText(label, 80);
        }
      } catch (_) {}
      return asText(fallback || passage, 80);
    }
    var exits = [];
    var nodeExits = Array.isArray(node.exits) ? node.exits : [];
    for (var i = 0; i < nodeExits.length && exits.length < 12; i++) {
      var exit = nodeExits[i] || {};
      if (!exit.passage) continue;
      exits.push({
        label: labelFor(exit.passage, exit.label || exit.passage),
        passage: asText(exit.passage, 80),
        via: Array.isArray(exit.via) ? exit.via.slice(0, 3).map(function (v) { return asText(v, 60); }) : []
      });
    }
    return {
      current: {
        label: labelFor(node.passage || raw, node.label || node.passage || raw),
        passage: asText(node.passage || raw, 80),
        locId: asText(node.locId || '', 60),
        parent: asText(node.parent || '', 60),
        inside: !!node.inside
      },
      adjacent: exits
    };
  }

  function buildNpcCanon(state, deps) {
    var rows = [];
    var seen = {};
    function push(key, name, title) {
      key = asText(key, 60);
      name = asText(name, 60);
      title = asText(title, 80);
      if (!key || seen[key]) return;
      seen[key] = true;
      rows.push({ key: key, name: name || key, title: title || name || key });
    }
    var details = state && Array.isArray(state.npcDetails) ? state.npcDetails : [];
    details.forEach(function (npc) {
      push(npc && npc.key, npc && npc.name, npc && npc.title);
    });
    var npcs = state && Array.isArray(state.npcs) ? state.npcs : [];
    npcs.forEach(function (npc) {
      push(npc && npc.key, npc && npc.name, npc && npc.title);
    });
    try {
      if (deps && typeof deps.getKnownNpcNames === 'function') {
        deps.getKnownNpcNames().forEach(function (npc) {
          if (typeof npc === 'string') push(npc, '', '');
          else push(npc && npc.key, npc && npc.name, npc && npc.title);
        });
      }
    } catch (_) {}
    return rows.slice(0, 80);
  }

  function splitNativePageSentences(pageText) {
    pageText = asText(pageText, 1800);
    if (!pageText) return [];
    pageText = pageText
      .replace(/0\.5\.\d+(?:\.\d+)*/g, ' ')
      .replace(/ML-v\d+(?:\.\d+)*/g, ' ')
      .replace(/\[[^\]]{0,12}\]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    var matches = pageText.match(/[^\u3002\uff01\uff1f!?]+[\u3002\uff01\uff1f!?]?/g) || [pageText];
    var out = [];
    var seen = {};
    for (var i = 0; i < matches.length && out.length < 8; i++) {
      var sentence = asText(matches[i], 220);
      if (!sentence || sentence.length < 4) continue;
      if (/^(?:\(\d+\)|\d+[:：]|\d+\s|[\u00a3$])/.test(sentence)) continue;
      if (/(?:ModLoader|AIStoryGen|AIPixel|Settings|Options|\u8bbe\u7f6e|\u5b58\u6863|\u9009\u9879|\u751f\u6210\u63d0\u793a\u8bcd|\u4e00\u952e\u751f\u6210|\u4f7f\u7528\u9053\u5177)/i.test(sentence)) continue;
      var key = sentence.toLowerCase();
      if (seen[key]) continue;
      seen[key] = 1;
      out.push(sentence);
    }
    return out;
  }

  function candidateNameMatches(pageText, value) {
    value = asText(value, 80);
    if (!value) return false;
    if (/[\u4e00-\u9fff]/.test(value)) return pageText.indexOf(value) >= 0;
    if (!/^[A-Za-z][A-Za-z\s'-]{1,60}$/.test(value)) return false;
    var re = new RegExp('(^|[^A-Za-z])' + value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^A-Za-z]|$)', 'i');
    return re.test(pageText);
  }

  function scoreCharacterEvidence(sentence, matchedName, key) {
    sentence = asText(sentence, 220);
    matchedName = asText(matchedName, 80);
    key = asText(key, 80);
    if (!sentence) return -999;
    var hasName = matchedName && sentence.indexOf(matchedName) >= 0;
    var hasKey = key && candidateNameMatches(sentence, key);
    if (!hasName && !hasKey) return -999;
    var score = 1;
    if (/(?:\u6b63\u5728|\u770b\u8d77\u6765|\u8bf4|\u95ee|\u7ad9|\u5750|\u9760|\u8d70|\u62ff|\u64e6|\u7b49|\u6ce8\u89c6|\u671b|\u56de\u5934|\u8f6c\u8eab|\u5fae\u7b11|\u76ef|\u5fd9|\u4f11\u606f|\u7761)/.test(sentence)) score += 4;
    if (/(?:\u65c1|\u9644\u8fd1|\u95e8\u8fb9|\u706b\u7089|\u7089\u8fb9|\u89d2\u843d|\u5c4b\u91cc|\u5ba4\u5185)/.test(sentence)) score += 1;
    if (hasName && new RegExp(matchedName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\u7684(?:\\u5c0f\\u5c4b|\\u623f\\u95f4|\\u5b85\\u90b8|\\u5bb6|\\u5e84\\u56ed|\\u516c\\u5bd3)').test(sentence)) {
      score -= 5;
    }
    return score;
  }

  function buildVisibleFacts(facts, npcCanon) {
    facts = facts || {};
    var pageText = asText(facts.pageText || '', 1800);
    var sentences = splitNativePageSentences(pageText);
    var hardFacts = sentences.slice(0, 6).map(function (sentence) {
      return {
        type: 'native_page_sentence',
        authority: 'hard',
        text: sentence
      };
    });
    var presentCharacters = [];
    var seen = {};
    (npcCanon || []).forEach(function (npc) {
      if (!npc || !npc.key || seen[npc.key]) return;
      var candidates = [npc.name, npc.title, npc.key];
      var matched = '';
      for (var i = 0; i < candidates.length; i++) {
        if (candidateNameMatches(pageText, candidates[i])) {
          matched = asText(candidates[i], 80);
          break;
        }
      }
      if (!matched) return;
      var evidence = '';
      var bestScore = -999;
      for (var si = 0; si < sentences.length; si++) {
        var score = scoreCharacterEvidence(sentences[si], matched, npc.key);
        if (score > bestScore) {
          bestScore = score;
          evidence = sentences[si];
        }
      }
      if (bestScore < 2) return;
      seen[npc.key] = 1;
      presentCharacters.push({
        key: asText(npc.key, 60),
        name: asText(npc.name || npc.title || npc.key, 80),
        evidence: asText(evidence || matched, 180),
        authority: 'native_page_text'
      });
    });
    return {
      authority: 'native_page_text_hard',
      hardFacts: hardFacts,
      presentCharacters: presentCharacters.slice(0, 8)
    };
  }

  function buildRules(cfg, page, school, business, mapContext, visibleFacts, specialEvent, npcContext) {
    cfg = cfg || {};
    var rules = [];
    rules.push('Native game state, current page, time, location, and visible links outrank memory and player supplements.');
    rules.push('Memory is continuity only; it does not prove current character, item, or location presence.');
    if (visibleFacts && visibleFacts.hardFacts && visibleFacts.hardFacts.length) {
      rules.push('visible_facts are hard facts extracted from the current native passage text; do not contradict them, especially character presence, current action, and indoor/outdoor location.');
    }
    if (visibleFacts && visibleFacts.presentCharacters && visibleFacts.presentCharacters.length) {
      rules.push('Characters listed in visible_facts.presentCharacters are currently present; do not narrate them as absent, away, not returned, or only remembered unless the player leaves or the native page changes.');
    }
    if (npcContext && npcContext.present && npcContext.present.length) {
      rules.push('npc_context.present gives current NPC relationship/state hints for visible or native-present NPCs; use those hints for reactions without listing them mechanically.');
    }
    if (npcContext && npcContext.background && npcContext.background.length) {
      rules.push('npc_context.background is not presence. These NPCs are known or context-related only; do not insert them unless current native text or player action brings them in.');
    }
    if (page && page.skip) {
      rules.push('Current page looks like shop/management/settings/settlement UI; do not rewrite buttons, prices, menus, or UI text as story facts.');
    }
    if (specialEvent && specialEvent.applies) {
      rules.push('special_event is authoritative for current-page classification; do not treat it as an ordinary stable location, and do not generalize it into normal map travel.');
      if (specialEvent.caution) rules.push(specialEvent.caution);
    }
    if (school && school.applies) {
      rules.push('School timing follows the native clock; do not invent lesson starts/ends beyond current time and visible page text.');
    }
    if (business && business.applies) {
      rules.push('Business/opening status follows native page text, visible controls, Time.dayState, and the native clock; do not describe closed or closing venues as normal open service.');
      if (business.caution) rules.push(business.caution);
    }
    if (mapContext && mapContext.adjacent && mapContext.adjacent.length) {
      rules.push('For movement, prefer current_map current/adjacent places; distant jumps need explicit transport, abduction, rescue, or special events.');
    }
    rules.push('Use canonical NPC names from npc_canonical_names; do not invent near-translation variants.');
    rules.push('Use retrieved_knowledge only as background; it must not override native state, current page text, visible links, or structured output rules.');
    return rules;
  }

  function collectVisibleMoneyAmounts(facts, visibleControls) {
    var seen = {};
    var out = [];
    function add(value, source) {
      value = asText(value, 40);
      if (!value) return;
      var key = value.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      out.push({ value: value, source: asText(source || 'page', 30) });
    }
    function scan(text, source) {
      text = asText(text || '', 1800);
      if (!text) return;
      var re = /(?:[\u00a3\uffe1]\s*\d[\d,]*(?:\.\d{1,2})?|\b\d[\d,]*(?:\.\d{1,2})?\s*(?:英镑|镑|元|块|便士|pence|p\b))/gi;
      var m;
      while ((m = re.exec(text)) && out.length < 8) {
        add(m[0], source);
      }
    }
    scan(facts && facts.pageText, 'pageText');
    (visibleControls || []).forEach(function (control) {
      scan(control && control.text, 'visibleControl');
    });
    return out;
  }

  function buildRuleFacts(page, school, business, mapContext, visibleFacts, specialEvent, npcContext, facts, visibleControls) {
    var out = [];
    function add(row) {
      row = row || {};
      if (!row.id || !row.summary) return;
      out.push({
        id: asText(row.id, 80),
        category: asText(row.category || '', 40),
        authority: asText(row.authority || 'native_state', 40),
        summary: asText(row.summary, 220),
        caution: asText(row.caution || '', 220),
        source: asText(row.source || '', 80),
        tags: Array.isArray(row.tags) ? row.tags.slice(0, 8).map(function (tag) { return asText(tag, 40); }).filter(Boolean) : []
      });
    }
    if (school && school.applies) {
      add({
        id: 'school_time_rule',
        category: 'time',
        authority: 'native_clock',
        summary: 'School timing: ' + school.summary,
        caution: school.caution || 'Do not invent lesson starts or ends beyond native time and visible page text.',
        source: 'timeRules.school',
        tags: ['school', 'time', school.phase || 'school_day']
      });
    }
    if (business && business.applies) {
      add({
        id: 'business_opening_rule',
        category: 'time',
        authority: 'native_page_and_clock',
        summary: business.summary,
        caution: business.caution || 'Do not convert prices, menus, or available services into completed events without a clicked action.',
        source: 'timeRules.business',
        tags: business.tags || ['business']
      });
    }
    add({
      id: 'money_unit_rule',
      category: 'economy',
      authority: 'native_money_unit',
      summary: 'DoL stores money internally as pence; player-facing \u00a32000.00 equals moneyChange 200000.',
      caution: 'When prose uses a decimal money amount, AI_EVENT moneyChange must use the matching signed pence amount; do not print raw pence as player-facing currency.',
      source: 'runtime.money',
      tags: ['money', 'pence', 'currency']
    });
    var visibleMoney = collectVisibleMoneyAmounts(facts, visibleControls);
    if (visibleMoney.length) {
      add({
        id: 'visible_money_amount_rule',
        category: 'economy',
        authority: 'native_page_text',
        summary: 'Visible page/control money amounts: ' + visibleMoney.map(function (row) { return row.value; }).slice(0, 6).join(', '),
        caution: 'Visible prices, rent, fees, rewards, and balances are facts or available actions only; do not apply moneyChange unless the player action actually completes payment or receipt.',
        source: 'visibleMoneyAmounts',
        tags: ['money', 'price', 'visible']
      });
    }
    if (page && page.skip) {
      add({
        id: 'ui_page_no_story_effect_rule',
        category: 'page',
        authority: 'native_dom_classifier',
        summary: 'Current page is classified as ' + (page.type || 'ui') + '; visible rows/buttons are interface, not completed story events.',
        caution: 'Do not apply money, item, NPC relationship, or location changes from UI text alone.',
        source: 'page.skip',
        tags: ['ui', page.type || 'page']
      });
    }
    if (specialEvent && specialEvent.applies) {
      add({
        id: 'special_event_rule',
        category: 'event',
        authority: 'native_page_classifier',
        summary: specialEvent.summary || specialEvent.type || 'Current page is a special native event.',
        caution: specialEvent.caution || 'Do not generalize this event page into normal free map travel.',
        source: 'specialEvent',
        tags: ['special_event', specialEvent.type || 'event']
      });
    }
    if (visibleFacts && visibleFacts.presentCharacters && visibleFacts.presentCharacters.length) {
      add({
        id: 'visible_npc_presence_rule',
        category: 'npc',
        authority: 'native_page_text',
        summary: 'Currently visible NPCs: ' + visibleFacts.presentCharacters.map(function (npc) { return npc.name || npc.key; }).join(', '),
        caution: 'Do not narrate these NPCs as absent unless the player leaves or native page changes.',
        source: 'visibleFacts.presentCharacters',
        tags: ['npc', 'presence']
      });
    }
    if (npcContext && npcContext.present && npcContext.present.some(function (npc) { return npc && npc.reactionHints && npc.reactionHints.length; })) {
      add({
        id: 'npc_state_reaction_rule',
        category: 'npc',
        authority: 'native_state',
        summary: 'Current present NPCs include relationship/state reaction hints: ' + npcContext.present.filter(function (npc) {
          return npc && npc.reactionHints && npc.reactionHints.length;
        }).map(function (npc) {
          return (npc.name || npc.key) + '(' + npc.reactionHints.map(function (hint) { return hint.type + ':' + hint.level; }).slice(0, 4).join(',') + ')';
        }).slice(0, 4).join('; '),
        caution: 'Use these hints to shape NPC tone and choices naturally; do not print numeric stat keys or treat background NPCs as present.',
        source: 'npcContext.present.reactionHints',
        tags: ['npc', 'relationship', 'reaction']
      });
    }
    if (npcContext && npcContext.background && npcContext.background.length) {
      add({
        id: 'npc_background_not_presence_rule',
        category: 'npc',
        authority: 'derived_context',
        summary: 'Some NPCs are only background/context-related, not physically present.',
        caution: 'Do not insert background NPCs into the scene without current native evidence or player action.',
        source: 'npcContext.background',
        tags: ['npc', 'background']
      });
    }
    if (mapContext && mapContext.current && mapContext.adjacent && mapContext.adjacent.length) {
      add({
        id: 'map_adjacency_rule',
        category: 'location',
        authority: 'native_location_graph',
        summary: 'Current map is ' + (mapContext.current.label || mapContext.current.passage || 'current') + '; adjacent destinations are preferred for movement.',
        caution: 'Distant jumps need explicit transport, abduction, rescue, or special event support.',
        source: 'currentMap',
        tags: ['location', 'movement']
      });
    }
    return out.slice(0, 16);
  }

  function buildRetrievedKnowledge(deps, context, input) {
    try {
      var knowledge = getWorldKnowledge(deps);
      if (!knowledge || typeof knowledge.retrieve !== 'function') return null;
      return knowledge.retrieve({
        context: context,
        state: input && input.state,
        scene: input && input.scene,
        pageText: input && input.pageText,
        cfg: input && input.cfg
      });
    } catch (_) {
      return null;
    }
  }

  function compactPromptMap(map) {
    if (!map || !map.current) return null;
    return {
      current: cloneShallow(map.current, ['label', 'passage', 'locId', 'parent', 'inside']),
      adjacent: (map.adjacent || []).slice(0, 8).map(function (row) {
        return {
          label: asText(row && row.label, 80),
          passage: asText(row && row.passage, 80),
          via: Array.isArray(row && row.via) ? row.via.slice(0, 2).map(function (value) { return asText(value, 60); }) : []
        };
      })
    };
  }

  function compactPromptNpc(row) {
    row = row || {};
    var out = cloneShallow(row, ['key', 'name', 'title', 'present', 'presenceSource', 'evidence', 'gender', 'state']);
    if (Array.isArray(row.relationshipHints)) {
      out.relationshipHints = row.relationshipHints.slice(0, 5).map(function (hint) {
        return cloneShallow(hint || {}, ['field', 'level']);
      });
    }
    if (Array.isArray(row.reactionHints)) {
      out.reactionHints = row.reactionHints.slice(0, 5).map(function (hint) {
        return cloneShallow(hint || {}, ['type', 'level', 'summary', 'caution']);
      });
    }
    Object.keys(out).forEach(function (key) {
      if (out[key] == null || out[key] === '' || (Array.isArray(out[key]) && !out[key].length)) delete out[key];
    });
    return out;
  }

  function compactKnowledgeRows(rows, maxRows) {
    return (rows || []).slice(0, maxRows).map(function (row) {
      row = row || {};
      var out = cloneShallow(row, ['id', 'label', 'key', 'canonicalName']);
      if (Array.isArray(row.facts)) out.facts = row.facts.slice(0, 3).map(function (value) { return asText(value, 240); });
      if (Array.isArray(row.cautions)) out.cautions = row.cautions.slice(0, 2).map(function (value) { return asText(value, 240); });
      return out;
    });
  }

  function compactReleaseLocation(row) {
    if (!row) return null;
    return {
      locId: asText(row.locId || '', 80),
      suggestedPassage: asText(row.suggestedPassage || '', 100),
      exits: (row.exits || []).slice(0, 4).map(function (exit) {
        return { label: asText(exit && exit.label, 60), target: asText(exit && exit.target, 100) };
      })
    };
  }

  function compactPromptKnowledge(knowledge, presentKeys) {
    if (!knowledge) return null;
    presentKeys = presentKeys || {};
    var out = {
      policy: 'supplement_only_native_state_wins',
      locations: compactKnowledgeRows(knowledge.locations, 2),
      sublocations: compactKnowledgeRows(knowledge.sublocations, 2),
      npcs: compactKnowledgeRows((knowledge.npcs || []).filter(function (row) { return row && presentKeys[row.key]; }), 4),
      routine: compactKnowledgeRows(knowledge.routine, 2),
      time: (knowledge.time || []).slice(0, 4).map(function (value) { return asText(value, 240); }),
      cautions: (knowledge.cautions || []).slice(0, 8).map(function (value) { return asText(value, 240); })
    };
    var release = knowledge.releaseSummary;
    if (release) {
      out.releaseSummary = {
        currentLocation: compactReleaseLocation(release.currentLocation),
        adjacentLocations: (release.adjacentLocations || []).slice(0, 4).map(compactReleaseLocation),
        sublocations: (release.sublocations || []).slice(0, 3).map(function (row) {
          return { id: asText(row && row.id, 80), passages: (row && row.passages || []).slice(0, 4).map(function (value) { return asText(value, 100); }) };
        }),
        npcs: (release.npcs || []).filter(function (row) { return row && presentKeys[row.key]; }).slice(0, 4).map(function (row) {
          return cloneShallow(row, ['key', 'zh']);
        })
      };
    }
    Object.keys(out).forEach(function (key) {
      if (out[key] == null || (Array.isArray(out[key]) && !out[key].length)) delete out[key];
    });
    return out;
  }

  function buildPromptView(context) {
    context = context || {};
    var npcContext = context.npcContext || {};
    var present = (npcContext.present || []).slice(0, 6).map(compactPromptNpc);
    var presentKeys = {};
    present.forEach(function (row) { if (row.key) presentKeys[row.key] = true; });
    ((context.visibleFacts && context.visibleFacts.presentCharacters) || []).forEach(function (row) {
      if (row && row.key) presentKeys[row.key] = true;
    });
    var aliases = (context.npcCanonicalNames || []).filter(function (row) {
      return row && presentKeys[row.key];
    }).slice(0, 8).map(function (row) {
      return cloneShallow(row, ['key', 'name', 'title']);
    });
    var out = {
      schemaVersion: MODULE_SCHEMA_VERSION,
      authority: 'native_current_scene_prompt_view',
      facts: cloneShallow(context.facts || {}, ['passage', 'location', 'gameLocation', 'physicalLocationLabel', 'physicalLocationSource', 'environmentDescription', 'environmentDescriptionSource', 'sceneFocus', 'sceneFocusSource', 'visualAction', 'visualActionSource', 'sceneEventMatched', 'sceneEventMatchSource', 'continuityCharacters', 'continuityEntities', 'continuityPresenceSource', 'locationStatus', 'area', 'day', 'weekday', 'hour', 'minute', 'dayState', 'clockPhase', 'dangerLevel', 'nativeNearby', 'nativeNearbySource', 'nearby']),
      page: cloneValue(context.page || {}),
      timeRules: cloneValue(context.timeRules || {}),
      currentMap: compactPromptMap(context.currentMap),
      visibleLinks: (context.visibleLinks || []).slice(0, 10),
      visibleControls: (context.visibleControls || []).slice(0, 10),
      specialEvent: cloneValue(context.specialEvent || {}),
      visibleFacts: cloneValue(context.visibleFacts || {}),
      npcCanonicalNames: aliases,
      npcContext: {
        authority: 'current_presence_only',
        present: present,
        nearbyGeneric: (npcContext.nearbyGeneric || []).slice(0, 6),
        rules: [
          'Only npcContext.present and visibleFacts.presentCharacters prove named NPC presence.',
          'Background NPC records are intentionally omitted from the prompt and must not be introduced as present.'
        ]
      },
      ruleFacts: (context.ruleFacts || []).slice(0, 12),
      rules: (context.rules || []).filter(function (rule) {
        return String(rule || '').indexOf('npc_context.background') < 0;
      }).slice(0, 10),
      retrievedKnowledge: compactPromptKnowledge(context.retrievedKnowledge, presentKeys)
    };
    Object.keys(out).forEach(function (key) {
      if (out[key] == null || (Array.isArray(out[key]) && !out[key].length)) delete out[key];
    });
    return out;
  }

  function create(deps) {
    deps = deps || {};

    function build(input) {
      input = input || {};
      var state = input.state || {};
      var scene = input.scene || {};
      var cfg = input.cfg || {};
      var facts = {
        passage: asText(input.passage || scene.nativePassage || scene.passageName || (state.world && state.world.passage) || '', 90),
        location: asText(scene.physicalLocationPassage || scene.physicalLocationLabel || scene.location || (state.world && state.world.location) || '', 90),
        gameLocation: asText(scene.gameLocation || scene.location || (state.world && state.world.location) || '', 90),
        physicalLocationLabel: asText(scene.physicalLocationLabel || '', 90),
        physicalLocationSource: asText(scene.physicalLocationSource || '', 40),
        environmentDescription: asText(scene.environmentDescription || '', 220),
        environmentDescriptionSource: asText(scene.environmentDescriptionSource || '', 40),
        sceneFocus: asText(scene.sceneFocus || '', 90),
        sceneFocusSource: asText(scene.sceneFocusSource || '', 40),
        visualAction: asText(scene.visualAction || '', 180),
        visualActionSource: asText(scene.visualActionSource || '', 40),
        sceneEventMatched: scene.sceneEventMatched === true,
        sceneEventMatchSource: asText(scene.sceneEventMatchSource || '', 40),
        locationStatus: asText(scene.locationStatus || 'current', 30),
        continuityCharacters: Array.isArray(scene.continuityCharacters) ? scene.continuityCharacters.slice(0, 8).map(function (name) { return asText(name, 60); }).filter(Boolean) : [],
        continuityEntities: Array.isArray(scene.continuityEntities) ? scene.continuityEntities.slice(0, 8).map(function (name) { return asText(name, 60); }).filter(Boolean) : [],
        continuityPresenceSource: asText(scene.continuityPresenceSource || '', 40),
        area: asText(scene.area || (state.world && state.world.area) || '', 80),
        day: scene.day != null ? scene.day : (state.world && state.world.day),
        weekday: scene.weekday != null ? scene.weekday : (state.world && state.world.weekday),
        hour: scene.hour != null ? scene.hour : readStateTime(state, 'hour'),
        minute: scene.minute != null ? scene.minute : readStateTime(state, 'minute'),
        dayState: asText(scene.dayState || readStateTime(state, 'dayState') || '', 40),
        clockPhase: inferClockPhase({
          hour: scene.hour != null ? scene.hour : readStateTime(state, 'hour'),
          minute: scene.minute != null ? scene.minute : readStateTime(state, 'minute')
        }),
        dangerLevel: asText(scene.dangerLevel || '', 40),
        nativeNearby: asText(scene.nativeNearby || '', 200),
        nativeNearbySource: asText(scene.nativeNearbySource || '', 40),
        nearby: asText(scene.nearby || '', 200),
        pageText: asText(input.pageText || '', 1800),
        markers: input.markers || {}
      };
      var visibleLinks = buildVisibleLinks(deps);
      var visibleControls = buildVisibleControls(deps);
      var page = classifyPage(deps, facts, visibleLinks);
      var specialEvent = classifySpecialEvent(facts, page);
      var school = inferSchoolRule(scene, state);
      var business = inferBusinessRule(scene, state, facts);
      var mapContext = buildMapContext(deps, scene, facts);
      var npcCanon = buildNpcCanon(state, deps);
      var visibleFacts = buildVisibleFacts(facts, npcCanon);
      var context = {
        schemaVersion: MODULE_SCHEMA_VERSION,
        facts: cloneShallow(facts, ['passage', 'location', 'gameLocation', 'physicalLocationLabel', 'physicalLocationSource', 'environmentDescription', 'environmentDescriptionSource', 'sceneFocus', 'sceneFocusSource', 'visualAction', 'visualActionSource', 'sceneEventMatched', 'sceneEventMatchSource', 'continuityCharacters', 'continuityEntities', 'continuityPresenceSource', 'locationStatus', 'area', 'day', 'weekday', 'hour', 'minute', 'dayState', 'clockPhase', 'dangerLevel', 'nativeNearby', 'nativeNearbySource', 'nearby']),
        page: page,
        timeRules: {
          school: school,
          business: business
        },
        currentMap: mapContext,
        visibleLinks: visibleLinks.slice(0, 12).map(function (link) {
          return {
            text: asText(link.text || link.linkText, 80),
            passage: asText(link.passage || link.targetPassage, 80)
          };
        }),
        visibleControls: visibleControls.slice(0, 16).map(function (control) {
          return {
            type: asText(control.type || '', 40),
            text: asText(control.text || control.linkText || '', 80),
            passage: asText(control.passage || control.targetPassage || '', 80)
          };
        }),
        specialEvent: specialEvent,
        visibleFacts: visibleFacts,
        npcCanonicalNames: npcCanon,
        rules: []
      };
      var npcProvider = getNpcContextProvider(deps);
      if (npcProvider && typeof npcProvider.build === 'function') {
        try {
          context.npcContext = npcProvider.build({
            state: state,
            scene: scene,
            cfg: cfg,
            pageText: facts.pageText,
            worldContext: context
          });
        } catch (_) {}
      }
      context.ruleFacts = buildRuleFacts(page, school, business, mapContext, visibleFacts, specialEvent, context.npcContext, facts, visibleControls);
      context.rules = buildRules(cfg, page, school, business, mapContext, visibleFacts, specialEvent, context.npcContext);
      var retrievedKnowledge = buildRetrievedKnowledge(deps, context, input);
      if (retrievedKnowledge) context.retrievedKnowledge = retrievedKnowledge;
      return context;
    }

    function formatPromptBlock(input) {
      var context = build(input);
      return [
        '<world_context schema="' + MODULE_SCHEMA_VERSION + '">',
        JSON.stringify(buildPromptView(context), null, 2),
        '</world_context>'
      ].join('\n');
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      moduleSchemaVersion: MODULE_SCHEMA_VERSION,
      build: build,
      buildPromptView: buildPromptView,
      formatPromptBlock: formatPromptBlock
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    buildPromptView: buildPromptView,
    create: create
  };

  root.AIStoryGen.WorldContextModule = api;
  root.AIStoryGenWorldContextModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
