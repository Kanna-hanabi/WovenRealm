/* ============================================================
 * AIStoryGen config schema helper
 * Owns config field filtering, tab grouping, and field coercion rules.
 * Field definitions can remain injected by the caller.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;

  function isAddonOwnedAdultConfigField(field) {
    if (!field || field.section) return false;
    return {
      aiSexModeEnabled: true,
      sexModeEngine: true,
      sexModeTriggerMode: true,
      aiIntimateDynamicActions: true
    }[field.k] === true;
  }

  function isHiddenAdultConfigField(field, opts) {
    opts = opts || {};
    if (!field || field.section) return false;
    if (isAddonOwnedAdultConfigField(field)) return true;
    if (opts.adultContentUnlocked) return false;
    return {
      enableCombat: true,
      combatPromptTemplate: true,
      combatPostProcessPattern: true,
      combatPostProcessReplacement: true
    }[field.k] === true;
  }

  function configFieldTab(field) {
    if (!field || field.section) return '';
    return field.tab || 'story';
  }

  function getConfigSchema(fields) {
    return (Array.isArray(fields) ? fields : []).filter(function (field) {
      return !isAddonOwnedAdultConfigField(field);
    });
  }

  function fieldsForTab(fields, tab, opts) {
    tab = tab || 'story';
    opts = opts || {};
    var out = [];
    var pendingSection = null;
    (Array.isArray(fields) ? fields : []).forEach(function (field) {
      if (field.section) {
        pendingSection = field.section;
        return;
      }
      if (configFieldTab(field) !== tab) return;
      if (isHiddenAdultConfigField(field, opts)) return;
      if (pendingSection) {
        out.push({ section: pendingSection });
        pendingSection = null;
      }
      out.push(field);
    });
    return out;
  }

  function defaultConfigValue(field, cfg, defaults) {
    if (!field || field.section) return '';
    if (cfg && cfg[field.k] != null) return cfg[field.k];
    if (defaults && defaults[field.k] != null) return defaults[field.k];
    return '';
  }

  function coerceFieldValue(field, input) {
    if (!field || field.section) return undefined;
    if (field.type === 'bool') {
      if (input && input.prop) return input.prop('checked') ? 1 : 0;
      return Number(input || 0) ? 1 : 0;
    }
    var value = input && input.val ? input.val() : input;
    if (field.type === 'select') {
      var numeric = Number(value);
      return Number.isNaN(numeric) ? value : numeric;
    }
    if (field.type === 'number' || field.type === 'range') return Number(value);
    return value == null ? '' : value;
  }

  function create(deps) {
    deps = deps || {};

    function getFields() {
      try {
        return typeof deps.getFields === 'function' ? (deps.getFields() || []) : (deps.fields || []);
      } catch (_) {
        return [];
      }
    }

    function isAdultUnlocked() {
      try {
        return typeof deps.isAdultContentUnlocked === 'function' ? !!deps.isAdultContentUnlocked() : !!deps.adultContentUnlocked;
      } catch (_) {
        return false;
      }
    }

    function defaults() {
      try {
        return typeof deps.getDefaults === 'function' ? (deps.getDefaults() || {}) : (deps.defaults || {});
      } catch (_) {
        return {};
      }
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      isAddonOwnedAdultConfigField: isAddonOwnedAdultConfigField,
      isHiddenAdultConfigField: function (field) {
        return isHiddenAdultConfigField(field, { adultContentUnlocked: isAdultUnlocked() });
      },
      configFieldTab: configFieldTab,
      getConfigSchema: function () {
        return getConfigSchema(getFields());
      },
      fieldsForTab: function (tab) {
        return fieldsForTab(getFields(), tab, { adultContentUnlocked: isAdultUnlocked() });
      },
      defaultConfigValue: function (field, cfg) {
        return defaultConfigValue(field, cfg, defaults());
      },
      coerceFieldValue: coerceFieldValue
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    isAddonOwnedAdultConfigField: isAddonOwnedAdultConfigField,
    isHiddenAdultConfigField: isHiddenAdultConfigField,
    configFieldTab: configFieldTab,
    getConfigSchema: getConfigSchema,
    fieldsForTab: fieldsForTab,
    defaultConfigValue: defaultConfigValue,
    coerceFieldValue: coerceFieldValue,
    create: create
  };

  root.AIStoryGen.ConfigSchemaModule = api;
  root.AIStoryGenConfigSchemaModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
