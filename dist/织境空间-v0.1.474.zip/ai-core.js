/* ============================================================
 * AIStoryGen core helpers
 * Shared config, error, network, and safe-read utilities.
 * ============================================================ */
(function () {
  'use strict';

  var root = window.AIStoryGen = window.AIStoryGen || {};

  var DEFAULT_LONG_TERM_REFINE_PROMPT = [
    '你是游戏剧情长期记忆整理器。请把下面内容压缩成可用的剧情索引，不要保留完整叙事原文。',
    '必须保留：当前AI剧情状态、重要地点与路线顺序、人物关系变化、剧情线索或剧情物品、未完成目标。',
    '剧情物品指的是对后续剧情有意义的线索物，例如原石、旧笔记、地图、名片、特殊硬币；不要把普通库存清单和数量当成记忆重点。',
    '必须删除：原版状态数据、玩家属性、技能、性癖、穿着、金钱数值、普通道具库存数量、房租任务、自由任务、资源状态、版本号、菜单文字、房间静态描写、重复句、心理铺陈和普通动作过程。',
    '如果原文包含AI剧情事件，不要回答「没有可保留的关键数据」；至少保留一条可用剧情索引。',
    '输出中文，只能使用以下五类格式；每类最多 6 条，每条不超过 80 字，只写事实变化：',
    '### 当前剧情状态 / 精炼',
    '- ...',
    '### 地点与路线 / 精炼',
    '- ...',
    '### 人物关系变化 / 精炼',
    '- ...',
    '### 线索与剧情物品 / 精炼',
    '- ...',
    '### 未完成目标 / 精炼',
    '- ...',
    '',
    '{{memory}}'
  ].join('\n');

  var DEFAULT_CFG = {
    apiKey: '',
    uiLayoutMode: 'auto',
    aiPixelEnabled: 0,
    aiSexModeEnabled: 0,
    sexModeEngine: 'ask',
    aiIntimateDynamicActions: 0,
    apiProvider: 'deepseek',
    endpoint: 'https://api.deepseek.com/v1/chat/completions',
    model: 'deepseek-v4-flash',
    highQualityMode: 1,
    highQualityEndpoint: 'https://api.deepseek.com/v1/chat/completions',
    highQualityModel: 'deepseek-v4-pro',
    temperature: 0.9,
    max_tokens: 400,
    jailbreak: '',
    tier: 2,
    language: 'zh',
    recentMax: 3,
    recentLimit: 600,
    choiceTriggerMode: 'auto',
    autoChoices: 1,
    aiChoiceMode: 1,
    aiReplaceLinks: 1,
    postProcessPattern: '',
    postProcessReplacement: '',
    showChangeSummary: 0,
    statChangeLimit: 50,
    statChangeLimitPain: 50,
    statChangeLimitArousal: 3000,
    statChangeLimitTiredness: 1000,
    statChangeLimitStress: 3000,
    statChangeLimitTrauma: 1000,
    statChangeLimitControl: 50,
    statChangeLimitSeduction: 50,
    npcRelationChangeChance: 35,
    npcRelationChangeLimit: 2,
    npcRelationChangeLimitLove: 2,
    npcRelationChangeLimitTrust: 2,
    npcRelationChangeLimitLust: 2,
    npcRelationChangeLimitRage: 2,
    npcRelationChangeLimitDom: 2,
    enableCombat: 1,
    combatMaxTokens: 1000,
    combatTemperature: 0.8,
    combatWindowTurns: 3,
    combatPostProcessPattern: '',
    combatPostProcessReplacement: '',
    combatIncludeOriginal: 0,
    combatPromptTemplate: '',
    cacheEnabled: 1,
    cacheTTLMinutes: 5,
    summarizeTrigger: 3,
    longTermCompressTrigger: 5,
    systemPromptExtra: '',
    longTermRefinePrompt: DEFAULT_LONG_TERM_REFINE_PROMPT,
    storyStylePreset: 'none',
    storyStylePrompt: '',
    longTermMax: 120,
    playerStoryProfile: '',
    sexModeTriggerMode: 1,
    barefootBuffEnabled: 0,
    barefootBuffRugged: 1,
    barefootBuffSwim: 0,
    extraLongHairStyle: 'off',
  };

  function normalizeCfg(cfg) {
    cfg = cfg || {};
    if (!cfg.model || cfg.model === 'deepseek-chat') cfg.model = DEFAULT_CFG.model;
    if (!/^(custom|deepseek|siliconflow|openrouter|gemini|local)$/.test(String(cfg.apiProvider || ''))) cfg.apiProvider = DEFAULT_CFG.apiProvider;
    if (cfg.highQualityMode == null) cfg.highQualityMode = DEFAULT_CFG.highQualityMode;
    if (!cfg.highQualityEndpoint) cfg.highQualityEndpoint = DEFAULT_CFG.highQualityEndpoint;
    if (!cfg.highQualityModel || cfg.highQualityModel === 'deepseek-chat') cfg.highQualityModel = DEFAULT_CFG.highQualityModel;
    if (cfg.aiPixelEnabled == null) cfg.aiPixelEnabled = DEFAULT_CFG.aiPixelEnabled;
    if (!/^(auto|mobile|tablet|desktop)$/.test(String(cfg.uiLayoutMode || 'auto'))) cfg.uiLayoutMode = DEFAULT_CFG.uiLayoutMode;
    if (cfg.aiSexModeEnabled == null) cfg.aiSexModeEnabled = DEFAULT_CFG.aiSexModeEnabled;
    if (!cfg.sexModeEngine) cfg.sexModeEngine = DEFAULT_CFG.sexModeEngine;
    if (!/^(ai|native|both|ask)$/.test(String(cfg.sexModeEngine || '').toLowerCase())) cfg.sexModeEngine = DEFAULT_CFG.sexModeEngine;
    if (cfg.aiIntimateDynamicActions == null) cfg.aiIntimateDynamicActions = DEFAULT_CFG.aiIntimateDynamicActions;
    if (cfg.longTermMax == null) cfg.longTermMax = DEFAULT_CFG.longTermMax;
    if (cfg.playerStoryProfile == null) cfg.playerStoryProfile = DEFAULT_CFG.playerStoryProfile;
    if (cfg.sexModeTriggerMode == null) cfg.sexModeTriggerMode = DEFAULT_CFG.sexModeTriggerMode;
    cfg.barefootBuffEnabled = Number(cfg.barefootBuffEnabled == null ? DEFAULT_CFG.barefootBuffEnabled : cfg.barefootBuffEnabled) ? 1 : 0;
    cfg.barefootBuffRugged = Number(cfg.barefootBuffRugged == null ? DEFAULT_CFG.barefootBuffRugged : cfg.barefootBuffRugged) ? 1 : 0;
    cfg.barefootBuffSwim = Number(cfg.barefootBuffSwim == null ? DEFAULT_CFG.barefootBuffSwim : cfg.barefootBuffSwim) ? 1 : 0;
    cfg.extraLongHairStyle = String(cfg.extraLongHairStyle == null ? DEFAULT_CFG.extraLongHairStyle : cfg.extraLongHairStyle).trim().toLowerCase();
    if (!/^(off|pooled|trailing|cascade|serpentine|fan|endless)$/.test(cfg.extraLongHairStyle)) cfg.extraLongHairStyle = DEFAULT_CFG.extraLongHairStyle;
    if (cfg.longTermRefinePrompt == null) cfg.longTermRefinePrompt = DEFAULT_CFG.longTermRefinePrompt;
    if (cfg.storyStylePrompt == null) cfg.storyStylePrompt = '';
    if (!/^(none|custom|minimal|epic|cult)$/.test(String(cfg.storyStylePreset || 'none'))) cfg.storyStylePreset = DEFAULT_CFG.storyStylePreset;
    cfg.recentMax = Math.max(0, Math.min(20, Number(cfg.recentMax == null ? DEFAULT_CFG.recentMax : cfg.recentMax) || 0));
    cfg.recentLimit = Math.max(200, Math.min(900, Number(cfg.recentLimit == null ? DEFAULT_CFG.recentLimit : cfg.recentLimit) || DEFAULT_CFG.recentLimit));
    cfg.summarizeTrigger = Math.max(0, Math.min(30, Number(cfg.summarizeTrigger == null ? DEFAULT_CFG.summarizeTrigger : cfg.summarizeTrigger) || 0));
    if (cfg.recentMax > 0 && cfg.summarizeTrigger > cfg.recentMax) cfg.summarizeTrigger = cfg.recentMax;
    cfg.longTermMax = Math.max(0, Math.min(300, Number(cfg.longTermMax == null ? DEFAULT_CFG.longTermMax : cfg.longTermMax) || 0));
    cfg.statChangeLimit = Math.max(0, Math.min(5000, Number(cfg.statChangeLimit == null ? DEFAULT_CFG.statChangeLimit : cfg.statChangeLimit) || 0));
    cfg.statChangeLimitPain = Math.max(0, Math.min(200, Number(cfg.statChangeLimitPain == null ? DEFAULT_CFG.statChangeLimitPain : cfg.statChangeLimitPain) || 0));
    cfg.statChangeLimitArousal = Math.max(0, Math.min(5000, Number(cfg.statChangeLimitArousal == null ? DEFAULT_CFG.statChangeLimitArousal : cfg.statChangeLimitArousal) || 0));
    cfg.statChangeLimitTiredness = Math.max(0, Math.min(2000, Number(cfg.statChangeLimitTiredness == null ? DEFAULT_CFG.statChangeLimitTiredness : cfg.statChangeLimitTiredness) || 0));
    cfg.statChangeLimitStress = Math.max(0, Math.min(5000, Number(cfg.statChangeLimitStress == null ? DEFAULT_CFG.statChangeLimitStress : cfg.statChangeLimitStress) || 0));
    cfg.statChangeLimitTrauma = Math.max(0, Math.min(2000, Number(cfg.statChangeLimitTrauma == null ? DEFAULT_CFG.statChangeLimitTrauma : cfg.statChangeLimitTrauma) || 0));
    cfg.statChangeLimitControl = Math.max(0, Math.min(200, Number(cfg.statChangeLimitControl == null ? DEFAULT_CFG.statChangeLimitControl : cfg.statChangeLimitControl) || 0));
    cfg.statChangeLimitSeduction = Math.max(0, Math.min(200, Number(cfg.statChangeLimitSeduction == null ? DEFAULT_CFG.statChangeLimitSeduction : cfg.statChangeLimitSeduction) || 0));
    cfg.npcRelationChangeChance = Math.max(0, Math.min(100, Number(cfg.npcRelationChangeChance == null ? DEFAULT_CFG.npcRelationChangeChance : cfg.npcRelationChangeChance) || 0));
    cfg.npcRelationChangeLimit = Math.max(0, Math.min(10, Number(cfg.npcRelationChangeLimit == null ? DEFAULT_CFG.npcRelationChangeLimit : cfg.npcRelationChangeLimit) || 0));
    cfg.npcRelationChangeLimitLove = Math.max(0, Math.min(10, Number(cfg.npcRelationChangeLimitLove == null ? DEFAULT_CFG.npcRelationChangeLimitLove : cfg.npcRelationChangeLimitLove) || 0));
    cfg.npcRelationChangeLimitTrust = Math.max(0, Math.min(10, Number(cfg.npcRelationChangeLimitTrust == null ? DEFAULT_CFG.npcRelationChangeLimitTrust : cfg.npcRelationChangeLimitTrust) || 0));
    cfg.npcRelationChangeLimitLust = Math.max(0, Math.min(10, Number(cfg.npcRelationChangeLimitLust == null ? DEFAULT_CFG.npcRelationChangeLimitLust : cfg.npcRelationChangeLimitLust) || 0));
    cfg.npcRelationChangeLimitRage = Math.max(0, Math.min(10, Number(cfg.npcRelationChangeLimitRage == null ? DEFAULT_CFG.npcRelationChangeLimitRage : cfg.npcRelationChangeLimitRage) || 0));
    cfg.npcRelationChangeLimitDom = Math.max(0, Math.min(10, Number(cfg.npcRelationChangeLimitDom == null ? DEFAULT_CFG.npcRelationChangeLimitDom : cfg.npcRelationChangeLimitDom) || 0));
    if (!cfg.choiceTriggerMode) cfg.choiceTriggerMode = cfg.autoChoices == null ? DEFAULT_CFG.choiceTriggerMode : (Number(cfg.autoChoices || 0) > 0 ? 'auto' : 'off');
    cfg.choiceTriggerMode = String(cfg.choiceTriggerMode || '').toLowerCase();
    if (!/^(auto|manual|off)$/.test(cfg.choiceTriggerMode)) cfg.choiceTriggerMode = DEFAULT_CFG.choiceTriggerMode;
    cfg.autoChoices = cfg.choiceTriggerMode === 'auto' ? 1 : 0;
    cfg.showChangeSummary = Number(cfg.showChangeSummary == null ? DEFAULT_CFG.showChangeSummary : cfg.showChangeSummary) ? 1 : 0;
    return cfg;
  }

  var AIErrorType = {
    NOT_CONFIGURED: 'not_configured',
    AUTH_ERROR: 'auth_error',
    RATE_LIMIT: 'rate_limit',
    NETWORK_ERROR: 'network_error',
    TIMEOUT: 'timeout',
    MODEL_ERROR: 'model_error',
    QUOTA_ERROR: 'quota_error',
    CONTENT_FILTER: 'content_filter',
    SERVER_ERROR: 'server_error',
    UNKNOWN: 'unknown',
  };

  function AIError(type, userMessage, detail, statusCode) {
    this.name = 'AIError';
    this.type = type;
    this.message = userMessage;
    this.detail = detail || '';
    this.statusCode = statusCode || 0;
  }

  function userErrorMessage(type, detail, lang) {
    var zh = lang === 'zh';
    var msgs = {
      not_configured: zh ? '未配置 API 密钥。请打开「设置 → 织境空间 → 剧情AI设置」，填写 API Key 后再测试连接。' : 'API Key is not configured. Open Settings → Woven Realm and fill in the API key.',
      auth_error: zh ? 'API 密钥无效或没有权限。请检查 Key 是否复制完整、是否选错服务商，必要时重新生成 API Key。' : 'API key is invalid or unauthorized. Check the key, provider, and account permissions.',
      rate_limit: zh ? 'API 请求过快或达到临时限流。请稍后重试，或降低连续生成频率。' : 'API rate limit reached. Try later or reduce request frequency.',
      quota_error: zh ? '账户余额、额度或订阅不可用。请检查服务商后台的余额、免费额度、账单状态或模型调用权限。' : 'Account quota, balance, billing, or subscription is unavailable. Check the provider dashboard.',
      network_error: zh ? '网络连接失败。请检查 API 地址是否正确、浏览器是否允许跨域/CORS、是否被 CSP/代理/本地防火墙拦截。' : 'Network error. Check endpoint, CORS/CSP, proxy, firewall, or local service availability.',
      timeout: zh ? 'API 请求超时。请稍后重试，或检查接口是否过慢、模型是否拥堵、本地服务是否卡住。' : 'API request timed out. Retry later or check whether the provider/local service is stalled.',
      model_error: zh ? '模型不可用或模型名不匹配。请在「测试连接」里查看模型候选，或按服务商模型列表填写完整模型 ID。' : 'Model is unavailable or the model name does not match. Use connection test candidates or provider model IDs.',
      content_filter: zh ? 'AI 内容被接口过滤。请调整提示词、降低敏感内容强度，或更换允许该内容的模型/服务商。' : 'Content was filtered. Adjust the prompt or use a model/provider that allows the content.',
      server_error: zh ? 'API 服务商服务器错误。通常不是 Mod 配置问题，请稍后重试或查看服务商状态页。' : 'Provider server error. Usually not a mod configuration issue; retry later or check provider status.',
      unknown: zh ? '未知错误' : 'Unknown error',
    };
    var msg = msgs[type] || msgs.unknown;
    if (detail && type !== 'not_configured') {
      msg += (zh ? ' (详情: ' : ' (detail: ') + detail + ')';
    }
    return msg;
  }

  function classifyError(err, lang) {
    if (err instanceof AIError) return err;
    var name = (err && err.name) || '';
    var message = (err && err.message) || String(err);
    var apiClient = (window.AIStoryGen && window.AIStoryGen.ApiClientModule) || window.AIStoryGenApiClientModule;
    var stringify = apiClient && apiClient.safeJsonStringify ? apiClient.safeJsonStringify : JSON.stringify;
    var parseJson = apiClient && apiClient.parseJsonMaybe ? apiClient.parseJsonMaybe : function (text) {
      try { return JSON.parse(text); } catch (_) { return null; }
    };

    if (name === 'AbortError' || message.indexOf('aborted') !== -1) {
      return new AIError(AIErrorType.TIMEOUT, userErrorMessage('timeout', '', lang));
    }

    var statusCode = Number((err && (err.status || err.statusCode)) || (err && err.cause && (err.cause.status || err.cause.statusCode)) || 0);
    var statusMatch = message.match(/(?:HTTP|status(?:\s*code)?)\s*[:=]?\s*(\d{3})/i);
    if (!statusCode && statusMatch) statusCode = parseInt(statusMatch[1], 10) || 0;
    var detail = message.replace(/^HTTP\s+\d{3}\s*/, '').slice(0, 300);
    var responseBody = err && (err.responseBody || err.data || (err.cause && err.cause.responseBody));
    var responseErrorText = '';
    if (typeof responseBody === 'string') {
      responseBody = parseJson(responseBody) || responseBody;
    }
    if (responseBody) {
      try {
        if (apiClient && apiClient.responseErrorText) responseErrorText = apiClient.responseErrorText(responseBody);
        var body = typeof responseBody === 'string' ? responseBody : stringify(responseBody);
        if (responseErrorText) detail = responseErrorText.slice(0, 500);
        else if (body) detail = body.slice(0, 500);
      } catch (_) {}
    }
    var lowerMsg = message.toLowerCase();
    var lowerDetail = String(detail || '').toLowerCase();
    var combined = (lowerMsg + ' ' + lowerDetail).toLowerCase();
    var quotaLike = /(quota|insufficient|balance|credit|billing|payment|required|subscription|prepaid|trial|exceeded|no funds|not enough|余额|额度|欠费|账单|付款|付费|订阅|用量不足|余额不足|额度不足)/i.test(combined);
    var modelLike = /(model|模型|does not exist|not found|invalid.*model|model.*invalid|unknown model|unsupported model)/i.test(combined);

    if (statusCode === 402 || quotaLike) {
      return new AIError(AIErrorType.QUOTA_ERROR, userErrorMessage('quota_error', detail, lang), detail, statusCode);
    }
    if (statusCode === 401 || statusCode === 403) {
      return new AIError(AIErrorType.AUTH_ERROR, userErrorMessage('auth_error', detail, lang), detail, statusCode);
    }
    if (statusCode === 429) {
      return new AIError(AIErrorType.RATE_LIMIT, userErrorMessage('rate_limit', '', lang), detail, statusCode);
    }
    if (statusCode === 404 || (statusCode === 400 && modelLike)) {
      return new AIError(AIErrorType.MODEL_ERROR, userErrorMessage('model_error', '', lang), detail, statusCode);
    }
    if (statusCode >= 500 && statusCode < 600) {
      return new AIError(AIErrorType.SERVER_ERROR, userErrorMessage('server_error', '', lang), detail, statusCode);
    }

    if (lowerMsg.indexOf('content_filter') !== -1 || lowerMsg.indexOf('content filter') !== -1 || lowerDetail.indexOf('content_filter') !== -1 || lowerDetail.indexOf('content filter') !== -1) {
      return new AIError(AIErrorType.CONTENT_FILTER, userErrorMessage('content_filter', '', lang));
    }
    if (err instanceof TypeError || message.indexOf('fetch') !== -1 || lowerMsg.indexOf('network') !== -1 || lowerMsg.indexOf('cors') !== -1 || lowerMsg.indexOf('csp') !== -1 || lowerDetail.indexOf('cors') !== -1 || lowerDetail.indexOf('csp') !== -1) {
      return new AIError(AIErrorType.NETWORK_ERROR, userErrorMessage('network_error', detail, lang), detail);
    }
    if (message.indexOf('未设置 API 密钥') !== -1 || message.indexOf('未配置 API 密钥') !== -1 || message.indexOf('API Key not set') !== -1 || message.indexOf('API key is not configured') !== -1) {
      return new AIError(AIErrorType.NOT_CONFIGURED, message);
    }

    return new AIError(AIErrorType.UNKNOWN, userErrorMessage('unknown', detail, lang), detail);
  }

  function getSafeV() {
    try {
      return (typeof State !== 'undefined' && State.variables) ? State.variables : null;
    } catch (e) {
      return null;
    }
  }

  function safeRead(fn, fallback) {
    try {
      var v = fn();
      if (typeof v === 'function') return fallback;
      return (v != null) ? v : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function checkNetwork(apiUrl, apiKey, callback, modelName, opts) {
    if (!apiUrl) { callback({ status: 'not_configured', message: '未配置 API 地址' }); return; }
    opts = opts || {};
    var apiClient = (window.AIStoryGen && window.AIStoryGen.ApiClientModule) || window.AIStoryGenApiClientModule;
    function fallbackModelsEndpoint(url) {
      var baseUrl = String(url || '').trim().replace(/\/+$/, '');
      return baseUrl
        .replace(/\/chat\/completions$/i, '')
        .replace(/\/responses$/i, '')
        .replace(/\/models$/i, '') + '/models';
    }
    var modelsUrl = apiClient && apiClient.normalizeModelsEndpoint
      ? apiClient.normalizeModelsEndpoint(apiUrl)
      : fallbackModelsEndpoint(apiUrl);
    var cspViolated = false;
    var cspHandler = function () { cspViolated = true; };
    document.addEventListener('securitypolicyviolation', cspHandler);

    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 10000);

    var headers = Object.assign({ Accept: 'application/json' }, opts.extraHeaders || {});
    if (apiKey) headers.Authorization = 'Bearer ' + apiKey;
    if (opts.skipModelsProbe) {
      callback({
        status: 'models_unavailable',
        message: '当前服务商预设跳过模型列表探测，将直接测试聊天接口',
        modelProbe: {
          checked: false,
          skipped: true,
          reason: 'provider_capability',
          provider: opts.provider || ''
        }
      });
      return;
    }

    var fetcher = apiClient && apiClient.safeFetch ? apiClient.safeFetch : fetch;
    fetcher(modelsUrl, { method: 'GET', headers: headers, signal: controller.signal })
      .then(function (resp) {
        clearTimeout(timer);
        document.removeEventListener('securitypolicyviolation', cspHandler);
        if (cspViolated) { callback({ status: 'csp_blocked', message: 'CSP 策略阻止了请求' }); return; }
        if (resp.ok) {
          resp.text().then(function (body) {
            var payload = apiClient && apiClient.parseJsonMaybe ? apiClient.parseJsonMaybe(body) : null;
            var probe = apiClient && apiClient.buildModelProbe ? apiClient.buildModelProbe(payload, modelName) : null;
            if (probe && probe.modelCount && modelName && !probe.modelFound) {
              callback({
                status: 'model_not_found',
                message: '模型列表可访问，但没有找到模型：' + modelName,
                modelProbe: probe
              });
              return;
            }
            callback({
              status: 'ok',
              message: probe && probe.modelFound ? '连接正常，模型已确认存在' : '连接正常',
              modelProbe: probe
            });
          }).catch(function () {
            callback({ status: 'ok', message: '连接正常，但模型列表内容无法读取' });
          });
          return;
        }
        if (resp.status === 401 || resp.status === 403) {
          callback({ status: 'auth_error', message: '认证失败 (HTTP ' + resp.status + ')，API Key 可能无效' });
        } else if (resp.status === 404 || resp.status === 405 || resp.status === 501) {
          callback({ status: 'models_unavailable', message: 'models endpoint unavailable (HTTP ' + resp.status + '), continue with chat test' });
        } else {
          resp.text().then(function (body) {
            callback({ status: 'api_error', message: 'API 返回错误 HTTP ' + resp.status + (body ? ': ' + body.slice(0, 120) : '') });
          }).catch(function () {
            callback({ status: 'api_error', message: 'API 返回错误 HTTP ' + resp.status });
          });
        }
      })
      .catch(function (err) {
        clearTimeout(timer);
        document.removeEventListener('securitypolicyviolation', cspHandler);
        if (cspViolated) { callback({ status: 'csp_blocked', message: 'CSP 策略阻止了请求' }); return; }
        if (err.name === 'AbortError') { callback({ status: 'timeout', message: '连接超时 (10秒)' }); return; }
        callback({ status: 'network_error', message: '网络错误: ' + (err.message || String(err)).slice(0, 80) });
      });
  }

  function applyPostProcess(text, cfg) {
    var pattern = cfg.postProcessPattern;
    if (!pattern) return text;
    try {
      var match = /^\/(.+)\/([gimsuy]*)$/.exec(pattern);
      if (!match) return text;
      var regex = new RegExp(match[1], match[2]);
      var replacement = cfg.postProcessReplacement || '';
      return text.replace(regex, replacement);
    } catch (e) {
      console.warn('[AIStoryGen] post-process regex error', e);
      return text;
    }
  }

  var Core = {
    schemaVersion: 1,
    DEFAULT_CFG: DEFAULT_CFG,
    DEFAULT_LONG_TERM_REFINE_PROMPT: DEFAULT_LONG_TERM_REFINE_PROMPT,
    normalizeCfg: normalizeCfg,
    AIErrorType: AIErrorType,
    AIError: AIError,
    userErrorMessage: userErrorMessage,
    classifyError: classifyError,
    getSafeV: getSafeV,
    safeRead: safeRead,
    checkNetwork: checkNetwork,
    applyPostProcess: applyPostProcess,
  };

  root.Core = Core;
  window.AIStoryGenCore = Core;
})();
