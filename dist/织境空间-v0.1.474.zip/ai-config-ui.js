/* ============================================================
 * AIStoryGen config UI controller
 * Owns the merged settings tabs shared by story AI and image AI.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var TAB_ORDER = ['story', 'extras', 'prompt', 'pixel', 'personal', 'npc', 'diagnostic'];
  var TAB_LABELS = {
    story: '\u5267\u60c5AI\u8bbe\u7f6e',
    extras: '\u9644\u52a0\u529f\u80fd',
    prompt: '\u63d0\u793a\u8bcd',
    pixel: '\u7ed8\u56fe\u8bbe\u7f6e',
    personal: '\u4e2a\u4eba\u8bbe\u5b9a',
    npc: 'NPC\u5f62\u8c61\u8bbe\u7f6e',
    diagnostic: '\u8bca\u65ad'
  };

  function isKnownTab(tab) {
    return TAB_ORDER.indexOf(String(tab || '')) >= 0;
  }

  function normaliseTab(tab, pixelEnabled) {
    tab = String(tab || 'story');
    if (!isKnownTab(tab)) tab = 'story';
    if (!pixelEnabled && ['pixel', 'personal', 'npc'].indexOf(tab) >= 0) return 'story';
    return tab;
  }

  function normaliseSearchText(text) {
    return String(text || '').toLowerCase().replace(/\s+/g, '');
  }

  function getVisibleTabs(pixelEnabled) {
    return pixelEnabled ? TAB_ORDER.slice() : ['story', 'extras', 'prompt', 'diagnostic'];
  }

  function create(deps) {
    deps = deps || {};
    var activeTab = 'story';
    var settingsSearchQuery = '';
    var settingsSearchIndex = 0;

    function get$() {
      var jq = deps.$ || root.jQuery || root.$;
      if (!jq) throw new Error('[AIStoryGen] jQuery is required for ai-config-ui.js');
      return jq;
    }

    function loadCfg() {
      try {
        return typeof deps.loadCfg === 'function' ? (deps.loadCfg() || {}) : {};
      } catch (_) {
        return {};
      }
    }

    function isPixelEnabled() {
      try {
        if (typeof deps.isPixelEnabled === 'function') return !!deps.isPixelEnabled(loadCfg());
      } catch (_) {}
      var cfg = loadCfg();
      return Number(cfg.aiPixelEnabled == null ? 1 : cfg.aiPixelEnabled) !== 0;
    }

    function pixelGen() {
      try {
        if (typeof deps.getPixelGen === 'function') return deps.getPixelGen() || null;
      } catch (_) {}
      return root.AIPixelGen || null;
    }

    function renderMissing($content, message) {
      var $ = get$();
      $content.empty().append($('<div class="ai-cfg-msg err"></div>').text(message));
    }

    function applySettingsSearch($content, $status, step) {
      if (!$content || typeof $content.find !== 'function') return;
      var $ = get$();
      var query = normaliseSearchText(settingsSearchQuery);
      try { $content.find('.ai-settings-search-hit').removeClass('ai-settings-search-hit'); } catch (_) {}
      if (!query) {
        if ($status && typeof $status.text === 'function') $status.text('\u8F93\u5165\u5173\u952E\u8BCD\u53EF\u5B9A\u4F4D\u5F53\u524D\u6807\u7B7E\u9875\u7684\u8BBE\u7F6E\u9879');
        return;
      }
      var selector = [
        '.ai-cfg-section',
        '.ai-cfg-row',
        '.ai-cfg-details',
        '.ai-cfg-debug-block',
        '.apg-cfg h3',
        '.apg-hint',
        '.apg-meta',
        '.apg-cfg-form label',
        '.apg-row',
        '.apg-npc-row',
        '.apg-personal-quick',
        '.wr-intimate-section',
        '.wr-intimate-settings-row',
        '.wr-intimate-settings-help',
        '.wr-intimate-asset-manager',
        '.wr-intimate-config-io',
        '.wr-intimate-library-settings',
        '.wr-intimate-npc-profile-manager'
      ].join(',');
      var $hits = $();
      try {
        $content.find(selector).each(function () {
          var $el = $(this);
          var text = normaliseSearchText($el.text ? $el.text() : '');
          if (text && text.indexOf(query) >= 0) $hits = $hits.add($el);
        });
      } catch (_) {
        return;
      }
      if (!$hits.length) {
        if ($status && typeof $status.text === 'function') $status.text('\u672A\u627E\u5230\u5339\u914D\u9879\uFF1A' + settingsSearchQuery);
        return;
      }
      settingsSearchIndex += Number(step || 0);
      settingsSearchIndex = ((settingsSearchIndex % $hits.length) + $hits.length) % $hits.length;
      $hits.addClass('ai-settings-search-hit');
      var target = $hits.get(settingsSearchIndex);
      if (target && typeof target.scrollIntoView === 'function') {
        try { target.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' }); } catch (_) { target.scrollIntoView(); }
      }
      if ($status && typeof $status.text === 'function') {
        $status.text('\u5339\u914D ' + $hits.length + ' \u9879\uFF0C\u5F53\u524D ' + (settingsSearchIndex + 1) + ' / ' + $hits.length);
      }
    }

    function renderUnifiedConfigForm($container, isSettingsTab, defaultTab) {
      var $ = get$();
      activeTab = normaliseTab(defaultTab || activeTab, isPixelEnabled());

      var $root = $('<div></div>').addClass('apg-panel-wrap ai-unified-settings ai-merged-settings');
      var $tabs = $('<div class="apg-subtabs ai-merged-subtabs"></div>');
      var buttons = {};
      TAB_ORDER.forEach(function (tab) {
        var cls = 'apg-subtab ai-merged-' + tab + '-tab';
        buttons[tab] = $('<button type="button"></button>').addClass(cls).text(TAB_LABELS[tab]);
        $tabs.append(buttons[tab]);
      });
      var $search = $('<div class="ai-settings-search"></div>');
      var $searchInput = $('<input class="ai-settings-search-input" type="search" placeholder="\u641C\u7D22\u8BBE\u7F6E\uFF1ANPC / \u56DE\u5FC6 / ComfyUI / \u52A8\u6001\u753B\u9762 / \u7ED3\u7B97">');
      var $searchNext = $('<button type="button" class="apg-btn ai-settings-search-next">\u5B9A\u4F4D\u4E0B\u4E00\u4E2A</button>');
      var $searchClear = $('<button type="button" class="apg-btn ai-settings-search-clear">\u6E05\u7A7A</button>');
      var $searchStatus = $('<span class="ai-settings-search-status"></span>').text('\u8F93\u5165\u5173\u952E\u8BCD\u53EF\u5B9A\u4F4D\u5F53\u524D\u6807\u7B7E\u9875\u7684\u8BBE\u7F6E\u9879');
      $search.append($searchInput).append($searchNext).append($searchClear).append($searchStatus);
      var $content = $('<div class="apg-subcontent ai-merged-content"></div>');
      $root.append($tabs).append($search).append($content);
      $container.empty().append($root);

      function refreshSearch(step) {
        applySettingsSearch($content, $searchStatus, step || 0);
      }

      $searchInput.on('input keyup', function (event) {
        if (event && event.type === 'keyup' && event.key && event.key !== 'Enter') return;
        settingsSearchQuery = String($searchInput.val ? ($searchInput.val() || '') : '');
        settingsSearchIndex = 0;
        refreshSearch(0);
      });
      $searchNext.on('click', function () {
        if ($searchInput && typeof $searchInput.val === 'function') settingsSearchQuery = String($searchInput.val() || '');
        refreshSearch(1);
      });
      $searchClear.on('click', function () {
        settingsSearchQuery = '';
        settingsSearchIndex = 0;
        if ($searchInput && typeof $searchInput.val === 'function') $searchInput.val('');
        refreshSearch(0);
      });

      function pixelButtons() {
        return buttons.pixel.add(buttons.personal).add(buttons.npc);
      }

      function refreshPixelTabs() {
        var enabled = isPixelEnabled();
        pixelButtons().toggle(enabled);
        if (!enabled) {
          try { $('#passages .apg-ai-assist').remove(); } catch (_) {}
        }
        if (!enabled && ['pixel', 'personal', 'npc'].indexOf(activeTab) >= 0) showStory();
        return enabled;
      }

      function setActive(tab) {
        activeTab = normaliseTab(tab, isPixelEnabled());
        TAB_ORDER.forEach(function (key) {
          buttons[key].toggleClass('active', activeTab === key);
        });
      }

      function showStory() {
        setActive('story');
        if (typeof deps.renderStoryConfig === 'function') deps.renderStoryConfig($content, isSettingsTab);
        else renderMissing($content, 'AIStoryGen story settings renderer is unavailable.');
        refreshPixelTabs();
        refreshSearch(0);
      }

      function showPrompt() {
        setActive('prompt');
        if (typeof deps.renderPromptConfig === 'function') deps.renderPromptConfig($content, isSettingsTab);
        else renderMissing($content, 'AIStoryGen prompt settings renderer is unavailable.');
        refreshPixelTabs();
        refreshSearch(0);
      }

      function showExtras() {
        setActive('extras');
        if (typeof deps.renderExtrasConfig === 'function') deps.renderExtrasConfig($content, isSettingsTab);
        else renderMissing($content, '\u9644\u52a0\u529f\u80fd\u9875\u6e32\u67d3\u5668\u5c1a\u672a\u52a0\u8f7d\uff0c\u8bf7\u5237\u65b0\u9875\u9762\u540e\u91cd\u8bd5\u3002');
        refreshPixelTabs();
        refreshSearch(0);
      }

      function showPixel() {
        if (!refreshPixelTabs()) return;
        setActive('pixel');
        var api = pixelGen();
        if (api && typeof api.buildConfigForm === 'function') api.buildConfigForm($content, isSettingsTab);
        else renderMissing($content, 'AI\u7ed8\u56fe\u6a21\u5757\u5c1a\u672a\u52a0\u8f7d\uff0c\u8bf7\u5237\u65b0\u9875\u9762\u540e\u91cd\u8bd5\u3002');
        refreshSearch(0);
      }

      function showPersonal() {
        if (!refreshPixelTabs()) return;
        setActive('personal');
        var api = pixelGen();
        if (api && typeof api.buildPersonalSettings === 'function') api.buildPersonalSettings($content);
        else renderMissing($content, 'AI\u7ed8\u56fe\u4e2a\u4eba\u8bbe\u5b9a\u5c1a\u672a\u52a0\u8f7d\uff0c\u8bf7\u5237\u65b0\u9875\u9762\u540e\u91cd\u8bd5\u3002');
        refreshSearch(0);
      }

      function showNpc() {
        if (!refreshPixelTabs()) return;
        setActive('npc');
        var api = pixelGen();
        if (api && typeof api.buildNpcAppearanceSettings === 'function') api.buildNpcAppearanceSettings($content);
        else renderMissing($content, 'AI\u7ed8\u56feNPC\u5f62\u8c61\u8bbe\u7f6e\u5c1a\u672a\u52a0\u8f7d\uff0c\u8bf7\u5237\u65b0\u9875\u9762\u540e\u91cd\u8bd5\u3002');
        refreshSearch(0);
      }

      function showDiagnostic() {
        setActive('diagnostic');
        if (typeof deps.renderDiagnosticConfig === 'function') deps.renderDiagnosticConfig($content, isSettingsTab);
        else renderMissing($content, '\u8bca\u65ad\u9875\u6e32\u67d3\u5668\u5c1a\u672a\u52a0\u8f7d\uff0c\u8bf7\u5237\u65b0\u9875\u9762\u540e\u91cd\u8bd5\u3002');
        refreshPixelTabs();
        refreshSearch(0);
      }

      buttons.story.on('click', showStory);
      buttons.extras.on('click', showExtras);
      buttons.prompt.on('click', showPrompt);
      buttons.pixel.on('click', showPixel);
      buttons.personal.on('click', showPersonal);
      buttons.npc.on('click', showNpc);
      buttons.diagnostic.on('click', showDiagnostic);

      root._AIStoryGenUnifiedSettingsRefresh = function () {
        if (!$root[0] || !root.document || !root.document.documentElement || !root.document.documentElement.contains($root[0])) return;
        refreshPixelTabs();
      };

      try {
        $(root.document).off('AIStoryGen:configSaved.aiUnified')
          .on('AIStoryGen:configSaved.aiUnified', function () {
            if (typeof root._AIStoryGenUnifiedSettingsRefresh === 'function') {
              root._AIStoryGenUnifiedSettingsRefresh();
            }
          });
      } catch (_) {}

      if (activeTab === 'extras') showExtras();
      else if (activeTab === 'prompt') showPrompt();
      else if (activeTab === 'pixel') showPixel();
      else if (activeTab === 'personal') showPersonal();
      else if (activeTab === 'npc') showNpc();
      else if (activeTab === 'diagnostic') showDiagnostic();
      else showStory();
      return getStatus();
    }

    function getStatus() {
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        activeTab: activeTab,
        pixelEnabled: isPixelEnabled(),
        visibleTabs: getVisibleTabs(isPixelEnabled())
      };
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      normaliseTab: normaliseTab,
      getVisibleTabs: getVisibleTabs,
      renderUnifiedConfigForm: renderUnifiedConfigForm,
      getStatus: getStatus
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    tabOrder: TAB_ORDER.slice(),
    tabLabels: Object.assign({}, TAB_LABELS),
    normaliseTab: normaliseTab,
    getVisibleTabs: getVisibleTabs,
    create: create
  };

  root.AIStoryGen.ConfigUIModule = api;
  root.AIStoryGenConfigUIModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
