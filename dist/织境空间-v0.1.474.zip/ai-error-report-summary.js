/* ============================================================
 * AIStoryGen error report summary
 * Builds a compact, human-readable diagnosis from an exported report.
 * Source strings use Unicode escapes to avoid Windows encoding drift.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 2;

  function text(value, maxLen) {
    var s = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    maxLen = maxLen || 240;
    return s.length > maxLen ? s.slice(0, maxLen) : s;
  }

  function arr(value) {
    return Array.isArray(value) ? value : [];
  }

  function addAction(summary, category, title, detail) {
    title = text(title, 180);
    if (!title) return null;
    var key = category + '|' + title;
    if (summary._actionKeys[key]) return null;
    summary._actionKeys[key] = true;
    var action = {
      category: category || 'general',
      title: title
    };
    if (detail) action.detail = text(detail, 500);
    summary.actions.push(action);
    return action;
  }

  function addIssue(summary, severity, category, message, detail, action) {
    var issue = {
      severity: severity || 'info',
      category: category || 'general',
      message: text(message, 300)
    };
    if (detail) issue.detail = text(detail, 500);
    if (action) issue.actionTitle = text(action.title || action, 180);
    summary.issues.push(issue);
    summary.sections[category] = summary.sections[category] || [];
    summary.sections[category].push(issue);
    if (action && action.title) addAction(summary, category, action.title, action.detail || '');
    return issue;
  }

  function severityRank(value) {
    return value === 'error' ? 3 : value === 'warning' ? 2 : value === 'ok' ? 0 : 1;
  }

  function highestSeverity(issues) {
    var max = 'ok';
    arr(issues).forEach(function (issue) {
      if (severityRank(issue && issue.severity) > severityRank(max)) max = issue.severity;
    });
    return max;
  }

  function latestRequest(report) {
    var cfgLog = report && report.configSummary && report.configSummary.apiRequestLog;
    if (arr(cfgLog).length) return cfgLog[0];
    var debugLog = report && report.debugState && report.debugState.controllerSchemas && report.debugState.controllerSchemas.requestLog;
    if (debugLog && arr(debugLog.recent).length) return debugLog.recent[0];
    return null;
  }

  function latestTransactionAudit(report) {
    var runtimeAudit = report && report.runtimeStats && report.runtimeStats.lastTransactionAudit;
    if (runtimeAudit) return runtimeAudit;
    var controller = report && report.debugState && report.debugState.controllerSchemas;
    if (controller && controller.lastTransactionAudit) return controller.lastTransactionAudit;
    if (controller && controller.transactionAudit && controller.transactionAudit.last) return controller.transactionAudit.last;
    return null;
  }

  function latestTransactionPlan(report) {
    var runtimePlan = report && report.runtimeStats && report.runtimeStats.lastTransactionPlan;
    if (runtimePlan) return runtimePlan;
    var debugPlan = report && report.debugState && report.debugState.lastTransactionPlan;
    if (debugPlan) return debugPlan;
    var controller = report && report.debugState && report.debugState.controllerSchemas;
    if (controller && controller.lastTransactionPlan) return controller.lastTransactionPlan;
    return null;
  }

  function mobileCompatState(report) {
    var controller = report && report.debugState && report.debugState.controllerSchemas;
    if (controller && controller.mobileCompat) return controller.mobileCompat;
    return null;
  }

  function mountState(report) {
    var settings = report && report.debugState && report.debugState.settingsInjection;
    if (settings && settings.mountController) return settings.mountController;
    var controller = report && report.debugState && report.debugState.controllerSchemas;
    if (controller && controller.mountController) return controller.mountController;
    return settings || null;
  }

  function consistencyBlockedSummary(report) {
    if (arr(report && report.consistencyBlockedEffectSummary).length) return report.consistencyBlockedEffectSummary;
    if (arr(report && report.debugState && report.debugState.consistencyBlockedEffectSummary).length) return report.debugState.consistencyBlockedEffectSummary;
    return [];
  }

  function consistencyDiagnostics(report) {
    if (arr(report && report.debugState && report.debugState.consistencyDiagnostics).length) return report.debugState.consistencyDiagnostics;
    if (arr(report && report.consistencyDiagnostics).length) return report.consistencyDiagnostics;
    return [];
  }

  function apiAction(title, detail) {
    return { title: title, detail: detail };
  }

  function currentReportPassage(report) {
    return text(
      (report && report.state && report.state.passage)
      || (report && report.currentPageSnapshot && report.currentPageSnapshot.passage)
      || (report && report.debugState && report.debugState.passage)
      || '',
      120
    );
  }

  function isSettingsLikeText(value) {
    return /settings|options|option|setting|\u8bbe\u7f6e|\u9009\u9879/i.test(String(value || ''));
  }

  function isSettingsMountContext(report, mount) {
    mount = mount || {};
    var main = mount.main || {};
    var passage = currentReportPassage(report);
    if (isSettingsLikeText(passage)) return true;
    if (main.hasSettingsOptions === true || main.hasSettingsTab === true || main.hasNativeSettingsTab === true || main.hasFallbackEntry === true) return true;
    return false;
  }

  function isSettingsOverlayContext(report, mount) {
    mount = mount || {};
    var overlay = mount.overlay || {};
    var mobile = mobileCompatState(report) || {};
    var mobileOverlay = mobile.overlay || {};
    var overlayText = [
      overlay.dataOverlay,
      overlay.tabText,
      overlay.activeTab,
      mobileOverlay.dataOverlay,
      mobileOverlay.tabText,
      mobileOverlay.activeTab
    ].filter(Boolean).join(' ');
    var hidden = mobileOverlay.hidden;
    if (hidden === true || hidden === 'true') return false;
    if (isSettingsLikeText(overlayText)) return true;
    if (overlay.hasOptionsTab === true || overlay.hasNativeOptionsTab === true || overlay.hasFallbackEntry === true) return true;
    return false;
  }

  function riskIdSet(risks) {
    var out = {};
    arr(risks).forEach(function (risk) {
      var id = text(risk && risk.id || '', 120);
      if (id) out[id] = true;
    });
    return out;
  }

  function addInferredRisk(risks, seen, id, message) {
    if (!id || seen[id]) return;
    seen[id] = true;
    risks.push({ id: id, message: message });
  }

  function inferPixelPromptRisks(report, diag, risks) {
    risks = arr(risks).slice();
    var seen = riskIdSet(risks);
    var finalPrompt = String(diag && diag.finalPrompt || '');
    var visualAction = String(diag && diag.visualAction || '');
    var combined = (finalPrompt + ' ' + visualAction).toLowerCase();
    var pageText = String(
      (report && report.currentPageSnapshot && (report.currentPageSnapshot.aiStoryText || report.currentPageSnapshot.visibleText || report.currentPageSnapshot.originalStoryText))
      || ''
    ).toLowerCase();
    var negativeLen = Number(diag && diag.lengths && diag.lengths.negativePrompt || String(diag && diag.negativePrompt || '').length || 0);
    var negLimit = Number(diag && diag.limits && diag.limits.negativePromptApiLimit || 800);
    if (negativeLen > negLimit) {
      addInferredRisk(risks, seen, 'negative_prompt_truncated', '\u8d1f\u9762\u63d0\u793a\u8bcd\u957f\u5ea6\u8d85\u8fc7\u53d1\u9001\u4e0a\u9650\uff0c\u5b9e\u9645\u8bf7\u6c42\u4f1a\u88ab\u622a\u65ad\u3002');
    }
    if ((/\bforest\b|\u68ee\u6797/.test(pageText))
        && /\b(?:manor|garden|hedge|shears|laboratory|bedroom|bathroom)\b|\u5b85\u90b8|\u82b1\u56ed|\u6811\u7bf1|\u526a\u5200|\u5b9e\u9a8c\u5ba4|\u5367\u5ba4|\u6d74\u5ba4/.test(combined)
        && !/\bforest cabin\b/.test(combined)) {
      addInferredRisk(risks, seen, 'stale_visual_action', '\u5f53\u524d\u9875\u9762\u50cf\u662f\u68ee\u6797\u573a\u666f\uff0c\u4f46\u751f\u56fe\u63d0\u793a\u8bcd\u4ecd\u542b\u5b85\u90b8/\u82b1\u56ed/\u5ba4\u5185\u7b49\u65e7\u573a\u666f\u52a8\u4f5c\u3002');
    }
    if ((/\bbathroom\b|\u6d74\u5ba4|\u6d17\u6fa1/.test(pageText))
        && /\b(?:forest|woods|manor garden|hedge|shears)\b|\u68ee\u6797|\u6811\u7bf1|\u526a\u5200/.test(combined)) {
      addInferredRisk(risks, seen, 'stale_visual_action', '\u5f53\u524d\u9875\u9762\u50cf\u662f\u6d74\u5ba4/\u6d17\u6fa1\u573a\u666f\uff0c\u4f46\u751f\u56fe\u63d0\u793a\u8bcd\u4ecd\u542b\u68ee\u6797\u6216\u65e7\u52a8\u4f5c\u3002');
    }
    var hairCount = (finalPrompt.match(/\bhaircolou?r\b/gi) || []).length;
    var wearCount = (finalPrompt.match(/\bwearing\s+upper\b/gi) || []).length;
    if (hairCount > 1 || wearCount > 1) {
      addInferredRisk(risks, seen, 'duplicate_appearance_terms', '\u73a9\u5bb6\u5916\u89c2\u5b57\u6bb5\u4f3c\u4e4e\u91cd\u590d\uff0c\u53ef\u80fd\u5360\u7528\u63d0\u793a\u8bcd\u7a7a\u95f4\u5e76\u5e72\u6270\u52a8\u4f5c/\u573a\u666f\u3002');
    }
    return risks;
  }

  function analyzeVersions(report, summary) {
    var versions = report.versions || {};
    var diag = versions.versionDiagnostics || (report.debugState && report.debugState.versionDiagnostics) || {};
    var runtimeVersion = text(diag.runtimeVersion || versions.modVersion || '', 80);
    var expectedVersion = text(diag.expectedBootVersion || versions.expectedBootVersion || '', 80);
    if (!runtimeVersion && !expectedVersion) {
      addIssue(summary, 'info', 'version',
        '\u62a5\u544a\u4e2d\u6ca1\u6709\u8fd0\u884c\u7248\u672c\u81ea\u68c0\u4fe1\u606f\uff0c\u5efa\u8bae\u4f7f\u7528\u6700\u65b0\u7248\u672c\u5bfc\u51fa\u62a5\u544a\u3002');
      return;
    }
    if (diag.mismatch || (runtimeVersion && expectedVersion && runtimeVersion !== expectedVersion)) {
      addIssue(summary, 'error', 'version',
        '\u8fd0\u884c\u4e2d\u7684\u7ec7\u5883\u7a7a\u95f4\u7248\u672c\u4e0e\u5f53\u524d\u5305\u7248\u672c\u4e0d\u4e00\u81f4\uff1a\u8fd0\u884c ' + (runtimeVersion || 'unknown') + '\uff0c\u671f\u671b ' + (expectedVersion || 'unknown') + '\u3002',
        '\u8fd9\u901a\u5e38\u8868\u793a ModLoader \u5408\u5e76\u7f13\u5b58\u6216\u65e7 zip \u4ecd\u5728\u751f\u6548\uff0c\u4f1a\u5bfc\u81f4\u201c\u5df2\u4fee\u590d\u4f46\u9875\u9762\u8fd8\u662f\u65e7\u884c\u4e3a\u201d\u3002',
        apiAction('\u91cd\u65b0\u52a0\u8f7d\u6700\u65b0 zip \u5e76\u6e05\u7406 ModLoader \u5408\u5e76\u7f13\u5b58',
          '\u5148\u786e\u8ba4 mods \u76ee\u5f55\u53ea\u4fdd\u7559\u4e00\u4efd\u6700\u65b0\u7ec7\u5883\u7a7a\u95f4 zip\uff1b\u5982\u679c\u4ecd\u663e\u793a\u65e7\u7248\uff0c\u9700\u8981\u91cd\u5efa\u6d4b\u8bd5\u9875\u6216\u6e05\u7406 ModLoader \u5408\u5e76\u7f13\u5b58\u3002'));
      return;
    }
    addIssue(summary, 'ok', 'version',
      '\u8fd0\u884c\u7248\u672c\u4e0e\u6253\u5305\u7248\u672c\u4e00\u81f4\uff1a' + runtimeVersion + '\u3002');
  }

  function analyzeApi(report, summary) {
    var cfg = report.configSummary || {};
    if (!cfg.hasApiKey) {
      addIssue(summary, 'info', 'api',
        '\u672a\u914d\u7f6e API Key\uff1b\u5982\u679c\u53ea\u662f\u5bfc\u51fa\u62a5\u544a\u6216\u68c0\u67e5\u754c\u9762\uff0c\u8fd9\u4e0d\u4ee3\u8868 Mod \u8fd0\u884c\u9519\u8bef\u3002');
    }
    if (!cfg.endpoint) {
      addIssue(summary, 'warning', 'api',
        '\u63a5\u53e3\u5730\u5740\u4e3a\u7a7a\u6216\u672a\u5199\u5165\u62a5\u544a\uff0c\u5efa\u8bae\u5148\u68c0\u67e5 API \u8bbe\u7f6e\u3002',
        '',
        apiAction('\u68c0\u67e5 API \u63a5\u53e3\u5730\u5740',
          '\u5982\u679c\u4f7f\u7528 OpenAI \u517c\u5bb9\u670d\u52a1\uff0c\u4f18\u5148\u586b\u5199\u670d\u52a1\u5546\u63a8\u8350\u7684 /v1 \u6216 /chat/completions \u5730\u5740\u3002'));
    }
    if (!cfg.model) {
      addIssue(summary, 'warning', 'api',
        '\u6a21\u578b\u540d\u4e3a\u7a7a\u6216\u672a\u5199\u5165\u62a5\u544a\uff0c\u5efa\u8bae\u5148\u68c0\u67e5\u6a21\u578b\u8bbe\u7f6e\u3002',
        '',
        apiAction('\u586b\u5199\u670d\u52a1\u5546\u652f\u6301\u7684\u6a21\u578b\u540d',
          '\u4f7f\u7528\u201c\u6d4b\u8bd5\u8fde\u63a5\u201d\u8bfb\u53d6\u5019\u9009\u6a21\u578b\uff0c\u70b9\u51fb\u5019\u9009\u6309\u94ae\u81ea\u52a8\u5199\u5165\u3002'));
    }
    arr(cfg.providerDiagnostic && cfg.providerDiagnostic.warnings).forEach(function (line) {
      addIssue(summary, 'warning', 'api', '\u670d\u52a1\u5546\u914d\u7f6e\u63d0\u793a\uff1a' + line,
        '',
        apiAction('\u6309\u670d\u52a1\u5546\u9884\u8bbe\u4fee\u6b63\u63a5\u53e3\u548c\u6a21\u578b',
          '\u5148\u9009\u62e9\u5bf9\u5e94\u670d\u52a1\u5546\u9884\u8bbe\uff0c\u518d\u6839\u636e\u4f53\u68c0\u9762\u677f\u7684\u63d0\u793a\u4fee\u6b63\u5730\u5740\u548c\u6a21\u578b\u540d\u3002'));
    });
    if (cfg.providerDiagnostic && cfg.providerDiagnostic.providerMismatch) {
      addIssue(summary, 'warning', 'api',
        '\u63a5\u53e3\u5730\u5740\u4e0e\u624b\u52a8\u9009\u62e9\u7684\u670d\u52a1\u5546\u4e0d\u4e00\u81f4\uff1a\u8bbe\u7f6e\u4e3a ' + text(cfg.providerDiagnostic.selected || 'custom', 80) + '\uff0c\u5b9e\u9645\u66f4\u50cf ' + text(cfg.providerDiagnostic.effective || cfg.providerDiagnostic.inferred || 'custom', 80) + '\u3002',
        '',
        apiAction('\u6309\u5f53\u524d\u63a5\u53e3\u5730\u5740\u91cd\u65b0\u9009\u62e9\u670d\u52a1\u5546\u9884\u8bbe',
          '\u4f8b\u5982 OpenRouter/Gemini/SiliconFlow \u9700\u8981\u5bf9\u5e94\u7684\u7aef\u70b9\u89c4\u5219\u3001\u6a21\u578b ID \u548c\u54cd\u5e94\u89e3\u6790\u65b9\u5f0f\uff1b\u4e0d\u4e00\u81f4\u65f6\u8bf7\u5148\u70b9\u51fb\u6b63\u786e\u9884\u8bbe\u518d\u6d4b\u8bd5\u8fde\u63a5\u3002'));
    }
    var probe = cfg.lastProviderProbe || {};
    if (probe && probe.modelMatches === false) {
      addIssue(summary, 'error', 'api',
        '\u6a21\u578b\u5217\u8868\u63a2\u6d4b\u663e\u793a\u5f53\u524d\u6a21\u578b\u4e0d\u5b58\u5728\u6216\u4e0d\u5339\u914d\u3002',
        '\u5f53\u524d\u6a21\u578b\uff1a' + text(cfg.model || probe.model || ''),
        apiAction('\u7528\u5019\u9009\u6a21\u578b\u66ff\u6362\u5f53\u524d\u6a21\u578b\u540d',
          '\u5728\u6d4b\u8bd5\u8fde\u63a5\u7ed3\u679c\u4e2d\u70b9\u51fb\u5019\u9009\u6a21\u578b\uff0c\u6216\u53bb\u670d\u52a1\u5546\u63a7\u5236\u53f0\u786e\u8ba4\u51c6\u786e ID\u3002'));
    }
    if (probe && probe.ok === false) {
      addIssue(summary, 'warning', 'api',
        '\u6a21\u578b\u5217\u8868\u63a2\u6d4b\u5931\u8d25\uff0c\u53ef\u80fd\u662f\u670d\u52a1\u5546\u4e0d\u652f\u6301 /models \u6216\u7f51\u7edc/API \u5730\u5740\u5f02\u5e38\u3002',
        probe.reason || probe.error || '',
        apiAction('\u7528\u804a\u5929\u63a5\u53e3\u590d\u6d4b\u8fde\u63a5',
          '/models \u5931\u8d25\u4e0d\u4e00\u5b9a\u4ee3\u8868\u804a\u5929\u63a5\u53e3\u4e0d\u53ef\u7528\uff1b\u770b\u201c\u6d4b\u8bd5\u8fde\u63a5\u201d\u7684\u6700\u7ec8\u804a\u5929\u7ed3\u679c\u3002'));
    }
    var apiError = cfg.lastApiError || {};
    if (apiError && (apiError.type || apiError.message || apiError.statusCode)) {
      addIssue(summary, 'error', 'api',
        '\u6700\u8fd1\u4e00\u6b21 API \u9519\u8bef\uff1a' + text(apiError.type || 'unknown') + (apiError.statusCode ? ' HTTP ' + apiError.statusCode : '') + '\u3002',
        apiError.message || apiError.detail || '',
        apiAction('\u6839\u636e API \u9519\u8bef\u7c7b\u578b\u4fee\u6b63\u914d\u7f6e',
          '401/403 \u901a\u5e38\u662f Key \u6216\u6743\u9650\uff1b404 \u901a\u5e38\u662f\u6a21\u578b\u540d\u6216\u63a5\u53e3\u5730\u5740\uff1b429/402 \u901a\u5e38\u662f\u9650\u989d\u6216\u4f59\u989d\u3002'));
    }
    var req = latestRequest(report);
    if (!req) return;
    if (req.status === 'error') {
      addIssue(summary, 'error', 'api',
        '\u6700\u8fd1 API \u8bf7\u6c42\u5931\u8d25\uff1a' + text(req.error && (req.error.type || req.error.message) || 'unknown') + (req.error && req.error.statusCode ? ' HTTP ' + req.error.statusCode : '') + '\u3002',
        req.error && (req.error.message || req.error.detail) || '',
        apiAction('\u5148\u4fee\u590d\u6700\u8fd1\u4e00\u6b21 API \u8bf7\u6c42\u9519\u8bef',
          '\u4f18\u5148\u770b\u6700\u8fd1\u8bf7\u6c42\u7684 statusCode\u3001error.type\u3001model \u548c endpoint\uff0c\u4e0d\u8981\u5148\u8c03\u5267\u60c5\u63d0\u793a\u8bcd\u3002'));
    } else if (req.retryCount > 0 || /length/i.test(req.finishReason || '')) {
      addIssue(summary, 'warning', 'api',
        '\u6700\u8fd1 API \u8bf7\u6c42\u51fa\u73b0\u7a7a\u54cd\u5e94/\u957f\u5ea6\u622a\u65ad\u98ce\u9669\u3002',
        'retryCount=' + (req.retryCount || 0) + ', finishReason=' + text(req.finishReason || ''),
        apiAction('\u63d0\u9ad8\u6700\u5927\u8f93\u51fa\u957f\u5ea6\u6216\u66f4\u6362\u6a21\u578b',
          '\u5982\u679c finish_reason=length \u6216\u7a7a\u54cd\u5e94\u91cd\u8bd5\u591a\uff0c\u628a\u6700\u5927\u8f93\u51fa\u957f\u5ea6\u8c03\u9ad8\uff0c\u5fc5\u8981\u65f6\u6362\u66f4\u7a33\u5b9a\u7684\u6a21\u578b\u3002'));
    }
  }

  function analyzeTransaction(report, summary) {
    var audit = latestTransactionAudit(report);
    var plan = latestTransactionPlan(report);
    if (!audit) {
      addIssue(summary, 'info', 'transaction', '\u62a5\u544a\u4e2d\u6ca1\u6709\u6700\u8fd1 AI \u5267\u60c5\u4e8b\u52a1\u5ba1\u8ba1\u8bb0\u5f55\u3002');
    }
    if (audit && audit.ok === false) {
      addIssue(summary, 'error', 'transaction',
        '\u6700\u8fd1 AI \u5267\u60c5\u4e8b\u52a1\u6709\u8ba1\u5212\u53d8\u5316\u672a\u5b9e\u9645\u751f\u6548\u3002',
        audit.readable && audit.readable.zh || '',
        { title: '\u67e5\u770b\u4e8b\u52a1\u5ba1\u8ba1\u5e76\u590d\u6d4b\u8be5\u8f6e\u5267\u60c5',
          detail: '\u91cd\u70b9\u770b diagnosticSummary\u3001runtimeStats.lastTransactionAudit \u548c transactionPlan.audit\uff0c\u786e\u8ba4\u662f\u65f6\u95f4\u3001\u6570\u503c\u3001\u9053\u5177\u3001\u5730\u70b9\u8fd8\u662f\u8bb0\u5fc6\u672a\u751f\u6548\u3002' });
      arr(audit.readable && audit.readable.warningLines).slice(0, 5).forEach(function (line) {
        addIssue(summary, 'warning', 'transaction', line);
      });
    } else if (audit) {
      addIssue(summary, 'ok', 'transaction', '\u6700\u8fd1 AI \u5267\u60c5\u4e8b\u52a1\u5ba1\u8ba1\u901a\u8fc7\u3002');
    }
    analyzeNavigationAttempt(plan, summary);
  }

  function analyzeConsistency(report, summary) {
    var blocked = arr(consistencyBlockedSummary(report));
    var diagnostics = arr(consistencyDiagnostics(report));
    if (!blocked.length && !diagnostics.length) return;

    if (blocked.length) {
      addIssue(summary, 'warning', 'consistency',
        '一致性系统拦截了 AI 计划写入游戏的部分变化。',
        blocked.slice(0, 3).map(function (line) { return text(line, 180); }).join('；'),
        { title: '查看最近被系统拦截的 AI 变化',
          detail: '如果剧情文字说发生了金钱、道具、地点或数值变化，但游戏没有变化，优先看这里确认是否被原版规则保护拦截。' });
    }

    var codeSeen = {};
    diagnostics.forEach(function (diag) {
      diag = diag || {};
      var code = text(diag.code || '', 120);
      if (!code || codeSeen[code]) return;
      codeSeen[code] = true;
      if (code === 'school_time_text_conflict') {
        addIssue(summary, 'warning', 'consistency',
          'AI 剧情文本可能和学校时间规则冲突。',
          text(diag.rule || diag.message || '', 220),
          { title: '检查学校时间规则和剧情文本',
            detail: '如果 AI 写“第一节课还没开始”等内容，但原版时间已经上课，说明需要调整该轮剧情或补充学校时间上下文。' });
      } else if (code === 'special_event_target_location_reset') {
        addIssue(summary, 'warning', 'consistency',
          '特殊事件/梦境/镜子流程中，AI 到达地点被重置。',
          text(diag.rule || diag.message || diag.value || '', 220),
          { title: '检查特殊事件中的到达地点',
            detail: 'AI 在特殊流程里不能直接把普通地点标记为已到达；需要剧情明确写出醒来、离开梦境或回到现实。' });
      } else if (/^restricted_business_/.test(code)) {
        addIssue(summary, 'warning', 'consistency',
          '商店或设施关闭状态下，AI 经济/物品变化被限制。',
          text(diag.rule || diag.message || '', 220),
          { title: '检查营业状态与物品/金钱变化',
            detail: '夜晚、关店或非营业流程下，普通购物、出售、付款类变化会被拦截；偷窃、拾取等例外必须在剧情文本中明确出现。' });
      }
    });
  }

  function analyzeNavigationAttempt(plan, summary) {
    var model = plan && plan.location && plan.location.returnButtonModel;
    var attempt = model && model.navigationAttempt;
    if (!attempt) return;
    var target = text(attempt.targetPassage || model.rawPassage || '', 120);
    var current = text(attempt.currentPassage || '', 120);
    var source = text(attempt.source || '', 80);
    var samples = arr(attempt.samples);
    var reached = !!attempt.reachedTarget || samples.some(function (sample) { return !!(sample && sample.reachedTarget); });
    var sampleText = samples.slice(-3).map(function (sample) {
      return text(sample.delay, 20) + 'ms=' + text(sample.passage || '', 80);
    }).join('\uff1b');
    if (attempt.phase === 'blocked' || attempt.phase === 'failed') {
      addIssue(summary, 'warning', 'transaction',
        '\u5230\u8fbe/\u8fd4\u56de\u6309\u94ae\u7684\u539f\u7248\u5bfc\u822a\u6ca1\u6709\u6210\u529f\u6267\u884c\u3002',
        '\u76ee\u6807\uff1a' + (target || 'unknown') + '\uff1b\u5f53\u524d\uff1a' + (current || 'unknown') + '\uff1b\u6765\u6e90\uff1a' + (source || 'unknown') + '\uff1b\u539f\u56e0\uff1a' + text(attempt.reason || attempt.error || '', 180),
        { title: '\u6839\u636e navigationAttempt \u68c0\u67e5\u5230\u8fbe\u6309\u94ae',
          detail: '\u91cd\u70b9\u770b targetPassage\u3001currentPassage\u3001reason\u3001usedOriginalLink \u548c usedEnginePlay\uff0c\u786e\u8ba4\u662f\u76ee\u6807 passage \u4e0d\u5b89\u5168\u3001\u539f\u7248\u94fe\u63a5\u672a\u89e6\u53d1\uff0c\u8fd8\u662f Engine.play \u5931\u8d25\u3002' });
      return;
    }
    if (target && samples.length && !reached) {
      addIssue(summary, 'warning', 'transaction',
        '\u5230\u8fbe/\u8fd4\u56de\u6309\u94ae\u5df2\u5c1d\u8bd5\u8df3\u8f6c\uff0c\u4f46\u91c7\u6837\u672a\u5230\u8fbe\u76ee\u6807 passage\u3002',
        '\u76ee\u6807\uff1a' + target + '\uff1b\u6700\u540e\u5f53\u524d\uff1a' + (current || 'unknown') + (sampleText ? '\uff1b\u91c7\u6837\uff1a' + sampleText : ''),
        { title: '\u68c0\u67e5 navigationAttempt \u4e2d\u7684\u6309\u94ae\u76ee\u6807\u4e0e\u5b9e\u9645 passage \u662f\u5426\u4e00\u81f4',
          detail: '\u5982\u679c\u6309\u94ae\u6587\u5b57\u663e\u793a\u5df2\u5230\u67d0\u5730\uff0c\u4f46 navigationAttempt.samples \u4e2d\u4ecd\u505c\u5728\u65e7 passage\uff0c\u4f18\u5148\u68c0\u67e5 LocationController \u7684\u76ee\u6807 passage \u548c\u539f\u7248\u94fe\u63a5\u6620\u5c04\u3002' });
      return;
    }
    if (attempt.ok === false) {
      addIssue(summary, 'warning', 'transaction',
        '\u5230\u8fbe/\u8fd4\u56de\u6309\u94ae\u7684\u539f\u7248\u5bfc\u822a\u6ca1\u6709\u6210\u529f\u6267\u884c\u3002',
        '\u76ee\u6807\uff1a' + (target || 'unknown') + '\uff1b\u5f53\u524d\uff1a' + (current || 'unknown') + '\uff1b\u6765\u6e90\uff1a' + (source || 'unknown') + '\uff1b\u539f\u56e0\uff1a' + text(attempt.reason || attempt.error || '', 180),
        { title: '\u6839\u636e navigationAttempt \u68c0\u67e5\u5230\u8fbe\u6309\u94ae',
          detail: '\u91cd\u70b9\u770b targetPassage\u3001currentPassage\u3001reason\u3001usedOriginalLink \u548c usedEnginePlay\uff0c\u786e\u8ba4\u662f\u76ee\u6807 passage \u4e0d\u5b89\u5168\u3001\u539f\u7248\u94fe\u63a5\u672a\u89e6\u53d1\uff0c\u8fd8\u662f Engine.play \u5931\u8d25\u3002' });
      return;
    }
    if (target && reached) {
      addIssue(summary, 'ok', 'transaction',
        '\u5230\u8fbe/\u8fd4\u56de\u6309\u94ae\u5df2\u8df3\u5230\u76ee\u6807 passage\uff1a' + target + '\u3002');
    } else {
      addIssue(summary, 'info', 'transaction',
        '\u62a5\u544a\u4e2d\u6709\u5230\u8fbe/\u8fd4\u56de\u6309\u94ae\u8bca\u65ad\uff0c\u4f46\u6ca1\u6709\u8db3\u591f\u91c7\u6837\u7ed3\u679c\u5224\u65ad\u662f\u5426\u5230\u8fbe\u3002',
        '\u6765\u6e90\uff1a' + (source || 'unknown') + '\uff1b\u76ee\u6807\uff1a' + (target || 'unknown'));
    }
  }

  function analyzeMount(report, summary) {
    var mount = mountState(report);
    if (!mount) {
      addIssue(summary, 'info', 'mount', '\u62a5\u544a\u4e2d\u6ca1\u6709\u8bbe\u7f6e\u9875/\u4fa7\u8fb9\u680f\u6302\u8f7d\u8bca\u65ad\u3002');
      return;
    }
    var main = mount.main || {};
    var overlay = mount.overlay || {};
    var diagnostics = mount.diagnostics || {};
    var mainActive = isSettingsMountContext(report, mount);
    var overlayActive = isSettingsOverlayContext(report, mount);
    if (!mainActive && !overlayActive) {
      addIssue(summary, 'info', 'mount',
        '\u5f53\u524d\u62a5\u544a\u4e0d\u662f\u5728\u8bbe\u7f6e\u9875/\u8bbe\u7f6e\u6d6e\u5c42\u4e2d\u5bfc\u51fa\uff0c\u5df2\u8df3\u8fc7\u8bbe\u7f6e\u6302\u8f7d\u5931\u8d25\u5224\u65ad\u3002');
      return;
    }
    if (mainActive && main.hasSettingsOptions === false && main.hasFallbackEntry === false && main.hasSettingsTab === false && main.hasNativeSettingsTab === false) {
      addIssue(summary, 'warning', 'mount',
        '\u8bbe\u7f6e\u9875\u6ca1\u6709\u68c0\u6d4b\u5230\u539f\u7248\u6807\u7b7e\u5bb9\u5668\uff0c\u4e5f\u6ca1\u6709\u515c\u5e95\u5165\u53e3\uff0c\u79fb\u52a8\u7aef\u53ef\u80fd\u770b\u4e0d\u5230\u7ec7\u5883\u7a7a\u95f4\u8bbe\u7f6e\u3002',
        '',
        { title: '\u91cd\u65b0\u6253\u5f00\u539f\u7248\u8bbe\u7f6e\u9875\u5e76\u5bfc\u51fa\u62a5\u544a',
          detail: '\u8fdb\u5165\u4fa7\u8fb9\u680f Options/\u8bbe\u7f6e\u540e\u7b49 2-3 \u79d2\uff0c\u5982\u679c\u4ecd\u6ca1\u6709\u7ec7\u5883\u7a7a\u95f4\u6807\u7b7e\uff0c\u518d\u5bfc\u51fa\u9519\u8bef\u62a5\u544a\u3002' });
    }
    if (overlayActive && overlay.hasCustomOverlay && overlay.hasOverlayContent && overlay.hasOptionsTab === false && overlay.hasNativeOptionsTab === false && overlay.hasFallbackEntry === false) {
      addIssue(summary, 'warning', 'mount',
        '\u4fa7\u8fb9\u680f\u8bbe\u7f6e\u6d6e\u5c42\u5b58\u5728\uff0c\u4f46\u6ca1\u6709\u68c0\u6d4b\u5230\u7ec7\u5883\u7a7a\u95f4\u6807\u7b7e\u6216\u515c\u5e95\u5165\u53e3\u3002',
        '',
        { title: '\u68c0\u67e5\u4fa7\u8fb9\u680f\u8bbe\u7f6e\u6302\u8f7d',
          detail: '\u786e\u8ba4 ModLoader \u6ca1\u6709\u62a5\u9519\uff0c\u5e76\u5728\u6253\u5f00\u4fa7\u8fb9\u680f\u8bbe\u7f6e\u540e\u5bfc\u51fa\u62a5\u544a\u3002' });
    }
    if (mainActive && diagnostics.main && diagnostics.main.status === 'retry') {
      addIssue(summary, 'warning', 'mount', '\u8bbe\u7f6e\u9875\u6302\u8f7d\u4ecd\u5728\u91cd\u8bd5\uff1a' + text(diagnostics.main.reason || ''));
    }
    if (overlayActive && diagnostics.overlay && diagnostics.overlay.status === 'retry') {
      addIssue(summary, 'warning', 'mount', '\u4fa7\u8fb9\u680f\u8bbe\u7f6e\u6302\u8f7d\u4ecd\u5728\u91cd\u8bd5\uff1a' + text(diagnostics.overlay.reason || ''));
    }
  }

  function analyzeMobile(report, summary) {
    var mobile = mobileCompatState(report);
    if (!mobile) return;
    var snapshot = mobile.lastSnapshot || mobile.snapshot || mobile;
    var layout = snapshot.layout || mobile.layout || {};
    var mode = text(snapshot.mode || mobile.mode || '');
    if (layout.hasHorizontalOverflow) {
      addIssue(summary, 'warning', 'mobile',
        '\u68c0\u6d4b\u5230\u9875\u9762\u5b58\u5728\u6a2a\u5411\u6ea2\u51fa\uff0c\u624b\u673a/\u5e73\u677f\u7aef\u53ef\u80fd\u51fa\u73b0\u753b\u9762\u53ef\u62d6\u52a8\u6216\u6309\u94ae\u70b9\u4e0d\u5230\u3002',
        '',
        { title: '\u5207\u6362\u79fb\u52a8\u7aef\u5e03\u5c40\u5e76\u590d\u6d4b',
          detail: '\u5728\u7ec7\u5883\u7a7a\u95f4\u8bbe\u7f6e\u91cc\u628a\u5e03\u5c40\u6a21\u5f0f\u8bbe\u4e3a\u624b\u673a\u6216\u81ea\u52a8\uff0c\u5237\u65b0\u9875\u9762\u540e\u518d\u6d4b\u8bd5\u4fa7\u8fb9\u680f\u548c AI \u9009\u9879\u3002' });
    }
    if (mode === 'mobile' || mode === 'tablet') {
      addIssue(summary, 'info', 'mobile', '\u5f53\u524d\u62a5\u544a\u6765\u81ea\u7d27\u51d1\u5e03\u5c40\uff1a' + mode + '\u3002');
    }
    var sidebar = snapshot.sidebar || mobile.sidebar || {};
    if (sidebar.hasMobileStats === false && (mode === 'mobile' || mode === 'tablet')) {
      addIssue(summary, 'warning', 'mobile',
        '\u7d27\u51d1\u5e03\u5c40\u4e0b\u6ca1\u6709\u68c0\u6d4b\u5230\u624b\u673a\u7cbe\u7b80\u72b6\u6001\u680f\uff0c\u65f6\u95f4/\u72b6\u6001\u663e\u793a\u53ef\u80fd\u4e0d\u4f1a\u5237\u65b0\u3002');
    }
  }

  function analyzeWorldContext(report, summary) {
    var controller = report && report.debugState && report.debugState.controllerSchemas || {};
    if (controller.worldContextModule == null || controller.worldKnowledgeModule == null) {
      addIssue(summary, 'warning', 'worldContext',
        '\u4e16\u754c\u4e0a\u4e0b\u6587/\u77e5\u8bc6\u5e93\u6a21\u5757\u72b6\u6001\u7f3a\u5931\uff0cAI \u53ef\u80fd\u65e0\u6cd5\u8bfb\u53d6\u5730\u56fe\u3001\u65f6\u95f4\u89c4\u5219\u6216 NPC \u8bbe\u5b9a\u8865\u5145\u3002',
        '',
        { title: '\u786e\u8ba4\u53d1\u5e03\u5305\u5b8c\u6574\u52a0\u8f7d',
          detail: '\u91cd\u65b0\u52a0\u8f7d\u6700\u65b0\u7248 zip\uff0c\u786e\u8ba4 boot.json \u91cc\u7684 ai-world-context.js \u548c ai-world-knowledge.js \u90fd\u5df2\u52a0\u8f7d\u3002' });
      return;
    }
    addIssue(summary, 'ok', 'worldContext', '\u4e16\u754c\u4e0a\u4e0b\u6587\u4e0e\u77e5\u8bc6\u5e93\u6a21\u5757\u5df2\u52a0\u8f7d\u3002');
  }

  function analyzePixelPrompt(report, summary) {
    var diag = report && report.pixelPromptDiagnostic;
    if (!diag) return;
    if (diag.available === false) {
      addIssue(summary, 'info', 'pixel',
        '\u751f\u56fe\u63d0\u793a\u8bcd\u8bca\u65ad\u4e0d\u53ef\u7528\uff1a' + text(diag.reason || 'unknown', 180));
      return;
    }
    var risks = inferPixelPromptRisks(report, diag, diag.risks);
    if (!risks.length) {
      addIssue(summary, 'ok', 'pixel',
        '\u751f\u56fe\u63d0\u793a\u8bcd\u8bca\u65ad\u672a\u53d1\u73b0\u660e\u663e\u98ce\u9669\u3002');
      return;
    }
    var highRisk = risks.some(function (risk) {
      var id = text(risk && risk.id || '', 120);
      return /^(?:cjk_in_model_prompt|context_leak|indoor_outdoor_conflict|multi_panel_positive|text_terms_in_positive|stale_visual_action|negative_prompt_truncated|subject_composition_conflict)$/.test(id);
    });
    var onlyBenignSourceLength = risks.every(function (risk) {
      return text(risk && risk.id || '', 120) === 'source_prompt_long';
    });
    if (onlyBenignSourceLength) {
      addIssue(summary, 'ok', 'pixel',
        '\u751f\u56fe\u63d0\u793a\u8bcd\u8bca\u65ad\u672a\u53d1\u73b0\u660e\u663e\u98ce\u9669\uff1b\u6e90\u5267\u60c5\u6587\u672c\u8f83\u957f\uff0c\u4f46\u6700\u7ec8\u63d0\u793a\u8bcd\u5df2\u538b\u7f29\u540e\u518d\u53d1\u9001\u3002');
      return;
    }
    var action = highRisk ? { title: '\u67e5\u770b\u751f\u56fe\u63d0\u793a\u8bcd\u8bca\u65ad',
      detail: '\u91cd\u70b9\u770b pixelPromptDiagnostic.finalPrompt\u3001negativePrompt\u3001locationPrompt\u3001visualAction \u548c risks\uff0c\u786e\u8ba4\u662f\u65e7\u5730\u70b9\u3001\u52a8\u4f5c\u7f3a\u5931\u3001\u4e2d\u6587\u6b8b\u7559\u3001\u591a\u683c\u56fe\u8fd8\u662f\u6587\u5b57\u8bcd\u6c61\u67d3\u3002' } : null;
    addIssue(summary, highRisk ? 'warning' : 'info', 'pixel',
      '\u751f\u56fe\u63d0\u793a\u8bcd\u8bca\u65ad\u53d1\u73b0 ' + risks.length + ' \u4e2a\u98ce\u9669\u70b9\u3002',
      risks.slice(0, 4).map(function (risk) {
        return '[' + text(risk && risk.id || 'unknown', 80) + '] ' + text(risk && risk.message || '', 180);
      }).join('\uff1b'),
      action);
  }

  function build(report) {
    report = report || {};
    var summary = {
      schemaVersion: MODULE_SCHEMA_VERSION,
      generatedAt: new Date().toISOString(),
      severity: 'ok',
      headline: '',
      issues: [],
      actions: [],
      sections: {},
      lines: [],
      actionLines: [],
      _actionKeys: {}
    };
    analyzeVersions(report, summary);
    analyzeApi(report, summary);
    analyzeTransaction(report, summary);
    analyzeConsistency(report, summary);
    analyzeMount(report, summary);
    analyzeMobile(report, summary);
    analyzeWorldContext(report, summary);
    analyzePixelPrompt(report, summary);

    summary.severity = highestSeverity(summary.issues);
    var errorCount = summary.issues.filter(function (i) { return i.severity === 'error'; }).length;
    var warningCount = summary.issues.filter(function (i) { return i.severity === 'warning'; }).length;
    if (summary.severity === 'error') summary.headline = '\u9519\u8bef\u62a5\u544a\u6458\u8981\uff1a\u53d1\u73b0 ' + errorCount + ' \u4e2a\u9ad8\u4f18\u5148\u7ea7\u95ee\u9898\uff0c\u5efa\u8bae\u4f18\u5148\u5904\u7406\u3002';
    else if (summary.severity === 'warning') summary.headline = '\u9519\u8bef\u62a5\u544a\u6458\u8981\uff1a\u6ca1\u6709\u81f4\u547d\u9519\u8bef\uff0c\u4f46\u53d1\u73b0 ' + warningCount + ' \u4e2a\u98ce\u9669\u70b9\u3002';
    else summary.headline = '\u9519\u8bef\u62a5\u544a\u6458\u8981\uff1a\u672a\u53d1\u73b0\u660e\u663e\u914d\u7f6e\u6216\u8fd0\u884c\u65f6\u5f02\u5e38\u3002';
    summary.lines = [summary.headline].concat(summary.issues.slice(0, 12).map(function (issue) {
      var prefix = issue.severity === 'error' ? '[\u9519\u8bef]' : issue.severity === 'warning' ? '[\u6ce8\u610f]' : issue.severity === 'ok' ? '[\u6b63\u5e38]' : '[\u4fe1\u606f]';
      return prefix + ' ' + issue.message;
    }));
    summary.actionLines = summary.actions.map(function (action, index) {
      return (index + 1) + '. ' + action.title + (action.detail ? '\uff1a' + action.detail : '');
    });
    delete summary._actionKeys;
    return summary;
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    build: build
  };

  root.AIStoryGenErrorReportSummaryModule = api;
  root.AIStoryGen.ErrorReportSummaryModule = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
