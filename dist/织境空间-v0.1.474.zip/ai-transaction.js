/* ============================================================
 * AIStoryGen transaction engine
 * Owns the apply/commit/rollback order for AI narrative effects.
 * Concrete game-state edits still live in aiMacro.js and are injected here.
 * ============================================================ */
(function () {
  'use strict';

  var root = window.AIStoryGen = window.AIStoryGen || {};
  var MODULE_SCHEMA_VERSION = 2;
  var PUBLIC_SCHEMA_VERSION = 5;

  function createTransactionEngine(deps) {
    deps = deps || {};
    var publicSchemaVersion = deps.publicSchemaVersion || PUBLIC_SCHEMA_VERSION;

    function loadCfg() {
      try {
        if (typeof deps.loadCfg === 'function') return deps.loadCfg();
      } catch (_) {}
      return {};
    }

    function warn(message, error) {
      try {
        if (typeof deps.warn === 'function') {
          deps.warn(message, error);
          return;
        }
        if (typeof console !== 'undefined' && console.warn) console.warn(message, error);
      } catch (_) {}
    }

    function captureRuntimeSnapshot() {
      return typeof deps.captureRuntimeSnapshot === 'function' ? deps.captureRuntimeSnapshot() : null;
    }

    function restoreRuntimeSnapshot(snapshot, opts) {
      if (typeof deps.restoreRuntimeSnapshot === 'function') deps.restoreRuntimeSnapshot(snapshot, opts || {});
    }

    function captureGameSnapshot() {
      return typeof deps.captureGameSnapshot === 'function' ? deps.captureGameSnapshot() : null;
    }

    function restoreGameSnapshot(snapshot) {
      if (typeof deps.restoreGameSnapshot === 'function') deps.restoreGameSnapshot(snapshot);
    }

    function prepareNarrativeTextEffects(rawText, cfg, opts) {
      if (typeof deps.prepareNarrativeTextEffects !== 'function') {
        throw new Error('AITransaction missing prepareNarrativeTextEffects dependency');
      }
      return deps.prepareNarrativeTextEffects(rawText, cfg, opts || {});
    }

    function getLastChoiceText() {
      try {
        return String((typeof deps.getLastChoiceText === 'function' && deps.getLastChoiceText()) || '');
      } catch (_) {
        return '';
      }
    }

    function parseLocationMarker(text, transactionPlan) {
      try {
        return typeof deps.parseLocationMarker === 'function' ? !!deps.parseLocationMarker(text, transactionPlan || null) : false;
      } catch (err) {
        throw err;
      }
    }

    function inferLocationFromText(choiceText, aiText, opts) {
      try {
        return typeof deps.inferLocationFromText === 'function' ? !!deps.inferLocationFromText(choiceText, aiText, opts || {}) : false;
      } catch (err) {
        throw err;
      }
    }

    function eventSuppressesLocationFallback(text) {
      try {
        return typeof deps.eventSuppressesLocationFallback === 'function' ? !!deps.eventSuppressesLocationFallback(text) : false;
      } catch (_) {
        return false;
      }
    }

    function stripAIMetadataMarkers(text) {
      try {
        if (typeof deps.stripAIMetadataMarkers === 'function') return deps.stripAIMetadataMarkers(text);
      } catch (_) {}
      return String(text || '');
    }

    function recordAiEventMemory(rawText, cleanText, memoryOpts, cfg) {
      if (typeof deps.recordAiEventMemory !== 'function') return null;
      return deps.recordAiEventMemory(rawText, cleanText, memoryOpts, cfg);
    }

    function lastAiEventLocationStatus() {
      try {
        return String((typeof deps.lastAiEventLocationStatus === 'function' && deps.lastAiEventLocationStatus()) || '');
      } catch (_) {
        return '';
      }
    }

    function getLastLocationDecision() {
      try {
        return typeof deps.getLastLocationDecision === 'function' ? (deps.getLastLocationDecision() || null) : null;
      } catch (_) {
        return null;
      }
    }

    function markLocationInTransit(reason) {
      try {
        if (typeof deps.markLocationInTransit === 'function') deps.markLocationInTransit(reason);
      } catch (_) {}
    }

    function applyNarrative(rawText, cfg, opts) {
      opts = opts || {};
      cfg = cfg || loadCfg();
      var beforeSnapshot = captureRuntimeSnapshot();
      try {
        return prepareNarrativeTextEffects(rawText, cfg, opts);
      } catch (e) {
        try { restoreRuntimeSnapshot(beforeSnapshot); } catch (_) {}
        warn('[AIStoryGen] AI transaction rolled back' + (opts.reason ? ' (' + opts.reason + ')' : ''), e);
        throw e;
      }
    }

    function commitNarrative(rawText, cfg, opts) {
      opts = opts || {};
      cfg = cfg || loadCfg();
      var beforeSnapshot = captureRuntimeSnapshot();
      try {
        var result = prepareNarrativeTextEffects(rawText, cfg, opts);
        var metadataText = result.cleanText;
        var locUpdated = false;
        if (opts.applyLocation !== false) {
          var hasLocationDirective = /\[LOC:|\[AI_META\]|\[AI_EVENT\]|\[AI_EVENT:/i.test(metadataText);
          var allowStrongTextLocationFallback = !!opts.allowStrongTextLocationFallback;
          var eventBlocksFallback = eventSuppressesLocationFallback(metadataText);
          var suppressLocationFallback = eventBlocksFallback || (!hasLocationDirective && !allowStrongTextLocationFallback);
          var locationPlan = result.transactionPlan && result.transactionPlan.location ? result.transactionPlan.location : null;
          if (locationPlan) {
            locationPlan.markerAttempted = true;
            locationPlan.hasDirective = !!hasLocationDirective;
            locationPlan.fallbackSuppressed = !!suppressLocationFallback;
            locationPlan.fallbackAttempted = false;
            locationPlan.fallbackApplied = false;
            locationPlan.fallbackStrongOnly = false;
            if (suppressLocationFallback) {
              locationPlan.fallbackBlockReason = eventBlocksFallback
                ? 'event suppresses location fallback'
                : 'no location directive and strong fallback disabled';
            } else {
              locationPlan.fallbackBlockReason = '';
            }
          }
          locUpdated = parseLocationMarker(metadataText, result.transactionPlan || null);
          if (locationPlan) locationPlan.markerApplied = !!locUpdated;
          var lastChoiceText = getLastChoiceText();
          if (!locUpdated && !suppressLocationFallback && lastChoiceText) {
            var beforeLocationDecision = getLastLocationDecision();
            if (locationPlan) {
              locationPlan.fallbackAttempted = true;
              locationPlan.fallbackStrongOnly = !!(allowStrongTextLocationFallback && !hasLocationDirective);
              locationPlan.fallbackChoiceTextLength = String(lastChoiceText || '').length;
              locationPlan.fallbackTextLength = String(metadataText || '').length;
            }
            locUpdated = inferLocationFromText(lastChoiceText, metadataText, {
              strongOnly: !!(allowStrongTextLocationFallback && !hasLocationDirective),
              transactionPlan: result.transactionPlan || null
            });
            var afterLocationDecision = getLastLocationDecision() || beforeLocationDecision || null;
            if (locationPlan) {
              locationPlan.fallbackApplied = !!locUpdated;
              if (afterLocationDecision) locationPlan.fallbackDecision = afterLocationDecision;
              if (!locUpdated && !locationPlan.failureReason) locationPlan.failureReason = 'text fallback found no valid location candidate';
            }
          } else if (locationPlan && !locUpdated && !suppressLocationFallback && !lastChoiceText && !locationPlan.failureReason) {
            locationPlan.failureReason = 'text fallback skipped: no last choice text';
          }
        }
        result.metadataText = metadataText;
        result.cleanText = stripAIMetadataMarkers(metadataText);
        if (opts.recordMemory !== false) {
          var memoryOpts = Object.assign({
            name: '[AI]',
            reason: 'AI剧情事件',
            choiceText: getLastChoiceText() || '',
            source: opts.source || 'advance',
          }, opts.memory || {});
          memoryOpts.transactionPlan = result.transactionPlan || null;
          result.event = recordAiEventMemory(String(rawText || ''), result.cleanText, memoryOpts, cfg);
        }
        result.locUpdated = !!locUpdated;
        result.latestLocationStatus = lastAiEventLocationStatus();
        if (result.transactionPlan) {
          result.transactionPlan.location = result.transactionPlan.location || {};
          result.transactionPlan.location.applied = !!locUpdated;
          result.transactionPlan.location.latestStatus = result.latestLocationStatus || '';
          var latestLocationDecision = getLastLocationDecision();
          if (latestLocationDecision) result.transactionPlan.location.latestDecision = latestLocationDecision;
          result.transactionPlan.memory = result.transactionPlan.memory || {};
          result.transactionPlan.memory.applied = !!(result.event && result.event.memoryApplied);
          if (result.event && result.event.summary) result.transactionPlan.memory.summary = result.event.summary;
        }
        // "current" means the physical location is unchanged. Preserve the
        // existing arrived location; only an explicit inTransit result may
        // clear arrival state while a route is still underway.
        if (opts.applyLocation !== false && !locUpdated && result.latestLocationStatus === 'inTransit') {
          markLocationInTransit('AI_EVENT locationStatus=' + result.latestLocationStatus);
        }
        return result;
      } catch (e) {
        try { restoreRuntimeSnapshot(beforeSnapshot, { syncMemory: true }); } catch (_) {}
        warn('[AIStoryGen] AI commit rolled back' + (opts.reason ? ' (' + opts.reason + ')' : ''), e);
        throw e;
      }
    }

    return {
      schemaVersion: publicSchemaVersion,
      moduleSchemaVersion: MODULE_SCHEMA_VERSION,
      applyNarrative: applyNarrative,
      commitNarrative: commitNarrative,
      captureSnapshot: captureGameSnapshot,
      restoreSnapshot: restoreGameSnapshot,
      captureRuntimeSnapshot: captureRuntimeSnapshot,
      restoreRuntimeSnapshot: restoreRuntimeSnapshot,
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    create: createTransactionEngine,
  };

  root.TransactionModule = api;
  window.AIStoryGenTransactionModule = api;
})();
