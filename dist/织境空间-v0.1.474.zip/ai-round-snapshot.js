/* ============================================================
 * AIStoryGen round snapshot policy
 * Keeps rollback entries flat, bounded, and safe to persist.
 * ============================================================ */
(function () {
  'use strict';

  var root = window.AIStoryGen = window.AIStoryGen || {};
  var SCHEMA_VERSION = 2;
  var DEFAULT_MAX_ENTRIES = 20;
  var DEFAULT_MAX_CHARS = 2000000;
  var FORBIDDEN_GAME_KEYS = {
    aiStoryGenState: true,
    aiStoryGenNavState: true,
    roundHistory: true,
    forwardStack: true
  };

  function clone(value) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (_) {
      return value;
    }
  }

  function positiveInt(value, fallback) {
    value = Math.floor(Number(value));
    return Number.isFinite(value) && value > 0 ? value : fallback;
  }

  function flattenLegacyGameSnapshot(snapshot) {
    snapshot = snapshot && typeof snapshot === 'object' ? snapshot : {};
    var state = snapshot.aiStoryGenState && typeof snapshot.aiStoryGenState === 'object'
      ? snapshot.aiStoryGenState
      : {};
    var out = {};

    Object.keys(snapshot).forEach(function (key) {
      if (FORBIDDEN_GAME_KEYS[key]) return;
      out[key] = snapshot[key];
    });

    if (out.aiStoryGenMemory == null && state.memory != null) out.aiStoryGenMemory = state.memory;
    if (out.aiStoryGenMemoryId == null && state.memoryId != null) out.aiStoryGenMemoryId = state.memoryId;
    if (out.aiStoryGenItems == null && state.items != null) out.aiStoryGenItems = state.items;
    if (out.aiStoryGenEventLog == null && state.eventLog != null) out.aiStoryGenEventLog = state.eventLog;
    return out;
  }

  function sanitizeGameSnapshot(snapshot, allowedKeys) {
    var flat = flattenLegacyGameSnapshot(snapshot);
    var keys = Array.isArray(allowedKeys) && allowedKeys.length
      ? allowedKeys
      : Object.keys(flat);
    var out = {};
    keys.forEach(function (key) {
      key = String(key || '');
      if (!key || FORBIDDEN_GAME_KEYS[key] || flat[key] === undefined) return;
      out[key] = clone(flat[key]);
    });
    if (flat.__aiNpcRelations !== undefined) {
      out.__aiNpcRelations = clone(flat.__aiNpcRelations);
    }
    return out;
  }

  function cloneEntry(entry, opts) {
    opts = opts || {};
    if (!entry || !entry.aiHTML) return null;
    return {
      snapshotSchemaVersion: SCHEMA_VERSION,
      aiHTML: String(entry.aiHTML || ''),
      roundCount: Number(entry.roundCount || 0),
      mode: entry.mode === 'normal' ? 'normal' : 'replace',
      originPassage: String(entry.originPassage || ''),
      targetLabel: String(entry.targetLabel || ''),
      targetPassage: String(entry.targetPassage || ''),
      originalLinkId: String(entry.originalLinkId || ''),
      originalEventMode: !!entry.originalEventMode,
      currentLocationLabel: String(entry.currentLocationLabel || ''),
      currentLocationPassage: String(entry.currentLocationPassage || ''),
      locationArrived: !!entry.locationArrived,
      choices: Array.isArray(entry.choices) ? clone(entry.choices) : [],
      gameSnapshot: sanitizeGameSnapshot(entry.gameSnapshot || null, opts.allowedGameKeys),
      pickupCandidates: clone(entry.pickupCandidates || {})
    };
  }

  function estimateChars(value) {
    try {
      return JSON.stringify(value == null ? null : value).length;
    } catch (_) {
      return Number.MAX_SAFE_INTEGER;
    }
  }

  function cloneStack(stack, opts) {
    opts = opts || {};
    if (!Array.isArray(stack) || !stack.length) return [];
    var maxEntries = positiveInt(opts.maxEntries, DEFAULT_MAX_ENTRIES);
    var maxChars = positiveInt(opts.maxChars, DEFAULT_MAX_CHARS);
    var out = [];
    var usedChars = 2;

    for (var i = stack.length - 1; i >= 0 && out.length < maxEntries; i--) {
      var entry = cloneEntry(stack[i], opts);
      if (!entry) continue;
      var entryChars = estimateChars(entry) + (out.length ? 1 : 0);
      if (usedChars + entryChars > maxChars) continue;
      out.unshift(entry);
      usedChars += entryChars;
    }
    return out;
  }

  function auditStack(stack, opts) {
    opts = opts || {};
    var maxChars = positiveInt(opts.maxChars, DEFAULT_MAX_CHARS);
    var recursiveFieldCount = 0;
    var visitedObjects = 0;
    var maxDepth = 0;
    var queue = [{ value: stack, depth: 0 }];
    var seen = typeof WeakSet === 'function' ? new WeakSet() : null;

    while (queue.length && visitedObjects < 20000) {
      var next = queue.shift();
      var value = next.value;
      if (!value || typeof value !== 'object') continue;
      if (seen) {
        if (seen.has(value)) continue;
        seen.add(value);
      }
      visitedObjects += 1;
      maxDepth = Math.max(maxDepth, next.depth);
      Object.keys(value).forEach(function (key) {
        if (FORBIDDEN_GAME_KEYS[key]) recursiveFieldCount += 1;
        if (next.depth < 40 && value[key] && typeof value[key] === 'object') {
          queue.push({ value: value[key], depth: next.depth + 1 });
        }
      });
    }

    var chars = estimateChars(stack || []);
    return {
      schemaVersion: SCHEMA_VERSION,
      entries: Array.isArray(stack) ? stack.length : 0,
      chars: chars,
      maxChars: maxChars,
      overBudget: chars > maxChars,
      recursiveFieldCount: recursiveFieldCount,
      maxDepth: maxDepth,
      visitedObjects: visitedObjects
    };
  }

  root.RoundSnapshotModule = {
    schemaVersion: SCHEMA_VERSION,
    defaultMaxEntries: DEFAULT_MAX_ENTRIES,
    defaultMaxChars: DEFAULT_MAX_CHARS,
    sanitizeGameSnapshot: sanitizeGameSnapshot,
    cloneEntry: cloneEntry,
    cloneStack: cloneStack,
    estimateChars: estimateChars,
    auditStack: auditStack
  };
  window.AIStoryGenRoundSnapshotModule = root.RoundSnapshotModule;
})();
