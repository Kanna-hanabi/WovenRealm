/* ============================================================
 * AIStoryGen mobile/tablet compatibility controller
 * Centralizes layout mode detection and layout marker diagnostics.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};

  var MODULE_SCHEMA_VERSION = 1;
  var LAYOUT_CLASSES = ['ai-layout-auto', 'ai-layout-mobile', 'ai-layout-tablet', 'ai-layout-desktop', 'ai-layout-forced'];

  function normalizeSetting(setting) {
    setting = String(setting || 'auto').toLowerCase();
    return /^(auto|mobile|tablet|desktop)$/.test(setting) ? setting : 'auto';
  }

  function toArray(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    if (typeof value.length === 'number' && typeof value !== 'string' && !value.nodeType) {
      try { return Array.prototype.slice.call(value); } catch (_) {}
    }
    return [value];
  }

  function getViewportSnapshot(deps) {
    deps = deps || {};
    var doc = root.document;
    var de = doc && doc.documentElement;
    var width = 0;
    var height = 0;
    var coarse = false;
    try { width = Number(typeof deps.getWidth === 'function' ? deps.getWidth() : (root.innerWidth || (de && de.clientWidth) || 0)) || 0; } catch (_) {}
    try { height = Number(typeof deps.getHeight === 'function' ? deps.getHeight() : (root.innerHeight || (de && de.clientHeight) || 0)) || 0; } catch (_) {}
    try {
      coarse = typeof deps.isCoarsePointer === 'function'
        ? !!deps.isCoarsePointer()
        : !!(root.matchMedia && root.matchMedia('(pointer: coarse)').matches);
    } catch (_) {}
    return {
      width: width,
      height: height,
      coarsePointer: coarse,
      aspect: width && height ? Math.round((width / height) * 100) / 100 : 0
    };
  }

  function resolveMode(setting, deps) {
    setting = normalizeSetting(setting);
    if (setting !== 'auto') return setting;
    var vp = getViewportSnapshot(deps);
    if (vp.width && vp.width <= 760) return 'mobile';
    if (vp.coarsePointer && vp.width && vp.width <= 1100) return 'tablet';
    return 'desktop';
  }

  function clearMarkers(elements) {
    toArray(elements).forEach(function (el) {
      if (!el) return;
      try {
        if (el.classList) {
          LAYOUT_CLASSES.forEach(function (cls) { el.classList.remove(cls); });
        } else if (typeof el.className === 'string') {
          var parts = el.className.split(/\s+/).filter(function (cls) {
            return LAYOUT_CLASSES.indexOf(cls) < 0;
          });
          el.className = parts.join(' ');
        }
      } catch (_) {}
      try {
        if (el.removeAttribute) {
          el.removeAttribute('data-ai-layout-mode');
          el.removeAttribute('data-ai-layout-setting');
        }
      } catch (_) {}
    });
  }

  function addClass(el, cls) {
    if (!el || !cls) return;
    try {
      if (el.classList) el.classList.add(cls);
      else if (typeof el.className === 'string' && el.className.split(/\s+/).indexOf(cls) < 0) el.className += (el.className ? ' ' : '') + cls;
    } catch (_) {}
  }

  function applyMarkers(elements, info) {
    var classes = ['ai-layout-' + info.mode];
    if (info.setting !== 'auto') classes.push('ai-layout-forced');
    toArray(elements).forEach(function (el) {
      if (!el) return;
      clearMarkers([el]);
      classes.forEach(function (cls) { addClass(el, cls); });
      try {
        if (el.setAttribute) {
          el.setAttribute('data-ai-layout-mode', info.mode);
          el.setAttribute('data-ai-layout-setting', info.setting);
        }
      } catch (_) {}
    });
  }

  function defaultRootElements() {
    var doc = root.document;
    return doc ? [doc.documentElement, doc.body].filter(Boolean) : [];
  }

  function textOf(el, maxLen) {
    try {
      return String(el && el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, maxLen || 300);
    } catch (_) {
      return '';
    }
  }

  function elementMetrics(el) {
    if (!el) return null;
    var rect = null;
    try { rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null; } catch (_) {}
    return {
      exists: true,
      clientWidth: Number(el.clientWidth || 0) || 0,
      scrollWidth: Number(el.scrollWidth || 0) || 0,
      clientHeight: Number(el.clientHeight || 0) || 0,
      scrollHeight: Number(el.scrollHeight || 0) || 0,
      rectWidth: rect ? Math.round(Number(rect.width || 0)) : 0,
      rectLeft: rect ? Math.round(Number(rect.left || 0)) : 0,
      overflowsX: !!(el.scrollWidth && el.clientWidth && el.scrollWidth > el.clientWidth + 2)
    };
  }

  function getDocumentLayoutSnapshot(doc) {
    doc = doc || root.document;
    if (!doc) return {};
    var de = doc.documentElement;
    var body = doc.body;
    var story = doc.getElementById && doc.getElementById('story');
    var passages = doc.getElementById && doc.getElementById('passages');
    return {
      html: elementMetrics(de),
      body: elementMetrics(body),
      story: elementMetrics(story),
      passages: elementMetrics(passages),
      hasHorizontalOverflow: !!(
        (de && de.scrollWidth && de.clientWidth && de.scrollWidth > de.clientWidth + 2) ||
        (body && body.scrollWidth && body.clientWidth && body.scrollWidth > body.clientWidth + 2) ||
        (story && story.scrollWidth && story.clientWidth && story.scrollWidth > story.clientWidth + 2) ||
        (passages && passages.scrollWidth && passages.clientWidth && passages.scrollWidth > passages.clientWidth + 2)
      )
    };
  }

  function getOverlaySnapshot(doc) {
    doc = doc || root.document;
    if (!doc || !doc.getElementById) return {};
    var overlay = doc.getElementById('customOverlay');
    var tabs = doc.getElementById('overlayTabs');
    var content = doc.getElementById('customOverlayContent');
    return {
      hasCustomOverlay: !!overlay,
      hidden: overlay && overlay.classList ? overlay.classList.contains('hidden') : null,
      dataOverlay: overlay && overlay.getAttribute ? String(overlay.getAttribute('data-overlay') || '') : '',
      hasOverlayTabs: !!tabs,
      hasOverlayContent: !!content,
      tabText: textOf(tabs, 240),
      contentMetrics: elementMetrics(content)
    };
  }

  function getSidebarSnapshot(doc) {
    doc = doc || root.document;
    if (!doc || !doc.getElementById) return {};
    var stats = doc.getElementById('stats');
    var mobileStats = doc.getElementById('mobileStats');
    var uiBar = doc.getElementById('ui-bar');
    return {
      hasDesktopStats: !!stats,
      hasMobileStats: !!mobileStats,
      hasUiBar: !!uiBar,
      desktopText: textOf(stats, 500),
      mobileText: textOf(mobileStats, 500),
      uiBarMetrics: elementMetrics(uiBar)
    };
  }

  function getSidebarTextSelectors() {
    return '#stats, #ui-bar, #ui-bar-body, #storyCaption, #storyCaptionContent, #sidebardescription';
  }

  function getMobileStatsRefreshMacro() {
    return (
      '<<replace #mobileStats>>' +
      '<<if $options.sidebarStats is "all">><div class="weatherIcon"><<weatherIcon>></div><</if>>' +
      '<<if $options.sidebarTime is "top">><<mobileStatsTime>><</if>>' +
      '<<if $options.sidebarStats isnot "disabled">><<mobileStats>><</if>>' +
      '<<if $options.sidebarTime is "bottom">><<mobileStatsTime>><</if>>' +
      '<</replace>>'
    );
  }

  function getSidebarRefreshPlan(doc) {
    var snap = getSidebarSnapshot(doc || root.document);
    return {
      hasDesktopStats: !!snap.hasDesktopStats,
      hasMobileStats: !!snap.hasMobileStats,
      canRefresh: !!(snap.hasDesktopStats || snap.hasMobileStats),
      desktopMacro: '<<replace #stats>><<statsCaption>><</replace>>',
      mobileMacro: getMobileStatsRefreshMacro(),
      textSelectors: getSidebarTextSelectors(),
      snapshot: snap
    };
  }

  function safeFixedWidth(rect, viewportWidth, opts) {
    opts = opts || {};
    rect = rect || {};
    viewportWidth = Number(viewportWidth || 0) || 0;
    var margin = Math.max(0, Number(opts.margin == null ? 8 : opts.margin) || 0);
    var minWidth = Math.max(0, Number(opts.minWidth == null ? 280 : opts.minWidth) || 0);
    var left = Math.max(margin, Math.round(Number(rect.left || 0) || 0));
    var rectWidth = Math.max(0, Math.round(Number(rect.width || rect.clientWidth || 0) || 0));
    var available = viewportWidth ? Math.max(0, Math.round(viewportWidth - left - margin)) : rectWidth;
    var width = Math.max(minWidth, Math.min(rectWidth || available || minWidth, available || rectWidth || minWidth));
    return { left: left, width: width, available: available, minWidth: minWidth, margin: margin };
  }

  function getConfigLayoutStyleText() {
    return [
      '.ai-merged-settings{box-sizing:border-box;max-width:100%;}',
      '.ai-merged-subtabs{display:flex;flex-wrap:wrap;gap:.35em;margin:0 0 .9em;padding:.35em;border:1px solid rgba(180,160,120,.28);border-radius:5px;background:rgba(18,18,18,.26);}',
      '.ai-merged-subtabs .apg-subtab{margin:0;border:1px solid rgba(180,160,120,.22);border-radius:4px;padding:.34em .85em;background:rgba(255,255,255,.025);color:#d8c58a;}',
      '.ai-merged-subtabs .apg-subtab:hover,.ai-merged-subtabs .apg-subtab.active{border-color:rgba(230,200,120,.52);background:rgba(180,150,90,.13);color:#ffe39a;}',
      '.ai-merged-content{min-width:0;}',
      '.ai-cfg-form{display:grid;grid-template-columns:minmax(11em,15em) minmax(0,1fr);gap:.48em .9em;margin-bottom:.9em;}',
      '.ai-cfg-row{display:contents;}',
      '.ai-cfg-row>label{align-self:center;font-weight:bold;color:#e4d2a2;}',
      '.ai-cfg-section{grid-column:1/-1;margin:.9em 0 .2em;padding:.35em .55em;border:1px solid rgba(180,160,120,.28);border-radius:4px;background:rgba(180,150,90,.08);color:#f0cc7a;font-weight:bold;}',
      '.ai-cfg-row>input,.ai-cfg-row>select,.ai-cfg-row>textarea{width:100%;box-sizing:border-box;padding:.3em .4em;font-family:inherit;font-size:.95em;}',
      '.ai-cfg-range{display:grid;grid-template-columns:1fr 4.2em;gap:.6em;align-items:center;}',
      '.ai-cfg-range input[type=range]{width:100%;}',
      '.ai-cfg-range-value{text-align:right;font-variant-numeric:tabular-nums;color:#d0b070;}',
      '.ai-cfg-details{grid-column:1/-1;margin:.25em 0 .45em;padding:.6em .7em .7em;border:1px solid rgba(180,160,120,.28);border-radius:5px;background:rgba(255,255,255,.025);}',
      '.ai-cfg-details>summary{cursor:pointer;color:#f0cc7a;font-weight:bold;margin:-.15em 0 .45em;}',
      '.ai-cfg-details-help{margin:.1em 0 .65em;color:#d7c497;line-height:1.5;}',
      '.ai-stat-limit-grid,.ai-relation-limit-grid{display:grid;grid-template-columns:repeat(2,minmax(15em,1fr));gap:.55em .8em;}',
      '.ai-stat-limit-item,.ai-relation-limit-item{display:grid;grid-template-columns:4.5em minmax(8em,1fr) 4.8em;gap:.55em;align-items:center;min-width:0;}',
      '.ai-stat-limit-name,.ai-relation-limit-name{color:#f1e7cd;font-weight:bold;}',
      '.ai-stat-limit-item input[type=range],.ai-relation-limit-item input[type=range]{width:100%;min-width:0;}',
      '.ai-stat-limit-number,.ai-relation-limit-number{width:100%;box-sizing:border-box;text-align:center;font-variant-numeric:tabular-nums;}',
      '.ai-cfg-actions,.ai-cfg-debug-actions{display:flex;flex-wrap:wrap;align-items:center;gap:.45em;margin:.65em 0;}',
      '.ai-cfg-actions .ai-cfg-btn,.ai-cfg-debug-actions .ai-cfg-btn{margin-right:0;}',
      '.ai-cfg-save-strong{font-weight:700;border-color:rgba(245,205,95,.72)!important;background:linear-gradient(180deg,rgba(86,66,25,.98),rgba(43,35,18,.98))!important;color:#fff0b2!important;box-shadow:0 0 0 1px rgba(255,220,120,.18),0 2px 8px rgba(0,0,0,.32);padding:.42em 1.1em;}',
      '.ai-cfg-msg{margin:.55em 0 .75em;padding:.45em .65em;min-height:1.4em;border-radius:3px;background:rgba(255,255,255,.035);}',
      '.ai-barefoot-buff-status{margin:.4em 0 .75em;padding:.65em .75em;border:1px solid rgba(180,160,120,.32);border-radius:4px;background:rgba(255,255,255,.035);color:#d8ccb0;line-height:1.5;}',
      '.ai-barefoot-buff-status.active{border-color:rgba(100,185,120,.48);background:rgba(70,150,90,.11);color:#bde3c4;}',
      '.ai-barefoot-buff-status.error{border-color:rgba(210,85,85,.58);background:rgba(180,55,55,.12);color:#f1aaaa;}',
      '.ai-cfg-diagnostics{display:grid;grid-template-columns:minmax(0,1fr);gap:.8em;margin-top:.75em;}',
      '.ai-cfg-debug-block{border:1px solid rgba(180,160,120,.35);border-radius:5px;background:rgba(18,18,18,.32);padding:.75em .85em;}',
      '.ai-provider-health-row{display:grid;grid-template-columns:8.5em minmax(0,1fr);gap:.55em;padding:.25em 0;border-top:1px solid rgba(255,255,255,.06);}',
      '.ai-provider-health-row:first-of-type{border-top:none;}',
      '.ai-provider-health-label{color:#d7c497;font-weight:bold;}',
      '.ai-provider-health-value{min-width:0;overflow-wrap:anywhere;}',
      '@media(max-width:900px){.ai-stat-limit-grid,.ai-relation-limit-grid{grid-template-columns:minmax(0,1fr);}.ai-provider-health-row{grid-template-columns:minmax(0,1fr);gap:.15em;}}',
      'html.ai-layout-mobile .ai-cfg-form,body.ai-layout-mobile .ai-cfg-form,html.ai-layout-tablet .ai-cfg-form,body.ai-layout-tablet .ai-cfg-form{grid-template-columns:minmax(0,1fr);}',
      'html.ai-layout-mobile .ai-cfg-row,body.ai-layout-mobile .ai-cfg-row,html.ai-layout-tablet .ai-cfg-row,body.ai-layout-tablet .ai-cfg-row{display:grid;grid-template-columns:minmax(0,1fr);gap:.25em;}',
      'html.ai-layout-mobile .ai-stat-limit-item,body.ai-layout-mobile .ai-stat-limit-item,html.ai-layout-tablet .ai-stat-limit-item,body.ai-layout-tablet .ai-stat-limit-item,html.ai-layout-mobile .ai-relation-limit-item,body.ai-layout-mobile .ai-relation-limit-item,html.ai-layout-tablet .ai-relation-limit-item,body.ai-layout-tablet .ai-relation-limit-item{grid-template-columns:4.2em minmax(0,1fr) 4.2em;}'
    ].join('\n');
  }

  function bindTapHelp(deps) {
    deps = deps || {};
    var $ = deps.$ || root.jQuery;
    var doc = deps.document || root.document;
    var selector = String(deps.selector || '.ai-cfg-help');
    var namespace = String(deps.namespace || 'aiStoryGenTapHelp').replace(/[^\w-]/g, '') || 'aiStoryGenTapHelp';
    if (typeof $ !== 'function' || !doc || !selector) return false;
    var lastTouchAt = 0;
    var show = typeof deps.show === 'function' ? deps.show : function (text) {
      try { if (root.alert) root.alert(text); } catch (_) {}
    };
    var getText = typeof deps.getText === 'function'
      ? deps.getText
      : function (node) {
        try {
          var wrapped = $(node);
          return wrapped.attr('data-help') || wrapped.attr('title') || '';
        } catch (_) {
          try { return node && (node.getAttribute('data-help') || node.getAttribute('title')) || ''; } catch (__) {}
        }
        return '';
      };
    function openHelp(node, ev) {
      try {
        if (ev && typeof ev.preventDefault === 'function') ev.preventDefault();
        if (ev && typeof ev.stopPropagation === 'function') ev.stopPropagation();
      } catch (_) {}
      var text = '';
      try { text = String(getText(node) || '').trim(); } catch (_) {}
      if (text) show(text, node, ev);
    }
    var events = 'touchend.' + namespace + ' click.' + namespace + ' keydown.' + namespace;
    var $doc = $(doc);
    $doc.off(events, selector)
      .on('touchend.' + namespace, selector, function (ev) {
        lastTouchAt = Date.now();
        openHelp(this, ev);
      })
      .on('click.' + namespace, selector, function (ev) {
        if (Date.now() - lastTouchAt < 500) return;
        openHelp(this, ev);
      })
      .on('keydown.' + namespace, selector, function (ev) {
        if (!ev || (ev.key !== 'Enter' && ev.key !== ' ')) return;
        openHelp(this, ev);
      });
    return true;
  }

  function bindInteractionShield(target, opts) {
    opts = opts || {};
    var $ = opts.$ || root.jQuery;
    var events = String(opts.events || 'click mousedown pointerdown touchstart touchend');
    var namespace = String(opts.namespace || 'aiStoryGenInteractionShield').replace(/[^\w-]/g, '') || 'aiStoryGenInteractionShield';
    var preventDefault = opts.preventDefault === true;
    var stopImmediate = opts.stopImmediate === true;
    function stop(ev) {
      try {
        if (preventDefault && ev && typeof ev.preventDefault === 'function') ev.preventDefault();
        if (ev && typeof ev.stopPropagation === 'function') ev.stopPropagation();
        if (stopImmediate && ev && typeof ev.stopImmediatePropagation === 'function') ev.stopImmediatePropagation();
      } catch (_) {}
    }
    try {
      if ($ && typeof $ === 'function') {
        var $target = target && target.jquery ? target : $(target);
        if (!$target || !$target.length) return false;
        var namespaced = events.split(/\s+/).filter(Boolean).map(function (eventName) {
          return eventName.indexOf('.') >= 0 ? eventName : eventName + '.' + namespace;
        }).join(' ');
        $target.off(namespaced).on(namespaced, stop);
        return true;
      }
    } catch (_) {}
    try {
      var nodes = toArray(target);
      if (!nodes.length) return false;
      events.split(/\s+/).filter(Boolean).forEach(function (eventName) {
        eventName = eventName.split('.')[0];
        nodes.forEach(function (node) {
          if (node && typeof node.addEventListener === 'function') node.addEventListener(eventName, stop, true);
        });
      });
      return true;
    } catch (_) {}
    return false;
  }

  function mountFloatingPanel(target, opts) {
    opts = opts || {};
    var $ = opts.$ || root.jQuery;
    var namespace = String(opts.namespace || opts.reason || 'aiFloatingPanel').replace(/[^\w-]/g, '') || 'aiFloatingPanel';
    var mode = String(opts.mode || 'append').toLowerCase();
    var className = String(opts.className || 'ai-mobile-floating-panel').trim();
    try {
      if (typeof $ !== 'function') return false;
      var $target = target && target.jquery ? target : $(target);
      if (!$target || !$target.length) return false;
      var $root = null;
      if (typeof opts.getRoot === 'function') $root = opts.getRoot();
      if (!$root || !$root.length) $root = $('body');
      if (!$root || !$root.length) return false;
      if (className && typeof $target.addClass === 'function') $target.addClass(className);
      if (typeof $target.attr === 'function') {
        $target.attr('data-ai-floating-panel', '1');
        $target.attr('data-ai-floating-reason', namespace);
      }
      if (mode === 'prepend' && typeof $root.prepend === 'function') $root.prepend($target);
      else $root.append($target);
      if (opts.shield !== false) {
        bindInteractionShield($target, {
          $: $,
          namespace: namespace,
          preventDefault: opts.preventDefault === true,
          stopImmediate: opts.stopImmediate === true
        });
      }
      if (typeof opts.onMounted === 'function') opts.onMounted($target);
      return true;
    } catch (_) {
      return false;
    }
  }

  function create(deps) {
    deps = deps || {};
    var lastInfo = null;

    function getSetting() {
      try {
        if (typeof deps.getSetting === 'function') return normalizeSetting(deps.getSetting());
      } catch (_) {}
      return 'auto';
    }

    function getRootElements() {
      try {
        if (typeof deps.getRootElements === 'function') return deps.getRootElements() || [];
      } catch (_) {}
      return defaultRootElements();
    }

    function apply(reason, settingOverride) {
      var setting = normalizeSetting(settingOverride == null ? getSetting() : settingOverride);
      var viewport = getViewportSnapshot(deps);
      var mode = resolveMode(setting, deps);
      var info = {
        mode: mode,
        setting: setting,
        reason: String(reason || ''),
        viewport: viewport,
        forced: setting !== 'auto'
      };
      applyMarkers(getRootElements(), info);
      try {
        root.AIStoryGen.currentLayoutMode = mode;
        root.AIStoryGen.currentLayoutSetting = setting;
        root.AIStoryGen.lastLayoutInfo = info;
      } catch (_) {}
      try {
        if (typeof deps.onApply === 'function') deps.onApply(info);
      } catch (_) {}
      lastInfo = info;
      return info;
    }

    function getCurrentMode() {
      try {
        return String(
          (lastInfo && lastInfo.mode) ||
          (root.AIStoryGen && root.AIStoryGen.currentLayoutMode) ||
          (root.document && root.document.documentElement && root.document.documentElement.getAttribute('data-ai-layout-mode')) ||
          (root.document && root.document.body && root.document.body.getAttribute('data-ai-layout-mode')) ||
          ''
        ).toLowerCase();
      } catch (_) {
        return '';
      }
    }

    function isCompact() {
      var mode = getCurrentMode();
      return mode === 'mobile' || mode === 'tablet';
    }

    function getDebugState() {
      return {
        schemaVersion: MODULE_SCHEMA_VERSION,
        lastInfo: lastInfo,
        currentMode: getCurrentMode(),
        currentSetting: (root.AIStoryGen && root.AIStoryGen.currentLayoutSetting) || '',
        viewport: getViewportSnapshot(deps),
        layout: getDocumentLayoutSnapshot(root.document),
        overlay: getOverlaySnapshot(root.document),
        sidebar: getSidebarSnapshot(root.document)
      };
    }

    return {
      schemaVersion: MODULE_SCHEMA_VERSION,
      normalizeSetting: normalizeSetting,
      resolveMode: function (setting) { return resolveMode(setting, deps); },
      apply: apply,
      clearMarkers: clearMarkers,
      applyMarkers: applyMarkers,
      safeFixedWidth: function (rect, viewportWidth, opts) { return safeFixedWidth(rect, viewportWidth, opts); },
      getDocumentLayoutSnapshot: function () { return getDocumentLayoutSnapshot(root.document); },
      getOverlaySnapshot: function () { return getOverlaySnapshot(root.document); },
      getSidebarSnapshot: function () { return getSidebarSnapshot(root.document); },
      getSidebarRefreshPlan: function () { return getSidebarRefreshPlan(root.document); },
      getConfigLayoutStyleText: getConfigLayoutStyleText,
      bindTapHelp: bindTapHelp,
      bindInteractionShield: function (target, opts) { opts = opts || {}; if (!opts.$ && deps.$) opts.$ = deps.$; return bindInteractionShield(target, opts); },
      mountFloatingPanel: function (target, opts) { opts = opts || {}; if (!opts.$ && deps.$) opts.$ = deps.$; return mountFloatingPanel(target, opts); },
      isCompact: isCompact,
      getDebugState: getDebugState
    };
  }

  var api = {
    schemaVersion: MODULE_SCHEMA_VERSION,
    normalizeSetting: normalizeSetting,
    resolveMode: resolveMode,
    getViewportSnapshot: getViewportSnapshot,
    getDocumentLayoutSnapshot: getDocumentLayoutSnapshot,
    getOverlaySnapshot: getOverlaySnapshot,
    getSidebarSnapshot: getSidebarSnapshot,
    getSidebarTextSelectors: getSidebarTextSelectors,
    getMobileStatsRefreshMacro: getMobileStatsRefreshMacro,
    getSidebarRefreshPlan: getSidebarRefreshPlan,
    getConfigLayoutStyleText: getConfigLayoutStyleText,
    safeFixedWidth: safeFixedWidth,
    bindTapHelp: bindTapHelp,
    bindInteractionShield: bindInteractionShield,
    mountFloatingPanel: mountFloatingPanel,
    create: create
  };

  root.AIStoryGen.MobileCompatModule = api;
  root.AIStoryGenMobileCompatModule = api;
})(typeof window !== 'undefined' ? window : globalThis);
