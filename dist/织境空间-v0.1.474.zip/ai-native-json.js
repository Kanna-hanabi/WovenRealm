/* ============================================================
 * AIStoryGen native JSON capture
 * Loaded as early as possible so API calls can avoid SugarCube's
 * JSON monkey-patching when building request bodies.
 * ============================================================ */
(function (root) {
  'use strict';

  root.AIStoryGen = root.AIStoryGen || {};
  if (!root.AIStoryGen.NativeJSON) {
    root.AIStoryGen.NativeJSON = {
      stringify: JSON.stringify.bind(JSON),
      parse: JSON.parse.bind(JSON),
      capturedAt: 'inject_early'
    };
  }
  root.AIStoryGenNativeJSON = root.AIStoryGen.NativeJSON;
})(typeof window !== 'undefined' ? window : globalThis);
